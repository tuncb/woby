import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
output = args.output.resolve()
if output.exists():
    raise ValueError('Use a new output directory.')
output.mkdir(parents=True)
(output/'runs').mkdir()
exe = root/'build/vs2026-vcpkg/bin/Release/woby_obj_prototype_benchmark.exe'
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def warm(path):
    with path.open('rb') as stream:
        while stream.read(8*1024*1024):
            pass
models = [Path('D:/temp/obj_tests')/name for name in (
    '20190810_BearTrap_Ground_Model.obj','bennu_OLA_v21_PTM_very-high.obj',
    'powerplant.obj','san-miguel.obj','uploads_files_2720101_BusGameMap.obj')]
sources = ['src/obj_mesh.cpp','src/obj_mesh.h','src/obj_corner_mapping.h',
           'src/model_mesh.cpp','src/coordinate_simd.h','src/coordinate_simd_avx512.cpp',
           'experiments/rapidobj_prototype.cpp','CMakeLists.txt','cmake/WobyCpu.cmake']
result = {'status':'running','method':'Warm OS file cache; fresh sequential Release processes; three rotating rounds; parser workers 16; deferred preparation; same parser and SIMD code in both modes',
          'exe_sha256':sha(exe),'sources_sha256':{},'models':[]}
for relative in sources:
    path = root/relative
    target = output/'sources'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,target)
    result['sources_sha256'][relative] = sha(path)
shutil.copyfile(Path(__file__),output/'runner.py')
def save():
    (output/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
ordinal = 0
for model in models:
    print('Model:',model.name,flush=True)
    entry = {'path':str(model),'source_bytes':model.stat().st_size,'sha256':sha(model),'records':[]}
    result['models'].append(entry)
    expected = None
    for round_index in range(3):
        modes = ('fused','prototype') if round_index%2 == 0 else ('prototype','fused')
        for mode in modes:
            warm(model)
            command = [str(exe),mode,str(model),'16','deferred']
            run = subprocess.run(command,capture_output=True,timeout=600)
            ordinal += 1
            stem = f'{ordinal:03d}-{model.stem[:20]}-{mode}'
            (output/'runs'/f'{stem}.stdout.json').write_bytes(run.stdout)
            (output/'runs'/f'{stem}.stderr.txt').write_bytes(run.stderr)
            if run.returncode:
                raise RuntimeError(run.stderr.decode(errors='replace'))
            probe = json.loads(run.stdout)
            expected = probe['fingerprint'] if expected is None else expected
            if probe['fingerprint'] != expected:
                raise ValueError('Ordered geometry fingerprint differs.')
            entry['records'].append({'round':round_index+1,'command':command,'probe':probe})
            save()
            print(f"  round {round_index+1} {mode}: {probe['cpu_load_ms']/1000:.3f}s; mapping {probe['corner_mapping']['total_ms']/1000:.3f}s; staged={probe['corner_mapping']['staged']}",flush=True)
result['status'] = 'complete'
save()
