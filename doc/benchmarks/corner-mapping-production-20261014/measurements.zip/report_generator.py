import csv
import html
import json
from pathlib import Path
import statistics
import zipfile

root=Path(__file__).resolve().parents[1]
inputs=[root/'build/staged-mapping-production-20261014',root/'build/staged-mapping-confirm-20261014']
destination=root/'doc/benchmarks/corner-mapping-production-20261014'
if destination.exists():
    raise ValueError('Use a new report directory.')
batches=[json.loads((p/'results.json').read_text()) for p in inputs]
assert all(b['status']=='complete' for b in batches)
destination.mkdir(parents=True)
names=['BearTrap','Bennu','Powerplant','San Miguel','BusGameMap']
rows=[]
for folder,batch in zip(inputs,batches):
    for name,model in zip(names,batch['models']):
        for mode in ('fused','prototype'):
            probes=[r['probe'] for r in model['records'] if r['probe']['mode']==mode]
            assert len(probes)==3
            assert len({r['probe']['fingerprint'] for r in model['records']})==1
            row={'batch':folder.name,'model':name,'mode':mode,'runs':len(probes),
                 'cpu_load_median_ms':statistics.median(p['cpu_load_ms'] for p in probes),
                 'cpu_load_min_ms':min(p['cpu_load_ms'] for p in probes),'cpu_load_max_ms':max(p['cpu_load_ms'] for p in probes),
                 'peak_rss_median_bytes':statistics.median(p['peak_working_set_bytes'] for p in probes),
                 'retained_array_capacity_bytes':probes[0]['retained_mesh_buffer_capacity_bytes']}
            row.update({field:statistics.median(p['corner_mapping'][field] for p in probes) for field in probes[0]['corner_mapping']})
            rows.append(row)
with (destination/'summary.csv').open('w',encoding='utf-8',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
current=[r for r in rows if r['batch']==inputs[-1].name]
table=[]
for name in names:
    old=next(r for r in current if r['model']==name and r['mode']=='fused')
    new=next(r for r in current if r['model']==name and r['mode']=='prototype')
    table.append(f"<tr><th>{name}</th><td>{old['cpu_load_median_ms']/1000:.3f}</td><td>{new['cpu_load_median_ms']/1000:.3f}</td><td>{100*(1-new['cpu_load_median_ms']/old['cpu_load_median_ms']):.1f}%</td><td>{old['total_ms']/1000:.3f}</td><td>{new['total_ms']/1000:.3f}</td><td>{old['retained_array_capacity_bytes']/2**20:,.1f}</td><td>{new['retained_array_capacity_bytes']/2**20:,.1f}</td><td>{bool(new['staged'])}</td></tr>")
checks=[('Warning-free Release build','staged-mapping-release-build-complete.log'),
        ('Final default test preset','staged-mapping-final-release-tests.log'),
        ('Slow test preset','staged-mapping-slow-tests.log'),
        ('Complete graphics test preset','staged-mapping-graphics-tests.log'),
        ('Final graphics regression checks','staged-mapping-final-graphics-tests.log'),
        ('Profiling source generation','staged-mapping-final-profile-tooling.log')]
(destination/'validation').mkdir()
for _,filename in checks:
    (destination/'validation'/filename).write_bytes((root/'build'/filename).read_bytes())
with zipfile.ZipFile(destination/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for folder in inputs:
        for file in folder.rglob('*'):
            if file.is_file(): archive.write(file,str(Path(folder.name)/file.relative_to(folder)).replace('\\','/'))
    for _,filename in checks: archive.write(root/'build'/filename,'validation/'+filename)
    archive.write(Path(__file__),'report_generator.py')
with zipfile.ZipFile(destination/'measurements.zip') as archive:
    assert archive.testzip() is None
details=''.join('<tr>'+''.join(f'<td>{html.escape(str(r[k]))}</td>' for k in rows[0])+'</tr>' for r in rows)
text="""<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>woby · Production corner mapping</title>
<style>body{margin:0;background:#f6f4ed;color:#173e34;font:16px/1.65 system-ui,sans-serif}main{max-width:1180px;margin:auto;padding:40px 24px}h1{font:44px/1.15 Georgia,serif}h2{margin-top:36px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:10px;text-align:right;border-bottom:1px solid #cbd3c8;white-space:nowrap}th:first-child{text-align:left}.scroll{overflow:auto}code{overflow-wrap:anywhere}a{color:#166b50}li{margin:10px 0}@media(max-width:600px){h1{font-size:34px}}</style><main>
<p>WOBY / PRODUCTION CORNER MAPPING / 14 OCTOBER 2026</p><h1>Resolve IDs first. Gather attributes after that.</h1>
<p>The importer now selects the staged mapper for triangle-only files with normals or UVs. It keeps global first-use IDs, ordered triangles, source double coordinates, full float32 vertex attributes, group names, and UV validity flags.</p>
<h2>Confirmed CPU results</h2><p>AMD Ryzen 7 5800H, 16 logical CPUs, about 64 GiB RAM. Three rotating rounds per model, warm OS file cache, fresh Release processes, 16 parser workers, and deferred preparation. Both modes use the same parser and SIMD code. The new mode selects up to eight gather workers. CPU load time excludes the verification pass, GPU upload, and the first visible frame. Reduction is the ratio of same-batch medians.</p>
<div class='scroll'><table><thead><tr><th>Model</th><th>Original load s</th><th>New load s</th><th>Load reduction</th><th>Original mapping s</th><th>New mapping s</th><th>Original retained MiB</th><th>New retained MiB</th><th>Staged path</th></tr></thead><tbody>"""+''.join(table)+"""</tbody></table></div>
<p>Every run has the same ordered-mesh fingerprint for its model. The fingerprint includes render vertices, ordered triangle/line/point indices, source coordinates and indices, position maps, origin, group ranges, and UV flags. Unit tests also cover eager and deferred state, identity positions, sparse sources, mixed primitives, freeforms, parallel output, worker limits, and cancellation.</p>
<h2>Selection and fallback</h2><ul><li>Use the compact staged path for attribute-bearing triangles. Source-position slots store the primary normal/UV key and render ID. Only seam vertices need full keys and hash lookup.</li><li>Keep the original mapper for position-only files, explicit line or point records, freeform patches, and source-position counts above twice the total corner-reference count. The sparse rule avoids a large 12-byte primary table when the 4-byte lookup and bounded full-key storage are smaller.</li><li>Bennu uses the position-only path. Its new-mode timings describe that same algorithm, with normal run-to-run variation.</li><li>Keep float32 GPU vertices and the existing upload path. The packed normals/UVs and binary import cache commit is excluded from this implementation.</li></ul>
<h2>Buffers and passes</h2><p>The staged path allocates one 12-byte primary record per source position, 16-byte seam records, and 4-byte hash buckets. It writes render indices, then releases parser triangle records before allocating the final vertex array. It checks position identity, builds the source map when required, and gathers primary and seam attributes in separate passes. Workers write to disjoint first-use IDs and join before publication. Only the caller reports progress or polls cancellation.</p>
<p>The final vertex array has the exact resolved length. This removes growth reserve when seams push the vertex count above the source-position estimate. The CSV records allocation, resolution, release, mapping, and gather times, table capacities, retained arrays, and process peaks. Released-triangle bytes describe logical array payloads. Worker stacks and allocator/driver overhead are outside exact array capacities. Lower retained memory does not imply a lower parser peak.</p>
<h2>Build and checks</h2><p>The default application enables this path. No experimental build option is required. The reference switch exists in the prototype benchmark API. Build with <code>cmake --build --preset vs2026-vcpkg --config Release</code>. Build the comparison executable with <code>-DWOBY_BUILD_RAPIDOBJ_PROTOTYPE_BENCHMARK=ON</code>, then compare <code>woby_obj_prototype_benchmark fused MODEL 16 deferred</code> and <code>woby_obj_prototype_benchmark prototype MODEL 16 deferred</code>.</p><ul>"""+''.join(f"<li><a href='validation/{f}'>{n}</a></li>" for n,f in checks)+"""</ul>
<h2>Evidence</h2><p>Two separate 30-run batches are preserved. The first implementation and the final pointer-access revision are not pooled. The headline table uses the final batch. <a href='summary.csv'>Summary CSV</a> · <a href='measurements.zip'>Raw runs, commands, source snapshots, runner, and validation logs</a>.</p>
<details><summary>All measured passes and buffers</summary><div class='scroll'><table><thead><tr>"""+''.join(f'<th>{k}</th>' for k in rows[0])+"</tr></thead><tbody>"+details+"</tbody></table></div></details></main></html>"
(destination/'report.html').write_text(text,encoding='utf-8')
print(destination)
