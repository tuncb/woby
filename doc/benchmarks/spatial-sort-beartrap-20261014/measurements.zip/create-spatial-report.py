import hashlib, html, json, statistics, subprocess, zipfile
from pathlib import Path
from PIL import Image, ImageChops
source=Path(r'C:/Users/tuncb/.t3/worktrees/woby/t3code-ad144470')
work=Path(r'D:/.worktree/woby-parallel-spatial-20261014')
raw=work/'build/spatial-measurements'
out=source/'doc/benchmarks/spatial-sort-beartrap-20261014'
out.mkdir(parents=True,exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
phase_names=['annotation_morton_keys','annotation_radix_sort','point_morton_keys','point_radix_sort',
             'post_load_cpu_total','post_point_preparation','post_annotation_cache',
             'annotation_blocks_fingerprints','annotation_tree_build']
runs=[]
reference_stats=None
images=set()
reference_image=None
image_comparisons=[]
scene_hashes=set()
for path in sorted((raw/'native').glob('*/result.json')):
 r=json.loads(path.read_text(encoding='utf-8'))
 assert 'error' not in r,r.get('error')
 assert r['loaded']['addedCount']==1 and r['loaded']['failedCount']==0
 stats={k:r['stats'][k] for k in ('vertexCount','triangleCount','groupCount','coordinateOrigin','bounds','renderer')}
 if reference_stats is None: reference_stats=stats
 assert stats==reference_stats
 phases=[p for p in r['trace'] if p['kind']=='phase']
 by_id={p['id']:p for p in phases}
 for p in phases:
  assert p['nesting_valid'] and p['end_ms']>=p['start_ms']
  if p['parent_id']:
   parent=by_id[p['parent_id']]
   assert parent['thread_id']==p['thread_id']
   assert parent['start_ms']<=p['start_ms'] and parent['end_ms']>=p['end_ms']
 marks={p['name']:p['time_ms'] for p in r['trace'] if p['kind']=='mark'}
 request=marks['model_add_requested']
 stages={name:sum(p['wall_ms'] for p in phases if p['name']==name)/1000 for name in phase_names}
 point=next(p for p in phases if p['name']=='post_point_preparation')
 annotation=next(p for p in phases if p['name']=='post_annotation_cache')
 stages['point_annotation_span']=(max(point['end_ms'],annotation['end_ms'])-min(point['start_ms'],annotation['start_ms']))/1000
 stages['point_annotation_overlap']=max(0,min(point['end_ms'],annotation['end_ms'])-max(point['start_ms'],annotation['start_ms']))/1000
 stages['ready']=(marks['all_tools_ready']-request)/1000
 stages['first_gpu_frame']=(marks['first_scene_frame_gpu_complete']-request)/1000
 stages['load_rpc']=r['load_rpc_ms']/1000
 stages['peak_working_set_gib']=max(p['process_peak_working_set'] for p in phases)/2**30
 images.add(r['image']['sha256'])
 image=Image.open(path.parent/'beartrap.png').convert('RGBA')
 if reference_image is None: reference_image=image
 bbox=ImageChops.difference(reference_image,image).convert('RGB').getbbox()
 changed=sum(a!=b for a,b in zip(reference_image.get_flattened_data(),image.get_flattened_data()))
 if bbox is not None:
  assert bbox[0]>=0 and bbox[2]<=140 and bbox[1]>=image.height-64 and bbox[3]<=image.height
 scene_hash=hashlib.sha256(image.tobytes()[:image.width*(image.height-64)*4]).hexdigest()
 scene_hashes.add(scene_hash)
 image_comparisons.append({'run':path.parent.name,'changed_pixels':changed,'difference_bbox':bbox,
                          'scene_rows_sha256':scene_hash,'excluded_rows':'bottom 64 rows contain grid-spacing HUD'})
 runs.append({'name':path.parent.name,'variant':path.parent.name.split('-')[1],
              'executable_sha256':r['executable_sha256'],'image_sha256':r['image']['sha256'],
              'metrics':stages,'trace_valid':True,'stats':stats})
assert len(runs)==6 and len(scene_hashes)==1
summary={'baseline_revision':revision,'date':'2026-10-14','cpu':'AMD Ryzen 7 5800H; 8 cores; 16 logical CPUs',
         'gpu':'NVIDIA RTX 3070 Laptop','input':{'path':'D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj',
           'bytes':7108991827,'sha256':'7abcb6005617270f3c799292991b858a16e0cddf39b9655eb3f1d691b2a45329'},
         'method':'Three alternating pairs of fresh hidden instrumented viewers; file warmed before each process; no concurrent build, tests, or profiler; one-second settle and render intervals after readiness.',
         'worker_budget':'At most 8 shared helper threads, including the point/annotation coordinator helper; callers also drain work. Small key jobs remain serial.',
         'validation':{'default_release_tests':84,'slow_release_tests':8,'new_test_cases':5,'build_warnings':0,
                       'same_scene_stats':True,'screenshot_sha256_values':sorted(images),'same_model_pixels':True,'image_comparisons':image_comparisons,'all_trace_nesting_valid':True},
         'runs':runs,'groups':{}}
for variant in ('baseline','parallel'):
 selected=[r for r in runs if r['variant']==variant]
 summary['groups'][variant]={key:{'median':statistics.median(r['metrics'][key] for r in selected),
      'min':min(r['metrics'][key] for r in selected),'max':max(r['metrics'][key] for r in selected)} for key in selected[0]['metrics']}
files=['CMakeLists.txt','src/parallel_work.h','src/spatial_sort.h','src/point_cloud.cpp','src/post_loading.cpp',
       'src/surface_annotation.cpp','tests/spatial_sort_tests.cpp','experiments/obj-profile/generate.py','experiments/obj-profile/e2e_generate.py']
summary['changed_source_sha256']={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
before=summary['groups']['baseline']; after=summary['groups']['parallel']
def median(key,variant): return summary['groups'][variant][key]['median']
def rows(keys):
 result=[]
 for key,label in keys:
  a,b=median(key,'baseline'),median(key,'parallel')
  result.append(f'<tr><td>{html.escape(label)}</td><td>{a:.3f}</td><td>{b:.3f}</td><td>{(1-b/a)*100:.1f}%</td></tr>')
 return ''.join(result)
def table(keys):
 return '<table><thead><tr><th>Measurement</th><th>Serial s</th><th>Parallel s</th><th>Less time</th></tr></thead><tbody>'+rows(keys)+'</tbody></table>'
ready_before,ready_after=median('ready','baseline'),median('ready','parallel')
critical=table([('post_load_cpu_total','Full post-load CPU preparation'),('point_annotation_span','Point + annotation elapsed span'),('ready','Request to all tools ready'),('first_gpu_frame','Request to first completed GPU frame')])
phase_table=table([('annotation_morton_keys','Annotation Morton-key generation'),('annotation_radix_sort','Annotation stable radix sort'),('point_morton_keys','Point Morton-key generation'),('point_radix_sort','Point stable radix sort')])
run_rows=''.join(f"<tr><td>{r['name']}</td><td>{r['metrics']['ready']:.3f}</td><td>{r['metrics']['post_load_cpu_total']:.3f}</td><td>{r['metrics']['first_gpu_frame']:.3f}</td><td>{r['metrics']['peak_working_set_gib']:.3f}</td></tr>" for r in runs)
report=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BearTrap parallel spatial preparation — 14 October 2026</title>
<style>body{{margin:40px auto;max-width:1080px;padding:0 24px;font:16px/1.6 system-ui;color:#182431;background:#f7f9fb}}h1,h2{{line-height:1.2}}table{{border-collapse:collapse;width:100%;margin:20px 0;background:white}}th,td{{padding:10px 14px;border-bottom:1px solid #d8e0e7;text-align:right}}th:first-child,td:first-child{{text-align:left}}th{{background:#e9f0f5}}a{{color:#075d9e}}code{{overflow-wrap:anywhere}}.lead{{font-size:22px}}.scroll{{overflow:auto}}img{{max-width:100%}}</style>
<h1>BearTrap: parallel spatial preparation</h1><p>14 October 2026 · Release · Ryzen 7 5800H · RTX 3070 Laptop</p>
<p class="lead">Median time to all tools ready: <strong>{ready_before:.2f} s → {ready_after:.2f} s</strong>. This is a <strong>{(1-ready_after/ready_before)*100:.1f}% reduction</strong> in three alternating pairs.</p>
<h2>Critical path</h2><div class="scroll">{critical}</div>
<p>The point and annotation preparation branches now run at the same time. The annotation branch is the longer branch in all three changed runs. Median overlap is {median('point_annotation_overlap','parallel'):.3f} s. Use the measured elapsed span or full post-load duration to assess the benefit. Do not add the individual phase savings.</p>
<p>Sorting starts after the first completed scene frame. The change does not target that first frame. The initial import and first-frame times vary between these runs; do not attribute their difference to spatial sorting.</p>
<h2>Phase durations</h2><div class="scroll">{phase_table}</div>
<p>These are phase wall times from the full viewer pipeline. Concurrent work can affect them. Process CPU counters can include the other branch and the renderer. They are not isolated kernel throughput measurements.</p>
<h2>Implementation and identity</h2>
<p>Point keys use 65,536-entry batches. Annotation key workers use separate output ranges for blocks of triangles. A serial compaction pass retains block order when triangles have invalid indices or nonfinite coordinates.</p>
<p>The shared four-pass radix sort counts each contiguous input chunk separately. Bucket prefixes follow input chunk order. Each chunk writes to its own range in each bucket and scans its input in order. Equal keys retain their input order. Original triangle offsets and original point IDs stay attached to the keys.</p>
<p>The existing global analysis worker budget also controls spatial preparation and the coordinator helper. It permits at most eight helper threads on this machine. The caller drains work too. Jobs fall back to the caller when the budget is occupied. Cancellation callbacks are serialized. All helpers join before a result or exception leaves the operation.</p>
<p>The annotation fingerprint pass retains its original sequential hash operations. It does not combine parallel hashes. Median fingerprint/block preparation is {median('annotation_blocks_fingerprints','parallel'):.3f} s in the changed runs and is now a large part of the annotation critical path.</p>
<h2>Validation and memory</h2>
<p>The Release application and test targets compile without warnings. All 84 default tests and all 8 slow tests pass. Five new test cases cover full-width radix keys, stable ties, occupied worker budgets, nested jobs, failure/cancellation cleanup, invalid triangles, overlapping and reordered annotation groups, source fingerprints, reversed point-source IDs, positions, and post-load result equivalence.</p>
<p>All six full loads have the same scene bounds and counts: 38,414,391 render vertices, 75,771,986 triangles, and one group. The model pixels match. Two serial captures differ from the other four captures by four pixels in the grid-spacing label at the bottom left. The raw screenshots are preserved. The five new CPU tests verify source identities and fingerprints on synthetic meshes; the screenshot comparison verifies the full BearTrap solid view.</p>
<p>Median process peak working set: {median('peak_working_set_gib','baseline'):.3f} GiB before and {median('peak_working_set_gib','parallel'):.3f} GiB after. This is the process lifetime peak, which includes parsing. It does not isolate temporary spatial-sort memory.</p>
<h2>All runs</h2><div class="scroll"><table><thead><tr><th>Run</th><th>Tools ready s</th><th>Post-load CPU s</th><th>First GPU frame s</th><th>Peak WS GiB</th></tr></thead><tbody>{run_rows}</tbody></table></div>
<h2>Method and evidence</h2>
<p>The serial baseline is application revision <code>{revision}</code>. The changed sources are recorded by hash in <a href="summary.json">summary.json</a> and included in <a href="measurements.zip">measurements.zip</a>. Builds use <code>vs2026-vcpkg</code> with explicit <code>--config Release</code>. The serial executables, runtime DLLs, and assets were frozen before the changed build.</p>
<p>Run order: serial/parallel, parallel/serial, serial/parallel. Each run uses a fresh hidden instrumented viewer and reads the file before launch to warm the file cache. No cache is flushed. No build, tests, or profiler runs during these measurements. Capture uses the existing end-to-end runner and production hidden-window pacing.</p>
<p>The input is <code>D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj</code>, 7,108,991,827 bytes. Its SHA256 matches the <a href="../e2e-beartrap-20261014/report.html">original report</a>: <code>{summary['input']['sha256']}</code>. These fresh serial durations differ from the older report. Use the paired serial baseline for this comparison. Three pairs on one computer do not establish scaling on other hardware.</p>
<p><a href="REPRODUCE.txt">Reproduction</a> · <a href="summary.json">Numeric summary</a> · <a href="measurements.zip">Raw results, traces, logs, and changed-source snapshots</a> · <a href="beartrap.png">Verified screenshot</a></p><img src="beartrap.png" alt="BearTrap rendered scene; model pixels match in all six runs"></html>'''
(out/'report.html').write_text(report,encoding='utf-8')
(out/'beartrap.png').write_bytes((raw/'native/r3-parallel/beartrap.png').read_bytes())
reproduce=f'''BearTrap parallel spatial preparation, 14 October 2026

Base application revision: {revision}
Input: D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj
Bytes: 7,108,991,827
SHA256: {summary['input']['sha256']}

Use Windows and separate source worktrees under D:/.worktree for the serial
baseline and changed source. The archive contains the baseline and changed
copies of each affected source file. The full repository and input are required.
Use a fresh build directory for each variant. If source files are copied into
an existing build checkout, update their timestamps before building.

In each source checkout:
  cmake --preset vs2026-vcpkg -DWOBY_BUILD_OBJ_PROFILE=ON
  cmake --build --preset vs2026-vcpkg --config Release
  ctest --preset vs2026-vcpkg -C Release
  ctest --preset vs2026-vcpkg-slow -C Release

Freeze the serial bin/Release directory, including assets and runtime DLLs,
before rebuilding its source checkout. Do not run a build, tests, or profiler
at the same time as a timed capture.

For each run, use a new output directory:
  uv run experiments/obj-profile/e2e_run.py <variant>/woby_obj_e2e_viewer.exe D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj --hidden --output <new-output> --settle-seconds 1 --render-seconds 1

Use three alternating pairs: serial/parallel, parallel/serial, serial/parallel.
The archive contains run-spatial-measurements.py with the exact recorded paths.
The runner warms the input before each new process. No file cache is flushed.
All readiness times use all_tools_ready minus model_add_requested trace marks.
Post-load CPU times use post_load_cpu_total. The point/annotation elapsed span
uses the earliest branch start and latest branch end. Individual phase times
must not be added after introducing overlap.

The one-second settled render interval is outside the load measurements and
is not a frame-rate study. Large native records, frozen binaries, and PDBs
remain in D:/.worktree/woby-parallel-spatial-20261014/build.
'''
(out/'REPRODUCE.txt').write_text(reproduce,encoding='utf-8')
with zipfile.ZipFile(out/'measurements.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for path in sorted((raw/'native').rglob('*')):
  if path.is_file(): archive.write(path,'native/'+path.relative_to(raw/'native').as_posix())
 for name in ('baseline-build.log','parallel-build.log','parallel-rebuild.log','parallel-tests.log','parallel-slow-tests.log','run-spatial-measurements.py'):
  archive.write(work/'build'/name,'build/'+name)
 archive.write(raw/'native-console.log','native-console.log')
 for name in files:
  archive.write(source/name,'source/parallel/'+name)
  old=subprocess.run(['git','show',f'HEAD:{name}'],cwd=source,capture_output=True)
  if old.returncode==0: archive.writestr('source/baseline/'+name,old.stdout)
 archive.writestr('source/changes.patch',subprocess.check_output(['git','diff','--binary'],cwd=source))
 archive.write(out/'summary.json','summary.json')
 archive.write(out/'REPRODUCE.txt','REPRODUCE.txt')
 archive.write(work/'build/create-spatial-report.py','create-spatial-report.py')
print(json.dumps({'ready_before':ready_before,'ready_after':ready_after,'groups':summary['groups'],'archive_bytes':(out/'measurements.zip').stat().st_size},indent=2))
