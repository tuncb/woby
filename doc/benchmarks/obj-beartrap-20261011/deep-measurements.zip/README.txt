Native .prd/.db traces, VTune results and matching executables/PDBs remain in build/obj-profile-measurements/deep.
This archive contains numerical records, decoded sample locations, reports, the NVTX trace and exported tables.
Hardware values are sampled estimates, not exact event totals. Native timing batches exclude profiler overhead.
