#include <bit>
#include <cstdint>
uint64_t before(double value) { return std::bit_cast<uint64_t>(value == 0 ? 0 : value); }
uint64_t after(double value) { auto bits = std::bit_cast<uint64_t>(value); return (bits & 0x7fffffffffffffffULL) == 0 ? 0 : bits; }
