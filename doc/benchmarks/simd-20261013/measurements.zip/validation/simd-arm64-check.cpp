#include "simd_bounds.h"
#include "coordinate_simd.h"
void check(std::span<std::array<double, 3>> points) {
    auto doubles = woby::doubleBoundsReduction({1, 2, 3});
    woby::expand(doubles, {4, 5, 6});
    const auto box = woby::boundsResult(doubles);
    auto floats = woby::floatBoundsReduction({1, 2, 3}, {1, 2, 3});
    woby::expand(floats, {4, 5, 6});
    (void)woby::boundsResult(floats);
    woby::rebaseCoordinates(points, box[0]);
}
