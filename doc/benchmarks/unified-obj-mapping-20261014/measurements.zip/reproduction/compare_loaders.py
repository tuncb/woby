"""Compare checkpoint and common-resolver Release binaries in fresh processes."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
EXES = {
    'checkpoint': OUT / 'baseline-bin/woby_obj_prototype_benchmark.exe',
    'common': ROOT / 'build/vs2026-vcpkg/bin/Release/woby_obj_prototype_benchmark.exe',
}


def warm(path):
    if path.is_file():
        with path.open('rb') as stream:
            for _ in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                pass


def compare(name, path, rounds, preparations=('deferred', 'eager')):
    target = OUT / name
    target.mkdir(exist_ok=False)
    manifest = {'input': str(path), 'rounds': rounds, 'executables': {
        label: {'path': str(exe), 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest()}
        for label, exe in EXES.items()}}
    if path.is_file():
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                digest.update(block)
        manifest.update(input_bytes=path.stat().st_size, input_sha256=digest.hexdigest())
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    records = []
    for preparation in preparations:
        for round_number in range(1, rounds + 1):
            for label in (('checkpoint', 'common') if round_number % 2 else ('common', 'checkpoint')):
                warm(path)
                command = [str(EXES[label]), 'prototype', str(path), '0']
                if preparation == 'deferred':
                    command.append('deferred')
                run = subprocess.run(command, capture_output=True, text=True, check=True, timeout=600)
                row = json.loads(run.stdout)
                row.update(configuration=label, preparation=preparation, round=round_number, command=command)
                records.append(row)
                (target / 'cpu.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
                print(name, label, preparation, round_number, round(row['cpu_load_ms'], 3), row['fingerprint'], flush=True)
        selected = [row for row in records if row['preparation'] == preparation]
        if len({row['fingerprint'] for row in selected}) != 1:
            raise ValueError(f'{name} {preparation}: ordered mesh fingerprints differ')
    summary = {}
    for preparation in preparations:
        summary[preparation] = {}
        for label in EXES:
            rows = [row for row in records if row['preparation'] == preparation and row['configuration'] == label]
            summary[preparation][label] = {key: statistics.median(row[key] for row in rows)
                for key in ('cpu_load_ms', 'prepare_ms', 'peak_working_set_bytes', 'peak_commit_bytes', 'private_bytes_after_load', 'retained_mesh_buffer_capacity_bytes')}
            summary[preparation][label]['mapping'] = {key: statistics.median(row['corner_mapping'][key] for row in rows)
                for key in rows[0]['corner_mapping'] if not isinstance(rows[0]['corner_mapping'][key], bool)}
    (target / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')


def fixtures():
    target = OUT / 'fixtures'
    target.mkdir(exist_ok=False)
    rng = random.Random(20261014)
    for case in range(120):
        count = rng.randrange(5, 31)
        text = ''.join(f'v {rng.randrange(-10,11)} {rng.randrange(-10,11)} {rng.randrange(-10,11)}\n' for _ in range(count))
        text += 'vt .25 .5\nvt .75 .25\nvt 1e39 .5\nvn 0 1 0\nvn 0 0 -1\n'
        for group in range(3):
            text += f'g group{rng.randrange(2)}\n'
            if case % 5 != 0:
                for _ in range(3):
                    corners = []
                    for position in rng.sample(range(1, count + 1), 3):
                        mode = rng.randrange(4)
                        corners.append(str(position) + (f'/{rng.randrange(1,4)}/{rng.randrange(1,3)}' if mode == 0 else f'/{rng.randrange(1,4)}' if mode == 1 else f'//{rng.randrange(1,3)}' if mode == 2 else ''))
                    text += 'f ' + ' '.join(corners) + '\n'
            text += 'l ' + ' '.join(str(rng.randrange(1,count+1)) for _ in range(6)) + '\n'
            text += 'p ' + ' '.join(str(rng.randrange(1,count+1)) for _ in range(9)) + '\n'
        (target / f'{case:03}.obj').write_text(text, encoding='ascii')
    (target / 'cloud.obj').write_text('v 0 0 0\nv 0 0 0\nv 1 0 1\nvt .5 .5\nvn 0 1 0\n', encoding='ascii')
    sparse = 'v 0 0 0\nv 1 0 0\nv 0 1 0\n' + 'v 2 2 2\n' * 20000
    (target / 'sparse.obj').write_text(sparse + 'f 3 1 2\nl 20003 1\np 20003 2\n', encoding='ascii')
    controls = 'v 0 0 0\nv 1 0 0\nv 0 1 0\nv 1 1 0\n'
    patch = 'g patch\ncstype bezier\ndeg 1 1\nsurf 0 1 0 1 1 2 3 4\nparm u 0 1\nparm v 0 1\nend\n'
    (target / 'freeform.obj').write_text(controls + patch, encoding='ascii')
    (target / 'mixed-freeform.obj').write_text(controls + 'g mesh\nf 3 1 2\nl 4 1\np 2 2\n' + patch, encoding='ascii')
    return target


def primitives(kind, count=2_000_000):
    path = OUT / f'{kind}.obj'
    with path.open('w', encoding='ascii', newline='\n') as stream:
        for i in range(count):
            stream.write(f'v {i % 997} {(i // 997) % 997} {i % 31}\n')
        if kind == 'lines':
            for start in range(1,count,100):
                stream.write('l ' + ' '.join(str(i) for i in range(start,min(start+101,count+1))) + '\n')
        elif kind == 'points':
            for start in range(1,count+1,100):
                values = [str(i) for i in range(start,min(start+100,count+1))]
                stream.write('p ' + ' '.join(values + list(reversed(values))) + '\n')
    return path


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=('fixtures','bennu','beartrap','cloud','lines','points','other'))
    args = parser.parse_args()
    if args.kind == 'fixtures':
        compare('fixture-validation', fixtures(), 1)
    elif args.kind == 'bennu':
        compare('bennu', Path('D:/temp/obj_tests/bennu_OLA_v21_PTM_very-high.obj'), 5)
    elif args.kind == 'beartrap':
        compare('beartrap', Path('D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj'), 3, ('deferred',))
    elif args.kind == 'other':
        for name in ('powerplant', 'san-miguel', 'uploads_files_2720101_BusGameMap'):
            compare(name, Path(f'D:/temp/obj_tests/{name}.obj'), 1)
    else:
        compare(args.kind, primitives(args.kind), 3, ('deferred',))
