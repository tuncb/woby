"""Apply the final hot-loop change and retain valid incremental build outputs."""
import hashlib
import os
from pathlib import Path
import shutil
import subprocess

SOURCE = Path(__file__).resolve().parents[2]
TARGET = Path('D:/woby').resolve(strict=True)
OUT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


if __name__ == '__main__':
    generated = TARGET/'build/vs2026-vcpkg/experiments'
    snapshot = {path: (digest(path),path.stat().st_mtime_ns) for path in generated.rglob('*')
                if path.is_file() and path.suffix in ('.cpp','.h','.hpp','.inc')}
    for name in ('src/obj_corner_mapping.h','experiments/obj-profile/generate.py'):
        shutil.copy2(SOURCE/name,TARGET/name)
    with (TARGET/'build/configure-unified-mapping-final.log').open('w',encoding='utf-8') as log:
        subprocess.run(['cmake','--preset','vs2026-vcpkg'],cwd=TARGET,stdout=log,stderr=subprocess.STDOUT,check=True)
    restored = 0
    for path,(before,mtime) in snapshot.items():
        if path.is_file() and digest(path) == before:
            os.utime(path,ns=(path.stat().st_atime_ns,mtime))
            restored += 1
    print(f'Kept timestamps for {restored} byte-identical generated files; changed files retain new timestamps.',flush=True)
    with (TARGET/'build/build-unified-mapping-final.log').open('w',encoding='utf-8') as log:
        subprocess.run(['cmake','--build','--preset','vs2026-vcpkg','--config','Release'],cwd=TARGET,
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    print('Final Release build passed.',flush=True)
    runtime = TARGET/'build/vs2026-vcpkg/bin/Release'
    destination = OUT/'final-common-bin'
    destination.mkdir(exist_ok=False)
    for name in ('woby.exe','woby_obj_e2e_viewer.exe','woby_obj_prototype_benchmark.exe'):
        shutil.copy2(runtime/name,destination/name)
    for path in runtime.glob('*.dll'):
        shutil.copy2(path,destination/path.name)
    shutil.copytree(runtime/'assets',destination/'assets')
    print(f'Saved final measurement binaries in {destination}',flush=True)
