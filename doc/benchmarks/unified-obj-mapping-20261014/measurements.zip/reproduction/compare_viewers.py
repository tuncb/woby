"""Measure first display and full readiness with the existing viewer observer."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'experiments/obj-profile'))
from e2e_analyze import summarize_run


def run(kind, final=False):
    executables = {
        'checkpoint': OUT/'baseline-bin/woby.exe' if kind == 'native' else ROOT/'build/bennu-paths-20261014/measured-bin/woby_position_mapping_traced_reference.exe',
        'common': (OUT/'final-common-bin' if final else ROOT/'build/vs2026-vcpkg/bin/Release')/('woby.exe' if kind == 'native' else 'woby_obj_e2e_viewer.exe'),
    }
    model = Path('D:/temp/obj_tests/bennu_OLA_v21_PTM_very-high.obj')
    target = OUT/('viewer-'+kind+('-final' if final else ''))
    target.mkdir(exist_ok=False)
    manifest = {'input': str(model), 'rounds': 3, 'kind': kind, 'executables': {
        label: {'path': str(exe), 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest()}
        for label, exe in executables.items()}}
    (target/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    rows = []
    for round_number in range(1,4):
        for label in (('checkpoint','common') if round_number % 2 else ('common','checkpoint')):
            folder = target/f'r{round_number}-{label}'
            command = ['uv','run',str(ROOT/'experiments/obj-profile/e2e_run.py'),str(executables[label]),str(model),
                       '--output',str(folder),'--hidden','--settle-seconds','1','--render-seconds','2']
            print('Starting', kind, round_number, label, flush=True)
            folder.mkdir()
            with (folder/'driver.log').open('w',encoding='utf-8') as log:
                subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
            row = summarize_run(folder/'result.json')
            row.update(configuration=label,round=round_number,command=command)
            rows.append(row)
            (target/'summary.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
            if row.get('error'):
                raise ValueError(row['error'])
            print(json.dumps({key: row[key] for key in ('configuration','round','cpu_import_ms','load_rpc_ms','milestones_ms','process') if key in row}),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('kind',choices=('native','traced'))
    parser.add_argument('--final',action='store_true')
    args = parser.parse_args()
    run(args.kind,args.final)
