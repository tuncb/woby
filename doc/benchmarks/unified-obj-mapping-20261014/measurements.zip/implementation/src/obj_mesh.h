#pragma once

#include "model_mesh.h"

#include <filesystem>
#include <istream>
#include <optional>
#include <string_view>

namespace woby {

struct ObjMeshCounts {
    size_t sourcePositions = 0;
    size_t triangleIndices = 0;
    size_t lineIndices = 0;
    size_t pointIndices = 0;
    bool vertexCloud = false;
};

// RapidOBJ emits n - 2 triangles for each valid n-corner polygon.
[[nodiscard]] size_t objTriangleIndexCount(size_t corners, size_t faces);

// Counts known before mesh expansion. Only vertex-only clouds have an exact
// render vertex count here; other OBJ files can omit positions or split seams.
void validateObjMeshCounts(const ObjMeshCounts& counts);

struct ObjPointCapacity {
    size_t highestPosition = 0;
    size_t distinctLowerBound = 0;
};
// Each new record-high position is provably distinct, without a growing set.
void checkObjPointReference(ObjPointCapacity& capacity, size_t position);

// Constant-memory preflight, not a syntax validator. Checks a lower bound on
// explicit point vertices, and returns an exact count for vertex-only clouds.
// Other geometry or attributes return nullopt to avoid duplicating a full
// mesh parse. Unused source positions must stay legal.
inline constexpr size_t objPreflightBlockBytes = 1024 * 1024;
[[nodiscard]] std::optional<size_t> scanObjCapacity(std::istream& input,
    const ModelLoadProgressCallback& progress = {}, uintmax_t fileBytesHint = 0);

// Unified polygon/freeform loading into caller-owned coordinate buffers.
[[nodiscard]] Mesh loadObjMesh(const std::filesystem::path& path, const ModelLoadProgressCallback& progress = {}, bool deferPreparation = false);
// OBJ held in memory, with no external material-library reads.
[[nodiscard]] Mesh loadObjMeshText(std::string_view text, const ModelLoadProgressCallback& progress = {});

// Reference entry points for comparison tests and benchmarks. Application
// loading always uses the unified parser through the entry points above.
[[nodiscard]] Mesh loadObjMeshLegacy(const std::filesystem::path& path, const ModelLoadProgressCallback& progress = {});
[[nodiscard]] Mesh loadObjMeshTextLegacy(std::string_view text, const ModelLoadProgressCallback& progress = {});
struct ObjPrototypeOptions {
    size_t chunkBytes = 4 * 1024 * 1024, readBytes = 256 * 1024, workers = 0;
    bool deferPreparation = false;
    size_t gatherWorkers = 0; // Zero selects up to eight hardware workers.
};
struct ObjCornerMappingMetrics {
    bool staged = false;
    size_t gatherWorkers = 0, primaryCapacityBytes = 0, keyCapacityBytes = 0, bucketCapacityBytes = 0;
    size_t seamVertices = 0, releasedTriangleBytes = 0, vertexCapacityBytes = 0, positionMapCapacityBytes = 0;
    double resolveMs = 0, releaseMs = 0, vertexAllocationMs = 0, positionMapMs = 0;
    double primaryGatherMs = 0, seamGatherMs = 0, totalMs = 0;
};
struct ObjPrototypeMetrics {
    size_t inputBytes = 0, chunks = 0, workers = 0, peakInflightTextBytes = 0, parsedChunkBytes = 0;
    size_t positionCopyBytesAvoided = 0;
    double parseMs = 0, freeformMs = 0, prepareMs = 0;
    ObjCornerMappingMetrics mapping;
};
[[nodiscard]] Mesh loadObjMeshPrototype(const std::filesystem::path& path,
    const ModelLoadProgressCallback& progress = {}, const ObjPrototypeOptions& options = {},
    ObjPrototypeMetrics* metrics = nullptr);
[[nodiscard]] Mesh loadObjMeshTextPrototype(std::string_view text,
    const ModelLoadProgressCallback& progress = {}, const ObjPrototypeOptions& options = {},
    ObjPrototypeMetrics* metrics = nullptr);

} // namespace woby
