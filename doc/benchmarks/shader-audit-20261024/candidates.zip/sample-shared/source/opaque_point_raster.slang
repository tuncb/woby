// Intentionally included twice. The parent defines the function names,
// literal sample count, and sample positions for each specialization.
[ForceInline] void WOBY_RASTER_POINT(float4 clip,float pointSize,uint id,bool query,bool ids) {
        if (!all(isfinite(clip)) || clip.w<=0 || clip.z<0 || clip.z>clip.w) return;
        float2 center=float2(clip.x/clip.w*.5+.5,.5-clip.y/clip.w*.5)*float2(cloud.width,cloud.height);
        float radius=pointSize*.5;
        if (any(center+radius<0) || any(center-radius>=float2(cloud.width,cloud.height))) return;
        int2 lo=int2(max(float2(0),floor(center-radius)));
        int2 hi=int2(min(float2(cloud.width-1,cloud.height-1),floor(center+radius)));
        if (query) { lo=max(lo,int2(cloud.query.xy)); hi=min(hi,int2(cloud.query.zw)-1); }
        if (any(lo>hi)) return;
        uint depth=asuint(max(clip.z/clip.w,0.0));
        uint64 key=(uint64(depth)<<32)|uint64(id);
        // A disabled cache uses one 65536-pixel tile. Both paths use shifts,
        // not per-point integer division by a runtime tile size.
        int tileSize=int(1u<<cloud.tileShift);
        for (int tileY=lo.y>>cloud.tileShift;tileY<=(hi.y>>cloud.tileShift);++tileY)
            for (int tileX=lo.x>>cloud.tileShift;tileX<=(hi.x>>cloud.tileShift);++tileX) {
            int2 first=int2(tileX,tileY)*tileSize;
            int2 last=min(first+tileSize-1,int2(cloud.width,cloud.height)-1);
#if defined(WOBY_POINT_ATOMIC64) && defined(WOBY_VULKAN)
            if (cloud.tileSize!=0) {
                uint tileIndex=uint(tileY)*((cloud.width+cloud.tileSize-1)>>cloud.tileShift)+uint(tileX);
                if (((Atomic<uint64>*)(cloud.coverage+tileIndex))->load(MemoryOrder.Relaxed)>=key) continue;
                float lowSample=WOBY_RASTER_SAMPLES==1?.5:.125;
                float highSample=WOBY_RASTER_SAMPLES==1?.5:.875;
                float2 farthest=max(abs(float2(first)+lowSample-center),abs(float2(last)+highSample-center));
                bool completeQuery=!query || (all(first>=int2(cloud.query.xy)) && all(last<int2(cloud.query.zw)));
                // Publish only circles that cover the entire tile and query.
                // This invocation must then write all covered samples below.
                // A later, greater certificate can replace it; either way a
                // skipped point cannot win after this dispatch completes.
                if (completeQuery && dot(farthest,farthest)<=radius*radius)
                    pointAtomicMax64(cloud.coverage+tileIndex,key);
            }
#endif
            int2 start=max(lo,first),finish=min(hi,last);
            for (int y=start.y;y<=finish.y;++y) for (int x=start.x;x<=finish.x;++x) [unroll] for (uint sample=0;sample<4;++sample) {
                if (sample>=WOBY_RASTER_SAMPLES) break;
                float2 delta=float2(x,y)+WOBY_RASTER_SAMPLE_POSITION(sample)-center;
                if (dot(delta,delta)>radius*radius) continue;
                uint index=(uint(y)*cloud.width+uint(x))*WOBY_RASTER_SAMPLES+min(sample,WOBY_RASTER_SAMPLES-1);
#ifdef WOBY_POINT_ATOMIC64
                pointAtomicMax64(cloud.winners+index,key);
#else
                if (!ids) pointAtomicMax32(cloud.batch[index].depth,depth);
                else if (cloud.batch[index].depth==depth) pointAtomicMax32(cloud.batch[index].id,id);
#endif
            }
        }
}
[ForceInline] void WOBY_RASTER_TASK(uint3 dispatch,uint lane,bool ids) {
    uint taskIndex=dispatch.y*cloud.dispatchWidth+dispatch.x;
    if (taskIndex>=cloud.taskCount) return;
    OpaquePointTaskData task=cloud.tasks[taskIndex];
    OpaquePointGroupData group=cloud.groups[task.group];
    for (uint i=lane;i<task.count;i+=128) {
        OpaquePoint p=task.points[i];
        WOBY_RASTER_POINT(mul(group.matrix,float4(p.position,1)),group.pointSize,
            group.firstId+p.id-group.sourceFirstId,task.query!=0,ids);
    }
}
