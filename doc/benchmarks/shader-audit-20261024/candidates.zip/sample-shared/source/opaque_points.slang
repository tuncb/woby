#include <NoGraphicsAPI/shader.slang>
#include "opaque_points.h"
GPU_ROOT(OpaquePointRoot, cloud);
// Slang's generic InterlockedMax currently emits the value-returning Metal
// overload even when its result is unused. Metal's ulong max returns void.
void pointAtomicMax64(uint64* address, uint64 value) {
    __target_switch {
    case metal:
        __intrinsic_asm "atomic_max_explicit((device atomic_ulong*)($0), $1, memory_order_relaxed)";
    default:
        // Winners only increase during a raster dispatch. A relaxed atomic
        // read can skip a losing update; a stale read only adds redundant work.
        if (((Atomic<uint64>*)address)->load(MemoryOrder.Relaxed)<value)
            InterlockedMax(*address,value);
    }
}
void pointAtomicMax32(__ref uint destination, uint value) {
    __target_switch {
    case metal:
        __intrinsic_asm "(void)atomic_fetch_max_explicit((device atomic_uint*)($0), $1, memory_order_relaxed)";
    default:
        InterlockedMax(destination,value);
    }
}
float2 pointSamplePosition4(uint sample) {
    const float2 positions[4]={float2(.375,.125),float2(.875,.375),float2(.125,.625),float2(.625,.875)};
    return positions[sample];
}
#ifdef WOBY_VULKAN
float opaqueSurfaceDepth(uint2 pixel,uint sample) {
    pixel+=uint2(cloud.x,cloud.y);
    if (cloud.samples==1) return gpu_texture<Texture2D<float>>(cloud.depthTexture).Load(int3(pixel,0));
    return gpu_texture<Texture2DMS<float>>(cloud.depthTexture).Load(pixel,sample);
}
#endif
[numthreads(8,8,1)] void cs_opaque_clear(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint depth=0;
#ifdef WOBY_VULKAN
        if (cloud.seedDepth!=0) depth=asuint(max(opaqueSurfaceDepth(thread.xy,sample),0.0));
#endif
        // A surface has ID zero. An equal-depth marker has a positive ID and
        // still wins. The fullscreen resolve discards surface-only entries.
        cloud.winners[(thread.y*cloud.width+thread.x)*cloud.samples+min(sample,cloud.samples-1)]=uint64(depth)<<32;
    }
    if (cloud.coverage!=nullptr) {
        const uint index=thread.y*cloud.width+thread.x;
        uint lowerBound=0;
#ifdef WOBY_VULKAN
        if (cloud.seedDepth!=0 && cloud.tileSize!=0) {
            const uint columns=(cloud.width+cloud.tileSize-1)>>cloud.tileShift;
            const uint rows=(cloud.height+cloud.tileSize-1)>>cloud.tileShift;
            if (index<columns*rows) {
                const uint2 first=uint2(index%columns,index/columns)*cloud.tileSize;
                const uint2 end=min(first+cloud.tileSize,uint2(cloud.width,cloud.height));
                lowerBound=asuint(1.0);
                for (uint y=first.y;y<end.y;++y) for (uint x=first.x;x<end.x;++x)
                    for (uint sample=0;sample<cloud.samples;++sample)
                        lowerBound=min(lowerBound,asuint(max(opaqueSurfaceDepth(uint2(x,y),sample),0.0)));
            }
        }
#endif
        cloud.coverage[index]=uint64(lowerBound)<<32;
    }
}
[numthreads(8,8,1)] void cs_opaque_batch_clear(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint index=(thread.y*cloud.width+thread.x)*cloud.samples+sample;
        cloud.batch[index].depth=0;
        cloud.batch[index].id=0;
    }
}
[numthreads(8,8,1)] void cs_opaque_merge(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint index=(thread.y*cloud.width+thread.x)*cloud.samples+sample;
        OpaquePointBatchSample winner=cloud.batch[index];
        // One invocation owns this sample. No 64-bit atomic is needed to merge
        // a completed batch into the persistent lexicographic depth/ID winner.
        uint64 key=(uint64(winner.depth)<<32)|uint64(winner.id);
        cloud.winners[index]=max(cloud.winners[index],key);
    }
}
// The adaptor accepts only 1x or 4x MSAA. Compile the shared raster body
// with a literal sample count, then choose once per task. This removes
// sample-count branches and address arithmetic from the inner loops.
#define WOBY_RASTER_SAMPLES 1u
#define WOBY_RASTER_POINT rasterProjectedPoint1
#define WOBY_RASTER_TASK rasterPointTask1
#define WOBY_RASTER_SAMPLE_POSITION(sample) float2(.5,.5)
#include "opaque_point_raster.slang"
#undef WOBY_RASTER_SAMPLES
#undef WOBY_RASTER_POINT
#undef WOBY_RASTER_TASK
#undef WOBY_RASTER_SAMPLE_POSITION
#define WOBY_RASTER_SAMPLES 4u
#define WOBY_RASTER_POINT rasterProjectedPoint4
#define WOBY_RASTER_TASK rasterPointTask4
#define WOBY_RASTER_SAMPLE_POSITION(sample) pointSamplePosition4(sample)
#include "opaque_point_raster.slang"
#undef WOBY_RASTER_SAMPLES
#undef WOBY_RASTER_POINT
#undef WOBY_RASTER_TASK
#undef WOBY_RASTER_SAMPLE_POSITION
[ForceInline] void rasterProjectedPoint(float4 clip,float pointSize,uint id,bool query,bool ids) {
    if (cloud.samples==1) rasterProjectedPoint1(clip,pointSize,id,query,ids);
    else rasterProjectedPoint4(clip,pointSize,id,query,ids);
}
[ForceInline] void rasterPoints(uint3 dispatch,uint lane,bool ids) {
    if (cloud.samples==1) rasterPointTask1(dispatch,lane,ids);
    else rasterPointTask4(dispatch,lane,ids);
}
#ifdef WOBY_POINT_ATOMIC64
[numthreads(128,1,1)] void cs_opaque_raster(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,false);
}
#else
[numthreads(128,1,1)] void cs_opaque_depth(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,false);
}
[numthreads(128,1,1)] void cs_opaque_ids(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,true);
}
#endif
struct ResolveVertex { float4 position:SV_Position; };
ResolveVertex vs_opaque_resolve(uint vertex:SV_VertexID) {
    ResolveVertex v; v.position=float4(vertex==1?3.0:-1.0,vertex==2?3.0:-1.0,0,1); return v;
}
struct ResolveOutput { float4 color:SV_Target0; float4 id:SV_Target1; float depth:SV_Depth; };
ResolveOutput fs_opaque_resolve(ResolveVertex input,uint sample:SV_SampleIndex) {
    uint2 relative=uint2(input.position.xy)-uint2(cloud.x,cloud.y);
    uint2 pixel=min(relative,uint2(cloud.width-1,cloud.height-1));
    // Helper lanes may execute outside a non-aligned viewport. Bound the address
    // even for discarded lanes; a discard alone does not guard a physical load.
    if (any(relative>=uint2(cloud.width,cloud.height))) { discard; return (ResolveOutput)0; }
    uint64 key=cloud.winners[(pixel.y*cloud.width+pixel.x)*cloud.samples+min(sample,cloud.samples-1)];
    uint id=uint(key);
    if (id==0) { discard; return (ResolveOutput)0; }
    uint lo=0,hi=cloud.groupCount;
    while (lo<hi) { uint mid=lo+(hi-lo)/2; if (cloud.groups[mid].endId<=id) lo=mid+1; else hi=mid; }
    if (lo>=cloud.groupCount) { discard; return (ResolveOutput)0; }
    ResolveOutput o;
    OpaquePointGroupData group=cloud.groups[min(lo,cloud.groupCount-1)];
    o.color=group.color;
    uint source=id-group.firstId+group.sourceFirstId-1;
    if (source<group.colorCount) {
        uint packed=group.colors[source];
        if ((packed>>24)!=0) o.color=float4(float3(packed&255,(packed>>8)&255,(packed>>16)&255)/255.0,group.color.a);
    }
    o.id=float4(float(id&255),float((id>>8)&255),float((id>>16)&255),float(id>>24))/255;
    o.depth=asfloat(uint(key>>32)); return o;
}
struct ColorResolveOutput { float4 color:SV_Target0; float depth:SV_Depth; };
ColorResolveOutput fs_opaque_color(ResolveVertex input,uint sample:SV_SampleIndex) {
    const ResolveOutput resolved=fs_opaque_resolve(input,sample);
    ColorResolveOutput output; output.color=resolved.color; output.depth=resolved.depth; return output;
}
