#include <NoGraphicsAPI/shader.slang>
#include "opaque_points.h"
GPU_ROOT(OpaquePointRoot, cloud);
// Slang's generic InterlockedMax currently emits the value-returning Metal
// overload even when its result is unused. Metal's ulong max returns void.
void pointAtomicMax64(uint64* address, uint64 value) {
    __target_switch {
    case metal:
        __intrinsic_asm "atomic_max_explicit((device atomic_ulong*)($0), $1, memory_order_relaxed)";
    default:
        if (WaveActiveAllEqual(uint64(address))) {
            value=WaveActiveMax(value);
            if (!WaveIsFirstLane()) return;
        }
        // Winners only increase during a raster dispatch. A relaxed atomic
        // read can skip a losing update; a stale read only adds redundant work.
        if (((Atomic<uint64>*)address)->load(MemoryOrder.Relaxed)<value)
            InterlockedMax(*address,value);
    }
}
void pointAtomicMax32(__ref uint destination, uint value) {
    __target_switch {
    case metal:
        __intrinsic_asm "(void)atomic_fetch_max_explicit((device atomic_uint*)($0), $1, memory_order_relaxed)";
    default:
        InterlockedMax(destination,value);
    }
}
float2 samplePosition(uint sample) {
    if (cloud.samples==1) return float2(.5,.5);
    const float2 positions[4]={float2(.375,.125),float2(.875,.375),float2(.125,.625),float2(.625,.875)};
    return positions[sample];
}
#ifdef WOBY_VULKAN
float opaqueSurfaceDepth(uint2 pixel,uint sample) {
    pixel+=uint2(cloud.x,cloud.y);
    if (cloud.samples==1) return gpu_texture<Texture2D<float>>(cloud.depthTexture).Load(int3(pixel,0));
    return gpu_texture<Texture2DMS<float>>(cloud.depthTexture).Load(pixel,sample);
}
#endif
[numthreads(8,8,1)] void cs_opaque_clear(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint depth=0;
#ifdef WOBY_VULKAN
        if (cloud.seedDepth!=0) depth=asuint(max(opaqueSurfaceDepth(thread.xy,sample),0.0));
#endif
        // A surface has ID zero. An equal-depth marker has a positive ID and
        // still wins. The fullscreen resolve discards surface-only entries.
        cloud.winners[(thread.y*cloud.width+thread.x)*cloud.samples+min(sample,cloud.samples-1)]=uint64(depth)<<32;
    }
    if (cloud.coverage!=nullptr) {
        const uint index=thread.y*cloud.width+thread.x;
        uint lowerBound=0;
#ifdef WOBY_VULKAN
        if (cloud.seedDepth!=0 && cloud.tileSize!=0) {
            const uint columns=(cloud.width+cloud.tileSize-1)>>cloud.tileShift;
            const uint rows=(cloud.height+cloud.tileSize-1)>>cloud.tileShift;
            if (index<columns*rows) {
                const uint2 first=uint2(index%columns,index/columns)*cloud.tileSize;
                const uint2 end=min(first+cloud.tileSize,uint2(cloud.width,cloud.height));
                lowerBound=asuint(1.0);
                for (uint y=first.y;y<end.y;++y) for (uint x=first.x;x<end.x;++x)
                    for (uint sample=0;sample<cloud.samples;++sample)
                        lowerBound=min(lowerBound,asuint(max(opaqueSurfaceDepth(uint2(x,y),sample),0.0)));
            }
        }
#endif
        cloud.coverage[index]=uint64(lowerBound)<<32;
    }
}
[numthreads(8,8,1)] void cs_opaque_batch_clear(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint index=(thread.y*cloud.width+thread.x)*cloud.samples+sample;
        cloud.batch[index].depth=0;
        cloud.batch[index].id=0;
    }
}
[numthreads(8,8,1)] void cs_opaque_merge(uint3 thread:SV_DispatchThreadID) {
    if (any(thread.xy>=uint2(cloud.width,cloud.height))) return;
    for (uint sample=0;sample<cloud.samples;++sample) {
        uint index=(thread.y*cloud.width+thread.x)*cloud.samples+sample;
        OpaquePointBatchSample winner=cloud.batch[index];
        // One invocation owns this sample. No 64-bit atomic is needed to merge
        // a completed batch into the persistent lexicographic depth/ID winner.
        uint64 key=(uint64(winner.depth)<<32)|uint64(winner.id);
        cloud.winners[index]=max(cloud.winners[index],key);
    }
}
[ForceInline] void rasterProjectedPoint(float4 clip,float pointSize,uint id,bool query,bool ids) {
        if (!all(isfinite(clip)) || clip.w<=0 || clip.z<0 || clip.z>clip.w) return;
        float2 center=float2(clip.x/clip.w*.5+.5,.5-clip.y/clip.w*.5)*float2(cloud.width,cloud.height);
        float radius=pointSize*.5;
        if (any(center+radius<0) || any(center-radius>=float2(cloud.width,cloud.height))) return;
        int2 lo=int2(max(float2(0),floor(center-radius)));
        int2 hi=int2(min(float2(cloud.width-1,cloud.height-1),floor(center+radius)));
        if (query) { lo=max(lo,int2(cloud.query.xy)); hi=min(hi,int2(cloud.query.zw)-1); }
        if (any(lo>hi)) return;
        uint depth=asuint(max(clip.z/clip.w,0.0));
        uint64 key=(uint64(depth)<<32)|uint64(id);
        // A disabled cache uses one 65536-pixel tile. Both paths use shifts,
        // not per-point integer division by a runtime tile size.
        int tileSize=int(1u<<cloud.tileShift);
        for (int tileY=lo.y>>cloud.tileShift;tileY<=(hi.y>>cloud.tileShift);++tileY)
            for (int tileX=lo.x>>cloud.tileShift;tileX<=(hi.x>>cloud.tileShift);++tileX) {
            int2 first=int2(tileX,tileY)*tileSize;
            int2 last=min(first+tileSize-1,int2(cloud.width,cloud.height)-1);
#if defined(WOBY_POINT_ATOMIC64) && defined(WOBY_VULKAN)
            if (cloud.tileSize!=0) {
                uint tileIndex=uint(tileY)*((cloud.width+cloud.tileSize-1)>>cloud.tileShift)+uint(tileX);
                if (((Atomic<uint64>*)(cloud.coverage+tileIndex))->load(MemoryOrder.Relaxed)>=key) continue;
                float lowSample=cloud.samples==1?.5:.125;
                float highSample=cloud.samples==1?.5:.875;
                float2 farthest=max(abs(float2(first)+lowSample-center),abs(float2(last)+highSample-center));
                bool completeQuery=!query || (all(first>=int2(cloud.query.xy)) && all(last<int2(cloud.query.zw)));
                // Publish only circles that cover the entire tile and query.
                // This invocation must then write all covered samples below.
                // A later, greater certificate can replace it; either way a
                // skipped point cannot win after this dispatch completes.
                if (completeQuery && dot(farthest,farthest)<=radius*radius)
                    pointAtomicMax64(cloud.coverage+tileIndex,key);
            }
#endif
            int2 start=max(lo,first),finish=min(hi,last);
            for (int y=start.y;y<=finish.y;++y) for (int x=start.x;x<=finish.x;++x) [unroll] for (uint sample=0;sample<4;++sample) {
                if (sample>=cloud.samples) break;
                float2 delta=float2(x,y)+samplePosition(sample)-center;
                if (dot(delta,delta)>radius*radius) continue;
                uint index=(uint(y)*cloud.width+uint(x))*cloud.samples+min(sample,cloud.samples-1);
#ifdef WOBY_POINT_ATOMIC64
                pointAtomicMax64(cloud.winners+index,key);
#else
                if (!ids) pointAtomicMax32(cloud.batch[index].depth,depth);
                else if (cloud.batch[index].depth==depth) pointAtomicMax32(cloud.batch[index].id,id);
#endif
            }
        }
}
[ForceInline] void rasterPoints(uint3 dispatch,uint lane,bool ids) {
    uint taskIndex=dispatch.y*cloud.dispatchWidth+dispatch.x;
    if (taskIndex>=cloud.taskCount) return;
    OpaquePointTaskData task=cloud.tasks[taskIndex];
    OpaquePointGroupData group=cloud.groups[task.group];
    for (uint i=lane;i<task.count;i+=128) {
        OpaquePoint p=task.points[i];
        rasterProjectedPoint(mul(group.matrix,float4(p.position,1)),group.pointSize,
            group.firstId+p.id-group.sourceFirstId,task.query!=0,ids);
    }
}
#ifdef WOBY_POINT_ATOMIC64
[numthreads(128,1,1)] void cs_opaque_raster(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,false);
}
#else
[numthreads(128,1,1)] void cs_opaque_depth(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,false);
}
[numthreads(128,1,1)] void cs_opaque_ids(uint3 dispatch:SV_GroupID,uint lane:SV_GroupIndex) {
    rasterPoints(dispatch,lane,true);
}
#endif
struct ResolveVertex { float4 position:SV_Position; };
ResolveVertex vs_opaque_resolve(uint vertex:SV_VertexID) {
    ResolveVertex v; v.position=float4(vertex==1?3.0:-1.0,vertex==2?3.0:-1.0,0,1); return v;
}
struct ResolveOutput { float4 color:SV_Target0; float4 id:SV_Target1; float depth:SV_Depth; };
ResolveOutput fs_opaque_resolve(ResolveVertex input,uint sample:SV_SampleIndex) {
    uint2 relative=uint2(input.position.xy)-uint2(cloud.x,cloud.y);
    uint2 pixel=min(relative,uint2(cloud.width-1,cloud.height-1));
    // Helper lanes may execute outside a non-aligned viewport. Bound the address
    // even for discarded lanes; a discard alone does not guard a physical load.
    if (any(relative>=uint2(cloud.width,cloud.height))) { discard; return (ResolveOutput)0; }
    uint64 key=cloud.winners[(pixel.y*cloud.width+pixel.x)*cloud.samples+min(sample,cloud.samples-1)];
    uint id=uint(key);
    if (id==0) { discard; return (ResolveOutput)0; }
    uint lo=0,hi=cloud.groupCount;
    while (lo<hi) { uint mid=lo+(hi-lo)/2; if (cloud.groups[mid].endId<=id) lo=mid+1; else hi=mid; }
    if (lo>=cloud.groupCount) { discard; return (ResolveOutput)0; }
    ResolveOutput o;
    OpaquePointGroupData group=cloud.groups[min(lo,cloud.groupCount-1)];
    o.color=group.color;
    uint source=id-group.firstId+group.sourceFirstId-1;
    if (source<group.colorCount) {
        uint packed=group.colors[source];
        if ((packed>>24)!=0) o.color=float4(float3(packed&255,(packed>>8)&255,(packed>>16)&255)/255.0,group.color.a);
    }
    o.id=float4(float(id&255),float((id>>8)&255),float((id>>16)&255),float(id>>24))/255;
    o.depth=asfloat(uint(key>>32)); return o;
}
struct ColorResolveOutput { float4 color:SV_Target0; float depth:SV_Depth; };
ColorResolveOutput fs_opaque_color(ResolveVertex input,uint sample:SV_SampleIndex) {
    const ResolveOutput resolved=fs_opaque_resolve(input,sample);
    ColorResolveOutput output; output.color=resolved.color; output.depth=resolved.depth; return output;
}
