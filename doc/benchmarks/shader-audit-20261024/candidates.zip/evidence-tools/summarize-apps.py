# /// script
# requires-python = ">=3.13"
# dependencies = ["Pillow>=11"]
# ///
"""Compare serial application measurements and full-detail exported pixels."""
import json
from pathlib import Path
import statistics
from PIL import Image

source = Path(__file__).resolve().parent
result = {}
for model in ("semantic100m", "beartrap", "semantic100m-navigation"):
    expected_cases=6 if model.endswith("navigation") else 4
    reports = {version:json.loads((source/f"app-{model}-{version}/measurements.json").read_text())
        for version in ("reference", "retained")}
    for report in reports.values():
        assert report["status"]=="completed" and not report["guard"]["violations"]
        assert len(report["rounds"])==expected_cases
    assert reports["reference"]["initial_camera"] == reports["retained"]["initial_camera"]
    assert reports["reference"]["model_sha256"] == reports["retained"]["model_sha256"]
    comparisons=[]
    for size in (4,8):
        for phase,field in (("full", "raster_frame_gpu_ms"), ("navigation", "raster_frame_gpu_ms"), ("cached", "gpu_ms")):
            values = {version:[row["summary"][phase][field]["median"] for row in report["rounds"] if row["size"]==size]
                for version,report in reports.items()}
            medians = {name:statistics.median(rows) for name,rows in values.items()}
            comparisons.append(dict(size=size,phase=phase,reference_ms=medians["reference"],retained_ms=medians["retained"],
                reduction_percent=100*(1-medians["retained"]/medians["reference"]),round_medians=values))
    images=[]
    for filename in ("cloud-only-4px.png", "cloud-only-8px.png", "full-detail.png"):
        with Image.open(source/f"app-{model}-reference"/filename) as reference, Image.open(source/f"app-{model}-retained"/filename) as retained:
            assert reference.size==retained.size
            # Inspect every channel. RGBA getbbox alone can ignore RGB changes
            # when the alpha difference is zero.
            before=reference.convert("RGBA").tobytes()
            after=retained.convert("RGBA").tobytes()
            changed=sum(before[i:i+4]!=after[i:i+4] for i in range(0,len(before),4))
            images.append(dict(filename=filename,dimensions=reference.size,different_pixels=changed))
    result[model]=dict(comparisons=comparisons,exports=images,
        exact_exports=all(row["different_pixels"]==0 for row in images),
        scope=f"Serial whole-application GPU time; {expected_cases//2} rounds. Hidden window uses 20 Hz pacing. Not FPS or paired per-frame ratios.")
(source/"application-summary.json").write_text(json.dumps(result,indent=2)+"\n")
for model,report in result.items():
    print(model, "exact exports:",report["exact_exports"])
    for row in report["comparisons"]:
        print(f"{row['size']} px {row['phase']:10}: {row['reference_ms']:.3f} -> {row['retained_ms']:.3f} ms ({row['reduction_percent']:.1f}%)")
