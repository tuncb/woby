"""Record the instruction-equivalence check and final runtime hashes."""
import hashlib
import json
from pathlib import Path

source=Path(__file__).resolve().parent
root=source.parents[1]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

records=[]
for entry in ("cs_opaque_raster", "cs_opaque_depth", "cs_opaque_ids"):
    hashes={}
    for name in ("sample-count", "sample-generic", "sample-shared"):
        normalized=source/"normalized"/(name+"-"+entry+".spv")
        hashes[name]=dict(raw_sha256=digest(source/"variants"/name/"spirv"/(entry+".bin")),
            normalized_sha256=digest(normalized))
    assert len({row["normalized_sha256"] for row in hashes.values()})==1
    records.append(dict(entry=entry,forms=hashes))
(source/"normalization.json").write_text(json.dumps(dict(
    operation="spirv-opt --strip-debug --compact-ids INPUT -o OUTPUT",
    tool="C:/VulkanSDK/1.4.357.0/Bin/spirv-opt.exe",entries=records),indent=2)+"\n")
verification=json.loads((source/"verification.json").read_text())
runtime=root/"build/vs2026-vcpkg/bin/Release"
assert digest(runtime/"woby.exe")==verification["retained_executable_sha256"]
for entry in verification["entries"]:
    assert digest(runtime/"assets/shaders/spirv"/(entry["entry"]+".bin"))==entry["runtime_sha256"]
print("Normalized instructions match for all three source forms; final runtime hashes still match the verified build.")
