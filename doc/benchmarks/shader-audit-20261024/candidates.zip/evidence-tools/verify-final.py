"""Record final shader provenance and translate every entry to Metal source."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
runtime = root / "build/vs2026-vcpkg/bin/Release"
reference = evidence / "baseline-app"
candidate = evidence / "variants/sample-generic/spirv"
compiler = Path("C:/tools/slang/2026.18.3/bin/slangc.exe")
validator = Path("C:/VulkanSDK/1.4.357.0/Bin/spirv-val.exe")
ngapi = root / "build/vs2026-vcpkg/_deps/woby_ngapi-src"
output = evidence / "metal-source"
output.mkdir(exist_ok=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

records = []
with (evidence / "metal-translation.log").open("w") as log:
    for binary in sorted((runtime / "assets/shaders/spirv").glob("*.bin")):
        entry = binary.stem
        source = root / "shaders/native" / ("opaque_points.slang" if "_opaque_" in entry else "woby.slang")
        command = [str(compiler), str(source), "-target", "metal", "-DNOGRAPHICSAPI_METAL",
            "-warnings-as-errors", "all", "-entry", entry, "-stage",
            "compute" if entry.startswith("cs_") else "vertex" if entry.startswith("vs_") else "fragment",
            "-fvk-use-c-layout", "-matrix-layout-row-major", "-I", str(ngapi/"include"),
            "-I", str(ngapi/"utility/include"), "-o", str(output/(entry+".metal"))]
        if entry == "cs_opaque_raster": command.append("-DWOBY_POINT_ATOMIC64")
        log.write(entry+"\n"); log.flush()
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        subprocess.run([str(validator), "--target-env", "vulkan1.4", "--scalar-block-layout", str(binary)],
            stdout=log, stderr=subprocess.STDOUT, check=True)
        record = dict(entry=entry, runtime_sha256=digest(binary),
            reference_sha256=digest(reference/"assets/shaders/spirv"/binary.name),
            measured_candidate_sha256=digest(candidate/binary.name),
            metal_source_sha256=digest(output/(entry+".metal")), metal_command=command)
        assert record["runtime_sha256"] == record["measured_candidate_sha256"], entry
        records.append(record)
changed = [r["entry"] for r in records if r["runtime_sha256"]!=r["reference_sha256"]]
assert len(records)==44
assert changed==["cs_opaque_depth", "cs_opaque_ids", "cs_opaque_raster"], changed
report = dict(entries=records, changed_entries=changed,
    measured_candidate_matches_runtime=True,
    reference_executable_sha256=digest(reference/"woby.exe"),
    retained_executable_sha256=digest(runtime/"woby.exe"),
    metal_scope="Slang source translation only. No Apple native compiler or Metal GPU was available.")
(evidence/"verification.json").write_text(json.dumps(report,indent=2)+"\n")
print("44 production shaders validated and translated; all match the measured candidate. Only three compute entries changed.")
