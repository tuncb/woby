"""Retain compact evidence for the shader audit; omit large models and binaries."""
import csv
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
source = Path(__file__).resolve().parent
destination = root / "doc/benchmarks/shader-audit-20261024"
destination.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location("summary", root/"experiments/point-pipeline/audit_summary.py")
summary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summary)
accepted, excluded, rows = {}, {}, []
for directory in sorted(source.iterdir()):
    if not directory.is_dir() or not (directory/"run.json").exists():
        continue
    run = json.loads((directory/"run.json").read_text())
    measurements = json.loads((directory/"measurements.json").read_text()) if (directory/"measurements.json").exists() else {}
    complete = run.get("exit_code") == 0 and run.get("guard_reason") is None and "exact_samples" in measurements
    for filename in ("run.json", "measurements.json", "run.log", "interrupted.txt"):
        path = directory/filename
        if path.exists():
            (destination/(directory.name+"-"+filename+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    if not complete:
        excluded[directory.name] = dict(exit_code=run.get("exit_code"), guard=run.get("guard_reason"),
            note=(directory/"interrupted.txt").read_text().strip() if (directory/"interrupted.txt").exists() else "Incomplete; no performance claim")
        continue
    aggregated = summary.summarize(measurements)
    accepted[directory.name] = dict(model=run["configuration"]["model"],
        points=measurements["points"], triangles=measurements["triangles"], groups=measurements["groups"],
        cases=len(measurements["validation"]), samples=sum(r["samples"] for r in measurements["validation"]),
        exact=measurements["exact_samples"], gpu_frames=sum(len(r["gpu_ms"]) for r in measurements["rounds"]),
        elapsed_seconds=run["elapsed_seconds"], peak_private=run["peak_private"],minimum_available=run["minimum_available"],
        variants=[v["name"] for v in run["configuration"]["variants"]])
    (destination/(directory.name+"-summary.json.gz")).write_bytes(gzip.compress(json.dumps(aggregated,indent=2).encode(),mtime=0))
    for row in aggregated:
        rows.append(dict(campaign=directory.name,kind=row["kind"],size=row["point_size"],variant=row["variant"],
            median_ms=row["median_ms"],minimum_round_ms=row["round_range_ms"][0],maximum_round_ms=row["round_range_ms"][1],
            paired_reduction_percent=row["reduction_percent"],exact=row["exact"]))
with (destination/"summary.csv").open("w",newline="") as stream:
    writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
    writer.writeheader(); writer.writerows(rows)
candidates = []
with zipfile.ZipFile(destination/"candidates.zip","w",zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for directory in sorted((source/"variants").iterdir()):
        if not (directory/"manifest.json").exists(): continue
        candidates.append(directory.name)
        for path in directory.rglob("*"):
            if path.is_file() and path.suffix!=".bin": archive.write(path,str(path.relative_to(source/"variants")))
    for path in (source/"baseline-source").glob("*"):
        if path.is_file(): archive.write(path,"reference/"+path.name)
    # Preserve the intermediate probes used by the final screens as well as the
    # maintained source. Early screen revisions are identified by their hashes.
    for directory in ("final-probe-source", "generic-probe-source"):
        for path in (source/directory).rglob("*"):
            if path.is_file(): archive.write(path,str(path.relative_to(source)))
    for directory in (root/"experiments/point-pipeline", root/"shaders/native"):
        for path in directory.glob("*"):
            if path.is_file(): archive.write(path,"retained/"+str(path.relative_to(root)))
    for filename in ("archive.py", "verify-final.py", "summarize-apps.py", "final-checks.ps1", "record-normalization.py"):
        archive.write(source/filename,"evidence-tools/"+filename)
applications={}
images={}
with zipfile.ZipFile(destination/"application-exports.zip","w",zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for directory in sorted(source.glob("app-*")):
        if not directory.is_dir() or not (directory/"measurements.json").exists(): continue
        report=json.loads((directory/"measurements.json").read_text())
        assert report.get("status")=="completed" and not report["guard"]["violations"], directory
        applications[directory.name]=dict(model=report["model"], rounds=len(report["rounds"]),
            elapsed_seconds=report["guard"]["elapsed_seconds"], peak_private=report["guard"]["peak_private"],
            minimum_available=report["guard"]["minimum_available"])
        for filename in ("measurements.json", "console.log", "viewer.log"):
            path=directory/filename
            if path.exists():
                (destination/(directory.name+"-"+filename+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
        for path in sorted(directory.glob("*.png")):
            sha=hashlib.sha256(path.read_bytes()).hexdigest()
            if sha not in images: archive.write(path,sha+".png")
            images.setdefault(sha,[]).append(str(path.relative_to(source)))
    archive.writestr("images.json",json.dumps(images,indent=2))
for filename in ("verification.json", "application-summary.json", "normalization.json", "machine.json"):
    path=source/filename
    if path.exists(): (destination/filename).write_bytes(path.read_bytes())
for filename in ("production-build.log", "production-targeted-tests.log", "final-tests.log", "camera-recheck.log",
        "metal-translation.log", "vulkan-validation.log", "msaa-transition-reference.log",
        "combined-layout-build.log", "final-probe-tests.log"):
    path=source/filename
    if path.exists(): (destination/(filename+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
manifest = dict(reference_commit="f83fb21",candidates=candidates,campaigns=accepted,excluded=excluded,applications=applications,
    totals=dict(cases=sum(r["cases"] for r in accepted.values()),
                samples=sum(r["samples"] for r in accepted.values()),
                gpu_frames=sum(r["gpu_frames"] for r in accepted.values()),
                all_exact=all(r["exact"] for r in accepted.values())),
    files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.iterdir()) if p.is_file() and p.name!="manifest.json"})
(destination/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest["totals"]))
print("accepted:",len(accepted),"excluded:",len(excluded),"candidates:",len(candidates))
