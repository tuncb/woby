$ErrorActionPreference = 'Stop'
$taskRoot = 'D:/woby/build/shader-audit-20261024'
$taskCheck = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'ctest.exe' -and $_.CommandLine -match 'until-fail:3' }
foreach ($process in $taskCheck) { Wait-Process -Id $process.ProcessId -Timeout 240 }
if (-not (Select-String -LiteralPath "$taskRoot/camera-recheck.log" -Pattern '100% tests passed' -Quiet)) {
    throw 'Camera and reporting rechecks did not pass'
}
foreach ($version in @('retained','reference')) {
    $binary = if ($version -eq 'reference') { "$taskRoot/baseline-app/woby.exe" } else { 'D:/woby/build/vs2026-vcpkg/bin/Release/woby.exe' }
    & uv run tests/point_render_benchmark.py $binary D:/temp/obj_tests/pointclouds/semantic3d_sg27_station8_100000000_xyz_points.obj "$taskRoot/app-semantic100m-navigation-$version" --rounds 3 --sizes 4 8 --full-frames 24 --navigation-frames 96 --points-only
    if ($LASTEXITCODE -ne 0) { throw "Navigation confirmation failed: $version" }
}
uv run build/shader-audit-20261024/summarize-apps.py
if ($LASTEXITCODE -ne 0) { throw 'Application comparison failed' }
uv run build/shader-audit-20261024/verify-final.py
if ($LASTEXITCODE -ne 0) { throw 'Shader validation failed' }
$taskSettings = "$taskRoot/vulkan-settings"
New-Item -ItemType Directory -Path $taskSettings -Force | Out-Null
@'
khronos_validation.validate_core = true
khronos_validation.validate_sync = true
khronos_validation.debug_action = VK_DBG_LAYER_ACTION_LOG_MSG
khronos_validation.log_filename = stdout
khronos_validation.report_flags = error,warn,info
khronos_validation.enable_message_limit = false
'@ | Set-Content -LiteralPath "$taskSettings/vk_layer_settings.txt"
$env:VK_INSTANCE_LAYERS = 'VK_LAYER_KHRONOS_validation'
$env:VK_LAYER_SETTINGS_PATH = $taskSettings
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
ctest --test-dir build/vs2026-vcpkg -C Release -V -R 'adaptive_points_gpu_tests|shader_audit_gpu|point_pipeline_gpu' *> "$taskRoot/vulkan-validation.log"
$taskExit = $LASTEXITCODE
Get-Content "$taskRoot/vulkan-validation.log" -Tail 35
exit $taskExit
