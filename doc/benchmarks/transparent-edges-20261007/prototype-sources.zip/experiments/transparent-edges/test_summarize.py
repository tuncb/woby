import copy
import hashlib
import json
import unittest
from summarize import aggregate


def fixture():
    rows=[]
    for round_index,(baseline,candidate) in enumerate(((10,2),(20,4),(30,6))):
        for name,time in (("legacy",baseline),("matched",candidate)):
            rows.append(dict(round=round_index,condition=name,frames=30,surface_opacity=.35,
                capture=dict(droppedFrames=0),gpu_ms=dict(median=time,p95=time*2),
                scene_submit_ms=dict(median=.1),graphics_submit_ms=dict(median=.2),main_thread_work_ms=dict(median=.4),
                memory=dict(geometryBytes=100,textureHeapBytes=200,overlayImageBytes=0),
                experiment=dict(frameDraws=3),gpu_stages={name:dict(median=1) for name in
                    ("transparencyAccumMs","transparencyResolveMs","triangleLinesMs")}))
    return dict(status="completed",guard=dict(violations=[]),shader_hashes=dict(shader="hash"),
                surface_opacity=.35,rounds=3,cases=rows)


def expect_rejected(report):
    try:
        aggregate(report)
    except AssertionError:
        return
    raise AssertionError("Invalid measurement run was accepted")


def test_scene_snapshot_integrity():
    report=fixture(); snapshot={"opacity":.35,"triangles":100}
    key=hashlib.sha256(json.dumps(snapshot,sort_keys=True).encode("utf-8")).hexdigest()
    report["scene_snapshots"]={key:snapshot}
    report["cases"][0]["capture"]["sceneSnapshotSHA256"]=key
    assert len(aggregate(report))==2
    snapshot["triangles"]=50
    expect_rejected(report)


def test_pairing_and_independent_rounds():
    rows=aggregate(fixture())
    assert rows[1]["gpu_ms"]==4
    assert rows[1]["paired_speedup"]==5
    assert rows[1]["paired_saved_ms"]==16
    assert rows[1]["frames"]==90


def test_reject_incomplete_or_confounded_runs():
    for key,value in (("status","failed"),("rounds",4),("shader_hashes",{}),("surface_opacity",.7)):
        report=fixture(); report[key]=value
        expect_rejected(report)
    for mutate in (lambda r:r["guard"]["violations"].append("overlap"),
                   lambda r:r["cases"][0]["memory"].update(geometryBytes=99),
                   lambda r:r["cases"][0].update(frames=3),
                   lambda r:r["cases"][0]["capture"].update(droppedFrames=2),
                   lambda r:r["cases"].append(copy.deepcopy(r["cases"][0]))):
        report=fixture(); mutate(report)
        expect_rejected(report)


if __name__=="__main__":
    functions=[value for name,value in globals().items() if name.startswith("test_") and callable(value)]
    result=unittest.TextTestRunner().run(unittest.TestSuite(unittest.FunctionTestCase(fn) for fn in functions))
    raise SystemExit(0 if result.wasSuccessful() else 1)
