# /// script
# requires-python = ">=3.13"
# dependencies = ["matplotlib>=3.10", "Pillow>=11"]
# ///
"""Plot measured GPU times and unretouched rendered policy comparisons."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image,ImageChops


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--fixture",type=Path)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    reports=json.loads(args.summary.read_text(encoding="utf-8"))
    names={"bus-4x":"BusGameMap · 1.05M triangles","bennu-4x":"Bennu · 17.87M triangles",
           "bear-4x":"BearTrap · 75.77M triangles","sanmiguel-4x":"San Miguel · 9.98M triangles / 2,203 groups"}
    policies=(("legacy","Current separate draws","#707a86"),("matched","Matched opacity","#158d87"),
              ("coating","Coated edges","#307bc4"),("overlay","Separate edge image","#ac65be"))
    fig,axes=plt.subplots(2,2,figsize=(12,7),layout="constrained")
    for ax,run_name in zip(axes.flat,names):
        report=next(r for r in reports if Path(r["run"]).name==run_name)
        rows={r["condition"]:r for r in report["conditions"]}
        for y,(name,label,color) in enumerate(policies):
            row=rows[name]; value=row["gpu_ms"]
            ax.barh(y,value,height=.65,color=color)
            ax.errorbar(value,y,xerr=[[value-row["round_min_ms"]],[row["round_max_ms"]-value]],fmt="none",color="#15232e",capsize=3)
            ax.text(row["round_max_ms"]+rows["legacy"]["gpu_ms"]*.025,y,f"{value:.2f} ms",va="center",fontsize=10)
        ax.set_yticks(range(4),[p[1] for p in policies]); ax.invert_yaxis()
        ax.set_title(names[run_name],loc="left",fontsize=12,fontweight="bold",pad=14)
        ax.set_xlabel("GPU frame time (ms) · lower is better")
        ax.set_xlim(0,rows["legacy"]["round_max_ms"]*1.22)
        ax.spines[["top","right","left"]].set_visible(False)
        ax.grid(axis="x",alpha=.14); ax.set_axisbelow(True); ax.tick_params(axis="y",length=0)
    fig.suptitle("One triangle draw removes the expensive line workload",fontsize=19,fontweight="bold")
    fig.savefig(args.output/"gpu-times.png",dpi=160,facecolor="white"); plt.close(fig)
    if args.fixture:
        policies=(("legacy","Current transparent lines"),("matched","Matched: edge alpha stays 0.35"),
                  ("coating","Coated: local edge alpha up to 0.58"),("opaque","Opaque material: OIT still mixes colors"),
                  ("overlay","Edge image: transparent overlay"),("overlay-opaque","Edge image: opaque overlay"))
        source=Image.open(args.fixture/"surface.png").convert("RGB")
        background=Image.new("RGB",source.size,source.getpixel((0,0)))
        box=ImageChops.difference(source,background).getbbox()
        assert box, "Blank fixture"
        box=(max(0,box[0]-40),max(0,box[1]-40),min(source.width,box[2]+40),min(source.height,box[3]+40))
        fig,axes=plt.subplots(2,3,figsize=(13,8),layout="constrained")
        for ax,(name,label) in zip(axes.flat,policies):
            with Image.open(args.fixture/(name+".png")) as image:
                ax.imshow(image.crop(box),interpolation="hanning")
            ax.set_title(label,fontsize=11,pad=9); ax.axis("off")
        fig.suptitle("Same intersecting sheets · same camera · surface opacity 35%",fontsize=17,fontweight="bold")
        fig.savefig(args.output/"edge-appearance.png",dpi=160,facecolor="white"); plt.close(fig)


if __name__=="__main__": main()
