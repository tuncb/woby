# Transparent edge research prototype

This isolated prototype measures issue 118 with unchanged source triangles. It
is not a selected product behavior. `performance.begin` accepts a research
`name` in this build; no scene property or saved file format is changed.

| Name | Edge calculation | Geometry submissions for each transparent group |
| --- | --- | --- |
| legacy | Existing hardware lines with inherited opacity | Surface + lines |
| legacy-opaque | Existing hardware lines with alpha 1 | Surface + lines |
| matched | Edge RGB in the surface material; unchanged alpha | One triangle draw |
| coating | Edge with inherited alpha over the local surface, then weighted OIT | One triangle draw |
| opaque | Edge with alpha 1 over the local surface, then weighted OIT | One triangle draw |
| overlay | Ordinary surface OIT plus premultiplied edges in a third render target | One triangle draw |
| overlay-opaque | Third render target with alpha 1 edges | One triangle draw |

The five combined policies support a `-pulled` suffix to force the barycentric
fallback. Native barycentrics use the existing indexed mesh. The fallback
reads the existing indices and emits three vertices per triangle. Both retain
UVs and original point identifiers. X-ray and edge-only drawing keep their
existing path. All policies omit edges when the surface opacity is zero.

`opaque` means local material alpha 1 at full edge coverage. Weighted OIT can
still mix color from overlapping layers. It does not guarantee nearest-edge
occlusion. The two image policies composite edges after the resolved surfaces,
retaining edge prominence and source-order dependence. Barycentric lines are
covered inside triangles and do not exactly reproduce hardware-line silhouettes
or the repeated opacity of duplicated shared lines.

## Running

Build Debug and run the tests with `vs2026-vcpkg`, then build `woby` in Release.
For example, from the worktree root:

```powershell
uv run experiments/transparent-edges/run.py `
  build/vs2026-vcpkg/bin/Release/woby.exe `
  D:/temp/obj_tests/uploads_files_2720101_BusGameMap.obj `
  build/transparent-edges/bus --rounds 3 --capture --visible-window
```

Use a new output folder for every run. Options include `--samples 1`,
`--opacity .1`, `--zoom .4` (closer), `--zoom 2.5` (farther), and a comma-separated
`--cases` list. `--group-colors` is only for small qualitative fixtures.

Use the active viewer (`--visible-window`) for measurements. Hidden windows let
the laptop GPU downclock into P8 and inflate timings. The runner fixes the
1280x720 drawable and isometric camera, disables vertices and helpers, and
fixes scene settings.
Cases rotate across rounds in the same process. Each measurement follows warmup,
retains at least 24 GPU samples after discarding three frames at both ends,
and saves the raw capture, executable/source/shader/model hashes, camera,
environment, GPU telemetry, and resource guard record. Screenshots are exported
only after the timing rounds. Their export resolution differs from the timed
viewport and their GPU costs are not used as interactive frame timings.
Later runner versions deduplicate identical scene snapshots by SHA-256 and
write each gzip checkpoint atomically. These changes affect storage outside the
measurement interval. The original core runner is retained with the raw runs.

GPU pass timestamps measure transparency accumulation (including pass
transitions), fullscreen transparency resolve, and the contiguous procedural
triangle-line block. CPU `scene_submit_ms` measures creation of the scene draw
commands. The existing `cpuSubmitMilliseconds` includes graphics frame pacing;
do not label it CPU command execution cost. Geometry memory is the sum of live
GPU vertex/index buffer payloads. Image memory is a logical attachment estimate;
the backend's allocated texture heap is recorded separately. Extra overlay
images persist after creation during a paired run.

Only one Woby/build/test workload is allowed, with private memory below 38 GiB,
available system memory above 6 GiB, and a 20 minute limit per run. Violations
terminate this runner's viewer and invalidate the run. Device validation errors
also fail a run.

```powershell
uv run experiments/transparent-edges/summarize.py `
  build/transparent-edges/bus build/transparent-edges/bennu `
  --output build/transparent-edges/summary
uv run experiments/transparent-edges/test_summarize.py
```

The summary uses per-round medians as independent observations and computes
speedups paired to the legacy condition in the same round. It rejects incomplete,
undersampled, geometry-changing, overflowed, or guard-violating runs.

Vulkan runs on the local RTX 3070 Laptop GPU. Slang compilation to Metal source
checks portability of all six new fragment entries; it does not validate Metal
runtime performance.
