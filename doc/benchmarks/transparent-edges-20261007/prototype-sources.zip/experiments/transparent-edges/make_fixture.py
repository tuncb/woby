"""Create two intersecting, independently colored sheets for image comparison."""
import argparse
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    assert not args.output.exists(), "Choose a new fixture path"
    args.output.parent.mkdir(parents=True,exist_ok=True)
    lines=[]; vertices=0
    for name,direction,shift in (("red",1,0),("blue",-1,.15)):
        count=4
        base=vertices+1
        for y in range(count+1):
            for x in range(count+1):
                px=-1+2*x/count+shift; py=-1+2*y/count-shift
                # The viewer defaults to Z-up; its front camera looks from -Y.
                lines.append(f"v {px} {direction*px*.6} {py}")
                vertices+=1
        lines.append(f"g {name}")
        for y in range(count):
            for x in range(count):
                a=base+y*(count+1)+x; b=a+1; d=a+count+1; c=d+1
                lines.extend((f"f {a} {b} {c}",f"f {a} {c} {d}"))
    args.output.write_text("\n".join(lines)+"\n",encoding="utf-8")


if __name__=="__main__": main()
