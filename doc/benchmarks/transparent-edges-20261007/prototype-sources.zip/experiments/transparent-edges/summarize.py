"""Validate and summarize paired runs; use round medians as the observation unit."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import statistics


def aggregate(report):
    assert report.get("status") == "completed", "Incomplete run"
    assert not report["guard"]["violations"], "Resource guard violation"
    assert report["shader_hashes"], "Missing shader fingerprints"
    groups={}
    geometry=set()
    for sample in report["cases"]:
        assert sample["frames"] >= 24, "Insufficient samples"
        assert not sample["capture"]["droppedFrames"], "Capture overflow"
        assert sample["gpu_ms"]["median"] > 0, "Invalid GPU time"
        assert sample["surface_opacity"] == report["surface_opacity"], "Changed opacity"
        capture=sample["capture"]
        if "sceneSnapshotSHA256" in capture:
            key=capture["sceneSnapshotSHA256"]
            snapshot=report["scene_snapshots"][key]
            assert hashlib.sha256(json.dumps(snapshot,sort_keys=True).encode("utf-8")).hexdigest()==key, "Changed scene snapshot"
        elif "sceneBefore" in capture:
            assert capture["sceneBefore"]==capture["sceneAfter"], "Changed scene"
        if "fixed_frame_camera" in report:
            for event in capture["events"][3:-3]:
                assert event["camera"]==report["fixed_frame_camera"], "Changed camera"
                assert event["points"]["submittedCount"]==0 and event["points"]["gpuRasterCount"]==0, "Point workload"
            for environment in capture["environments"]:
                assert environment["drawable"]==report["environment"]["drawable"], "Changed drawable"
                assert environment["viewport"]==report["environment"]["viewport"], "Changed viewport"
                assert environment["pacing"]["msaaSamples"]==report["msaa_samples"], "Changed MSAA"
        geometry.add(sample["memory"]["geometryBytes"])
        groups.setdefault(sample["condition"],[]).append(sample)
    assert len(geometry)==1, "Changed geometry"
    assert groups, "Empty run"
    rows=[]
    baseline={sample["round"]:sample["gpu_ms"]["median"] for sample in groups.get("legacy",[])}
    for name,samples in groups.items():
        assert sorted(sample["round"] for sample in samples)==list(range(report["rounds"])), "Missing/duplicate round"
        medians=[sample["gpu_ms"]["median"] for sample in samples]
        row=dict(condition=name,rounds=len(samples),frames=sum(sample["frames"] for sample in samples),
                 gpu_ms=statistics.median(medians),round_min_ms=min(medians),round_max_ms=max(medians),
                 frame_p95_ms=statistics.median(sample["gpu_ms"]["p95"] for sample in samples),
                 scene_cpu_ms=statistics.median(sample["scene_submit_ms"]["median"] for sample in samples),
                 graphics_cpu_ms=statistics.median(sample["graphics_submit_ms"]["median"] for sample in samples),
                 main_thread_work_ms=statistics.median(sample["main_thread_work_ms"]["median"] for sample in samples),
                 draws=statistics.median(sample["experiment"]["frameDraws"] for sample in samples),
                 geometry_bytes=next(iter(geometry)),
                 texture_heap_bytes=max(sample["memory"]["textureHeapBytes"] for sample in samples),
                 overlay_image_bytes=max(sample["memory"]["overlayImageBytes"] for sample in samples))
        for stage in ("transparencyAccumMs","transparencyResolveMs","triangleLinesMs"):
            row[stage]=statistics.median(sample["gpu_stages"][stage]["median"] for sample in samples)
        if baseline:
            row["paired_speedup"]=statistics.median(baseline[sample["round"]]/sample["gpu_ms"]["median"] for sample in samples)
            row["paired_saved_ms"]=statistics.median(baseline[sample["round"]]-sample["gpu_ms"]["median"] for sample in samples)
        rows.append(row)
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs",nargs="+",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    reports=[]
    all_rows=[]
    build_hashes=set()
    shader_hashes=set()
    source_hashes=set()
    for run in args.runs:
        with gzip.open(run/"measurements.json.gz","rt",encoding="utf-8") as stream:
            report=json.load(stream)
        rows=aggregate(report)
        build_hashes.add(report["executable_sha256"])
        shader_hashes.add(json.dumps(report["shader_hashes"],sort_keys=True))
        source_hashes.add(json.dumps(report["source_hashes"],sort_keys=True))
        metadata={key:report[key] for key in ("model","model_sha256","source_revision","source_hashes","shader_hashes",
                    "executable_sha256","runner_sha256","msaa_samples","surface_opacity","zoom","camera","stats","environment","guard")}
        reports.append(dict(run=str(run.resolve()),**metadata,conditions=rows))
        for row in rows:
            all_rows.append(dict(run=run.name,msaa=report["msaa_samples"],opacity=report["surface_opacity"],zoom=report["zoom"],**row))
    assert len(build_hashes)==1, "Different executable builds"
    assert len(shader_hashes)==1, "Different shader builds"
    assert len(source_hashes)==1, "Different rendering sources"
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/"summary.json").write_text(json.dumps(reports,indent=2),encoding="utf-8")
    fields=list(dict.fromkeys(key for row in all_rows for key in row))
    with (args.output/"summary.csv").open("w",newline="",encoding="utf-8") as stream:
        writer=csv.DictWriter(stream,fieldnames=fields); writer.writeheader(); writer.writerows(all_rows)
    for report in reports:
        print(Path(report["run"]).name)
        for row in report["conditions"]:
            print(f"  {row['condition']:18} {row['gpu_ms']:9.4f} ms  rounds {row['round_min_ms']:.4f}..{row['round_max_ms']:.4f}  scene CPU {row['scene_cpu_ms']:.4f}")


if __name__=="__main__":
    main()
