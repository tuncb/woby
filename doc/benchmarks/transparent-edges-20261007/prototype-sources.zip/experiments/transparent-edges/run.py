# /// script
# requires-python = ">=3.13"
# dependencies = ["psutil>=6", "Pillow>=11"]
# ///
"""Compare transparent edge prototypes in the normal viewer with fixed geometry."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import tempfile
import threading
import time
import urllib.request
import uuid

import psutil
from PIL import Image

REPOSITORY = Path(__file__).resolve().parents[2]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def distribution(values):
    values = sorted(values)
    assert values, "No timing samples"
    return dict(median=statistics.median(values),
                p95=values[math.ceil((len(values)-1)*.95)],
                minimum=values[0], maximum=values[-1])


def gpu_telemetry():
    executable=shutil.which("nvidia-smi")
    if not executable:
        return None
    query=subprocess.run([executable,"--query-gpu=name,driver_version,pstate,temperature.gpu,clocks.gr,clocks.mem,power.draw,utilization.gpu",
                          "--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=10)
    return dict(fields="name,driver_version,pstate,temperature.gpu,clocks.gr,clocks.mem,power.draw,utilization.gpu",
                values=query.stdout.strip(),exit_code=query.returncode)


def save_report(path,report):
    # Encode in C and compress once, outside the timed interval. Streaming
    # millions of tiny JSON fragments through gzip made large captures slow.
    temporary=path.with_suffix(path.suffix+".tmp")
    temporary.write_bytes(gzip.compress(json.dumps(report,separators=(",",":")).encode("utf-8"),compresslevel=1,mtime=0))
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("executable", type=Path)
    parser.add_argument("model", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--seconds", type=float, default=2)
    parser.add_argument("--warmup", type=float, default=1)
    parser.add_argument("--zoom", type=float, default=1)
    parser.add_argument("--capture", action="store_true")
    parser.add_argument("--visible-window", action="store_true")
    parser.add_argument("--samples",type=int,choices=(1,4),default=4)
    parser.add_argument("--opacity",type=float,default=.35)
    parser.add_argument("--cases",default="")
    parser.add_argument("--view",default="isometric")
    parser.add_argument("--group-colors",action="store_true",help="Distinct colors for a small qualitative fixture")
    args = parser.parse_args()
    assert args.rounds > 0 and args.seconds > 0 and args.warmup >= 0
    assert math.isfinite(args.opacity) and 0 < args.opacity < 1
    assert math.isfinite(args.zoom) and args.zoom > 0
    args.executable = args.executable.resolve()
    args.model = args.model.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location("guard", REPOSITORY/"experiments/mesh-overlays/run.py")
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    def overlaps(excluded_pid=None):
        found = guard.overlapping_workloads(excluded_pid)
        for probe in psutil.process_iter(["pid", "name"]):
            if probe.info["pid"] != excluded_pid and probe.info["name"].lower() in ("woby-edge-benchmark.exe", "woby-edge-paired.exe"):
                found.append(dict(pid=probe.info["pid"], name=probe.info["name"]))
        return found
    assert not overlaps(), "Another rendering/build/test workload is active"
    report = dict(source_revision=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPOSITORY, text=True).strip(),
        source_renderer_sha256=digest(REPOSITORY/"src/scene_renderer.cpp"),
        executable=str(args.executable), executable_sha256=digest(args.executable),
        runner_sha256=digest(__file__),
        source_hashes={str(path.relative_to(REPOSITORY)):digest(path) for path in [REPOSITORY/"src/scene_renderer.cpp",REPOSITORY/"src/graphics.cpp",REPOSITORY/"src/main.cpp",REPOSITORY/"shaders/native/woby.slang",REPOSITORY/"shaders/native/root.h"]},
        shader_hashes={path.name:digest(path) for path in (args.executable.parent/"assets/shaders/spirv").glob("*.bin")},
        msaa_samples=args.samples,surface_opacity=args.opacity,
        model=str(args.model), model_sha256=digest(args.model),
        rounds=args.rounds, measurement_seconds=args.seconds,
        warmup_seconds=args.warmup, zoom=args.zoom, hidden_window=not args.visible_window,
        gpu_before=gpu_telemetry(),cases=[],scene_snapshots={})
    instance = "edge-app-"+uuid.uuid4().hex[:12]
    command = [str(args.executable), "--instance", instance,
        "--drawable-size", "1280x720", "--log-file", str(args.output/"viewer.log"), "--log-level", "info"]
    if not args.visible_window:
        command.append("--hidden-window")
    environment = dict(os.environ, VK_LOADER_LAYERS_DISABLE="~implicit~",
        WOBY_EDGE_SAMPLES=str(args.samples))
    stopped = threading.Event()
    memory = []
    violations = []
    with tempfile.TemporaryDirectory(prefix="edge-app-") as directory, (args.output/"console.log").open("w", encoding="utf-8") as log:
        startup = subprocess.STARTUPINFO()
        startup.dwFlags = subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = 1 if args.visible_window else 0
        process = subprocess.Popen(command, cwd=directory, env=environment,
            stdout=log, stderr=log, startupinfo=startup)
        start = time.monotonic()

        def monitor():
            probe = psutil.Process(process.pid)
            while not stopped.wait(.2) and process.poll() is None:
                try:
                    info = probe.memory_info()
                    private = getattr(info, "private", info.rss)
                    available = psutil.virtual_memory().available
                    memory.append(dict(seconds=time.monotonic()-start, private=private, available=available))
                    overlap = overlaps(process.pid)
                    reason = ("overlap" if overlap else "private memory" if private>38*2**30 else
                              "available memory" if available<6*2**30 else "timeout" if time.monotonic()-start>1200 else None)
                    if reason:
                        violations.append(dict(reason=reason, overlap=overlap))
                        process.terminate()
                        return
                except psutil.NoSuchProcess:
                    return
        watcher = threading.Thread(target=monitor, daemon=True)
        watcher.start()
        request_id = 0
        registry_record = {}

        def rpc(method, params=None, timeout=120):
            nonlocal request_id
            request_id += 1
            params = dict(params or {})
            if method not in ("instance.info", "command.get"):
                params["timeoutSeconds"] = timeout
            request = urllib.request.Request(f"http://127.0.0.1:{registry_record['port']}/rpc",
                data=json.dumps(dict(jsonrpc="2.0", id=request_id, method=method, params=params)).encode(),
                headers={"Content-Type": "application/json", "Authorization": "Bearer "+registry_record["token"]})
            with urllib.request.urlopen(request, timeout=timeout+5) as response:
                value = json.load(response)
            if "error" in value:
                raise RuntimeError(f"{method}: {value['error']}")
            return value["result"]

        try:
            registry = Path(os.environ["LOCALAPPDATA"])/"woby/instances"/("instance-"+instance+".json")
            deadline = time.monotonic()+45
            while time.monotonic() < deadline:
                assert process.poll() is None, "Viewer exited during startup"
                try:
                    registry_record = json.loads(registry.read_text(encoding="utf-8"))
                    if rpc("instance.info").get("ready"):
                        break
                except (OSError, ValueError):
                    pass
                time.sleep(.05)
            else:
                raise TimeoutError("Startup timed out")
            load_start = time.monotonic()
            loaded = rpc("model.add", {"path":str(args.model)}, 600)
            assert loaded["addedCount"] == 1 and loaded["failedCount"] == 0, loaded
            file_id = loaded["addedIds"][0]
            report["load_seconds"] = time.monotonic()-load_start
            rpc("pane.set", dict(visible=False, propertiesVisible=False))
            for helper in ("grid", "origin", "dimensions"):
                rpc(helper+".set", dict(visible=False))
            rpc("render.set", dict(target="scene", solid=True, triangles=False, vertices=False, adaptivePoints=False, xray=False))
            rpc("color.set", dict(target=file_id, rgb=[.15,.45,.7]))
            if args.group_colors:
                def group_nodes(nodes):
                    for node in nodes:
                        if node["kind"]=="group": yield node
                        yield from group_nodes(node.get("children",[]))
                groups=list(group_nodes(rpc("scene.tree")["nodes"]))
                palette=((.8,.15,.12),(.1,.3,.85),(.12,.7,.25))
                report["group_colors"]=[]
                assert len(groups)<=len(palette), "Use group colors only for a small fixture"
                for group,color in zip(groups,palette):
                    rpc("color.set",dict(target=group["id"],rgb=color))
                    report["group_colors"].append(dict(id=group["id"],rgb=color))
            rpc("camera.view", dict(preset=args.view))
            rpc("camera.frame")
            if args.zoom != 1:
                rpc("camera.dolly", dict(factor=args.zoom))
            report["camera"] = rpc("camera.get")["camera"]
            report["stats"] = rpc("stats")
            initial = rpc("performance.get")
            report["environment"] = {name:initial[name] for name in ("drawable", "viewport", "pacing", "renderer") if name in initial}
            assert initial["drawable"] == dict(width=1280, height=720), initial
            viewport = initial["viewport"]
            assert viewport["width"] == 1280 and viewport["height"] > 600, viewport
            assert initial["pacing"]["msaaSamples"] == args.samples, initial
            conditions = [("surface",True,False,args.opacity,"legacy")]
            for mode in ("legacy","legacy-opaque","matched","coating","opaque","overlay","overlay-opaque",
                         "matched-pulled","coating-pulled","opaque-pulled","overlay-pulled"):
                conditions.append((mode,True,True,args.opacity,mode))
            if args.cases:
                selected=args.cases.split(",")
                conditions=[case for case in conditions if case[0] in selected]
                assert len(conditions)==len(selected), "Unknown case"
            fixed_frame_camera=None
            for round_index in range(args.rounds):
                order = conditions[round_index:]+conditions[:round_index]
                for name,solid,edges,opacity,mode in order:
                    rpc("render.set", dict(target="scene", solid=solid, triangles=edges, vertices=False, xray=False))
                    rpc("opacity.set", dict(target=file_id, value=opacity))
                    # Switch only the research runtime policy, then warm it before timing.
                    rpc("performance.begin",dict(name=mode))
                    time.sleep(max(args.warmup,.75))
                    warm=rpc("performance.end")
                    warm_events=warm["events"]
                    gpu_warm=[row["gpuFrameMilliseconds"] for row in warm_events[-8:] if row["gpuFrameMilliseconds"] is not None]
                    estimate=statistics.median(gpu_warm)/1000 if gpu_warm else .2
                    if len(warm_events)>1:
                        wall_period=(warm_events[-1]["completedMilliseconds"]-warm_events[0]["completedMilliseconds"])/(len(warm_events)-1)/1000
                        estimate=max(estimate,wall_period)
                    if len(warm_events)<16:
                        rpc("performance.begin")
                        time.sleep(max(args.warmup,20*estimate))
                        rpc("performance.end")
                    measured_seconds=max(args.seconds,48*estimate)
                    rpc("performance.begin")
                    time.sleep(measured_seconds)
                    capture = rpc("performance.end")
                    assert capture["events"] and not capture["droppedFrames"], capture
                    assert capture["sceneBefore"]==capture["sceneAfter"], "Scene changed during capture"
                    scene=capture.pop("sceneBefore"); capture.pop("sceneAfter")
                    scene_hash=hashlib.sha256(json.dumps(scene,sort_keys=True).encode("utf-8")).hexdigest()
                    report["scene_snapshots"].setdefault(scene_hash,scene)
                    capture["sceneSnapshotSHA256"]=scene_hash
                    for env in capture["environments"]:
                        assert env["drawable"] == initial["drawable"] and env["viewport"] == viewport, env
                        assert env["pacing"]["msaaSamples"] == args.samples, env
                    rows = capture["events"][3:-3]
                    for row in rows:
                        assert row["points"]["submittedCount"]==0 and row["points"]["gpuRasterCount"]==0, "Unexpected point work"
                        if fixed_frame_camera is None:
                            fixed_frame_camera=row["camera"]
                            report["fixed_frame_camera"]=fixed_frame_camera
                        assert row["camera"]==fixed_frame_camera, "Camera changed between cases"
                    timings = [row["gpuFrameMilliseconds"] for row in rows if row["gpuFrameMilliseconds"] is not None]
                    assert len(timings) >= 24, f"Only {len(timings)} GPU samples"
                    sample = dict(round=round_index, condition=name, surface_opacity=opacity,
                        edge_policy=mode, solid=solid, edges=edges, xray=False, measured_seconds=measured_seconds,
                        gpu_stages={key:distribution([row[key] for row in rows]) for key in ("transparencyAccumMs","transparencyResolveMs","triangleLinesMs")},
                        memory=capture["experimentMemory"],experiment=capture["edgeExperiment"],
                        frames=len(rows), gpu_ms=distribution(timings),
                        scene_submit_ms=distribution([row["stagesMilliseconds"]["submit_scene"] for row in rows]),
                        graphics_submit_ms=distribution([row["cpuSubmitMilliseconds"] for row in rows]),
                        main_thread_work_ms=distribution([sum(v for k,v in row["stagesMilliseconds"].items() if k!="graphics_frame") for row in rows]),
                        gpu_telemetry=gpu_telemetry(),
                        capture=capture)
                    report["cases"].append(sample)
                    print(json.dumps({key:sample[key] for key in ("round", "condition", "frames", "gpu_ms", "scene_submit_ms","gpu_stages","experiment")}),flush=True)
                    save_report(args.output/"measurements.json.gz",report)
            if args.capture:
                report["images"]=[]
                for name,solid,edges,opacity,mode in conditions:
                    rpc("render.set",dict(target="scene",solid=solid,triangles=edges,vertices=False,xray=False))
                    rpc("opacity.set",dict(target=file_id,value=opacity))
                    rpc("performance.begin",dict(name=mode)); time.sleep(.1); rpc("performance.end")
                    image=args.output/(name+".png")
                    rpc("screenshot.capture",dict(path=str(image)),120)
                    with Image.open(image) as pixels:
                        report["images"].append(dict(condition=name,path=image.name,width=pixels.width,height=pixels.height,
                            rgb_sha256=hashlib.sha256(pixels.convert("RGB").tobytes()).hexdigest()))
            rpc("quit", dict(onDirty="discard"))
            assert process.wait(timeout=30) == 0
            report["status"] = "completed"
        finally:
            stopped.set()
            watcher.join(timeout=2)
            if process.poll() is None:
                process.kill()
                process.wait(timeout=15)
            report["guard"] = dict(violations=violations, peak_private=max((m["private"] for m in memory), default=0),
                minimum_available=min((m["available"] for m in memory), default=0), elapsed_seconds=time.monotonic()-start)
            save_report(args.output/"measurements.json.gz",report)
            assert not violations, violations
            log_text = (args.output/"viewer.log").read_text(encoding="utf-8")
            assert not any(token in log_text for token in ("Validation Error", "VUID-", "SYNC-HAZARD", "Unhandled exception")), log_text


if __name__ == "__main__":
    main()
