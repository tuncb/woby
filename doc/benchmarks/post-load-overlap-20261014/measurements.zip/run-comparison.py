"""Run paired controls sequentially after builds and tests have stopped."""
import json
from pathlib import Path
import subprocess
import sys
import time

repo = Path(__file__).resolve().parents[2]
root = Path(__file__).resolve().parent
model = Path(r"D:\temp\obj_tests\20190810_BearTrap_Ground_Model.obj")
bins = {"baseline": root / "baseline-bin", "overlap": root / "overlap-bin"}
manifest = {"baseline_revision": "f8bd1e4385129549017610abf8b4b70befde6a5a",
            "method": "Three rotating rounds; fresh processes; warm input; hidden 1280x720; no concurrent builds, tests or profilers",
            "runs": []}
configurations = [("native", "baseline"), ("native", "overlap"),
                  ("motion", "baseline"), ("motion", "overlap")]
for round_number in range(3):
    order = configurations[round_number:] + configurations[:round_number]
    for mode, variant in order:
        name = f"{len(manifest['runs'])+1:02d}-r{round_number+1}-{mode}-{variant}"
        output = root / "runs" / name
        executable = "woby.exe" if mode == "native" else "woby_obj_e2e_viewer.exe"
        command = ["uv", "run", str(repo / "experiments/obj-profile/e2e_run.py"),
                   str(bins[variant] / executable), str(model), "--hidden", "--output", str(output),
                   "--settle-seconds", "1", "--render-seconds", "1", "--navigation"]
        if mode == "motion":
            command.append("--post-load-navigation")
        output.mkdir(parents=True, exist_ok=True)
        print(f"Starting {name}", flush=True)
        if not (output / "result.json").exists():
            with (output / "driver.log").open("w", encoding="utf-8") as log:
                result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if result.returncode:
                raise RuntimeError(f"Run failed: {name}; see driver.log")
        saved = json.loads((output / "result.json").read_text(encoding="utf-8"))
        if saved.get("error") or saved.get("exit_code") != 0:
            raise RuntimeError(f"Invalid run: {name}: {saved.get('error')}")
        manifest["runs"].append({"name": name, "round": round_number + 1, "mode": mode,
                                 "variant": variant, "output": str(output), "command": command,
                                 "sha256": saved["executable_sha256"]})
        (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        print(f"Finished {name}: {saved['load_rpc_ms']/1000:.3f} s", flush=True)
        time.sleep(2)
