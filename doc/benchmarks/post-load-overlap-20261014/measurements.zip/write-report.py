"""Write the measured comparison and archive its evidence."""
from html import escape
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
out = repo / "doc/benchmarks/post-load-overlap-20261014"
out.mkdir(parents=True, exist_ok=True)
summary = json.loads((root / "summary.json").read_text())
groups = summary["groups"]

def metric(mode, variant, name, sub=None):
    value = groups[f"{mode}-{variant}"][name]
    return value[sub] if sub else value

def cell(value):
    return f"{value['median']:.3f} <small>({value['min']:.3f}–{value['max']:.3f})</small>"

metrics = [
    ("Native full readiness, s", "native", "ready_s", None),
    ("Native initial CPU work (before post-load tasks), s", "native", "initial_cpu_s", None),
    ("Native full-run peak commit, GiB", "native", "peak_commit_gib", None),
    ("Native full-run peak working set, GiB", "native", "peak_working_set_gib", None),
    ("Traced first GPU frame during motion control, s", "motion", "first_gpu_frame_s", None),
    ("Traced post-load CPU work during motion, s", "motion", "post_cpu_s", None),
    ("Traced first GPU frame to full readiness, s", "motion", "post_frame_ready_s", None),
    ("Post-frame sampled peak commit during motion, GiB", "motion", "post_frame_peak_commit_gib", None),
    ("Post-frame sampled peak working set during motion, GiB", "motion", "post_frame_peak_working_set_gib", None),
    ("Visible motion during preparation: CPU frame P99, ms", "visible-motion", "preparing_navigation_3s", "cpu_p99_ms"),
    ("Visible motion during preparation: GPU frame P95, ms", "visible-motion", "preparing_navigation_3s", "gpu_p95_ms"),
    ("Visible motion during preparation: frames/s", "visible-motion", "preparing_navigation_3s", "fps"),
    ("Visible motion: post-load CPU work, s", "visible-motion", "post_cpu_s", None),
    ("Visible motion: post-frame peak commit, GiB", "visible-motion", "post_frame_peak_commit_gib", None),
    ("Hidden motion during preparation: CPU frame P99, ms", "motion", "preparing_navigation_3s", "cpu_p99_ms"),
    ("Hidden motion during preparation: frames/s", "motion", "preparing_navigation_3s", "fps"),
    ("Native motion after readiness: CPU frame P99, ms", "native", "settled_navigation", "cpu_p99_ms"),
    ("Native motion after readiness: frames/s", "native", "settled_navigation", "fps"),
]
table_rows = "".join(f"<tr><td>{label}</td><td>{cell(metric(mode,'baseline',name,sub))}</td>"
                     f"<td>{cell(metric(mode,'overlap',name,sub))}</td></tr>" for label,mode,name,sub in metrics)
base = metric("native", "baseline", "ready_s")["median"]
changed = metric("native", "overlap", "ready_s")["median"]
post_base = metric("visible-motion", "baseline", "post_cpu_s")["median"]
post_changed = metric("visible-motion", "overlap", "post_cpu_s")["median"]
frame_base = metric("visible-motion", "baseline", "preparing_navigation_3s", "cpu_p99_ms")["median"]
frame_changed = metric("visible-motion", "overlap", "preparing_navigation_3s", "cpu_p99_ms")["median"]
run_rows = ""
for row in summary["runs"]:
    optional = lambda key: f"{row[key]:.3f}" if key in row else "—"
    run_rows += (f"<tr><td>{escape(row['name'])}</td><td>{row['ready_s']:.3f}</td>"
                 f"<td>{optional('post_cpu_s')}</td><td>{optional('early_annotation_overlap_s')}</td>"
                 f"<td>{row['peak_commit_gib']:.3f}</td></tr>")

html = f'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BearTrap: earlier annotation preparation — 14 October 2026</title>
<style>body{{font:16px/1.6 system-ui,sans-serif;max-width:1120px;margin:40px auto;padding:0 24px;color:#172635;background:#fbfcfe}}
h1{{line-height:1.2;font-size:32px}}h2{{margin-top:32px}}table{{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;background:white}}
td,th{{padding:10px 12px;text-align:left;border-bottom:1px solid #dce3ec}}th{{background:#eaf0f6}}small{{color:#536478;white-space:nowrap}}
code{{background:#eaf0f6;padding:2px 5px}}a{{color:#0862a3}}.scroll{{overflow-x:auto}}.lead{{font-size:20px;max-width:960px}}</style>
<h1>BearTrap: start annotations with the other post-load work</h1>
<p>14 October 2026 · Release · Baseline <code>f8bd1e4</code> · Three runs per build and capture mode</p>
<p class="lead">Post-load CPU work during visible camera motion changed from
<strong>{post_base:.3f} s to {post_changed:.3f} s</strong> ({(post_base-post_changed)/post_base*100:.1f}% less time).
Post-frame peak commit stayed near <strong>8.08 GiB</strong>. The P99 CPU frame time rose from
<strong>{frame_base:.3f} ms to {frame_changed:.3f} ms</strong>, while the frame rate stayed near 57 FPS.</p>
<p>This experiment reduces preparation time with a measured cost in the tail of the frame-time
distribution. The per-run ranges overlap. Keep this uncertainty when judging the three-run result.
Native full-readiness medians were {base:.3f} s and {changed:.3f} s; earlier, unchanged loading stages
also varied. The tables below separate these measurements.</p>
<p>The current baseline already runs point preparation alongside annotations. This change also overlaps
source-index mapping and original bounds with annotations. Both tasks use the same immutable geometry
snapshot and shared helper limit. They join before the point upload. Full readiness still requires both
CPU results and the completed upload. Stale results are rejected before publication.</p>
<p>The <a href="../e2e-beartrap-20261014/report.html">earlier report</a> used revision <code>7ee6133</code>.
Its 20.6-second CPU sequence and 10.9-second ideal overlap limit are not the baseline for this comparison.
Later commits already changed the preparation costs. The ideal limit was not a predicted result.</p>
<h2>Measurements</h2>
<p>Cells show the median and the minimum–maximum range of three runs. Native controls establish full-load
time. Traced motion controls establish phase overlap and frame behavior during preparation. Their absolute
times differ, so they are not pooled. Frame percentile cells show the median of three per-run percentiles.</p>
<p>Initial CPU work also varied between the native builds, although this change starts only after the first
model frame. Do not attribute the whole native end-to-end difference to annotation overlap. The traced
post-load intervals measure the affected work directly.</p>
<div class="scroll"><table><thead><tr><th>Metric</th><th>Baseline</th><th>Earlier annotations</th></tr></thead>
<tbody>{table_rows}</tbody></table></div>
<p>Memory columns separate private commit from working set. The full-run peaks include loading, screenshot
verification, and motion after readiness. The post-frame peaks use samples between first GPU completion
and full readiness. The observer requests a 100 ms sample period; actual intervals are in summary.json.</p>
<h2>Navigation control</h2>
<p>The generated trace viewer calls the normal UI camera operation at 30 degrees/second while preparation
is pending. The production viewer has no added motion code. The comparison uses the first three seconds
after the first moving frame. A separate recording sends 24 camera-orbit commands after readiness.</p>
<p>These controls measure frame cadence during motion. They do not measure physical input-to-display
latency. GPU timing can trail CPU submission. Hidden windows were paced at 20 FPS. A separate set of three
visible-window pairs tests active rendering. All captures use a 1280×720 drawable, fresh processes,
and a warmed copy of the same 7,108,991,827-byte OBJ. They run in rotating or alternating order without concurrent builds,
tests, or profilers. Three runs do not establish results for other hardware.</p>
<h2>Worker limit</h2>
<p><code>hardware &gt; 3 ? min(8, hardware - 3) : 0</code>, where <code>hardware</code> is the logical CPU
count reported by <code>std::thread::hardware_concurrency()</code>. This Ryzen 7 5800H has eight cores and
16 logical CPUs, so the cap is eight helper threads. Calling threads also do work. The cap is shared by
simultaneous and nested analyses; it is not a limit on all application threads.</p>
<p>The post-load split can reserve one helper slot for its second task. Nested operations share the
remaining slots. Small operations and operations without free slots run on their caller. The cap was
introduced in commit <code>89a4e93</code> to leave capacity for the UI and other threads. No recorded study
was found that selects eight as the best value. This change leaves the cap unchanged.</p>
<h2>Individual runs</h2>
<p>Early overlap is the intersection of the annotation interval with the source-index and bounds interval.
It is zero in the baseline. All changed motion captures start annotations before source mapping ends,
on a different thread. Both CPU tasks finish after the first GPU frame and before readiness.</p>
<div class="scroll"><table><thead><tr><th>Run</th><th>Ready s</th><th>Post CPU s</th><th>Early overlap s</th><th>Peak commit GiB</th></tr></thead>
<tbody>{run_rows}</tbody></table></div>
<h2>Validation and evidence</h2>
<p>The Release build completed without compiler warnings. All 112 default, eight slow, and 26 graphics
CTest checks passed. Tests cover serial/parallel result equality, deferred source indices, shared worker
limits, cancellation, source/bounds errors, stale results, the first-frame gate, and the upload readiness
gate. The trace fixture also verifies camera motion during preparation.</p>
<p><a href="summary.json">Numeric summary</a> · <a href="REPRODUCE.txt">Reproduction steps and worker policy</a>
· <a href="measurements.zip">Raw results, commands, source snapshots, and validation logs</a></p>
</html>'''
(out / "report.html").write_text(html, encoding="utf-8")
shutil.copy2(root / "summary.json", out / "summary.json")
with zipfile.ZipFile(out / "measurements.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for directory in ("runs", "visible-runs", "validation", "source"):
        for path in (root / directory).rglob("*"):
            if path.is_file() and path.suffix in (".json", ".jsonl", ".log", ".txt", ".cpp", ".h", ".py", ".patch"):
                archive.write(path, path.relative_to(root).as_posix())
    for name in ("provenance.json", "manifest.json", "visible-manifest.json", "run-comparison.py", "run-visible-motion.py", "analyze-comparison.py", "write-report.py"):
        archive.write(root / name, name)
print(out)
print(f"Native readiness: {base:.3f} -> {changed:.3f} s ({(base-changed)/base*100:.1f}% less)")
