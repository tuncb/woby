"""Measure active-window camera motion separately from hidden timing controls."""
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root.parents[1]
model = Path(r"D:\temp\obj_tests\20190810_BearTrap_Ground_Model.obj")
manifest = {"method": "Three alternating visible motion pairs; fresh processes; warm input; 1280x720; no concurrent builds, tests or profilers", "runs": []}
for round_number in range(3):
    order = ("baseline", "overlap") if round_number % 2 == 0 else ("overlap", "baseline")
    for variant in order:
        name = f"{len(manifest['runs'])+1:02d}-r{round_number+1}-visible-motion-{variant}"
        output = root / "visible-runs" / name
        executable = root / f"{variant}-bin" / "woby_obj_e2e_viewer.exe"
        command = ["uv", "run", str(repo / "experiments/obj-profile/e2e_run.py"), str(executable), str(model),
                   "--output", str(output), "--settle-seconds", "1", "--render-seconds", "1", "--navigation", "--post-load-navigation"]
        output.mkdir(parents=True, exist_ok=True)
        print(f"Starting {name}", flush=True)
        if not (output / "result.json").exists():
            with (output / "driver.log").open("w", encoding="utf-8") as log:
                result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if result.returncode:
                raise RuntimeError(f"Run failed: {name}")
        saved = json.loads((output / "result.json").read_text())
        if saved.get("error") or saved.get("exit_code") != 0:
            raise RuntimeError(f"Invalid run: {name}: {saved.get('error')}")
        manifest["runs"].append({"name": name, "round": round_number+1, "mode": "visible-motion", "variant": variant,
                                 "output": str(output), "command": command, "sha256": saved["executable_sha256"]})
        (root / "visible-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        print(f"Finished {name}: {saved['load_rpc_ms']/1000:.3f} s", flush=True)
        time.sleep(2)
