"""Summarize complete intervals; do not add overlapping task times."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
repo = root.parents[1]
sys.path.insert(0, str(repo / "experiments/obj-profile"))
from e2e_analyze import distribution, frame_summary, native_first_frame_bounds, log_values

manifest = json.loads((root / "manifest.json").read_text())
visible = root / "visible-manifest.json"
if visible.exists():
    manifest["runs"] += json.loads(visible.read_text())["runs"]
rows = []
for item in manifest["runs"]:
    record = json.loads((Path(item["output"]) / "result.json").read_text())
    assert not record.get("error"), item["name"]
    samples = record["samples"]
    row = {k: item[k] for k in ("name", "round", "mode", "variant", "sha256")}
    load_rpc = next(r for r in record["rpc"] if r["method"] == "model.add")
    row.update(ready_s=(load_rpc["end_ms"] - load_rpc["start_ms"]) / 1000,
               observer_ready_s=record["load_rpc_ms"] / 1000,
               first_scene_cpu_bounds_ms=native_first_frame_bounds(record),
               peak_commit_gib=max(s["peak_commit"] for s in samples) / 2**30,
               peak_working_set_gib=max(s["peak_working_set"] for s in samples) / 2**30,
               settled_navigation=frame_summary(record["navigation_frames"]),
               image=record["image"],
               sample_interval_ms=distribution([b["time_ms"]-a["time_ms"] for a,b in zip(samples,samples[1:])]))
    orbit = [r["end_ms"] - r["start_ms"] for r in record["rpc"] if r["method"] == "camera.orbit"]
    row["settled_camera_rpc_ms"] = distribution(orbit)
    row["initial_cpu_s"] = log_values(Path(item["output"]) / "viewer.log")["initial_cpu_preparation_ms"] / 1000
    if item["mode"] != "native":
        trace = record["trace"]
        marks = {t["name"]: t["time_ms"] for t in trace if t["kind"] == "mark"}
        phases = {t["name"]: t for t in trace if t["kind"] == "phase"}
        assert all(t["nesting_valid"] for t in phases.values())
        meta = next(t for t in trace if t["kind"] == "metadata")
        offset = (meta["steady_epoch_nanoseconds"] - record["observer_epoch_qpc_ns"]) / 1e6
        start, end = marks["first_scene_frame_gpu_complete"], marks["all_tools_ready"]
        post_samples = [s for s in samples if start + offset <= s["time_ms"] <= end + offset]
        annotation = phases["post_annotation_cache"]
        source = phases["post_source_indices"]
        bounds = phases["post_original_bounds"]
        assert phases["post_load_cpu_total"]["start_ms"] >= start
        assert phases["post_load_cpu_total"]["end_ms"] <= end
        early_overlap = max(0, min(annotation["end_ms"], bounds["end_ms"]) - max(annotation["start_ms"], source["start_ms"]))
        if item["variant"] == "overlap":
            assert annotation["start_ms"] < source["end_ms"], item["name"]
            assert annotation["thread_id"] != source["thread_id"]
        else:
            assert annotation["start_ms"] >= bounds["end_ms"]
        row.update(first_gpu_frame_s=(start - marks["model_add_requested"]) / 1000,
                   post_frame_ready_s=(end-start) / 1000,
                   post_cpu_s=phases["post_load_cpu_total"]["wall_ms"] / 1000,
                   early_annotation_overlap_s=early_overlap / 1000,
                   post_frame_peak_commit_gib=max(s["private_bytes"] for s in post_samples) / 2**30,
                   post_frame_peak_working_set_gib=max(s["working_set"] for s in post_samples) / 2**30,
                   phases={name: {key: t[key] for key in ("start_ms", "end_ms", "wall_ms", "thread_id")}
                           for name,t in phases.items() if name.startswith("post_")})
        events = record["load_frames"]["events"]
        moving = [b for a,b in zip(events,events[1:]) if a["camera"][3] != b["camera"][3]]
        assert len(moving) > 2
        # Exclude the first moving frame, which can include scene publication.
        begin = moving[1]["completedMilliseconds"]
        matched = [e for e in moving[1:] if e["completedMilliseconds"] - begin <= 3000]
        assert matched[-1]["completedMilliseconds"] - begin >= 2900, item["name"]
        capture = dict(record["load_frames"], events=matched)
        row["preparing_navigation_3s"] = frame_summary(capture)
        row["preparing_navigation_all"] = frame_summary(dict(record["load_frames"], events=moving))
    rows.append(row)

groups = {}
for mode in ("native", "motion", "visible-motion"):
    for variant in ("baseline", "overlap"):
        selected = [r for r in rows if (r["mode"], r["variant"]) == (mode,variant)]
        group = {key: distribution([r[key] for r in selected if key in r]) for key in
                 ("ready_s", "initial_cpu_s", "peak_commit_gib", "peak_working_set_gib", "first_gpu_frame_s", "post_cpu_s",
                  "post_frame_ready_s", "early_annotation_overlap_s", "post_frame_peak_commit_gib", "post_frame_peak_working_set_gib")}
        for capture in ("settled_navigation", "preparing_navigation_3s"):
            measured = [r[capture] for r in selected if capture in r]
            if measured:
                group[capture] = {"fps": distribution([m["frames_per_second"] for m in measured]),
                                  "cpu_p99_ms": distribution([m["cpu_frame_ms"]["p99"] for m in measured]),
                                  "gpu_p95_ms": distribution([m["gpu_frame_ms"]["p95"] for m in measured])}
        groups[f"{mode}-{variant}"] = group

summary = {"method": "Separate hidden rotating controls and visible alternating motion controls; three runs per variant and mode",
           "provenance": json.loads((root / "provenance.json").read_text()),
           "navigation_method": "Generated trace viewer uses navigateUiCamera at 30 degrees/s only while post loading. Compare the first three seconds after the first moving frame. This measures frame cadence during motion, not physical input-to-photon latency.",
           "runs": rows, "groups": groups}
(root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
for name, group in groups.items():
    print(name)
    for key,value in group.items():
        if value.get("count"):
            print(f"  {key}: {value['median']:.4f} [{value['min']:.4f}, {value['max']:.4f}]")
        elif "fps" in value:
            print(f"  {key}: FPS {value['fps']['median']:.3f}, CPU P99 {value['cpu_p99_ms']['median']:.3f} ms, GPU P95 {value['gpu_p95_ms']['median']:.3f} ms")
