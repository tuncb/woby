import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument("--complete",action="store_true")
args = parser.parse_args()
measure = Path(__file__).resolve().parent
root = measure.parents[1]
groups = ("cpu-final","native","traced","native-matched","traced-matched")
manifests = [json.loads((measure/name/"manifest.json").read_text()) for name in groups]
assert all(x["input_sha256"] == manifests[0]["input_sha256"] for x in manifests)
for group,manifest in zip(groups,manifests):
    rows = json.loads((measure/group/("cpu.json" if group == "cpu-final" else "summary.json")).read_text())
    for row in rows:
        name = Path(row["command"][0 if group == "cpu-final" else 3]).name
        digest = manifest["executables"][name]
        assert hashlib.sha256((measure/"measured-bin"/name).read_bytes()).hexdigest() == digest, (group,name)
        if group != "cpu-final":
            assert row["executable_sha256"] == digest
        if group.startswith("traced"):
            raw = json.loads(Path(row["path"]).read_text())
            mapping = next(p for p in raw["trace"] if p.get("name") == "corner_mapping")
            assert mapping["data"]["production_staged"] == (row["configuration"] == "staged")
cpu = json.loads((measure/"cpu-final/cpu.json").read_text())
for preparation in ("eager","deferred"):
    assert len({x["fingerprint"] for x in cpu if x["preparation"] == preparation}) == 1
assert all(x["corner_mapping"]["staged"] == (x["configuration"] == "staged") for x in cpu)
assert (measure/"full-verify.log").read_text().count("All mesh buffers and group fields match") == 2
source = (root/"src/obj_mesh.cpp").read_text(encoding="utf-8")
generated = (measure/"source-snapshots/obj_mesh.cpp").read_text(encoding="utf-8")
expected = '#include "control.h"\n' + source.replace("stagedCornerMapping && attributes && indexCount != 0", "stagedCornerMapping && (attributes || position_mapping::forcePositionFaces) && indexCount != 0",1)
assert generated == expected
(measure/"source-comparison.diff").write_text("".join(difflib.unified_diff(source.splitlines(True),generated.splitlines(True),fromfile="production/obj_mesh.cpp",tofile="comparison/obj_mesh.cpp")),encoding="utf-8")
checks = {"full_Bennu_buffers": "passed; eager and deferred; byte comparisons plus group fields and bounds",
          "path_contract": (measure/"contract.log").read_text().strip(),
          "timed_CPU_imports": len(cpu), "fresh_viewer_imports":24, "headline_viewer_imports":12,
          "timed_fingerprints":"match within each preparation mode",
          "input_and_executable_hashes":"input matches across five groups; each used executable matches its manifest and frozen executable",
          "comparison_change":"one eligibility predicate plus comparison control header; other production guards retained",
          "production_routing":"unchanged"}
images = [p for name in groups[1:] for p in (measure/name).rglob("*.png")]
assert len(images) == 24 and len({hashlib.sha256(p.read_bytes()).hexdigest() for p in images}) == 1
checks["viewer_screenshots"] = "24 captures byte-for-byte identical; Bennu geometry visible"
linkage = json.loads((measure/"linkage-controls.json").read_text())
for kind in ("native","traced"):
    a = linkage["woby_position_mapping_"+kind+".exe"]
    b = linkage["woby_position_mapping_"+kind+"_reference.exe"]
    assert a["executable_bytes"] == b["executable_bytes"] and a["sections"][".text"] == b["sections"][".text"]
checks["matched_viewer_linkage"] = "identical executable and code-section sizes in each pair"
build_logs = [measure/name for name in ("build-release.log","build-release-final.log","build-all-release.log","build-reference-release.log")]
warnings = sum(len(re.findall(r"\bwarning (?:C\d+|LNK\d+)|\bwarning:",p.read_text(errors="replace"),re.I)) for p in build_logs)
checks["compiler_warnings"] = warnings
checks["Release_build"] = "passed" if args.complete else "in progress"
tests = {}
for preset in ("vs2026-vcpkg","vs2026-vcpkg-slow","vs2026-vcpkg-graphics"):
    path = measure/(preset+"-tests.log")
    text = path.read_text(errors="replace") if path.exists() else ""
    match = re.search(r"100% tests passed, 0 tests failed out of (\d+)",text)
    tests[preset] = {"status":"passed","checks":int(match[1])} if match else {"status":"in progress"}
    if args.complete:
        assert match, preset
workspace = (measure/"workspace-graphics-tests.log").read_text(errors="replace") if (measure/"workspace-graphics-tests.log").exists() else ""
match = re.search(r"100% tests passed, 0 tests failed out of (\d+)",workspace)
tests["workspace_full_graphics"] = {"status":"passed","checks":int(match[1])} if match else {"status":"in progress"}
if args.complete:
    assert match, "workspace full graphics"
checks["test_suites"] = tests
if args.complete:
    assert warnings == 0
    checks["total_checks"] = sum(x["checks"] for x in tests.values())
(measure/"validation.json").write_text(json.dumps(checks,indent=2),encoding="utf-8")
print(json.dumps(checks,indent=2))
