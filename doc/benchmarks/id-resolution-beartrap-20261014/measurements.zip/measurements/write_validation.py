import hashlib,json,re,sys
from pathlib import Path
root=Path(r"D:/.worktree/woby-id-resolution-20261014/build/id-resolution-20261014")
allow_running="--allow-running" in sys.argv
suites={}
for preset in ("vs2026-vcpkg","vs2026-vcpkg-slow","vs2026-vcpkg-graphics"):
    p=root/("workspace-"+preset+"-tests.log")
    text=p.read_text(encoding="utf-8",errors="replace") if p.exists() else ""
    match=re.search(r"100% tests passed, 0 tests failed out of (\d+)",text)
    if not match and not allow_running:raise RuntimeError("Test suite is incomplete: "+preset)
    if match:suites[preset]={"status":"passed","checks":int(match[1]),"log":p.name}
    else:suites[preset]={"status":"running","log":p.name}
log=(root/"workspace-build-release.log").read_text(encoding="utf-8",errors="replace")
warnings=re.findall(r"(?im)^.*\bwarning(?: [A-Z]\d+|:).*$",log)
assert not warnings,warnings
mesh=json.loads((root/"full-mesh.json").read_text())
assert mesh[0]["fingerprint"]==mesh[1]["fingerprint"]
for name in ("primary_capacity_bytes","key_capacity_bytes","bucket_capacity_bytes","vertex_capacity_bytes","position_map_capacity_bytes"):
    assert mesh[0]["corner_mapping"][name]==mesh[1]["corner_mapping"][name],name
trials=[]
for pattern in ("sweep*.jsonl","final-replay.jsonl","regression-*.jsonl"):
    for p in root.glob(pattern):trials += [r for r in map(json.loads,p.read_text().splitlines()) if "variant" in r]
assert all(r["exact"] for r in trials)
record={"release_build":"passed","compiler_warnings":len(warnings),"suites":suites,"exact_replay_trials":len(trials),"resolver_variants":len({r["variant"] for r in trials}),"full_mesh_fingerprint_equal":True,"full_mesh_fingerprint":str(mesh[0]["fingerprint"]),"render_vertices":mesh[0]["render_vertices"],"primary_table_capacity_bytes":mesh[0]["corner_mapping"]["primary_capacity_bytes"],"all_recorded_mapping_capacities_equal":True,"added_large_resolver_buffers":0,"input_sha256_verified":True,"initial_test_setup":"The first worktree CTest invocation missed three support executables. The default Release build supplied them, then all selected suites passed."}
(root/"validation.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
print(json.dumps(record,indent=2))
