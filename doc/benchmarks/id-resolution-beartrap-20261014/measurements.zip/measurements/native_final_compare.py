import json,subprocess,sys,time
from pathlib import Path
ROOT=Path(r'D:/woby')
TASK=Path(r'D:/.worktree/woby-id-resolution-20261014')
BASE=ROOT/'build/e2e-beartrap-20261014/matching-bin/woby.exe'
OPT=TASK/'build/vs2026-vcpkg/bin/Release/woby.exe'
MODEL=Path(r'D:/temp/obj_tests/20190810_BearTrap_Ground_Model.obj')
OUT=TASK/'build/id-resolution-20261014/native-final'
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'experiments/obj-profile'))
from e2e_analyze import summarize_run
manifest=[]
for rd in range(1,4):
    for label in (('baseline','optimized') if rd%2 else ('optimized','baseline')):
        dest=OUT/f'r{rd}-{label}'
        if dest.exists(): raise RuntimeError(f'Output already exists: {dest}')
        exe=BASE if label=='baseline' else OPT
        command=['uv','run',str(ROOT/'experiments/obj-profile/e2e_run.py'),str(exe),str(MODEL),'--output',str(dest),'--hidden','--settle-seconds','1','--render-seconds','2']
        print('Starting',rd,label,flush=True)
        dest.mkdir()
        with (dest/'driver.log').open('w') as log:
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
        s=summarize_run(dest/'result.json')
        s.update(configuration=label,round=rd)
        manifest.append(s)
        (OUT/'summary.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        print(json.dumps({k:s[k] for k in ('configuration','round','load_rpc_ms','native_scene_frame_cpu_complete_bounds_ms','cpu_import_ms')}),flush=True)
