from pathlib import Path
import shutil, subprocess
source=Path(r"D:/.worktree/woby-id-resolution-20261014")
dest=Path(r"D:/woby")
files=("CMakeLists.txt","src/obj_corner_mapping.h","tests/obj_prototype_tests.cpp")
for name in files:
    changed=subprocess.check_output(["git","diff","--",name],cwd=dest)
    if changed: raise RuntimeError("Workspace file changed during the investigation: "+name)
for name in files:
    shutil.copyfile(source/name,dest/name)
for item in (source/"experiments/id-resolution").iterdir():
    if item.is_file():
        folder=dest/"experiments/id-resolution";folder.mkdir(exist_ok=True)
        shutil.copyfile(item,folder/item.name)
p=dest/"experiments/obj-profile/e2e_generate.py"
original=(source/"build/id-resolution-20261014/source-baseline/e2e_generate.py").read_bytes()
if p.read_bytes()!=original: raise RuntimeError("The E2E generator changed during the investigation")
shutil.copyfile(source/"experiments/obj-profile/e2e_generate.py",p)
print("Applied the resolver, tests, probe, and ID timing anchor. Other profiling files were retained.")
