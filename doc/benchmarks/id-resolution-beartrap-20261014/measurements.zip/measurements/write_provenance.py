import hashlib,json,subprocess
from pathlib import Path
root=Path(r"D:/.worktree/woby-id-resolution-20261014")
measure=root/"build/id-resolution-20261014"
workspace=Path(r"D:/woby")
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
files=("CMakeLists.txt","src/obj_corner_mapping.h","tests/obj_prototype_tests.cpp","experiments/id-resolution/main.cpp","experiments/id-resolution/baseline.h","experiments/obj-profile/e2e_generate.py")
for name in files:assert (root/name).read_bytes()==(workspace/name).read_bytes(),name
binary_names=("woby.exe","woby_obj_e2e_viewer.exe","woby_id_resolution.exe","woby_obj_prototype_benchmark.exe")
bin=measure/"final-bin"
binaries={name:{"path":str(bin/name),"sha256":digest(bin/name)} for name in binary_names}
baseline=workspace/"build/e2e-beartrap-20261014/matching-bin"
originals={name:{"path":str(baseline/name),"sha256":digest(baseline/name)} for name in binary_names if (baseline/name).exists()}
for group,exe in (("native-final","woby.exe"),("traced-final","woby_obj_e2e_viewer.exe")):
    for row in json.loads((measure/group/"summary.json").read_text()):
        expected=(originals if row["configuration"]=="baseline" else binaries)[exe]["sha256"]
        assert row["executable_sha256"]==expected,(group,row["configuration"])
record={"baseline_revision":"7ee6133eb133b2102551ebd47a3ecca263e86cce","input":json.loads((measure/"input-verified.json").read_text()),"method":"Sequential fresh processes; warm input; rotating order; no concurrent build, tests, or profiler","cpu":"AMD Ryzen 7 5800H, 8 cores, 16 logical processors","memory_bytes":68564348928,"compiler":"MSVC 19.51.36243.0, /O2 /Ob2 /arch:AVX2","preset":"vs2026-vcpkg, Release","source_sha256":{name:digest(root/name) for name in files},"baseline_binaries":originals,"optimized_frozen_binaries":binaries,"workspace_woby_sha256":digest(workspace/"build/vs2026-vcpkg/bin/Release/woby.exe")}
(measure/"provenance.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
print("Final capture binary hashes and workspace source hashes match.")
