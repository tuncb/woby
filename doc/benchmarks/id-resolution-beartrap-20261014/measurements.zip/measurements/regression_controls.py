import json,subprocess
from pathlib import Path
ROOT=Path(r'D:/.worktree/woby-id-resolution-20261014')
OUT=ROOT/'build/id-resolution-20261014'
EXE=ROOT/'build/vs2026-vcpkg/bin/Release/woby_id_resolution.exe'
MODELS=Path(r'D:/temp/obj_tests')
for label,name in [('bus','uploads_files_2720101_BusGameMap.obj'),('san-miguel','san-miguel.obj'),('powerplant','powerplant.obj'),('bennu','bennu_OLA_v21_PTM_very-high.obj')]:
    print('Resolver regression:',label,flush=True)
    subprocess.run([str(EXE),str(MODELS/name),str(OUT/f'regression-{label}.jsonl'),'3','original','production'],check=True)
records=[]
for label,exe in [('baseline',Path(r'D:/woby/build/e2e-beartrap-20261014/matching-bin/woby_obj_prototype_benchmark.exe')),('optimized',ROOT/'build/vs2026-vcpkg/bin/Release/woby_obj_prototype_benchmark.exe')]:
    command=[str(exe),'prototype',str(MODELS/'20190810_BearTrap_Ground_Model.obj'),'16','deferred']
    print('Full mesh check:',label,flush=True)
    p=subprocess.run(command,capture_output=True,text=True,check=True,timeout=300)
    (OUT/f'full-mesh-{label}.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
    record=json.loads(p.stdout);record['configuration']=label;record['command']=command
    records.append(record)
    print(label,record['fingerprint'],record['corner_mapping'],flush=True)
assert records[0]['fingerprint']==records[1]['fingerprint'],'Full mesh fingerprint changed'
(OUT/'full-mesh.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
