#pragma once

#include "surface_mesh_quality.h"
#include "mesh_duplicates.h"
#include "mesh_degenerates.h"
#include "mesh_topology.h"
#include "mesh_intersections.h"
#include "uv_grid.h"
#include "difference_mesh.h"

#include <cstddef>
#include <string>
#include <stdexcept>

namespace woby
{

enum class ComparisonSide { a, b };
enum class AnalysisMode { model, perVolume, whole };
inline const char* analysisModeName(AnalysisMode mode) {
    return mode == AnalysisMode::perVolume ? "per_volume" : mode == AnalysisMode::whole ? "whole" : "model";
}
inline AnalysisMode parseAnalysisMode(const std::string& name) {
    if (name == "model") { return AnalysisMode::model; }
    if (name == "per_volume") { return AnalysisMode::perVolume; }
    if (name == "whole") { return AnalysisMode::whole; }
    throw std::invalid_argument("analysisMode must be model, per_volume or whole.");
}
inline AnalysisMode parseModelAnalysisMode(const std::string& name) {
    const auto mode = parseAnalysisMode(name);
    if (mode == AnalysisMode::model) { throw std::invalid_argument("Model analysisMode must be per_volume or whole."); }
    return mode;
}
enum class DiagnosticCategory { boundary, nonManifold, winding, duplicatePoints, duplicateTriangles, degenerateTriangles, nonManifoldVertices, holes, fins, selfIntersections };
inline constexpr size_t backgroundDetectorCount = static_cast<size_t>(DiagnosticCategory::selfIntersections);
inline constexpr size_t diagnosticCategoryCount = backgroundDetectorCount + 1;
inline constexpr std::array<const char*, diagnosticCategoryCount> diagnosticCategoryKeys = {
    "boundary_edges", "non_manifold_edges", "inconsistently_oriented_tris", "duplicate_points",
    "duplicate_tris", "degenerate_tris", "non_manifold_vertices", "holes", "fins", "self_intersections"
};

struct DetectorRequest {
    uint64_t revision = 0;
    bool cancel = false;
};

struct ComparisonMembership
{
    bool a = false;
    bool b = false;
    friend bool operator==(const ComparisonMembership &, const ComparisonMembership &) = default;
};

[[nodiscard]] inline bool comparisonMember(ComparisonMembership membership, ComparisonSide side)
{
    return side == ComparisonSide::a ? membership.a : membership.b;
}

enum class ComparisonMode
{
    distance,
    original,
    repaired,
    overlay,
    surfaceQuality
};

enum class ComparisonColorRange { custom, max90, max95, max975, max99, allSamples };
inline constexpr std::array<const char*, 6> comparisonColorRangeKeys = {"custom", "max90", "max95", "max975", "max99", "all"};
inline constexpr std::array<const char*, 6> comparisonColorRangeLabels = {
    "Custom", "90% of maximum", "95% of maximum", "97.5% of maximum", "99% of maximum", "100% of maximum"};

enum class AnalysisType { mesh, uv, uvQuality, surfaceComparison };
// Automatic preserves the behavior of scenes and API clients predating task selection.
enum class AnalysisTask { automatic, meshChecks, meshQuality, surfaceComparison, uvInspection };
[[nodiscard]] inline bool isUvAnalysis(AnalysisType type) { return type == AnalysisType::uv || type == AnalysisType::uvQuality; }
[[nodiscard]] inline bool isSingleSourceMeshTask(AnalysisTask task) { return task == AnalysisTask::meshChecks || task == AnalysisTask::meshQuality; }
[[nodiscard]] inline const char* analysisTypeKey(AnalysisType type) { return type == AnalysisType::surfaceComparison ? "surface_comparison" : type == AnalysisType::uvQuality ? "uv_quality" : type == AnalysisType::uv ? "uv" : "mesh"; }
enum class UvQualityMetric { angle, area, orientation, anisotropy, minStretch, overlap };
enum class UvAreaNormalization { perPatch, absolute };
enum class UvOverlapScope { perPatch, selectedPatches };
enum class UvView { layout, surface };

struct ComparisonSettings
{
    DifferenceSettings difference;
    AnalysisType type = AnalysisType::mesh;
    AnalysisTask task = AnalysisTask::automatic;
    UvView uvView = UvView::layout;
    UvGridSettings uvGrid{true, 10, 10};
    bool uvSeparated = false;
    bool uvLinkedSelection = true;
    UvQualityMetric uvMetric = UvQualityMetric::angle;
    UvAreaNormalization uvNormalization = UvAreaNormalization::perPatch;
    bool uvThresholdEnabled = false;
    float uvThreshold = 2.0f;
    float uvNearCollapse = .01f;
    bool uvOverlapEnabled = false;
    UvOverlapScope uvOverlapScope = UvOverlapScope::perPatch;
    bool uvRangeEnabled = false;
    float uvRangeMinimum = 0, uvRangeMaximum = 1;
    bool enabled = false;
    ComparisonMode mode = ComparisonMode::distance;
    bool distanceOnOriginal = false;
    float tolerance = 0.05f;
    float colorRange = 0.5f;
    float colorMinimum = 0;
    ComparisonColorRange colorRangeMode = ComparisonColorRange::custom;
    bool showEdges = false;
    bool showBoundaries = true;
    bool showNonManifold = true;
    bool showWinding = true;
    bool autoUpdateBoundaries = true, autoUpdateNonManifold = true, autoUpdateWinding = true;
    TopologyInspectionSettings topologyInspection;
    TopologyMode topologyMode = TopologyMode::originalIndex;
    AnalysisMode analysisMode = AnalysisMode::model;
    ComparisonSide diagnosticSide = ComparisonSide::a;
    DiagnosticCategory diagnosticCategory = DiagnosticCategory::boundary;
    SurfaceQualitySettings quality;
    DuplicateSettings duplicates;
    DegenerateSettings degenerates;
    IntersectionSettings intersections;
    friend bool operator==(const ComparisonSettings &, const ComparisonSettings &) = default;
};

[[nodiscard]] ComparisonSettings normalizedComparisonSettings(ComparisonSettings settings);
// The legacy detector enabled fields now specify automatic scheduling, not result visibility.
[[nodiscard]] bool diagnosticAutoUpdate(const ComparisonSettings& settings, DiagnosticCategory category);
void setDiagnosticAutoUpdate(ComparisonSettings& settings, DiagnosticCategory category, bool automatic);

} // namespace woby
