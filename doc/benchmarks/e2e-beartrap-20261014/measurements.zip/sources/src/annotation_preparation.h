#pragma once

#include "ui_state.h"
#include <atomic>
#include <memory>
#include <thread>

namespace woby {
struct AnnotationPreparationJob {
    const UiState* owner = nullptr;
    uint64_t generation = 0, contentRevision = 0;
    SceneObjectId fileId = 0;
    const Vertex* vertices = nullptr;
    const uint32_t* indices = nullptr;
    size_t vertexCount = 0, indexCount = 0;
    std::shared_ptr<const MeshAnnotationCache> result;
    std::string error;
    std::atomic<bool> done = false;
    // Last member: stop/join before destroying anything used by the worker.
    std::jthread worker;
};
struct AnnotationPreparationRuntime {
    std::unique_ptr<AnnotationPreparationJob> job;
    std::string error;
};
// Main-thread adapter. Call after scene commit; only this function publishes results.
void updateAnnotationPreparation(AnnotationPreparationRuntime& runtime, UiState& state);
// Optional when replacing geometry: each job owns its input. Cancellation joins
// the worker; stale results are also rejected by document, file, and revision.
void cancelAnnotationPreparation(AnnotationPreparationRuntime& runtime);
// Projection examines visible occluders too, so all visible model caches are needed.
[[nodiscard]] bool annotationPreparationReady(const UiState& state);
} // namespace woby
