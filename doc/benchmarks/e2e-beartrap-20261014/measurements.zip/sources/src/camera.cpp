#include "camera.h"
#include "math_utils.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace woby {
namespace {

constexpr float pi = 3.14159265358979323846f;

woby::Vec3 toVec3(const std::array<float, 3>& value)
{
    return {value[0], value[1], value[2]};
}

std::array<float, 3> viewDirection(const SceneCamera& camera, SceneUpAxis upAxis)
{
    const float pitchCos = std::cos(camera.pitchRadians);
    if (upAxis == SceneUpAxis::y) {
        return {
            std::cos(camera.yawRadians) * pitchCos,
            std::sin(camera.pitchRadians),
            -std::sin(camera.yawRadians) * pitchCos,
        };
    }

    return {
        std::cos(camera.yawRadians) * pitchCos,
        std::sin(camera.yawRadians) * pitchCos,
        std::sin(camera.pitchRadians),
    };
}

std::array<float, 3> rightDirection(const SceneCamera& camera, SceneUpAxis upAxis)
{
    if (upAxis == SceneUpAxis::y) {
        return {std::sin(camera.yawRadians), 0.0f, std::cos(camera.yawRadians)};
    }

    return {std::sin(camera.yawRadians), -std::cos(camera.yawRadians), 0.0f};
}

std::array<float, 3> upDirection(const SceneCamera& camera, SceneUpAxis upAxis)
{
    const auto view = viewDirection(camera, upAxis);
    const auto right = rightDirection(camera, upAxis);
    return {
        right[1] * view[2] - right[2] * view[1],
        right[2] * view[0] - right[0] * view[2],
        right[0] * view[1] - right[1] * view[0],
    };
}

std::array<float, 3> rolledRightDirection(const SceneCamera& camera, SceneUpAxis upAxis)
{
    const auto right = rightDirection(camera, upAxis);
    const auto up = upDirection(camera, upAxis);
    const float rollCos = std::cos(camera.rollRadians);
    const float rollSin = std::sin(camera.rollRadians);
    return {
        right[0] * rollCos - up[0] * rollSin,
        right[1] * rollCos - up[1] * rollSin,
        right[2] * rollCos - up[2] * rollSin,
    };
}

std::array<float, 3> rolledUpDirection(const SceneCamera& camera, SceneUpAxis upAxis)
{
    const auto right = rightDirection(camera, upAxis);
    const auto up = upDirection(camera, upAxis);
    const float rollCos = std::cos(camera.rollRadians);
    const float rollSin = std::sin(camera.rollRadians);
    return {
        up[0] * rollCos + right[0] * rollSin,
        up[1] * rollCos + right[1] * rollSin,
        up[2] * rollCos + right[2] * rollSin,
    };
}

void moveTarget(SceneCamera& camera, const std::array<float, 3>& direction, float amount)
{
    for (size_t axis = 0; axis < camera.target.size(); ++axis) {
        camera.target[axis] += direction[axis] * amount;
    }
}

} // namespace

SceneCamera normalizedSceneCamera(SceneCamera camera)
{
    for (const float value : {camera.target[0], camera.target[1], camera.target[2],
        camera.yawRadians, camera.pitchRadians, camera.rollRadians, camera.distance,
        camera.verticalFovDegrees, camera.nearPlane}) {
        if (!std::isfinite(value)) {
            throw std::runtime_error("Camera values must be finite.");
        }
    }
    // Leave headroom for squared distances and projection math in float precision.
    constexpr float maxCoordinate = 1.0e15f;
    for (auto& value : camera.target) { value = std::clamp(value, -maxCoordinate, maxCoordinate); }
    camera.distance = std::clamp(camera.distance, 0.001f, maxCoordinate);
    camera.pitchRadians = std::clamp(camera.pitchRadians, -pi * 0.5f, pi * 0.5f);
    camera.verticalFovDegrees = std::clamp(camera.verticalFovDegrees, 1.0f, 179.0f);
    // cameraFarPlane is at least max(distance, 10); keep a valid depth interval.
    camera.nearPlane = std::clamp(camera.nearPlane, 0.0001f, std::max(camera.distance, 10.0f) * 0.5f);
    return camera;
}

SceneCamera cameraWithPlacement(SceneCamera camera, const CameraPlacement& placement)
{
    const auto angle = [](float degrees) {
        if (!std::isfinite(degrees)) { throw std::invalid_argument("Camera angles must be finite."); }
        return std::fmod(degrees, 360.0f) * pi / 180.0f;
    };
    if (placement.target) { camera.target = *placement.target; }
    if (placement.yawDegrees) { camera.yawRadians = angle(*placement.yawDegrees); }
    if (placement.rollDegrees) { camera.rollRadians = angle(*placement.rollDegrees); }
    if (placement.pitchDegrees) {
        (void)angle(*placement.pitchDegrees);
        camera.pitchRadians = std::clamp(*placement.pitchDegrees, -90.0f, 90.0f) * pi / 180.0f;
    }
    if (placement.distance) {
        if (*placement.distance <= 0) { throw std::invalid_argument("Camera distance must be positive."); }
        camera.distance = *placement.distance;
    }
    if (placement.fovDegrees) { camera.verticalFovDegrees = *placement.fovDegrees; }
    if (placement.nearPlane) {
        camera.nearPlane = *placement.nearPlane;
        camera.automaticNearPlane = false;
    }
    if (placement.automaticNearPlane) { camera.automaticNearPlane = *placement.automaticNearPlane; }
    return normalizedSceneCamera(camera);
}

SceneCamera cameraLookingAt(SceneCamera camera, const std::array<float, 3>& eye,
    const std::array<float, 3>& target, SceneUpAxis upAxis)
{
    std::array<double, 3> offset{};
    for (size_t axis = 0; axis < offset.size(); ++axis) {
        if (!std::isfinite(eye[axis]) || !std::isfinite(target[axis])
            || std::abs(eye[axis]) > 1.0e15f || std::abs(target[axis]) > 1.0e15f) {
            throw std::invalid_argument("Eye and target must be finite world coordinates within +/-1e15.");
        }
        offset[axis] = static_cast<double>(eye[axis]) - target[axis];
    }
    const double distance = std::hypot(offset[0], offset[1], offset[2]);
    if (distance < 0.001 || distance > 1.0e15) {
        throw std::invalid_argument("Eye-to-target distance must be between 0.001 and 1e15.");
    }
    const double horizontal = upAxis == SceneUpAxis::y ? -offset[2] : offset[1];
    const double vertical = upAxis == SceneUpAxis::y ? offset[1] : offset[2];
    const double planar = std::hypot(offset[0], horizontal);
    if (planar > 0) { camera.yawRadians = static_cast<float>(std::atan2(horizontal, offset[0])); }
    camera.pitchRadians = static_cast<float>(std::atan2(vertical, planar));
    camera.target = target;
    camera.distance = static_cast<float>(distance);
    return normalizedSceneCamera(camera);
}

SceneCamera frameCameraBounds(const Bounds& bounds, SceneUpAxis upAxis)
{
    SceneCamera camera;
    camera.yawRadians = 0.48f;
    camera.pitchRadians = 0.28f;
    if (upAxis == SceneUpAxis::y) {
        camera.yawRadians = -0.48f;
    }

    return fitCameraBounds(camera, bounds);
}

SceneCamera fitCameraBounds(SceneCamera camera, const Bounds& bounds)
{
    camera = normalizedSceneCamera(camera);
    camera.target = bounds.center;
    const float radius = std::max(bounds.radius, 0.001f);
    const float halfFovRadians = camera.verticalFovDegrees * pi / 360.0f;
    const float minimumNear = camera.automaticNearPlane ? 0.0001f : camera.nearPlane;
    camera.distance = std::max((radius / std::sin(halfFovRadians)) * 1.35f,
        radius + minimumNear * 1.35f);
    return normalizedSceneCamera(camera);
}

SceneCamera cameraWithView(SceneCamera camera, CameraView view)
{
    // Z-up: front looks from -Y. Y-up: front looks from +Z.
    camera.yawRadians = -pi * 0.5f;
    camera.pitchRadians = 0.0f;
    camera.rollRadians = 0.0f;
    switch (view) {
    case CameraView::top: camera.pitchRadians = pi * 0.5f; break;
    case CameraView::bottom: camera.pitchRadians = -pi * 0.5f; break;
    case CameraView::isometric: camera.yawRadians = -pi * 0.25f; camera.pitchRadians = std::asin(1.0f / std::sqrt(3.0f)); break;
    case CameraView::front: break;
    case CameraView::back: camera.yawRadians = pi * 0.5f; break;
    case CameraView::left: camera.yawRadians = pi; break;
    case CameraView::right: camera.yawRadians = 0.0f; break;
    }
    return normalizedSceneCamera(camera);
}

float cameraViewportFov(const SceneCamera& camera, float aspectRatio)
{
    // Keep the camera field of view on the shorter canvas axis so framing a
    // bounding sphere remains valid with narrow canvases and open inspectors.
    const float aspect = std::isfinite(aspectRatio) ? std::clamp(aspectRatio, 0.0001f, 1.0f) : 1.0f;
    return 2.0f * std::atan(std::tan(camera.verticalFovDegrees * pi / 360.0f) / aspect) * 180.0f / pi;
}

woby::Vec3 cameraEye(const SceneCamera& camera, SceneUpAxis upAxis)
{
    const std::array<float, 3> view = viewDirection(camera, upAxis);
    return {
        camera.target[0] + view[0] * camera.distance,
        camera.target[1] + view[1] * camera.distance,
        camera.target[2] + view[2] * camera.distance};
}

woby::Vec3 cameraLookAt(const SceneCamera& camera)
{
    return toVec3(camera.target);
}

woby::Vec3 cameraUp(const SceneCamera& camera, SceneUpAxis upAxis)
{
    return toVec3(rolledUpDirection(camera, upAxis));
}

CameraDepthRange cameraDepthRange(const SceneCamera& camera, const Bounds& bounds, SceneUpAxis upAxis)
{
    const auto direction = viewDirection(camera, upAxis); // Target to eye.
    const double length = std::hypot(direction[0], direction[1], direction[2]);
    // Compute relative to the target in double precision instead of subtracting
    // rounded world-space eye coordinates on large, translated models.
    double centerDepth = camera.distance;
    for (size_t axis = 0; axis < 3; ++axis) {
        centerDepth += (static_cast<double>(camera.target[axis]) - bounds.center[axis]) * direction[axis] / length;
    }
    const double radius = bounds.radius;
    const double front = centerDepth - radius;
    const double automaticNear = front > 0 ? std::min(centerDepth * 0.01, front * 0.5) : 0;
    const double minimumNear = camera.automaticNearPlane ? 0.0001 : static_cast<double>(camera.nearPlane);
    const double nearPlane = std::max(minimumNear, automaticNear);
    const double padding = std::max({radius * 0.05, std::abs(centerDepth) * 0.00001, 0.0001});
    // Preserve the previous generous helper extent, but also cover scenes that
    // are far beyond the camera target after keyboard movement or look-at.
    const double farPlane = std::max({static_cast<double>(camera.distance) + radius * 4.0,
        centerDepth + radius + padding, nearPlane * 2.0, 10.0});
    return {static_cast<float>(nearPlane), static_cast<float>(farPlane)};
}

float cameraFarPlane(const SceneCamera& camera, const Bounds& bounds, SceneUpAxis upAxis)
{
    return cameraDepthRange(camera, bounds, upAxis).farPlane;
}

void orbitCamera(SceneCamera& camera, float deltaX, float deltaY, SceneUpAxis upAxis)
{
    constexpr float sensitivity = 0.006f;
    const float yawSign = upAxis == SceneUpAxis::y ? -1.0f : 1.0f;
    camera.yawRadians += deltaX * sensitivity * yawSign;
    camera.pitchRadians = std::clamp(camera.pitchRadians + deltaY * sensitivity, -pi * 0.5f, pi * 0.5f);
}

void rollCamera(SceneCamera& camera, float deltaX)
{
    constexpr float sensitivity = 0.006f;
    camera.rollRadians += deltaX * sensitivity;
}

void panCamera(
    SceneCamera& camera,
    float deltaX,
    float deltaY,
    float viewportHeight,
    SceneUpAxis upAxis)
{
    const float unitsPerPixel = std::max(camera.distance, 0.001f)
        * std::tan(camera.verticalFovDegrees * 0.5f * pi / 180.0f)
        * 2.0f
        / std::max(viewportHeight, 1.0f);
    moveTarget(camera, rolledRightDirection(camera, upAxis), -deltaX * unitsPerPixel);
    moveTarget(camera, rolledUpDirection(camera, upAxis), deltaY * unitsPerPixel);
}

void dollyCamera(SceneCamera& camera, float amount)
{
    camera.distance = std::max(camera.distance * std::exp(amount), 0.001f);
}

void moveCameraLocal(
    SceneCamera& camera,
    float rightAmount,
    float upAmount,
    float forwardAmount,
    SceneUpAxis upAxis)
{
    moveTarget(camera, rolledRightDirection(camera, upAxis), rightAmount);
    moveTarget(camera, rolledUpDirection(camera, upAxis), upAmount);

    const auto forward = viewDirection(camera, upAxis);
    moveTarget(camera, forward, -forwardAmount);
}

} // namespace woby
