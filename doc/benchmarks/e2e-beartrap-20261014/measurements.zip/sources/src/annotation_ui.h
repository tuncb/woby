#pragma once

#include "surface_annotation.h"
#include "annotation_work.h"
#include "scene_renderer.h"

namespace woby {
struct AnnotationExecutor;
struct AnnotationPointerRuntime;
struct AnnotationInteraction {
    SceneQueryRuntime* queries = nullptr;
    AnnotationWorkIdentity identity;
    SceneQueryStamp overlayStamp;
    uint64_t overlayAnnotations = 0;
    AnnotationExecutor* executor = nullptr;
    std::shared_ptr<AnnotationPointerRuntime> pending;
    std::optional<AnnotationShape> tool;
    bool sectionTool = false;
    std::optional<CrossSectionSettings> sectionStart;
    std::array<float, 3> sectionGrab{};
    bool dragging = false;
    // Runtime-only coarse guide on dense meshes; commit resolves the full edge.
    bool sampledPreview = false;
    SceneObjectId editing = 0;
    int handle = -1;
    // Editing with handle == -1 translates the entire outline.
    std::array<float, 2> grabControl{};
    AnnotationProjection projection, currentProjection;
    ScenePickView view;
    UiAnnotation preview;
    std::array<float, 2> start{}, end{}, pointerStart{}, pointerEnd{};
    std::string error;
    // Re-evaluate handle visibility once after navigation/scene changes settle.
    PickMatrix overlayView{}, overlayProjection{};
    uint32_t overlayWidth = 0, overlayHeight = 0;
    float overlayPixelScale = 0;
    SceneObjectId overlaySelection = 0;
    bool overlayReady = false;
    std::vector<PickPoint> overlayHandles;
    std::optional<PickPoint> overlayEdgePoint;
    bool overlayEdgeHit = false;
};
// ImGui editing state remains outside the logical scene.
struct AnnotationNameEdit {
    SceneObjectId objectId = invalidSceneObjectId;
    uint64_t generation = 0;
    std::string text;
    bool focus = false;
};
void drawAnnotationTools(const UiState& state, AnnotationInteraction& interaction, bool disabled);
void drawAnnotationObjects(UiState& state, AnnotationNameEdit& edit);
void drawAnnotationInspector(UiState& state, SceneQueryRuntime* queries = nullptr);
// True consumes the left-button gesture, including invalid placement attempts.
// Unprepared geometry returns false so camera navigation can handle the gesture.
bool beginAnnotationPointer(UiState& state, AnnotationInteraction& interaction,
    const ScenePickView& view, PickPoint point);
void moveAnnotationPointer(const UiState& state, AnnotationInteraction& interaction, PickPoint point, bool lockDirection = false);
void endAnnotationPointer(UiState& state, AnnotationInteraction& interaction, bool allowed);
void cancelAnnotationPointer(AnnotationInteraction& interaction);
// Poll on the UI thread, before history recording. Never waits for a worker.
void updateAnnotationPointer(UiState& state, AnnotationInteraction& interaction, const ScenePickView* view = nullptr);
// Returns the message banner's bottom edge in window coordinates (zero if absent),
// so other viewport notifications can be stacked below it.
float drawAnnotationOverlay(const UiState& state, AnnotationInteraction& interaction,
    const ScenePickView& view, float windowX, float pixelsToWindow, bool pointerAllowed, float windowY = 0.0f);
// CPU preparation is separate from GPU submission.
void prepareSceneAnnotations(const UiState& state, const ScenePickView& view,
    SceneRenderScratch& scratch, const AnnotationInteraction* interaction = nullptr);
// Requires prepared queries and the annotation vertex shader (projected NDC positions).
void submitSceneAnnotations(woby::graphics::ViewId viewId, const UiState& state,
    const woby::graphics::VertexLayout& layout, woby::graphics::ProgramHandle program,
    const SceneRenderScratch& scratch,
    const AnnotationInteraction* interaction = nullptr);
} // namespace woby
