#pragma once
#include "line_style.h"

#include "camera.h"
#include "comparison_report.h"
#include "model_mesh.h"
#include "scene_file.h"
#include "scene_objects.h"

#include <array>
#include <filesystem>
#include <string>
#include <vector>

namespace woby {

inline constexpr float defaultMasterVertexPointSize = 4.0f;
inline constexpr float minVertexPointSize = 1.0f;
inline constexpr float maxVertexPointSize = 40.0f;
inline constexpr float minVertexSizeScale = 0.1f;
inline constexpr float maxVertexSizeScale = 10.0f;
inline constexpr float minGroupScale = 0.01f;
inline constexpr float maxGroupScale = 20.0f;
inline constexpr float minGroupOpacity = 0.0f;
inline constexpr float maxGroupOpacity = 1.0f;
inline constexpr float minRotationDegrees = -180.0f;
inline constexpr float maxRotationDegrees = 180.0f;
inline constexpr float defaultDisplayBoundsMin = -10.0f;
inline constexpr float defaultDisplayBoundsMax = 10.0f;

struct UiGroupState {
    LineStyle lines;
    UvGridSettings uvGrid;
    bool visible = true;
    bool showSolidMesh = true;
    bool showTriangles = false;
    bool showVertices = false;
    float scale = 1.0f;
    float opacity = 1.0f;
    float vertexSizeScale = 1.0f;
    std::array<float, 3> center{};
    std::array<float, 3> translation{};
    std::array<float, 3> rotationDegrees{};
    std::array<float, 4> color{};
    Bounds localBounds;
    bool localBoundsValid = false;
    std::optional<std::array<std::array<double, 3>, 2>> originalBounds;
    SceneObjectId objectId = invalidSceneObjectId;
};

struct UiFileSettings {
    bool visible = true;
    float scale = 1.0f;
    float opacity = 1.0f;
    std::array<float, 3> center{};
    std::array<float, 3> translation{};
    std::array<float, 3> rotationDegrees{};
    Coordinate coordinateOffset{}; // Mesh origin minus the stable scene origin.
    AnalysisMode analysisMode = AnalysisMode::perVolume;
};

enum class PostLoadPhase { waitingForFrame, preparing, uploading, ready, failed };

struct UiFileState {
    std::filesystem::path path;
    std::string importerId;
    Mesh mesh;
    std::vector<UiGroupState> groupSettings;
    UiFileSettings fileSettings;
    float vertexSizeScale = 1.0f;
    SceneObjectId objectId = invalidSceneObjectId;
    PostLoadPhase postLoadPhase = PostLoadPhase::ready;
    std::string postLoadError; // Transient; excluded from scene files and undo settings.
};

[[nodiscard]] inline bool postLoadReady(const UiFileState& file) { return file.postLoadPhase == PostLoadPhase::ready; }

inline constexpr size_t invalidSceneNodeIndex = static_cast<size_t>(-1);

enum class UiSceneNodeKind {
    folder,
    file,
    group,
};

struct UiSceneNodeSettings {
    bool visible = true;
    float scale = 1.0f;
    float opacity = 1.0f;
    std::array<float, 3> center{};
    std::array<float, 3> translation{};
    std::array<float, 3> rotationDegrees{};
};

struct UiSceneNode {
    UiSceneNodeKind kind = UiSceneNodeKind::folder;
    std::string name;
    UiSceneNodeSettings settings;
    size_t fileIndex = invalidSceneNodeIndex;
    size_t groupIndex = invalidSceneNodeIndex;
    std::vector<UiSceneNode> children;
    // Folder identity, or the referenced file/group's canonical identity.
    SceneObjectId objectId = invalidSceneObjectId;
};

struct UiComparisonPart {
    SceneObjectId objectId = invalidSceneObjectId;
    // Retained when a source is removed, so missing inputs remain repairable.
    std::string name;
    bool enabled = true;
    friend bool operator==(const UiComparisonPart&, const UiComparisonPart&) = default;
};

// Navigation refers only to the computed result with this geometry signature.
// Live focus is session-only; views persist its finding index as a checkpoint.
struct DiagnosticFocus {
    uint64_t signature = 0;
    size_t index = 0;
    ComparisonSide side = ComparisonSide::a;
    DiagnosticCategory category = DiagnosticCategory::boundary;
};

struct UvFindingFocus {
    uint64_t signature = 0;
    size_t index = 0;
    // Empty while switching from layout to the 3D surface for a missing/collapsed UV.
    std::optional<std::array<std::array<float, 3>, 3>> geometry;
};

struct UvProbe {
    uint64_t signature = 0;
    SceneObjectId partId = 0;
    size_t triangle = 0; // One based within the source part.
    std::array<double,3> barycentric{1.0/3,1.0/3,1.0/3};
};

struct UiComparison {
    SceneObjectId objectId = invalidSceneObjectId;
    std::string name;
    ComparisonSettings settings;
    // Presentation only: source measurements always use source world transforms.
    std::array<float, 3> translation{};
    std::vector<UiComparisonPart> a, b;
    std::optional<DiagnosticFocus> diagnosticFocus;
    std::optional<UvProbe> uvProbe; // Transient inspection selection, excluded from scene/history.
    // View selection waiting for matching detector results; never drawn directly.
    std::optional<DiagnosticFocus> pendingDiagnosticFocus;
    std::optional<UvFindingFocus> uvFindingFocus;
    // One-shot inspection commands, excluded from scene files and history.
    uint64_t intersectionRequestRevision = 0;
    bool cancelIntersections = false;
    std::array<DetectorRequest, backgroundDetectorCount> detectorRequests{};
    DetectorRequest differenceRequest;
    // Derived memoization only, never serialized. Immutable entries can safely
    // be shared by state copies; queries do not change logical scene state.
    struct BoundsCache {
        uint64_t signature = 0;
        std::optional<Bounds> bounds;
    };
    mutable std::shared_ptr<const BoundsCache> boundsCache;
};

using ViewId = uint64_t;

struct UiViewObject {
    SceneObjectId objectId = invalidSceneObjectId;
    ViewObjectSettings settings;
    friend bool operator==(const UiViewObject&, const UiViewObject&) = default;
};

struct UiViewPart {
    SceneObjectId comparisonId = invalidSceneObjectId, partId = invalidSceneObjectId;
    ComparisonSide side = ComparisonSide::a;
    bool enabled = true;
    friend bool operator==(const UiViewPart&, const UiViewPart&) = default;
};

struct UiView {
    ViewId id = 0;
    std::string name;
    ViewSceneSettings scene;
    std::vector<UiViewObject> objects;
    std::vector<UiViewPart> parts;
};

struct ViewDiagnosticSelection {
    SceneObjectId comparisonId = invalidSceneObjectId;
    std::optional<size_t> index;
    friend bool operator==(const ViewDiagnosticSelection&, const ViewDiagnosticSelection&) = default;
};

struct ViewNavigation {
    SceneCamera camera;
    std::vector<SceneObjectId> selection;
    std::vector<ViewDiagnosticSelection> diagnostics;
    friend bool operator==(const ViewNavigation&, const ViewNavigation&) = default;
};

struct ViewApplication {
    ViewNavigation before, after;
    uint64_t revision = 0;
};

struct UiAnnotation {
    SceneObjectId objectId = 0, targetId = 0;
    std::vector<SceneObjectId> targetIds;
    std::string targetName;
    AnnotationSettings settings;
    AnnotationGeometryOwner geometry;
    std::optional<CrossSectionSettings> section;
    // Derived at load/geometry replacement boundaries, never serialized.
    uint64_t geometryRevision = 0; // Session-only attachment/outline identity.
    bool targetValid = false;
    bool targetPending = false;
};

// Derived-data dependencies. These counters are session metadata, never scene content.
// geometry: mesh content, hierarchy, transforms and coordinate frames.
// appearance: property values/colors; visibility: contributors to visible bounds (also opacity/render modes).
// labels: names/paths; analysis: membership and source/UV inputs.
// annotations: attachment/outline/visibility/readiness; presentation: analysis display/settings.
// picking: point sizes, line widths/depth and edge x-ray. Navigation and saved view records are independent.
// Unknown edits must use all. History advances all counters monotonically; New/Open changes sceneGeneration.
enum class SceneChange : uint32_t {
    none = 0, geometry = 1, appearance = 2, labels = 4, analysis = 8, visibility = 16,
    annotations = 32, presentation = 64, picking = 128, all = 255
};
constexpr SceneChange operator|(SceneChange a, SceneChange b) { return static_cast<SceneChange>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b)); }
struct SceneRevisions {
    uint64_t geometry = 0, appearance = 0, labels = 0, analysis = 0, visibility = 0;
    uint64_t annotations = 0, presentation = 0, picking = 0;
};

struct UiState {
    SceneRevisions revisions;
    std::optional<Coordinate> coordinateOrigin; // Fixed once the first file enters the scene.
    std::vector<UiAnnotation> annotations;
    std::vector<UiView> views;
    // Session identities and history notification; never serialized.
    ViewId nextViewId = 1, activeViewId = 0;
    std::optional<ViewApplication> viewApplication;
    // Application preference, excluded from scene persistence and dirty tracking.
    float uiScale = 1.0f;
    // Export preferences are session-only, not scene content or dirty state.
    ScreenshotSettings screenshotSettings;
    std::vector<UiComparison> comparisons;
    // Last active comparison, retained for source membership commands and badges.
    SceneObjectId activeComparisonId = invalidSceneObjectId;
    // Transient tree/canvas selection in click order; excluded from scene files and dirty tracking.
    std::vector<SceneObjectId> selectedSceneObjects;
    bool running = true;
    bool isDirty = false;
    bool showOrigin = false;
    bool showGrid = true;
    bool showDimensions = false;
    bool triangleEdgeXray = false;
    bool adaptivePoints = true;
    SceneUpAxis upAxis = SceneUpAxis::z;
    float masterVertexPointSize = defaultMasterVertexPointSize;
    // Persisted on Save/Open, but navigation never dirties the scene or enters history.
    SceneCamera camera;
    CameraInput cameraInput;
    Bounds sceneBounds;
    float viewerPaneWidth = 0.0f;
    bool viewerPaneVisible = true;
    // Shared right-hand inspector preferences; session-only, not scene content.
    float propertiesPaneWidth = 420.0f;
    bool propertiesPaneVisible = false;
    std::vector<UiFileState> files;
    std::vector<UiSceneNode> sceneNodes;
    // Session metadata: never saved, reset on scene open, or used for dirty tracking.
    SceneObjectId nextObjectId = 1;
    // Logical document identity; successful New/Open starts a fresh undo history.
    uint64_t sceneGeneration = 0;
    // Operation notification, not persisted content. Camera/selection/preferences
    // do not advance it. History consumes this revision at action boundaries.
    uint64_t sceneEditRevision = 0;
    uint64_t postLoadRevision = 0; // Derived readiness; excluded from dirty tracking and history notifications.
};

[[nodiscard]] bool scenePostLoadReady(const UiState& state);
[[nodiscard]] bool postLoadGroupDrawable(const UiFileState& file, const UiGroupState& group);
[[nodiscard]] bool postLoadNodeDrawable(const UiState& state, const UiSceneNode& node);
[[nodiscard]] std::array<float, 4> defaultGroupColor(size_t groupIndex);
[[nodiscard]] std::array<float, 3> nodeCenter(const Mesh& mesh, const MeshNode& node);
[[nodiscard]] std::vector<UiGroupState> createUiGroupStates(const Mesh& mesh, size_t firstColorIndex,
    const ModelLoadProgressCallback& progress = {});
[[nodiscard]] UiFileState createUiFileState(
    std::filesystem::path modelPath,
    Mesh mesh,
    size_t firstColorIndex,
    std::string importerId = {},
    const ModelLoadProgressCallback& progress = {});
// Establish the origin once and update derived file offsets at load/edit boundaries.
void synchronizeCoordinateFrames(UiState& state);
void groupTransformMatrix(const UiGroupState& settings, float* model);
void groupTransformMatrix(const UiGroupState& settings, double* model);
void fileTransformMatrix(const UiFileSettings& settings, float* model);
void fileTransformMatrix(const UiFileSettings& settings, double* model);
void sceneNodeTransformMatrix(const UiSceneNodeSettings& settings, float* model);
void sceneNodeTransformMatrix(const UiSceneNodeSettings& settings, double* model);
[[nodiscard]] Bounds defaultDisplayBounds();
// Visible selected objects, including descendants and comparison display offsets.
[[nodiscard]] std::optional<Bounds> selectedSceneBounds(const UiState& state);
// Union of visible, transformed occurrences and descendants of these IDs.
[[nodiscard]] std::optional<Bounds> sceneObjectBounds(const UiState& state, const std::vector<SceneObjectId>& objects);
[[nodiscard]] Bounds combineBounds(const std::vector<UiFileState>& files);
[[nodiscard]] Bounds combineBounds(
    const std::vector<UiFileState>& files,
    const std::vector<UiSceneNode>& sceneNodes);

[[nodiscard]] UiSceneNode createFileSceneNode(const UiFileState& file, size_t fileIndex);
void appendDefaultSceneNodesForFiles(UiState& state, size_t firstFileIndex);
void refreshSceneTreeFolderVisibility(UiState& state);
void refreshSceneTreeFolderCenters(UiState& state);

[[nodiscard]] SceneFileSettings sceneFileSettings(const UiFileSettings& settings);
[[nodiscard]] SceneGroupSettings sceneGroupSettings(const UiGroupState& settings);
[[nodiscard]] SceneNodeSettings sceneNodeSettings(const UiSceneNodeSettings& settings);
[[nodiscard]] SceneDocument createSceneDocument(const UiState& state);
void applySceneFileRecord(UiFileState& file, const SceneFileRecord& record);
void applySceneNodeRecords(UiState& state, const std::vector<SceneNodeRecord>& records);

} // namespace woby
