#include "ui_state.h"
#include "simd_bounds.h"
#include "surface_annotation.h"
#include "ui_operations.h"
#include "comparison_scene.h"
#include "utf8_path.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <utility>
#include <boost/unordered/unordered_flat_map.hpp>
#include <tuple>

#include "math_utils.h"

namespace woby {
namespace {

float finiteOr(float value, float fallback)
{
    return std::isfinite(value) ? value : fallback;
}

float clampFinite(float value, float minValue, float maxValue, float fallback)
{
    return std::clamp(finiteOr(value, fallback), minValue, maxValue);
}

std::array<float, 3> finiteArrayOrZero(const std::array<float, 3>& value)
{
    return {
        finiteOr(value[0], 0.0f),
        finiteOr(value[1], 0.0f),
        finiteOr(value[2], 0.0f),
    };
}

std::array<float, 3> clampFiniteArray(
    const std::array<float, 3>& value,
    float minValue,
    float maxValue)
{
    return {
        clampFinite(value[0], minValue, maxValue, 0.0f),
        clampFinite(value[1], minValue, maxValue, 0.0f),
        clampFinite(value[2], minValue, maxValue, 0.0f),
    };
}

std::array<float, 4> clampColor(const std::array<float, 4>& value)
{
    return {
        clampFinite(value[0], 0.0f, 1.0f, 1.0f),
        clampFinite(value[1], 0.0f, 1.0f, 1.0f),
        clampFinite(value[2], 0.0f, 1.0f, 1.0f),
        clampFinite(value[3], 0.0f, 1.0f, 1.0f),
    };
}

std::array<float, 3> transformPoint(const float* matrix, const std::array<float, 3>& position)
{
    const float x = matrix[0] * position[0] + matrix[4] * position[1] + matrix[8] * position[2] + matrix[12];
    const float y = matrix[1] * position[0] + matrix[5] * position[1] + matrix[9] * position[2] + matrix[13];
    const float z = matrix[2] * position[0] + matrix[6] * position[1] + matrix[10] * position[2] + matrix[14];
    const float w = matrix[3] * position[0] + matrix[7] * position[1] + matrix[11] * position[2] + matrix[15];
    if (std::abs(w) <= 0.000001f) {
        return {x, y, z};
    }

    return {x / w, y / w, z / w};
}

void transformFromSettings(
    const std::array<float, 3>& center,
    const std::array<float, 3>& translation,
    const std::array<float, 3>& rotationDegrees,
    float scale, double* model)
{
    float rotation[16];
    woby::transformMatrix(rotation, scale, scale, scale, woby::radians(rotationDegrees[0]),
        woby::radians(rotationDegrees[1]), woby::radians(rotationDegrees[2]), 0, 0, 0);
    CoordinateMatrix toOrigin{}, transformed{};
    coordinateIdentity(toOrigin.data());
    std::copy_n(rotation, 16, transformed.begin());
    for (size_t k = 0; k < 3; ++k) {
        toOrigin[12+k] = -double(center[k]);
        transformed[12+k] = double(center[k]) + translation[k];
    }
    coordinateMultiply(model, transformed.data(), toOrigin.data());
}

bool boundsContainFinitePoints(const Bounds& bounds)
{
    return std::isfinite(bounds.min[0])
        && std::isfinite(bounds.min[1])
        && std::isfinite(bounds.min[2])
        && std::isfinite(bounds.max[0])
        && std::isfinite(bounds.max[1])
        && std::isfinite(bounds.max[2])
        && bounds.min[0] <= bounds.max[0]
        && bounds.min[1] <= bounds.max[1]
        && bounds.min[2] <= bounds.max[2];
}

Bounds emptyAccumulatedBounds()
{
    Bounds bounds;
    bounds.min = {
        std::numeric_limits<float>::max(),
        std::numeric_limits<float>::max(),
        std::numeric_limits<float>::max(),
    };
    bounds.max = {
        std::numeric_limits<float>::lowest(),
        std::numeric_limits<float>::lowest(),
        std::numeric_limits<float>::lowest(),
    };
    bounds.center = {};
    bounds.radius = 0.0f;
    return bounds;
}

void expandBounds(Bounds& bounds, const std::array<float, 3>& position)
{
    for (size_t axis = 0; axis < 3u; ++axis) {
        bounds.min[axis] = std::min(bounds.min[axis], position[axis]);
        bounds.max[axis] = std::max(bounds.max[axis], position[axis]);
    }
}

void finalizeBounds(Bounds& bounds)
{
    for (size_t axis = 0; axis < 3u; ++axis) {
        bounds.center[axis] = (bounds.min[axis] + bounds.max[axis]) * 0.5f;
    }

    float radiusSquared = 0.0f;
    for (size_t corner = 0; corner < 8u; ++corner) {
        std::array<float, 3> position{};
        for (size_t axis = 0; axis < 3u; ++axis) {
            position[axis] = (corner & (size_t{1u} << axis)) != 0u
                ? bounds.max[axis]
                : bounds.min[axis];
        }

        const float x = position[0] - bounds.center[0];
        const float y = position[1] - bounds.center[1];
        const float z = position[2] - bounds.center[2];
        radiusSquared = std::max(radiusSquared, x * x + y * y + z * z);
    }

    bounds.radius = std::max(std::sqrt(radiusSquared), 0.001f);
}

Bounds nodeBounds(const Mesh& mesh, const MeshNode& node, const ModelLoadProgressCallback& progress = {},
    size_t completed = 0, size_t total = 0)
{
    if (mesh.preparationDeferred) { return mesh.bounds; }
    Bounds bounds = emptyAccumulatedBounds();
    auto reduction = floatBoundsReduction(bounds.min, bounds.max);
    const auto indices = meshNodeIndices(mesh, node);
    for (size_t index = 0; index < indices.size(); ++index) {
        if (index % 16384 == 0) {
            reportModelLoadProgress(progress, ModelLoadStage::groups, completed + index, total);
        }
        const uint32_t vertexIndex = indices[index];
        if (vertexIndex < meshGeometry(mesh).vertices.size()) {
            expand(reduction, meshGeometry(mesh).vertices[vertexIndex].position);
        }
    }
    const auto box = boundsResult(reduction);
    bounds.min = box[0]; bounds.max = box[1];

    if (!boundsContainFinitePoints(bounds)) {
        return mesh.bounds;
    }

    finalizeBounds(bounds);
    return bounds;
}

void expandTransformedBounds(Bounds& bounds, const Bounds& localBounds, const float* model)
{
    for (size_t corner = 0; corner < 8u; ++corner) {
        std::array<float, 3> position{};
        for (size_t axis = 0; axis < 3u; ++axis) {
            position[axis] = (corner & (size_t{1u} << axis)) != 0u
                ? localBounds.max[axis]
                : localBounds.min[axis];
        }
        expandBounds(bounds, transformPoint(model, position));
    }
}

UiSceneNodeKind uiSceneNodeKind(SceneNodeKind kind)
{
    switch (kind) {
    case SceneNodeKind::folder:
        return UiSceneNodeKind::folder;
    case SceneNodeKind::file:
        return UiSceneNodeKind::file;
    case SceneNodeKind::group:
        return UiSceneNodeKind::group;
    }

    return UiSceneNodeKind::folder;
}

SceneNodeKind sceneNodeKind(UiSceneNodeKind kind)
{
    switch (kind) {
    case UiSceneNodeKind::folder:
        return SceneNodeKind::folder;
    case UiSceneNodeKind::file:
        return SceneNodeKind::file;
    case UiSceneNodeKind::group:
        return SceneNodeKind::group;
    }

    return SceneNodeKind::folder;
}

UiSceneNodeSettings uiSceneNodeSettings(const SceneNodeSettings& settings)
{
    UiSceneNodeSettings result;
    result.visible = settings.visible;
    result.scale = clampFinite(settings.scale, minGroupScale, maxGroupScale, 1.0f);
    result.opacity = clampFinite(settings.opacity, minGroupOpacity, maxGroupOpacity, 1.0f);
    result.translation = finiteArrayOrZero(settings.translation);
    result.rotationDegrees = clampFiniteArray(
        settings.rotationDegrees,
        minRotationDegrees,
        maxRotationDegrees);
    return result;
}

bool validFileIndex(const std::vector<UiFileState>& files, size_t fileIndex)
{
    return fileIndex != invalidSceneNodeIndex && fileIndex < files.size();
}

bool validGroupIndex(const std::vector<UiFileState>& files, size_t fileIndex, size_t groupIndex)
{
    return validFileIndex(files, fileIndex)
        && groupIndex != invalidSceneNodeIndex
        && groupIndex < files[fileIndex].groupSettings.size()
        && groupIndex < meshGeometry(files[fileIndex].mesh).nodes.size();
}

bool refreshFolderVisibilityRecursive(const std::vector<UiFileState>& files, UiSceneNode& node)
{
    if (node.kind == UiSceneNodeKind::group) {
        return validGroupIndex(files, node.fileIndex, node.groupIndex)
            && files[node.fileIndex].fileSettings.visible
            && files[node.fileIndex].groupSettings[node.groupIndex].visible;
    }

    if (node.kind == UiSceneNodeKind::file) {
        if (!validFileIndex(files, node.fileIndex)) {
            return false;
        }

        const auto& file = files[node.fileIndex];
        if (!file.fileSettings.visible) {
            return false;
        }

        if (node.children.empty()) {
            return std::any_of(
                file.groupSettings.begin(),
                file.groupSettings.end(),
                [](const UiGroupState& group) {
                    return group.visible;
                });
        }

        bool hasVisibleChild = false;
        for (auto& child : node.children) {
            hasVisibleChild = refreshFolderVisibilityRecursive(files, child) || hasVisibleChild;
        }
        return hasVisibleChild;
    }

    bool hasVisibleChild = false;
    for (auto& child : node.children) {
        hasVisibleChild = refreshFolderVisibilityRecursive(files, child) || hasVisibleChild;
    }
    node.settings.visible = hasVisibleChild;
    return hasVisibleChild;
}

void expandSceneNodeBounds(
    Bounds& bounds,
    const std::vector<UiFileState>& files,
    const UiSceneNode& node,
    const float* parentModel,
    const std::vector<SceneObjectId>* selection = nullptr,
    bool included = false)
{
    const auto selected = [selection](SceneObjectId id) {
        return selection && id != invalidSceneObjectId
            && std::find(selection->begin(), selection->end(), id) != selection->end();
    };
    included = included || !selection || selected(node.objectId);
    if (node.kind == UiSceneNodeKind::folder) {
        if (!node.settings.visible) {
            return;
        }

        float nodeModel[16];
        float model[16];
        sceneNodeTransformMatrix(node.settings, nodeModel);
        woby::multiplyMatrices(model, parentModel, nodeModel);
        for (const auto& child : node.children) {
            expandSceneNodeBounds(bounds, files, child, model, selection, included);
        }
        return;
    }

    if (node.kind == UiSceneNodeKind::file) {
        if (!validFileIndex(files, node.fileIndex)) {
            return;
        }

        const auto& file = files[node.fileIndex];
        if (!file.fileSettings.visible || (selection && meshGeometry(file.mesh).vertices.empty())) {
            return;
        }

        float fileModel[16];
        float model[16];
        fileTransformMatrix(file.fileSettings, fileModel);
        woby::multiplyMatrices(model, parentModel, fileModel);
        if (node.children.empty()) {
            const size_t groupCount = std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size());
            for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
                if (!file.groupSettings[groupIndex].visible
                    || (!included && !selected(file.groupSettings[groupIndex].objectId))) {
                    continue;
                }
                float groupModel[16];
                float groupWorld[16];
                groupTransformMatrix(file.groupSettings[groupIndex], groupModel);
                woby::multiplyMatrices(groupWorld, model, groupModel);
                const Bounds localBounds = file.groupSettings[groupIndex].localBoundsValid
                    ? file.groupSettings[groupIndex].localBounds
                    : nodeBounds(file.mesh, meshGeometry(file.mesh).nodes[groupIndex]);
                expandTransformedBounds(bounds, localBounds, groupWorld);
            }
            return;
        }

        for (const auto& child : node.children) {
            expandSceneNodeBounds(bounds, files, child, model, selection, included);
        }
        return;
    }

    if (!included || !validGroupIndex(files, node.fileIndex, node.groupIndex)) {
        return;
    }

    const auto& file = files[node.fileIndex];
    const auto& group = file.groupSettings[node.groupIndex];
    if (!group.visible) {
        return;
    }

    float groupModel[16];
    float model[16];
    groupTransformMatrix(group, groupModel);
    woby::multiplyMatrices(model, parentModel, groupModel);
    const Bounds localBounds = group.localBoundsValid
        ? group.localBounds
        : nodeBounds(file.mesh, meshGeometry(file.mesh).nodes[node.groupIndex]);
    expandTransformedBounds(bounds, localBounds, model);
}

bool boundsValidOrDefault(const Bounds& bounds)
{
    return boundsContainFinitePoints(bounds);
}

Bounds sceneNodesBounds(const std::vector<UiFileState>& files, const std::vector<UiSceneNode>& sceneNodes)
{
    Bounds bounds = emptyAccumulatedBounds();
    float identity[16];
    woby::identityMatrix(identity);
    for (const auto& node : sceneNodes) {
        expandSceneNodeBounds(bounds, files, node, identity);
    }

    if (!boundsValidOrDefault(bounds)) {
        return defaultDisplayBounds();
    }

    finalizeBounds(bounds);
    return bounds;
}

void appendSceneNodeRecord(
    SceneDocument& document,
    const UiSceneNode& node,
    int parentIndex)
{
    SceneNodeRecord record;
    record.kind = sceneNodeKind(node.kind);
    record.name = node.name;
    record.parentIndex = parentIndex;
    record.fileIndex = node.fileIndex == invalidSceneNodeIndex ? -1 : static_cast<int>(node.fileIndex);
    record.groupIndex = node.groupIndex == invalidSceneNodeIndex ? -1 : static_cast<int>(node.groupIndex);
    record.settings = sceneNodeSettings(node.settings);

    const int nodeIndex = static_cast<int>(document.nodes.size());
    document.nodes.push_back(std::move(record));
    for (const auto& child : node.children) {
        appendSceneNodeRecord(document, child, nodeIndex);
    }
}

void refreshFolderCentersRecursive(UiState& state, UiSceneNode& node)
{
    for (auto& child : node.children) {
        refreshFolderCentersRecursive(state, child);
    }

    if (node.kind != UiSceneNodeKind::folder) {
        return;
    }

    Bounds bounds = emptyAccumulatedBounds();
    float identity[16];
    woby::identityMatrix(identity);
    for (const auto& child : node.children) {
        expandSceneNodeBounds(bounds, state.files, child, identity);
    }

    if (boundsContainFinitePoints(bounds)) {
        finalizeBounds(bounds);
        node.settings.center = bounds.center;
    }
}

} // namespace

bool scenePostLoadReady(const UiState& state)
{
    return std::all_of(state.files.begin(), state.files.end(), [](const auto& file) { return postLoadReady(file); });
}

bool postLoadGroupDrawable(const UiFileState& file, const UiGroupState& group)
{
    return postLoadReady(file) || (group.scale == 1.0f && group.rotationDegrees == std::array<float, 3>{});
}

bool postLoadNodeDrawable(const UiState& state, const UiSceneNode& node)
{
    if (node.kind != UiSceneNodeKind::folder || (node.settings.scale == 1.0f && node.settings.rotationDegrees == std::array<float, 3>{})) { return true; }
    const auto ready = [&](auto&& self, const UiSceneNode& item) -> bool {
        if (item.kind != UiSceneNodeKind::folder && item.fileIndex < state.files.size() && !postLoadReady(state.files[item.fileIndex])) { return false; }
        return std::all_of(item.children.begin(), item.children.end(), [&](const auto& child) { return self(self, child); });
    };
    return ready(ready, node);
}

std::array<float, 4> defaultGroupColor(size_t groupIndex)
{
    constexpr std::array<std::array<float, 4>, 12> palette = {{
        {0.90f, 0.22f, 0.24f, 1.0f},
        {0.13f, 0.58f, 0.95f, 1.0f},
        {0.20f, 0.72f, 0.38f, 1.0f},
        {1.00f, 0.70f, 0.18f, 1.0f},
        {0.67f, 0.42f, 0.95f, 1.0f},
        {0.06f, 0.76f, 0.78f, 1.0f},
        {0.96f, 0.36f, 0.67f, 1.0f},
        {0.58f, 0.72f, 0.16f, 1.0f},
        {0.98f, 0.48f, 0.16f, 1.0f},
        {0.40f, 0.55f, 1.00f, 1.0f},
        {0.74f, 0.62f, 0.34f, 1.0f},
        {0.72f, 0.78f, 0.86f, 1.0f},
    }};

    return palette[groupIndex % palette.size()];
}

std::array<float, 3> nodeCenter(const Mesh& mesh, const MeshNode& node)
{
    return nodeBounds(mesh, node).center;
}

std::vector<UiGroupState> createUiGroupStates(const Mesh& mesh, size_t firstColorIndex,
    const ModelLoadProgressCallback& progress)
{
    std::vector<UiGroupState> settings;
    settings.reserve(meshGeometry(mesh).nodes.size());
    size_t completed = 0, total = 0;
    for (const auto& node : meshGeometry(mesh).nodes) { total += size_t(node.indexCount) + node.lineIndexCount + node.pointIndexCount; }
    reportModelLoadProgress(progress, ModelLoadStage::groups, 0, total);

    for (size_t groupIndex = 0; groupIndex < meshGeometry(mesh).nodes.size(); ++groupIndex) {
        UiGroupState group;
        group.color = defaultGroupColor(firstColorIndex + groupIndex);
        const auto& node = meshGeometry(mesh).nodes[groupIndex];
        if (node.pointIndexCount) { group.showSolidMesh = false; group.showVertices = true; }
        setGroupVisible(group, node.defaultVisible);
        if (node.defaultColor) {
            const auto& color = *node.defaultColor;
            setGroupColor(group, {color[0], color[1], color[2], 1.0f});
            setGroupOpacity(group, color[3]);
        }
        group.localBounds = mesh.preparationDeferred ? mesh.bounds
            : nodeBounds(mesh, meshGeometry(mesh).nodes[groupIndex], progress, completed, total);
        group.localBoundsValid = !mesh.preparationDeferred;
        if (!mesh.preparationDeferred) { group.originalBounds = originalMeshBounds(mesh, &meshGeometry(mesh).nodes[groupIndex]); }
        group.center = group.localBounds.center;
        completed += size_t(node.indexCount) + node.lineIndexCount + node.pointIndexCount;
        settings.push_back(group);
    }

    reportModelLoadProgress(progress, ModelLoadStage::groups, total, total);
    return settings;
}

UiFileState createUiFileState(std::filesystem::path modelPath, Mesh mesh, size_t firstColorIndex, std::string importerId,
    const ModelLoadProgressCallback& progress)
{
    UiFileState file;
    file.path = std::move(modelPath);
    file.importerId = std::move(importerId);
    publishMeshGeometry(mesh);
    file.mesh = std::move(mesh);
    if (file.mesh.preparationDeferred) { file.postLoadPhase = PostLoadPhase::waitingForFrame; }
    file.groupSettings = createUiGroupStates(file.mesh, firstColorIndex, progress);
    if (!file.groupSettings.empty()) {
        file.fileSettings.visible = std::any_of(file.groupSettings.begin(), file.groupSettings.end(),
            [](const UiGroupState& group) { return group.visible; });
    }
    file.fileSettings.center = file.mesh.bounds.center;
    file.fileSettings.coordinateOffset = file.mesh.origin;
    reportModelLoadProgress(progress, ModelLoadStage::ready, 1, 1);
    return file;
}

void synchronizeCoordinateFrames(UiState& state)
{
    if (!state.coordinateOrigin && !state.files.empty()) { state.coordinateOrigin = state.files.front().mesh.origin; }
    if (!state.coordinateOrigin) { return; }
    if (!finiteCoordinate(*state.coordinateOrigin)) { throw std::invalid_argument("Non-finite scene origin."); }
    for (auto& file : state.files) { file.fileSettings.coordinateOffset = relativePosition(file.mesh.origin, *state.coordinateOrigin); }
}

void groupTransformMatrix(const UiGroupState& settings, double* model)
{
    transformFromSettings(settings.center, settings.translation, settings.rotationDegrees, settings.scale, model);
}
void fileTransformMatrix(const UiFileSettings& settings, double* model)
{
    transformFromSettings(settings.center, settings.translation, settings.rotationDegrees, settings.scale, model);
    for (size_t k = 0; k < 3; ++k) { model[12+k] += settings.coordinateOffset[k]; }
}
void sceneNodeTransformMatrix(const UiSceneNodeSettings& settings, double* model)
{
    transformFromSettings(settings.center, settings.translation, settings.rotationDegrees, settings.scale, model);
}
void groupTransformMatrix(const UiGroupState& settings, float* model)
{
    CoordinateMatrix precise; groupTransformMatrix(settings, precise.data());
    std::transform(precise.begin(), precise.end(), model, [](double v) { return static_cast<float>(v); });
}
void fileTransformMatrix(const UiFileSettings& settings, float* model)
{
    CoordinateMatrix precise; fileTransformMatrix(settings, precise.data());
    std::transform(precise.begin(), precise.end(), model, [](double v) { return static_cast<float>(v); });
}
void sceneNodeTransformMatrix(const UiSceneNodeSettings& settings, float* model)
{
    CoordinateMatrix precise; sceneNodeTransformMatrix(settings, precise.data());
    std::transform(precise.begin(), precise.end(), model, [](double v) { return static_cast<float>(v); });
}

Bounds defaultDisplayBounds()
{
    Bounds bounds;
    bounds.min = {defaultDisplayBoundsMin, defaultDisplayBoundsMin, defaultDisplayBoundsMin};
    bounds.max = {defaultDisplayBoundsMax, defaultDisplayBoundsMax, defaultDisplayBoundsMax};
    finalizeBounds(bounds);
    return bounds;
}

Bounds combineBounds(const std::vector<UiFileState>& files)
{
    Bounds bounds = emptyAccumulatedBounds();

    for (const auto& file : files) {
        float fileModel[16];
        fileTransformMatrix(file.fileSettings, fileModel);
        if (file.groupSettings.empty()) {
            expandTransformedBounds(bounds, file.mesh.bounds, fileModel);
            continue;
        }

        const size_t groupCount = std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size());
        for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
            float groupModel[16];
            float model[16];
            groupTransformMatrix(file.groupSettings[groupIndex], groupModel);
            woby::multiplyMatrices(model, fileModel, groupModel);
            const Bounds localBounds = file.groupSettings[groupIndex].localBoundsValid
                ? file.groupSettings[groupIndex].localBounds
                : nodeBounds(file.mesh, meshGeometry(file.mesh).nodes[groupIndex]);
            expandTransformedBounds(bounds, localBounds, model);
        }
    }

    if (!boundsContainFinitePoints(bounds)) {
        return defaultDisplayBounds();
    }

    finalizeBounds(bounds);
    return bounds;
}

Bounds combineBounds(
    const std::vector<UiFileState>& files,
    const std::vector<UiSceneNode>& sceneNodes)
{
    if (sceneNodes.empty()) {
        return combineBounds(files);
    }

    return sceneNodesBounds(files, sceneNodes);
}

UiSceneNode createFileSceneNode(const UiFileState& file, size_t fileIndex)
{
    UiSceneNode fileNode;
    fileNode.kind = UiSceneNodeKind::file;
    fileNode.objectId = file.objectId;
    const auto filename = pathToUtf8(file.path.filename());
    fileNode.name = filename.empty() ? pathToUtf8(file.path) : filename;
    fileNode.fileIndex = fileIndex;
    fileNode.children.reserve(file.groupSettings.size());

    const size_t groupCount = std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size());
    const auto makeGroup = [&](size_t groupIndex) {
        UiSceneNode groupNode;
        groupNode.kind = UiSceneNodeKind::group;
        groupNode.objectId = file.groupSettings[groupIndex].objectId;
        groupNode.name = meshNodeDisplayName(meshGeometry(file.mesh).nodes[groupIndex]);
        groupNode.fileIndex = fileIndex;
        groupNode.groupIndex = groupIndex;
        return groupNode;
    };
    if (meshGeometry(file.mesh).hierarchy.empty()) {
        for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
            fileNode.children.push_back(makeGroup(groupIndex));
        }
    } else {
        // Import validation guarantees a forest, parent-before-child ordering,
        // bounded depth and exactly one occurrence of each group.
        const auto& source = meshGeometry(file.mesh).hierarchy;
        std::vector<std::vector<size_t>> children(source.size() + 1u);
        for (size_t i = 0; i < source.size(); ++i) {
            children[source[i].parentIndex == UINT32_MAX ? source.size() : source[i].parentIndex].push_back(i);
        }
        const auto makeNode = [&](auto&& self, size_t index) -> UiSceneNode {
            const auto& item = source[index];
            if (item.groupIndex != UINT32_MAX) { return makeGroup(item.groupIndex); }
            UiSceneNode node;
            node.kind = UiSceneNodeKind::folder;
            node.name = item.name;
            node.settings.visible = false;
            for (const auto childIndex : children[index]) {
                auto child = self(self, childIndex);
                node.settings.visible = node.settings.visible || (child.kind == UiSceneNodeKind::group
                    ? file.groupSettings[child.groupIndex].visible : child.settings.visible);
                node.children.push_back(std::move(child));
            }
            return node;
        };
        for (const auto index : children[source.size()]) {
            fileNode.children.push_back(makeNode(makeNode, index));
        }
    }

    return fileNode;
}

void appendDefaultSceneNodesForFiles(UiState& state, size_t firstFileIndex)
{
    synchronizeCoordinateFrames(state);
    if (firstFileIndex >= state.files.size()) {
        return;
    }

    state.sceneNodes.reserve(state.sceneNodes.size() + state.files.size() - firstFileIndex);
    for (size_t fileIndex = firstFileIndex; fileIndex < state.files.size(); ++fileIndex) {
        state.sceneNodes.push_back(createFileSceneNode(state.files[fileIndex], fileIndex));
    }
    assignSceneObjectIds(state);
    refreshSceneTreeFolderCenters(state);
    notifySceneEdit(state);
}

std::optional<Bounds> selectedSceneBounds(const UiState& state)
{
    return sceneObjectBounds(state, state.selectedSceneObjects);
}

std::optional<Bounds> sceneObjectBounds(const UiState& state, const std::vector<SceneObjectId>& objects)
{
    if (objects.empty()) { return std::nullopt; }
    Bounds bounds = emptyAccumulatedBounds();
    float identity[16];
    woby::identityMatrix(identity);
    if (state.sceneNodes.empty()) {
        for (size_t index = 0; index < state.files.size(); ++index) {
            expandSceneNodeBounds(bounds, state.files, createFileSceneNode(state.files[index], index),
                identity, &objects);
        }
    } else {
        for (const auto& node : state.sceneNodes) {
            expandSceneNodeBounds(bounds, state.files, node, identity, &objects);
        }
    }
    for (const auto& comparison : state.comparisons) {
        if (!comparison.settings.enabled
            || std::find(objects.begin(), objects.end(), comparison.objectId) == objects.end()) { continue; }
        if (const auto display = comparisonDisplayBounds(state, comparison.objectId)) {
            expandBounds(bounds, display->min);
            expandBounds(bounds, display->max);
        }
    }
    const auto parts = state.annotations.empty() ? std::vector<ScenePickPart>{} : scenePickParts(state);
    for (const auto& item : state.annotations) {
        if (std::find(objects.begin(), objects.end(), item.objectId) == objects.end()) { continue; }
        for (const auto& line : annotationWorldLines(item, parts)) { expandBounds(bounds, line.a); expandBounds(bounds, line.b); }
    }
    if (!boundsContainFinitePoints(bounds)) { return std::nullopt; }
    finalizeBounds(bounds);
    return bounds;
}

void refreshSceneTreeFolderVisibility(UiState& state)
{
    for (auto& node : state.sceneNodes) {
        (void)refreshFolderVisibilityRecursive(state.files, node);
    }
}

void refreshSceneTreeFolderCenters(UiState& state)
{
    synchronizeCoordinateFrames(state);
    for (auto& node : state.sceneNodes) {
        refreshFolderCentersRecursive(state, node);
    }
}

SceneFileSettings sceneFileSettings(const UiFileSettings& settings)
{
    SceneFileSettings result;
    result.analysisMode = settings.analysisMode;
    result.visible = settings.visible;
    result.scale = settings.scale;
    result.opacity = settings.opacity;
    result.translation = settings.translation;
    result.rotationDegrees = settings.rotationDegrees;
    return result;
}

SceneGroupSettings sceneGroupSettings(const UiGroupState& settings)
{
    SceneGroupSettings result;
    result.uvGrid = settings.uvGrid;
    result.lines = settings.lines;
    result.visible = settings.visible;
    result.showSolidMesh = settings.showSolidMesh;
    result.showTriangles = settings.showTriangles;
    result.showVertices = settings.showVertices;
    result.scale = settings.scale;
    result.opacity = settings.opacity;
    result.vertexSizeScale = settings.vertexSizeScale;
    result.translation = settings.translation;
    result.rotationDegrees = settings.rotationDegrees;
    result.color = settings.color;
    return result;
}

SceneNodeSettings sceneNodeSettings(const UiSceneNodeSettings& settings)
{
    SceneNodeSettings result;
    result.visible = settings.visible;
    result.scale = settings.scale;
    result.opacity = settings.opacity;
    result.translation = settings.translation;
    result.rotationDegrees = settings.rotationDegrees;
    return result;
}

SceneDocument createSceneDocument(const UiState& state)
{
    SceneDocument document;
    document.coordinateOrigin = state.coordinateOrigin;
    if (!document.coordinateOrigin && !state.files.empty()) { document.coordinateOrigin = state.files.front().mesh.origin; }
    document.camera = state.camera;
    document.views = sceneViewRecords(state);
    document.annotations = sceneAnnotationRecords(state);
    // History snapshots use this mapping too. Resolve each part once instead
    // of scanning every file/group for every analysis member on every edit.
    boost::unordered_flat_map<SceneObjectId, std::pair<int, int>> partLocations;
    if (!state.comparisons.empty()) {
        size_t count = 0;
        for (const auto& file : state.files) { count += std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size()); }
        partLocations.reserve(count);
        for (size_t f = 0; f < state.files.size(); ++f) {
            const auto& file = state.files[f];
            for (size_t g = 0; g < std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size()); ++g) {
                const auto id = file.groupSettings[g].objectId;
                if (id != invalidSceneObjectId) {
                    partLocations.insert_or_assign(id, std::pair{static_cast<int>(f), static_cast<int>(g)});
                }
            }
        }
    }
    for (const auto& comparison : state.comparisons) {
        SceneComparisonRecord record;
        record.name = comparison.name;
        record.settings = comparison.settings;
        record.translation = comparison.translation;
        const auto saveParts = [&](const std::vector<UiComparisonPart>& members) {
            std::vector<SceneComparisonPartRecord> result;
            result.reserve(members.size());
            for (const auto& part : members) {
                SceneComparisonPartRecord reference;
                reference.name = part.name;
                reference.enabled = part.enabled;
                if (const auto location = partLocations.find(part.objectId); location != partLocations.end()) {
                    reference.fileIndex = location->second.first;
                    reference.groupIndex = location->second.second;
                }
                result.push_back(std::move(reference));
            }
            std::sort(result.begin(), result.end(), [](const auto& a, const auto& b) {
                return std::tie(a.fileIndex, a.groupIndex, a.name) < std::tie(b.fileIndex, b.groupIndex, b.name);
            });
            return result;
        };
        record.a = saveParts(comparison.a);
        record.b = saveParts(comparison.b);
        document.comparisons.push_back(std::move(record));
    }
    document.masterVertexPointSize = state.masterVertexPointSize;
    document.showOrigin = state.showOrigin;
    document.showGrid = state.showGrid;
    document.triangleEdgeXray = state.triangleEdgeXray;
    document.adaptivePoints = state.adaptivePoints;
    document.showDimensions = state.showDimensions;
    document.upAxis = state.upAxis;
    document.files.reserve(state.files.size());

    for (const auto& file : state.files) {
        SceneFileRecord fileRecord;
        fileRecord.path = file.path;
        fileRecord.coordinateOrigin = file.mesh.origin;
        fileRecord.importerId = file.importerId;
        fileRecord.settings = sceneFileSettings(file.fileSettings);
        fileRecord.vertexSizeScale = file.vertexSizeScale;
        fileRecord.groups.reserve(file.groupSettings.size());

        const size_t groupCount = std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size());
        for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
            SceneGroupRecord groupRecord;
            groupRecord.name = meshGeometry(file.mesh).nodes[groupIndex].name;
            groupRecord.lineGroup = meshGeometry(file.mesh).nodes[groupIndex].lineIndexCount != 0;
            groupRecord.pointGroup = meshGeometry(file.mesh).nodes[groupIndex].pointIndexCount != 0;
            groupRecord.settings = sceneGroupSettings(file.groupSettings[groupIndex]);
            fileRecord.groups.push_back(std::move(groupRecord));
        }

        document.files.push_back(std::move(fileRecord));
    }

    if (state.sceneNodes.empty()) {
        for (size_t fileIndex = 0; fileIndex < state.files.size(); ++fileIndex) {
            appendSceneNodeRecord(document, createFileSceneNode(state.files[fileIndex], fileIndex), -1);
        }
    } else {
        for (const auto& node : state.sceneNodes) {
            appendSceneNodeRecord(document, node, -1);
        }
    }

    return document;
}

void applySceneFileRecord(UiFileState& file, const SceneFileRecord& record)
{
    if (record.coordinateOrigin && file.mesh.origin != *record.coordinateOrigin) {
        rebaseMesh(file.mesh, *record.coordinateOrigin);
        publishMeshGeometry(file.mesh);
        file.groupSettings = createUiGroupStates(file.mesh, 0);
        file.fileSettings.center = file.mesh.bounds.center;
        file.fileSettings.coordinateOffset = file.mesh.origin;
    }
    if (!record.importerId.empty() || std::any_of(record.groups.begin(), record.groups.end(),
            [](const SceneGroupRecord& group) { return group.lineGroup || group.pointGroup; })) {
        if (record.importerId != file.importerId || record.groups.size() != meshGeometry(file.mesh).nodes.size()) {
            throw std::runtime_error("Saved importer or group layout does not match the imported file.");
        }
        for (size_t i = 0; i < record.groups.size(); ++i) {
            if (record.groups[i].name != meshGeometry(file.mesh).nodes[i].name
                || record.groups[i].lineGroup != (meshGeometry(file.mesh).nodes[i].lineIndexCount != 0)
                || record.groups[i].pointGroup != (meshGeometry(file.mesh).nodes[i].pointIndexCount != 0)) {
                throw std::runtime_error("Importer group order changed; cannot restore saved group settings.");
            }
        }
    }
    file.fileSettings.visible = record.settings.visible;
    file.fileSettings.analysisMode = record.settings.analysisMode;
    file.fileSettings.scale = clampFinite(record.settings.scale, minGroupScale, maxGroupScale, 1.0f);
    file.fileSettings.opacity = clampFinite(record.settings.opacity, minGroupOpacity, maxGroupOpacity, 1.0f);
    file.fileSettings.translation = finiteArrayOrZero(record.settings.translation);
    file.fileSettings.rotationDegrees = clampFiniteArray(
        record.settings.rotationDegrees,
        minRotationDegrees,
        maxRotationDegrees);
    file.vertexSizeScale = clampFinite(record.vertexSizeScale, minVertexSizeScale, maxVertexSizeScale, 1.0f);

    const size_t groupCount = std::min(file.groupSettings.size(), record.groups.size());
    for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
        auto& group = file.groupSettings[groupIndex];
        const auto& recordGroup = record.groups[groupIndex].settings;
        group.uvGrid = normalizedUvGrid(recordGroup.uvGrid);
        group.lines = normalizedLineStyle(recordGroup.lines);
        group.visible = recordGroup.visible;
        group.showSolidMesh = recordGroup.showSolidMesh;
        group.showTriangles = recordGroup.showTriangles;
        group.showVertices = recordGroup.showVertices;
        group.scale = clampFinite(recordGroup.scale, minGroupScale, maxGroupScale, 1.0f);
        group.opacity = clampFinite(recordGroup.opacity, minGroupOpacity, maxGroupOpacity, 1.0f);
        group.vertexSizeScale = clampFinite(
            recordGroup.vertexSizeScale,
            minVertexSizeScale,
            maxVertexSizeScale,
            1.0f);
        group.translation = finiteArrayOrZero(recordGroup.translation);
        group.rotationDegrees = clampFiniteArray(
            recordGroup.rotationDegrees,
            minRotationDegrees,
            maxRotationDegrees);
        group.color = clampColor(recordGroup.color);
    }

    if (!record.settings.visible) {
        for (auto& group : file.groupSettings) {
            group.visible = false;
        }
        file.fileSettings.visible = false;
    } else if (!file.groupSettings.empty()) {
        file.fileSettings.visible = std::any_of(
            file.groupSettings.begin(),
            file.groupSettings.end(),
            [](const UiGroupState& group) {
                return group.visible;
            });
    }
}

void applySceneNodeRecords(UiState& state, const std::vector<SceneNodeRecord>& records)
{
    state.sceneNodes.clear();
    if (records.empty()) {
        appendDefaultSceneNodesForFiles(state, 0u);
        refreshSceneTreeFolderCenters(state);
        return;
    }

    std::vector<std::vector<size_t>> childIndices(records.size());
    std::vector<size_t> rootIndices;
    rootIndices.reserve(records.size());
    for (size_t index = 0; index < records.size(); ++index) {
        const int parentIndex = records[index].parentIndex;
        if (parentIndex < 0) {
            rootIndices.push_back(index);
            continue;
        }

        if (static_cast<size_t>(parentIndex) >= index) {
            throw std::runtime_error("Scene node parent must appear before its child.");
        }
        childIndices[static_cast<size_t>(parentIndex)].push_back(index);
    }

    auto buildNode = [&](auto&& self, size_t recordIndex) -> UiSceneNode {
        const auto& record = records[recordIndex];
        UiSceneNode node;
        node.kind = uiSceneNodeKind(record.kind);
        node.name = record.name;
        node.settings = uiSceneNodeSettings(record.settings);
        node.fileIndex = record.fileIndex < 0
            ? invalidSceneNodeIndex
            : static_cast<size_t>(record.fileIndex);
        node.groupIndex = record.groupIndex < 0
            ? invalidSceneNodeIndex
            : static_cast<size_t>(record.groupIndex);

        if (node.kind == UiSceneNodeKind::file && !validFileIndex(state.files, node.fileIndex)) {
            throw std::runtime_error("Scene file node references an invalid file index.");
        }
        if (node.kind == UiSceneNodeKind::group
            && !validGroupIndex(state.files, node.fileIndex, node.groupIndex)) {
            throw std::runtime_error("Scene group node references an invalid file or group index.");
        }

        node.children.reserve(childIndices[recordIndex].size());
        for (const size_t childIndex : childIndices[recordIndex]) {
            node.children.push_back(self(self, childIndex));
        }
        return node;
    };

    state.sceneNodes.reserve(rootIndices.size());
    for (const size_t rootIndex : rootIndices) {
        state.sceneNodes.push_back(buildNode(buildNode, rootIndex));
    }
    assignSceneObjectIds(state);
    refreshSceneTreeFolderVisibility(state);
    refreshSceneTreeFolderCenters(state);
}

} // namespace woby
