#pragma once

#include "scene_objects.h"
#include <nlohmann/json_fwd.hpp>
#include <array>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace woby {

enum class ControlAction {
    status, capabilities, sceneInfo, sceneTree, sceneBounds, sceneUndo, sceneRedo,
    visibility, render, transformGet, transformSet, transformReset,
    opacity, colorSet, colorReset, vertexSize, grid, dimensions, origin, upAxis,
    viewList, viewCreate, viewApply, viewUpdate, viewRename, viewDelete, cameraView,
    cameraGet, cameraFrame, cameraSet, cameraLookAt, cameraOrbit, cameraPan, cameraRoll, cameraDolly, cameraMove,
    modelAdd, modelRemove, modelSet, folderAdd, importersList, importersAdd, importersScan,
    importersForget, stats, performance, performanceBegin, performanceEnd, pane,
    comparisonCreate, comparisonDelete, comparisonSet, comparisonAdd, comparisonRemove,
    comparisonClear, comparisonSwap, comparisonFindings, comparisonExport, comparisonExportStatus, comparisonExportCancel, comparisonResults, comparisonFocus, comparisonEnable, comparisonRun, comparisonCancel,
    comparisonUvTriangles, comparisonUvProbe, comparisonUvProbeGet, comparisonUvProbeClear,
    annotationList, annotationGet, annotationCreate, annotationSet, annotationReshape, annotationMove, annotationDelete,
    differenceCreate, differenceGet, differenceSet, differenceRebuild, differenceCancel, differenceExport, differenceDelete,
};

// Validated, owned command data. No scene pointers or runtime resources cross threads.
struct ControlOperation {
    ControlAction action = ControlAction::status;
    std::string target;
    SceneObjectId objectId = invalidSceneObjectId;
    std::filesystem::path path;
    std::string axis, preset, viewId;
    bool tree = false;
    bool remember = false;
    std::optional<bool> visible, solid, triangles, vertices, xray, adaptivePoints;
    std::optional<bool> propertiesVisible;
    std::optional<std::string> analysisMode;
    std::optional<bool> uvThresholdEnabled, uvOverlapEnabled, uvRangeEnabled;
    std::optional<float> uvThreshold, uvNearCollapse, uvRangeMinimum, uvRangeMaximum;
    std::optional<std::string> uvOverlapScope;
    std::optional<bool> uvGrid, uvSeparated, uvLinkedSelection, isolate;
    std::optional<std::string> uvColor, uvMetric, uvNormalization;
    std::optional<float> uvMinimum, uvMaximum;
    std::optional<float> uvDensityU, uvDensityV;
    std::optional<float> lineWidth;
    std::optional<bool> lineDepthTest;
    std::optional<std::array<float, 3>> translation, rotationDegrees, rgb;
    std::optional<std::array<double, 3>> barycentric;
    std::optional<float> scale, value, pixels, width;
    std::optional<float> yawDegrees, pitchDegrees, rollDegrees, right, up, forward, factor;
    std::optional<std::array<float, 3>> cameraTarget, eye;
    std::optional<float> distance, fovDegrees, nearPlane;
    std::optional<bool> automaticNearPlane;
    std::optional<std::string> name, mode, side, a, b, object;
    SceneObjectId aId = invalidSceneObjectId, bId = invalidSceneObjectId, memberId = invalidSceneObjectId;
    std::optional<bool> distanceOnA, showEdges, showBoundaries, showNonManifold, showWinding, enabled;
    std::optional<float> tolerance, colorRange, colorMinimum;
    std::optional<std::string> type, uvView;
    std::optional<std::string> qualityMetric, topologyMode, detector;
    std::optional<uint64_t> index, offset, limit, intersectionPairLimit, intersectionCandidateLimit;
    std::optional<std::string> collection, revision;
    std::optional<bool> duplicatePoints, duplicateTriangles, showDuplicatePoints, showDuplicateTriangles;
    std::optional<bool> nonManifoldVertices, showNonManifoldVertices, holes, showHoles, fins, showFins;
    std::optional<float> holeSizeRatioTolerance, finMaxAreaRatio;
    std::optional<bool> selfIntersections, autoUpdateSelfIntersections, showSelfIntersections;
    std::optional<bool> autoUpdateBoundaries, autoUpdateNonManifold, autoUpdateWinding;
    std::optional<bool> degenerateTriangles, showDegenerateTriangles;
    std::optional<float> needleThresholdRatio, capMinAngleDegrees;
    std::optional<bool> qualityOnA, qualityMinimumEnabled, qualityMaximumEnabled;
    std::optional<float> qualityMinimumSize, qualityMaximumSize;
    std::optional<std::string> shape, comments;
    std::optional<bool> locked;
    std::optional<std::array<float, 2>> start, end, delta;
    std::optional<float> aspect, opacity;
    std::optional<bool> showAOnly, showBOnly, showWalls;
    std::optional<std::array<float, 3>> planeStart, planeEnd;
    std::optional<std::string> sectionUpAxis;
    std::optional<float> lift;
    std::optional<bool> showPlane, showConnections, showDifferences, faceOn, sourceVisible;
    std::optional<uint64_t> sourceIndex, referenceIndex, comparedIndex;
};

struct ControlMethod {
    ControlAction action;
    std::string method;
    std::string cli;
    std::string positional;
    std::vector<std::string> options;
    std::vector<std::string> required;
    bool requiresValues = false;
    bool mutating = false;
};

const std::vector<ControlMethod>& controlMethods();
const ControlMethod* findControlMethod(const std::string& method);
const ControlMethod& controlMethod(ControlAction action);
std::string controlMethodUsage(const ControlMethod& method);
ControlOperation parseControlOperation(const ControlMethod& method, const nlohmann::json& params);
nlohmann::json controlOperationParams(const ControlOperation& operation);
nlohmann::json controlCapabilities();
struct ControlArguments;
bool parseExtendedControlArguments(int argc, char** argv, ControlArguments& arguments);

} // namespace woby
