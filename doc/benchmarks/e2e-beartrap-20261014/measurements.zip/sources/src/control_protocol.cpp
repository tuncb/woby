#include "uv_quality.h"
#include "control_protocol.h"
#include "comparison_settings.h"
#include "command_line.h"
#include "utf8_path.h"

#include <nlohmann/json.hpp>

#include <algorithm>
#include <cmath>
#include <charconv>
#include <limits>
#include <stdexcept>

namespace woby {
using Json = nlohmann::json;

const std::vector<ControlMethod>& controlMethods()
{
    static const std::vector<ControlMethod> methods = {
        {ControlAction::differenceCreate, "analysis.difference-create", "analysis difference-create", "target", {}, {}, false, true},
        {ControlAction::differenceRebuild, "analysis.difference-rebuild", "analysis difference-rebuild", "target", {}, {}, false, true},
        {ControlAction::differenceGet, "analysis.difference-get", "analysis difference-get", "target", {}, {}},
        {ControlAction::differenceSet, "analysis.difference-set", "analysis difference-set", "target", {"visible", "showAOnly", "showBOnly", "showWalls", "opacity"}, {}, true, true},
        {ControlAction::differenceCancel, "analysis.difference-cancel", "analysis difference-cancel", "target", {}, {}, false, true},
        {ControlAction::differenceDelete, "analysis.difference-delete", "analysis difference-delete", "target", {}, {}, false, true},
        {ControlAction::differenceExport, "analysis.difference-export", "analysis difference-export", "target", {"path"}, {"path"}, false, true},
        {ControlAction::annotationList, "annotation.list", "annotation list", {}, {}, {}},
        {ControlAction::annotationGet, "annotation.get", "annotation get", "target", {}, {}},
        {ControlAction::annotationCreate, "annotation.create", "annotation create", "target",
            {"shape", "start", "end", "aspect", "name", "comments", "visible", "locked", "rgb", "opacity", "width",
             "planeStart", "planeEnd", "sectionUpAxis", "lift", "showPlane", "showConnections", "showDifferences", "faceOn", "sourceIndex", "sourceVisible", "referenceIndex", "comparedIndex"}, {"shape"}, false, true},
        {ControlAction::annotationSet, "annotation.set", "annotation set", "target",
            {"name", "comments", "visible", "locked", "rgb", "opacity", "width",
             "planeStart", "planeEnd", "sectionUpAxis", "lift", "showPlane", "showConnections", "showDifferences", "faceOn", "sourceIndex", "sourceVisible", "referenceIndex", "comparedIndex"}, {}, true, true},
        {ControlAction::annotationReshape, "annotation.reshape", "annotation reshape", "target", {"start", "end"}, {}, true, true},
        {ControlAction::annotationMove, "annotation.move", "annotation move", "target", {"delta"}, {"delta"}, false, true},
        {ControlAction::annotationDelete, "annotation.delete", "annotation delete", "target", {}, {}, false, true},
        {ControlAction::status, "status", "status", {}, {}, {}},
        {ControlAction::capabilities, "capabilities", "capabilities", {}, {}, {}},
        {ControlAction::sceneInfo, "scene.info", "scene info", {}, {}, {}},
        {ControlAction::sceneTree, "scene.tree", "scene tree", {}, {}, {}},
        {ControlAction::sceneBounds, "scene.bounds", "scene bounds", {}, {}, {}},
        {ControlAction::sceneUndo, "scene.undo", "scene undo", {}, {}, {}, false, true},
        {ControlAction::sceneRedo, "scene.redo", "scene redo", {}, {}, {}, false, true},
        {ControlAction::visibility, "visibility.set", "visibility set", "target", {"visible"}, {"visible"}, false, true},
        {ControlAction::render, "render.set", "render set", "target", {"solid", "triangles", "vertices", "xray", "adaptivePoints", "uvGrid", "uvDensityU", "uvDensityV", "uvColor", "uvMinimum", "uvMaximum", "lineWidth", "lineDepthTest"}, {}, true, true},
        {ControlAction::transformGet, "transform.get", "transform get", "target", {}, {}},
        {ControlAction::transformSet, "transform.set", "transform set", "target", {"translation", "rotationDegrees", "scale"}, {}, true, true},
        {ControlAction::transformReset, "transform.reset", "transform reset", "target", {}, {}, false, true},
        {ControlAction::opacity, "opacity.set", "opacity set", "target", {"value"}, {"value"}, false, true},
        {ControlAction::colorSet, "color.set", "color set", "target", {"rgb"}, {"rgb"}, false, true},
        {ControlAction::colorReset, "color.reset", "color reset", "target", {}, {}, false, true},
        {ControlAction::vertexSize, "vertex-size.set", "vertex-size set", "target", {"pixels", "scale"}, {}, true, true},
        {ControlAction::grid, "grid.set", "grid set", {}, {"visible"}, {"visible"}, false, true},
        {ControlAction::dimensions, "dimensions.set", "dimensions set", {}, {"visible"}, {"visible"}, false, true},
        {ControlAction::origin, "origin.set", "origin set", {}, {"visible"}, {"visible"}, false, true},
        {ControlAction::upAxis, "up-axis.set", "up-axis set", "axis", {}, {}, false, true},
        {ControlAction::viewList, "view.list", "view list", "", {}, {}, false, false},
        {ControlAction::viewCreate, "view.create", "view create", "", {"name"}, {}, false, true},
        {ControlAction::viewApply, "view.apply", "view apply", "viewId", {}, {}, false, true},
        {ControlAction::viewUpdate, "view.update", "view update", "viewId", {}, {}, false, true},
        {ControlAction::viewRename, "view.rename", "view rename", "viewId", {"name"}, {"name"}, false, true},
        {ControlAction::viewDelete, "view.delete", "view delete", "viewId", {}, {}, false, true},
        {ControlAction::cameraView, "camera.view", "camera view", "preset", {}, {}, false, true},
        {ControlAction::cameraGet, "camera.get", "camera get", {}, {}, {}},
        {ControlAction::cameraFrame, "camera.frame", "camera frame", {}, {"object"}, {}, false, true},
        {ControlAction::cameraSet, "camera.set", "camera set", {},
            {"target", "yawDegrees", "pitchDegrees", "rollDegrees", "distance", "fovDegrees", "nearPlane", "automaticNearPlane"}, {}, true, true},
        {ControlAction::cameraLookAt, "camera.look-at", "camera look-at", {}, {"eye", "target"}, {"eye", "target"}, false, true},
        {ControlAction::cameraOrbit, "camera.orbit", "camera orbit", {}, {"yawDegrees", "pitchDegrees"}, {}, true, true},
        {ControlAction::cameraPan, "camera.pan", "camera pan", {}, {"right", "up"}, {}, true, true},
        {ControlAction::cameraRoll, "camera.roll", "camera roll", {}, {"rollDegrees"}, {"rollDegrees"}, false, true},
        {ControlAction::cameraDolly, "camera.dolly", "camera dolly", {}, {"factor"}, {"factor"}, false, true},
        {ControlAction::cameraMove, "camera.move", "camera move", {}, {"right", "up", "forward"}, {}, true, true},
        {ControlAction::modelAdd, "model.add", "model add", "path", {}, {}, false, true},
        {ControlAction::modelSet, "model.set", "model set", "target", {"analysisMode"}, {"analysisMode"}, false, true},
        {ControlAction::modelRemove, "model.remove", "model remove", "target", {}, {}, false, true},
        {ControlAction::folderAdd, "folder.add", "folder add", "path", {"tree"}, {}, false, true},
        {ControlAction::importersList, "importers.list", "importers list", {}, {}, {}},
        {ControlAction::importersAdd, "importers.add", "importers add", "path", {"remember"}, {}, false, true},
        {ControlAction::importersScan, "importers.scan", "importers scan", "path", {"remember"}, {}, false, true},
        {ControlAction::importersForget, "importers.forget", "importers forget", "path", {}, {}, false, true},
        {ControlAction::stats, "stats", "stats", {}, {}, {}},
        {ControlAction::performance, "performance.get", "performance get", {}, {}, {}},
        {ControlAction::performanceBegin, "performance.begin", "performance begin", {}, {}, {}, false, true},
        {ControlAction::performanceEnd, "performance.end", "performance end", {}, {}, {}, false, true},
        {ControlAction::pane, "pane.set", "pane set", {}, {"visible", "width", "propertiesVisible"}, {}, true, true},
        {ControlAction::comparisonCreate, "analysis.create", "analysis create", {}, {"type", "name", "a", "b"}, {}, false, true},
        {ControlAction::comparisonDelete, "analysis.delete", "analysis delete", "target", {}, {}, false, true},
        {ControlAction::comparisonSet, "analysis.set", "analysis set", "target",
            {"uvThresholdEnabled", "uvOverlapEnabled", "uvRangeEnabled", "uvThreshold", "uvNearCollapse", "uvRangeMinimum", "uvRangeMaximum", "uvOverlapScope", "uvSeparated", "uvLinkedSelection", "uvMetric", "uvNormalization", "uvView", "uvGrid", "uvDensityU", "uvDensityV", "uvColor", "uvMinimum", "uvMaximum", "intersectionPairLimit", "intersectionCandidateLimit", "autoUpdateBoundaries", "autoUpdateNonManifold", "autoUpdateWinding", "name", "visible", "mode", "distanceOnA", "tolerance", "colorRange", "colorMinimum", "showEdges", "showBoundaries", "showNonManifold", "showWinding", "topologyMode", "analysisMode", "qualityMetric", "qualityOnA", "qualityMinimumEnabled", "qualityMaximumEnabled", "qualityMinimumSize", "qualityMaximumSize", "duplicatePoints", "duplicateTriangles", "showDuplicatePoints", "showDuplicateTriangles", "selfIntersections", "autoUpdateSelfIntersections", "showSelfIntersections", "degenerateTriangles", "showDegenerateTriangles", "needleThresholdRatio", "capMinAngleDegrees", "nonManifoldVertices", "showNonManifoldVertices", "holes", "showHoles", "holeSizeRatioTolerance", "fins", "showFins", "finMaxAreaRatio"}, {}, true, true},
        {ControlAction::comparisonAdd, "analysis.add", "analysis add", "target", {"side", "object"}, {"side", "object"}, false, true},
        {ControlAction::comparisonRemove, "analysis.remove", "analysis remove", "target", {"side", "object"}, {"side", "object"}, false, true},
        {ControlAction::comparisonEnable, "analysis.enable", "analysis enable", "target", {"side", "enabled", "object", "isolate"}, {"side", "enabled"}, false, true},
        {ControlAction::comparisonClear, "analysis.clear", "analysis clear", "target", {"side"}, {"side"}, false, true},
        {ControlAction::comparisonSwap, "analysis.swap", "analysis swap", "target", {}, {}, false, true},
        {ControlAction::comparisonRun, "analysis.run", "analysis run", "target", {"detector", "analysisMode"}, {"detector"}, false, true},
        {ControlAction::comparisonCancel, "analysis.cancel", "analysis cancel", "target", {"detector"}, {"detector"}, false, true},
        {ControlAction::comparisonFindings, "analysis.findings", "analysis findings", "target",
            {"side", "detector", "collection", "offset", "limit", "revision"}, {"side", "detector"}},
        {ControlAction::comparisonExport, "analysis.export", "analysis export", "target", {"path"}, {"path"}},
        {ControlAction::comparisonExportStatus, "analysis.export-status", "analysis export-status", {}, {}, {}},
        {ControlAction::comparisonExportCancel, "analysis.export-cancel", "analysis export-cancel", {}, {}, {}},
        {ControlAction::comparisonResults, "analysis.results", "analysis results", "target", {}, {}},
        {ControlAction::comparisonUvTriangles, "analysis.uv-triangles", "analysis uv-triangles", "target",
            {"offset", "limit", "revision"}, {}},
        {ControlAction::comparisonUvProbe, "analysis.uv-probe", "analysis uv-probe", "target",
            {"object", "index", "barycentric"}, {"object", "index"}, false, true},
        {ControlAction::comparisonUvProbeGet, "analysis.uv-probe-get", "analysis uv-probe-get", "target", {}, {}},
        {ControlAction::comparisonUvProbeClear, "analysis.uv-probe-clear", "analysis uv-probe-clear", "target", {}, {}, false, true},
        {ControlAction::comparisonFocus, "analysis.focus", "analysis focus", "target",
            {"side", "detector", "index"}, {"side", "detector", "index"}, false, true},
    };
    return methods;
}

const ControlMethod* findControlMethod(const std::string& method)
{
    for (const auto& entry : controlMethods()) { if (entry.method == method) { return &entry; } }
    return nullptr;
}

const ControlMethod& controlMethod(ControlAction action)
{
    for (const auto& entry : controlMethods()) { if (entry.action == action) { return entry; } }
    throw std::invalid_argument("Unknown control action.");
}

namespace {
bool booleanOption(const std::string& name)
{
    if (name == "showAOnly" || name == "showBOnly" || name == "showWalls") { return true; }
    if (name == "showPlane" || name == "showConnections" || name == "showDifferences" || name == "faceOn" || name == "sourceVisible") { return true; }
    if (name == "uvThresholdEnabled" || name == "uvOverlapEnabled" || name == "uvRangeEnabled" || name == "uvSeparated" || name == "uvLinkedSelection" || name == "isolate" || name == "uvGrid" || name == "lineDepthTest") { return true; }
    return name == "autoUpdateBoundaries" || name == "autoUpdateNonManifold" || name == "autoUpdateWinding" || name == "autoUpdateSelfIntersections" || name == "selfIntersections" || name == "showSelfIntersections" || name == "nonManifoldVertices" || name == "showNonManifoldVertices" || name == "fins" || name == "showFins" || name == "holes" || name == "showHoles" || name == "degenerateTriangles" || name == "showDegenerateTriangles" || name == "duplicatePoints" || name == "duplicateTriangles" || name == "showDuplicatePoints" || name == "showDuplicateTriangles"
        || name == "adaptivePoints" || name == "xray" || name == "locked" || name == "enabled" || name == "visible" || name == "propertiesVisible" || name == "solid" || name == "triangles" || name == "vertices"
        || name == "tree" || name == "remember" || name == "distanceOnA" || name == "automaticNearPlane"
        || name == "showEdges" || name == "showBoundaries" || name == "showNonManifold" || name == "showWinding" || name == "qualityOnA" || name == "qualityMinimumEnabled" || name == "qualityMaximumEnabled";
}
bool stringOption(const std::string& name)
{
    if (name == "sectionUpAxis") { return true; }
    return name == "analysisMode" || name == "uvOverlapScope" || name == "uvColor" || name == "uvMetric" || name == "uvNormalization" || name == "type" || name == "uvView" || name == "path" || name == "collection" || name == "revision" || name == "detector" || name == "shape" || name == "comments" || name == "name" || name == "mode" || name == "side" || name == "a" || name == "b" || name == "object" || name == "topologyMode" || name == "qualityMetric";
}
bool integerOption(const std::string& name)
{
    if (name == "sourceIndex" || name == "referenceIndex" || name == "comparedIndex") { return true; }
    return name == "index" || name == "offset" || name == "limit" || name == "intersectionPairLimit" || name == "intersectionCandidateLimit";
}
size_t vectorSize(const std::string& name) { return name == "start" || name == "end" || name == "delta" ? 2u : 3u; }
bool vectorOption(const std::string& name)
{
    if (name == "planeStart" || name == "planeEnd") { return true; }
    return name == "barycentric" || name == "start" || name == "end" || name == "delta" || name == "translation" || name == "rotationDegrees" || name == "rgb" || name == "eye" || name == "target";
}
std::string cliOption(const std::string& name)
{
    if (name == "showAOnly") { return "--show-a-only"; }
    if (name == "showBOnly") { return "--show-b-only"; }
    if (name == "showWalls") { return "--show-walls"; }
    if (name == "planeStart") { return "--plane-start"; }
    if (name == "planeEnd") { return "--plane-end"; }
    if (name == "sectionUpAxis") { return "--section-up-axis"; }
    if (name == "showPlane") { return "--show-plane"; }
    if (name == "showConnections") { return "--show-connections"; }
    if (name == "showDifferences") { return "--show-differences"; }
    if (name == "faceOn") { return "--face-on"; }
    if (name == "sourceIndex") { return "--source-index"; }
    if (name == "sourceVisible") { return "--source-visible"; }
    if (name == "referenceIndex") { return "--reference-index"; }
    if (name == "comparedIndex") { return "--compared-index"; }
    if (name == "uvSeparated") { return "--uv-separated"; }
    if (name == "uvLinkedSelection") { return "--uv-linked-selection"; }
    if (name == "uvColor") { return "--uv-color"; }
    if (name == "uvMinimum") { return "--uv-minimum"; }
    if (name == "uvMaximum") { return "--uv-maximum"; }
    if (name == "uvThresholdEnabled") { return "--uv-threshold-enabled"; }
    if (name == "uvOverlapEnabled") { return "--uv-overlap-enabled"; }
    if (name == "uvRangeEnabled") { return "--uv-range-enabled"; }
    if (name == "uvThreshold") { return "--uv-threshold"; }
    if (name == "uvNearCollapse") { return "--uv-near-collapse"; }
    if (name == "uvRangeMinimum") { return "--uv-range-minimum"; }
    if (name == "uvRangeMaximum") { return "--uv-range-maximum"; }
    if (name == "uvOverlapScope") { return "--uv-overlap-scope"; }
    if (name == "uvMetric") { return "--uv-metric"; }
    if (name == "uvNormalization") { return "--uv-normalization"; }
    if (name == "uvGrid") { return "--uv-grid"; }
    if (name == "uvView") { return "--uv-view"; }
    if (name == "lineWidth") { return "--line-width"; }
    if (name == "propertiesVisible") { return "--properties-visible"; }
    if (name == "lineDepthTest") { return "--line-depth-test"; }
    if (name == "uvDensityU") { return "--uv-density-u"; }
    if (name == "uvDensityV") { return "--uv-density-v"; }
    if (name == "intersectionPairLimit") { return "--intersection-pair-limit"; }
    if (name == "intersectionCandidateLimit") { return "--intersection-candidate-limit"; }
    if (name == "rotationDegrees") { return "--rotation-degrees"; }
    if (name == "yawDegrees") { return "--yaw-degrees"; }
    if (name == "adaptivePoints") { return "--adaptive-points"; }
    if (name == "pitchDegrees") { return "--pitch-degrees"; }
    if (name == "rollDegrees") { return "--roll-degrees"; }
    if (name == "fovDegrees") { return "--fov-degrees"; }
    if (name == "nearPlane") { return "--near-plane"; }
    if (name == "automaticNearPlane") { return "--automatic-near-plane"; }
    if (name == "distanceOnA") { return "--distance-on-a"; }
    if (name == "colorRange") { return "--color-range"; }
    if (name == "colorMinimum") { return "--color-minimum"; }
    if (name == "showEdges") { return "--show-edges"; }
    if (name == "showBoundaries") { return "--show-boundaries"; }
    if (name == "showWinding") { return "--show-winding"; }
    if (name == "nonManifoldVertices") { return "--non-manifold-vertices"; }
    if (name == "showNonManifoldVertices") { return "--show-non-manifold-vertices"; }
    if (name == "fins") { return "--fins"; }
    if (name == "showFins") { return "--show-fins"; }
    if (name == "finMaxAreaRatio") { return "--fin-max-area-ratio"; }
    if (name == "holes") { return "--holes"; }
    if (name == "showHoles") { return "--show-holes"; }
    if (name == "holeSizeRatioTolerance") { return "--hole-size-ratio-tolerance"; }
    if (name == "analysisMode") { return "--analysis-mode"; }
    if (name == "topologyMode") { return "--topology-mode"; }
    if (name == "showNonManifold") { return "--show-non-manifold"; }
    if (name == "autoUpdateBoundaries") { return "--auto-update-boundaries"; }
    if (name == "autoUpdateNonManifold") { return "--auto-update-non-manifold"; }
    if (name == "autoUpdateWinding") { return "--auto-update-winding"; }
    if (name == "autoUpdateSelfIntersections") { return "--auto-update-self-intersections"; }
    if (name == "selfIntersections") { return "--self-intersections"; }
    if (name == "showSelfIntersections") { return "--show-self-intersections"; }
    if (name == "degenerateTriangles") { return "--degenerate-triangles"; }
    if (name == "showDegenerateTriangles") { return "--show-degenerate-triangles"; }
    if (name == "needleThresholdRatio") { return "--needle-threshold-ratio"; }
    if (name == "capMinAngleDegrees") { return "--cap-min-angle-degrees"; }
    if (name == "duplicatePoints") { return "--duplicate-points"; }
    if (name == "duplicateTriangles") { return "--duplicate-triangles"; }
    if (name == "showDuplicatePoints") { return "--show-duplicate-points"; }
    if (name == "showDuplicateTriangles") { return "--show-duplicate-triangles"; }
    if (name == "qualityMetric") { return "--quality-metric"; }
    if (name == "qualityOnA") { return "--quality-on-a"; }
    if (name == "qualityMinimumEnabled") { return "--quality-minimum-enabled"; }
    if (name == "qualityMaximumEnabled") { return "--quality-maximum-enabled"; }
    if (name == "qualityMinimumSize") { return "--quality-minimum-size"; }
    if (name == "qualityMaximumSize") { return "--quality-maximum-size"; }
    return "--" + name;
}
float number(const Json& value)
{
    if (!value.is_number()) { throw std::invalid_argument("Expected a finite number."); }
    const double result = value.get<double>();
    if (!std::isfinite(result) || std::abs(result) > static_cast<double>(std::numeric_limits<float>::max())) {
        throw std::invalid_argument("Expected a finite float-range number.");
    }
    return static_cast<float>(result);
}
double cliNumber(const std::string& value)
{
    size_t used = 0;
    const double result = std::stod(value, &used);
    if (used != value.size() || !std::isfinite(result)) { throw std::invalid_argument("Expected a finite number."); }
    return result;
}
}

ControlOperation parseControlOperation(const ControlMethod& method, const Json& params)
{
    if (!params.is_object()) { throw std::invalid_argument("params must be an object."); }
    for (const auto& item : params.items()) {
        if (item.key() != method.positional
            && std::find(method.options.begin(), method.options.end(), item.key()) == method.options.end()) {
            if (method.action == ControlAction::comparisonSet && item.key() == "translation") {
                throw std::invalid_argument("analysis.set does not accept translation. Use transform.set with the analysis ID as target and translation: [X, Y, Z] (display offset only).");
            }
            throw std::invalid_argument("Unknown " + method.method + " parameter: " + item.key());
        }
    }
    auto required = method.required;
    if (!method.positional.empty()) { required.push_back(method.positional); }
    for (const auto& name : required) {
        if (!params.contains(name)) { throw std::invalid_argument("Missing parameter: " + name); }
    }
    if (method.requiresValues && std::none_of(method.options.begin(), method.options.end(),
        [&](const auto& name) { return params.contains(name); })) {
        throw std::invalid_argument("Supply at least one value to change.");
    }
    ControlOperation command;
    command.action = method.action;
    if (params.contains("target") && method.positional == "target") {
        if (!params["target"].is_string() || params["target"].get<std::string>().empty()) {
            throw std::invalid_argument("target must be scene or an object ID.");
        }
        command.target = params["target"].get<std::string>();
        const bool sceneAllowed = method.action == ControlAction::visibility || method.action == ControlAction::render
            || method.action == ControlAction::vertexSize || (method.action == ControlAction::annotationCreate && params.value("shape", "") == "section");
        if (command.target == "scene" && !sceneAllowed) { throw std::invalid_argument("This command requires an object ID."); }
    }
    if (params.contains("path")) {
        if (!params["path"].is_string()) { throw std::invalid_argument("path must be an absolute path."); }
        const auto value = params["path"].get<std::string>();
        if (value.empty() || value.size() > 8192 || value.find('\0') != std::string::npos) {
            throw std::invalid_argument("Invalid path.");
        }
        command.path = pathFromUtf8(value).lexically_normal();
        if (!command.path.is_absolute()) { throw std::invalid_argument("path must be absolute."); }
    }
    if (params.contains("viewId")) {
        if (!params["viewId"].is_string()) { throw std::invalid_argument("viewId must be a positive decimal ID string from view list."); }
        command.viewId = params["viewId"].get<std::string>();
        uint64_t id = 0;
        const auto& text = command.viewId;
        const auto parsed = std::from_chars(text.data(), text.data() + text.size(), id);
        if (parsed.ec != std::errc{} || parsed.ptr != text.data() + text.size() || id == 0) {
            throw std::invalid_argument("viewId must be a positive decimal ID string from view list.");
        }
    }
    if (params.contains("preset")) {
        const std::vector<std::string> presets = {"front", "back", "left", "right", "top", "bottom", "isometric"};
        if (!params["preset"].is_string() || std::find(presets.begin(), presets.end(), params["preset"].get<std::string>()) == presets.end()) {
            throw std::invalid_argument("preset must be front, back, left, right, top, bottom, or isometric.");
        }
        command.preset = params["preset"].get<std::string>();
    }
    if (params.contains("axis")) {
        if (params["axis"] != "y" && params["axis"] != "z") { throw std::invalid_argument("axis must be y or z."); }
        command.axis = params["axis"].get<std::string>();
    }
    for (const auto& name : method.options) {
        if (!params.contains(name)) { continue; }
        const auto& value = params[name];
        if (booleanOption(name) && !value.is_boolean()) { throw std::invalid_argument(name + " must be a boolean."); }
        if (stringOption(name) && (!value.is_string() || (name != "comments" && value.get_ref<const std::string&>().empty())
            || value.get_ref<const std::string&>().size() > ((name == "comments" || name == "path") ? 8192u : 511u)
            || value.get_ref<const std::string&>().find('\0') != std::string::npos)) {
            throw std::invalid_argument(name + (name == "comments" ? " must be a string of at most 8192 bytes without NUL characters."
                : " must be a nonempty string of at most 511 bytes without NUL characters."));
        }
        if (vectorOption(name)) {
            if (!value.is_array() || value.size() != vectorSize(name)) { throw std::invalid_argument(name + " has the wrong number of coordinates."); }
            for (const auto& component : value) { (void)number(component); }
        }
    }
#define BOOL_FIELD(field) if (params.contains(#field)) { command.field = params[#field].get<bool>(); }
    BOOL_FIELD(showAOnly) BOOL_FIELD(showBOnly) BOOL_FIELD(showWalls)
    BOOL_FIELD(showPlane) BOOL_FIELD(showConnections) BOOL_FIELD(showDifferences) BOOL_FIELD(faceOn) BOOL_FIELD(sourceVisible)
    BOOL_FIELD(visible) BOOL_FIELD(solid) BOOL_FIELD(xray) BOOL_FIELD(adaptivePoints) BOOL_FIELD(triangles) BOOL_FIELD(vertices) BOOL_FIELD(tree) BOOL_FIELD(remember)
    BOOL_FIELD(uvThresholdEnabled) BOOL_FIELD(uvOverlapEnabled) BOOL_FIELD(uvRangeEnabled)
    BOOL_FIELD(uvSeparated) BOOL_FIELD(uvLinkedSelection) BOOL_FIELD(isolate) BOOL_FIELD(uvGrid) BOOL_FIELD(lineDepthTest)
    BOOL_FIELD(nonManifoldVertices) BOOL_FIELD(showNonManifoldVertices) BOOL_FIELD(holes) BOOL_FIELD(showHoles) BOOL_FIELD(fins) BOOL_FIELD(showFins)
    BOOL_FIELD(autoUpdateBoundaries) BOOL_FIELD(autoUpdateNonManifold) BOOL_FIELD(autoUpdateWinding)
    BOOL_FIELD(autoUpdateSelfIntersections) BOOL_FIELD(selfIntersections) BOOL_FIELD(showSelfIntersections)
    BOOL_FIELD(degenerateTriangles) BOOL_FIELD(showDegenerateTriangles)
    BOOL_FIELD(duplicatePoints) BOOL_FIELD(duplicateTriangles) BOOL_FIELD(showDuplicatePoints) BOOL_FIELD(showDuplicateTriangles)
    BOOL_FIELD(locked) BOOL_FIELD(propertiesVisible) BOOL_FIELD(automaticNearPlane)
    BOOL_FIELD(qualityOnA) BOOL_FIELD(qualityMinimumEnabled) BOOL_FIELD(qualityMaximumEnabled)
    BOOL_FIELD(distanceOnA) BOOL_FIELD(showEdges) BOOL_FIELD(showBoundaries) BOOL_FIELD(showNonManifold) BOOL_FIELD(showWinding) BOOL_FIELD(enabled)
#undef BOOL_FIELD
#define NUMBER_FIELD(field) if (params.contains(#field)) { command.field = number(params[#field]); }
    NUMBER_FIELD(lift)
    NUMBER_FIELD(scale) NUMBER_FIELD(value) NUMBER_FIELD(pixels) NUMBER_FIELD(width)
    NUMBER_FIELD(uvThreshold) NUMBER_FIELD(uvNearCollapse) NUMBER_FIELD(uvRangeMinimum) NUMBER_FIELD(uvRangeMaximum)
    NUMBER_FIELD(uvMinimum) NUMBER_FIELD(uvMaximum) NUMBER_FIELD(lineWidth) NUMBER_FIELD(uvDensityU) NUMBER_FIELD(uvDensityV)
    NUMBER_FIELD(aspect) NUMBER_FIELD(opacity)
    NUMBER_FIELD(yawDegrees) NUMBER_FIELD(pitchDegrees) NUMBER_FIELD(rollDegrees)
    NUMBER_FIELD(right) NUMBER_FIELD(up) NUMBER_FIELD(forward) NUMBER_FIELD(factor)
    NUMBER_FIELD(distance) NUMBER_FIELD(fovDegrees) NUMBER_FIELD(nearPlane)
    NUMBER_FIELD(qualityMinimumSize) NUMBER_FIELD(qualityMaximumSize)
    NUMBER_FIELD(holeSizeRatioTolerance) NUMBER_FIELD(finMaxAreaRatio)
    NUMBER_FIELD(needleThresholdRatio) NUMBER_FIELD(capMinAngleDegrees)
    NUMBER_FIELD(tolerance) NUMBER_FIELD(colorRange) NUMBER_FIELD(colorMinimum)
#undef NUMBER_FIELD
#define VECTOR_FIELD(field) if (params.contains(#field)) { command.field = params[#field].get<std::array<float, 3>>(); }
    VECTOR_FIELD(planeStart) VECTOR_FIELD(planeEnd)
    VECTOR_FIELD(translation) VECTOR_FIELD(rotationDegrees) VECTOR_FIELD(rgb) VECTOR_FIELD(eye)
#undef VECTOR_FIELD
    if (params.contains("barycentric")) {
        command.barycentric = params["barycentric"].get<std::array<double, 3>>();
        double sum = 0;
        for (const double v : *command.barycentric) {
            if (v < 0 || v > 1) { throw std::invalid_argument("barycentric coordinates must be between 0 and 1."); }
            sum += v;
        }
        if (std::abs(sum - 1) > 1e-8) { throw std::invalid_argument("barycentric coordinates must sum to 1."); }
    }
    if (params.contains("start")) { command.start = params["start"].get<std::array<float, 2>>(); }
    if (params.contains("end")) { command.end = params["end"].get<std::array<float, 2>>(); }
    if (params.contains("delta")) { command.delta = params["delta"].get<std::array<float, 2>>(); }
    if (params.contains("target") && method.positional != "target") {
        command.cameraTarget = params["target"].get<std::array<float, 3>>();
    }
#define STRING_FIELD(field) if (params.contains(#field)) { command.field = params[#field].get<std::string>(); }
    STRING_FIELD(sectionUpAxis)
    STRING_FIELD(analysisMode) STRING_FIELD(detector) STRING_FIELD(qualityMetric) STRING_FIELD(topologyMode) STRING_FIELD(name) STRING_FIELD(mode) STRING_FIELD(side) STRING_FIELD(a) STRING_FIELD(b) STRING_FIELD(object)
    STRING_FIELD(shape) STRING_FIELD(comments) STRING_FIELD(collection) STRING_FIELD(revision)
    STRING_FIELD(uvOverlapScope)
    STRING_FIELD(uvColor) STRING_FIELD(uvMetric) STRING_FIELD(uvNormalization) STRING_FIELD(type) STRING_FIELD(uvView)
#undef STRING_FIELD
    if (command.type && *command.type != "mesh" && *command.type != "surface_comparison" && *command.type != "uv" && *command.type != "uv_quality") { throw std::invalid_argument("type must be mesh, surface_comparison, uv or uv_quality."); }
    if (command.uvColor && *command.uvColor != "grid" && *command.uvColor != "u" && *command.uvColor != "v") { throw std::invalid_argument("uvColor must be grid, u or v."); }
    if (command.uvMetric) { (void)parseUvQualityMetric(*command.uvMetric); }
    if (command.uvOverlapScope && *command.uvOverlapScope != "per_patch" && *command.uvOverlapScope != "selected_patches") { throw std::invalid_argument("uvOverlapScope must be per_patch or selected_patches."); }
    if (command.uvThreshold && *command.uvThreshold < 0) { throw std::invalid_argument("uvThreshold must be nonnegative."); }
    if (command.uvNearCollapse && *command.uvNearCollapse <= 0) { throw std::invalid_argument("uvNearCollapse must be positive."); }
    if (command.uvNormalization && *command.uvNormalization != "per_patch" && *command.uvNormalization != "absolute") { throw std::invalid_argument("uvNormalization must be per_patch or absolute."); }
    if (command.isolate.value_or(false) && (!command.object || command.enabled != true)) { throw std::invalid_argument("isolate requires --object and --enabled true."); }
    if (command.uvView && *command.uvView != "layout" && *command.uvView != "surface") { throw std::invalid_argument("uvView must be layout or surface."); }
    if ((command.type == "uv" || command.type == "uv_quality") && command.b) { throw std::invalid_argument("UV analysis uses one source input: --a."); }
    if (command.shape && *command.shape != "line" && *command.shape != "rectangle" && *command.shape != "section") { throw std::invalid_argument("shape must be line, rectangle, or section."); }
    if (command.sectionUpAxis && *command.sectionUpAxis != "y" && *command.sectionUpAxis != "z") { throw std::invalid_argument("sectionUpAxis must be y or z."); }
    if (command.lift && *command.lift < 0) { throw std::invalid_argument("lift must be nonnegative."); }
    if (method.action == ControlAction::annotationCreate) {
        if (command.shape == "section") {
            if (!command.planeStart || !command.planeEnd) { throw std::invalid_argument("A section requires planeStart and planeEnd in world coordinates."); }
            if (command.start || command.end || command.aspect || command.rgb) { throw std::invalid_argument("Sections use planeStart/planeEnd and per-source colors, without start/end/aspect/rgb."); }
        } else {
            if (!command.start || !command.end) { throw std::invalid_argument("A surface annotation requires start and end."); }
            for (const auto* key : {"planeStart", "planeEnd", "sectionUpAxis", "lift", "showPlane", "showConnections", "showDifferences", "faceOn", "sourceIndex", "sourceVisible", "referenceIndex", "comparedIndex"}) {
                if (params.contains(key)) { throw std::invalid_argument(std::string(key) + " requires a section annotation."); }
            }
        }
    }
    if (command.aspect && (*command.aspect < .1f || *command.aspect > 10)) { throw std::invalid_argument("aspect must be between 0.1 and 10."); }
    for (const auto& point : {command.start, command.end}) {
        if (point && (std::abs((*point)[0]) > 1 || std::abs((*point)[1]) > 1)) { throw std::invalid_argument("Drawing coordinates must be between -1 and 1."); }
    }
    if (command.mode && *command.mode != "distance" && *command.mode != "a" && *command.mode != "b" && *command.mode != "overlay" && *command.mode != "surface_quality") {
        throw std::invalid_argument("mode must be distance, a, b, overlay, or surface_quality.");
    }
    if (command.qualityMetric && *command.qualityMetric != "longest_edge" && *command.qualityMetric != "equivalent_size"
        && *command.qualityMetric != "shape" && *command.qualityMetric != "size_jump") {
        throw std::invalid_argument("qualityMetric must be longest_edge, equivalent_size, shape, or size_jump.");
    }
    if (command.detector && std::find(diagnosticCategoryKeys.begin(), diagnosticCategoryKeys.end(), *command.detector) == diagnosticCategoryKeys.end()) {
        throw std::invalid_argument("Unknown detector. Use a detector key from analysis.results.");
    }
    if (command.analysisMode) {
        if (command.action == ControlAction::modelSet) { (void)parseModelAnalysisMode(*command.analysisMode); }
        else { (void)parseAnalysisMode(*command.analysisMode); }
    }
    if (command.topologyMode && *command.topologyMode != "original_index" && *command.topologyMode != "exact_position") {
        throw std::invalid_argument("topologyMode must be original_index or exact_position.");
    }
    if (command.side && *command.side != "a" && *command.side != "b") { throw std::invalid_argument("side must be a or b."); }
#define INTEGER_FIELD(field, maximum) if (params.contains(#field)) { \
        const auto& v = params[#field]; \
        if (!v.is_number_integer() || (!v.is_number_unsigned() && v.get<int64_t>() < 0) || v.get<uint64_t>() > maximum) { \
            throw std::invalid_argument(#field " must be a nonnegative integer within its documented range."); \
        } command.field = v.get<uint64_t>(); }
    INTEGER_FIELD(offset, std::numeric_limits<size_t>::max())
    INTEGER_FIELD(sourceIndex, 2147483647)
    INTEGER_FIELD(referenceIndex, 2147483647)
    INTEGER_FIELD(comparedIndex, 2147483647)
    INTEGER_FIELD(limit, 100)
    INTEGER_FIELD(intersectionPairLimit, 2147483647)
    INTEGER_FIELD(intersectionCandidateLimit, 2147483647)
#undef INTEGER_FIELD
    if (command.sourceIndex.has_value() != command.sourceVisible.has_value()) { throw std::invalid_argument("Supply sourceIndex and sourceVisible together."); }
    if (command.limit && !*command.limit) { throw std::invalid_argument("limit must be from 1 to 100."); }
    if (command.collection && (command.collection->empty() || command.collection->front() != '/')) { throw std::invalid_argument("collection must start with /."); }
    if (params.contains("index")) {
        const auto& value = params["index"];
        if (!value.is_number_integer() || (value.is_number_unsigned() ? value.get<uint64_t>() == 0 : value.get<int64_t>() <= 0)) {
            throw std::invalid_argument("index must be a positive integer.");
        }
        command.index = value.get<uint64_t>();
    }
    if (command.factor && *command.factor <= 0) { throw std::invalid_argument("factor must be positive."); }
    if (command.distance && *command.distance <= 0) { throw std::invalid_argument("distance must be positive."); }
    if (command.action == ControlAction::vertexSize
        && (command.target == "scene" ? (!command.pixels || command.scale.has_value()) : (!command.scale || command.pixels.has_value()))) {
        throw std::invalid_argument("Use pixels for scene, or scale for a file/group.");
    }
    return command;
}

std::string controlMethodUsage(const ControlMethod& method)
{
    std::string result = method.cli;
    if (method.positional == "path") { result += " PATH"; }
    else if (method.positional == "viewId") { result += " VIEW_ID"; }
    else if (method.positional == "preset") { result += " front|back|left|right|top|bottom|isometric"; }
    else if (method.positional == "axis") { result += " y|z"; }
    else if (method.positional == "target") {
        if (method.action == ControlAction::annotationCreate) { result += " TARGET"; }
        else if (method.method.starts_with("annotation.")) { result += " ANNOTATION_ID"; }
        else if (method.method.starts_with("analysis.")) { result += " ANALYSIS_ID"; }
        else if (method.action == ControlAction::visibility || method.action == ControlAction::render
            || method.action == ControlAction::vertexSize) { result += " TARGET"; }
        else if (method.action == ControlAction::modelRemove) { result += " FILE_ID"; }
        else if (method.action == ControlAction::transformGet || method.action == ControlAction::transformSet
            || method.action == ControlAction::transformReset) { result += " OBJECT_ID|ANALYSIS_ID"; }
        else { result += " OBJECT_ID"; }
    }
    for (const auto& name : method.options) {
        const bool required = std::find(method.required.begin(), method.required.end(), name) != method.required.end();
        result += required ? " " : " [";
        result += cliOption(name);
        if (name != "tree" && name != "remember") {
            result += booleanOption(name) ? " true|false" : name == "rgb" ? " R G B" : vectorOption(name) ? (vectorSize(name) == 2 ? " U V" : " X Y Z")
                : name == "sectionUpAxis" ? " y|z" : name == "type" ? " mesh|surface_comparison|uv|uv_quality" : name == "uvColor" ? " grid|u|v" : name == "uvMetric" ? " angle|area|orientation|anisotropy|min_stretch|overlap" : name == "uvNormalization" ? " per_patch|absolute" : name == "uvView" ? " layout|surface" : name == "shape" ? " line|rectangle|section" : name == "mode" ? " distance|a|b|overlay|surface_quality" : name == "side" ? " a|b"
                : name == "path" ? " PATH" : name == "collection" ? " ARRAY_PATH" : name == "index" ? " POSITIVE_INTEGER"
                : name == "a" || name == "b" || name == "object" ? " OBJECT_ID" : stringOption(name) ? " TEXT" : " N";
        }
        if (!required) { result += "]"; }
    }
    if (method.action == ControlAction::transformSet) { result += " (analyses: --translation only, display offset)"; }
    if (method.action == ControlAction::transformReset) { result += " (analyses: reset display offset)"; }
    return result;
}

Json controlOperationParams(const ControlOperation& command)
{
    Json result = Json::object();
    if (!command.target.empty()) { result["target"] = command.target; }
    if (command.cameraTarget) { result["target"] = *command.cameraTarget; }
    if (!command.path.empty()) { result["path"] = pathToUtf8(command.path); }
    if (!command.viewId.empty()) { result["viewId"] = command.viewId; }
    if (!command.preset.empty()) { result["preset"] = command.preset; }
    if (!command.axis.empty()) { result["axis"] = command.axis; }
    if (command.action == ControlAction::folderAdd) { result["tree"] = command.tree; }
    if (command.action == ControlAction::importersAdd || command.action == ControlAction::importersScan) { result["remember"] = command.remember; }
#define FIELD(field) if (command.field) { result[#field] = *command.field; }
    FIELD(showAOnly) FIELD(showBOnly) FIELD(showWalls)
    FIELD(planeStart) FIELD(planeEnd) FIELD(sectionUpAxis) FIELD(lift) FIELD(showPlane) FIELD(showConnections) FIELD(showDifferences) FIELD(faceOn) FIELD(sourceIndex) FIELD(sourceVisible) FIELD(referenceIndex) FIELD(comparedIndex)
    FIELD(analysisMode) FIELD(visible) FIELD(propertiesVisible) FIELD(solid) FIELD(xray) FIELD(adaptivePoints) FIELD(triangles) FIELD(vertices) FIELD(translation) FIELD(rotationDegrees) FIELD(rgb) FIELD(barycentric)
    FIELD(lineWidth) FIELD(lineDepthTest) FIELD(uvGrid) FIELD(uvDensityU) FIELD(uvDensityV)
    FIELD(uvThresholdEnabled) FIELD(uvOverlapEnabled) FIELD(uvRangeEnabled) FIELD(uvThreshold) FIELD(uvNearCollapse) FIELD(uvRangeMinimum) FIELD(uvRangeMaximum) FIELD(uvOverlapScope)
    FIELD(uvSeparated) FIELD(uvLinkedSelection) FIELD(uvColor) FIELD(uvMinimum) FIELD(uvMaximum) FIELD(uvMetric) FIELD(uvNormalization) FIELD(isolate)
    FIELD(type) FIELD(uvView)
    FIELD(scale) FIELD(value) FIELD(pixels) FIELD(width) FIELD(yawDegrees) FIELD(pitchDegrees) FIELD(rollDegrees)
    FIELD(right) FIELD(up) FIELD(forward) FIELD(factor)
    FIELD(eye) FIELD(distance) FIELD(fovDegrees) FIELD(nearPlane) FIELD(automaticNearPlane)
    FIELD(offset) FIELD(limit) FIELD(collection) FIELD(revision) FIELD(intersectionPairLimit) FIELD(intersectionCandidateLimit)
    FIELD(name) FIELD(mode) FIELD(side) FIELD(a) FIELD(b) FIELD(object) FIELD(index)
    FIELD(nonManifoldVertices) FIELD(showNonManifoldVertices) FIELD(holes) FIELD(showHoles) FIELD(holeSizeRatioTolerance) FIELD(fins) FIELD(showFins) FIELD(finMaxAreaRatio)
    FIELD(autoUpdateBoundaries) FIELD(autoUpdateNonManifold) FIELD(autoUpdateWinding)
    FIELD(detector) FIELD(autoUpdateSelfIntersections) FIELD(selfIntersections) FIELD(showSelfIntersections)
    FIELD(degenerateTriangles) FIELD(showDegenerateTriangles) FIELD(needleThresholdRatio) FIELD(capMinAngleDegrees)
    FIELD(duplicatePoints) FIELD(duplicateTriangles) FIELD(showDuplicatePoints) FIELD(showDuplicateTriangles)
    FIELD(shape) FIELD(comments) FIELD(locked) FIELD(start) FIELD(end) FIELD(delta) FIELD(aspect) FIELD(opacity)
    FIELD(qualityMetric) FIELD(qualityOnA) FIELD(qualityMinimumEnabled) FIELD(qualityMaximumEnabled) FIELD(qualityMinimumSize) FIELD(qualityMaximumSize)
    FIELD(distanceOnA) FIELD(showEdges) FIELD(showBoundaries) FIELD(showNonManifold) FIELD(showWinding) FIELD(topologyMode) FIELD(tolerance) FIELD(colorRange) FIELD(colorMinimum) FIELD(enabled)
#undef FIELD
    return result;
}

Json controlCapabilities()
{
    Json methods = Json::array();
    for (const auto* name : {"instance.info", "objects.list", "object.get", "screenshot.capture", "scene.save",
        "scene.save-as", "scene.open", "scene.new", "quit", "command.get"}) { methods.push_back({{"method", name}}); }
    for (const auto& method : controlMethods()) {
        Json parameters = Json::object();
        if (!method.positional.empty()) { parameters[method.positional] = {{"type", "string"}, {"required", true}}; }
        for (const auto& name : method.options) {
            parameters[name] = {{"type", booleanOption(name) ? "boolean" : vectorOption(name) ? (vectorSize(name) == 2 ? "number[2]" : "number[3]") : stringOption(name) ? "string" : integerOption(name) ? "integer" : "number"},
                {"required", std::find(method.required.begin(), method.required.end(), name) != method.required.end()},
                {"cliOption", cliOption(name)}};
        }
        methods.push_back({{"method", method.method}, {"cli", method.cli}, {"usage", controlMethodUsage(method)},
            {"positional", method.positional}, {"parameters", parameters}, {"options", method.options},
            {"requiredOptions", method.required}, {"requiresValues", method.requiresValues}, {"mutating", method.mutating}});
    }
    return {{"analysisResults", {{"defaultListingLimit", 100}, {"pageLimit", {1, 100}}, {"offsetBase", 0}, {"collectionIndexBase", 0}, {"defaultCollection", "/findings"}, {"intersectionPairLimitDefault", 10000}, {"intersectionCandidateLimitDefault", 1000000}, {"intersectionBudgetRange", {0, 2147483647}}, {"zeroBudgetMeansUnlimited", true}, {"exportOverwrites", false}, {"concurrentExports", 1}}}, {"apiVersion", 1}, {"methods", methods}, {"objectKinds", {"folder", "file", "group", "analysis", "annotation"}},
        {"analysisTransformFields", {"translation"}},
        {"differenceMeshes", {{"targets", {"analysis"}}, {"inputTypes", {"closed_solids", "single_boundary_surfaces"}},
            {"exportFormat", "obj"}, {"exportOverwrites", false}, {"volumeUnits", "model_units_cubed"},
            {"buildOnSceneLoad", true}, {"boundaryEditing", false}}},
        {"annotations", {{"shapes", {"line", "rectangle", "section"}},
            {"createRequiredByShape", {{"line", {"start", "end"}}, {"rectangle", {"start", "end"}}, {"section", {"planeStart", "planeEnd"}}}},
            {"sectionTargets", {"scene", "folder", "file", "group"}}, {"sectionIndexBase", 0}, {"sectionCoordinateSpace", "world"}}},
        {"cameraPersistent", false}, {"screenshot", {{"width", 1920}, {"height", 1800}, {"overwrite", true}}},
        {"scopes", {{"visibility.set", {"scene", "folder", "file", "group", "analysis", "annotation"}},
            {"render.set", {"scene", "folder", "file", "group"}}, {"transform", {"folder", "file", "group", "analysis"}},
            {"opacity.set", {"folder", "file", "group", "annotation"}}, {"color", {"folder", "file", "group", "annotation"}},
            {"vertex-size.set", {"scene", "file", "group"}}, {"model.remove", {"file"}}}}};
}

bool parseExtendedControlArguments(int argc, char** argv, ControlArguments& arguments)
{
    std::vector<std::string> words;
    Json common = Json::object();
    for (int index = 2; index < argc; ++index) {
        const std::string word = argv[index];
        const bool global = word == "--instance" || word == "--timeout" || word == "--request-key" || word == "--json" || word == "--wait";
        if (!global) { words.push_back(word); continue; }
        if (common.contains(word)) { throw std::runtime_error("Repeated option: " + word); }
        if (word == "--json" || word == "--wait") { common[word] = true; }
        else {
            if (++index >= argc) { throw std::runtime_error("Missing value for " + word); }
            common[word] = argv[index];
        }
    }
    const ControlMethod* selected = nullptr;
    size_t commandWords = 0;
    for (const auto& method : controlMethods()) {
        if (!words.empty() && words[0] == method.cli) { selected = &method; commandWords = 1; break; }
        if (words.size() >= 2 && words[0] + " " + words[1] == method.cli) { selected = &method; commandWords = 2; break; }
    }
    if (!selected) { return false; }
    if (!common.contains("--instance") || !validInstanceId(common["--instance"].get<std::string>())) {
        throw std::runtime_error("Control commands require --instance ID with a valid instance ID.");
    }
    arguments.instanceId = common["--instance"].get<std::string>();
    arguments.json = common.contains("--json");
    if (common.contains("--request-key")) {
        arguments.requestKey = common["--request-key"].get<std::string>();
        if (!validAutomationRequestKey(*arguments.requestKey)) { throw std::runtime_error("Invalid request key."); }
    }
    if (common.contains("--timeout")) {
        const auto text = common["--timeout"].get<std::string>();
        if (text.empty() || text.find_first_not_of("0123456789") != std::string::npos) { throw std::runtime_error("timeout must be an integer from 1 to 3600."); }
        const double timeout = cliNumber(text);
        if (timeout < 1 || timeout > 3600) { throw std::runtime_error("timeout must be from 1 to 3600."); }
        arguments.timeoutSeconds = static_cast<int>(timeout);
    }
    Json params = Json::object();
    for (size_t index = commandWords; index < words.size(); ++index) {
        const auto word = words[index];
        if (word.rfind("--", 0) != 0 && !selected->positional.empty() && !params.contains(selected->positional)) {
            params[selected->positional] = selected->positional == "path"
                ? pathToUtf8(std::filesystem::absolute(pathFromUtf8(word)).lexically_normal()) : word;
            continue;
        }
        auto option = std::find_if(selected->options.begin(), selected->options.end(), [&](const auto& name) { return cliOption(name) == word; });
        if (selected->action == ControlAction::comparisonSet && word == "--translation") {
            throw std::runtime_error("analysis set does not accept --translation. Use transform set ANALYSIS_ID --translation X Y Z (display offset only).");
        }
        if (option == selected->options.end() || params.contains(*option)) { throw std::runtime_error("Unexpected or repeated option: " + word); }
        const auto& name = *option;
        if (name == "tree" || name == "remember") { params[name] = true; continue; }
        const size_t count = vectorOption(name) ? vectorSize(name) : 1u;
        if (words.size() - index - 1 < count) { throw std::runtime_error("Missing value for " + word); }
        if (booleanOption(name)) {
            const auto value = words[++index];
            if (value != "true" && value != "false") { throw std::runtime_error(word + " expects true or false."); }
            params[name] = value == "true";
        } else if (count > 1) {
            params[name] = Json::array();
            for (size_t component = 0; component < count; ++component) { params[name].push_back(cliNumber(words[++index])); }
        } else if (name == "path") { params[name] = pathToUtf8(std::filesystem::absolute(pathFromUtf8(words[++index])).lexically_normal()); }
        else if (stringOption(name)) { params[name] = words[++index]; }
        else if (integerOption(name)) {
            const auto& value = words[++index];
            uint64_t parsed = 0;
            const auto converted = std::from_chars(value.data(), value.data() + value.size(), parsed);
            if (converted.ec != std::errc{} || converted.ptr != value.data() + value.size() || (name == "index" && parsed == 0)) {
                throw std::runtime_error(word + " expects an integer (index starts at 1; offsets and budgets allow 0).");
            }
            params[name] = parsed;
        }
        else { params[name] = cliNumber(words[++index]); }
    }
    arguments.operation = parseControlOperation(*selected, params);
    arguments.command = ControlCommand::operation;
    return true;
}

} // namespace woby
