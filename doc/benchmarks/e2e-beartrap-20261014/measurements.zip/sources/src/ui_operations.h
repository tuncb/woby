#pragma once

#include "ui_state.h"

#include <array>
#include <cstddef>
#include <filesystem>
#include <optional>
#include <vector>

namespace woby {
struct PostLoadIdentity;
struct PostLoadData;
void setPostLoadPhase(UiState& state, SceneObjectId id, PostLoadPhase phase, std::string error = {});
bool publishPostLoadData(UiState& state, const PostLoadIdentity& identity, PostLoadData data);
struct DiagnosticEdge;
struct MeshComparison;
bool setUvProbe(UiState& state, SceneObjectId analysisId, SceneObjectId partId,
    size_t triangle, const std::array<double,3>& barycentric);
void clearUvProbe(UiState& state, SceneObjectId analysisId);

[[nodiscard]] ViewNavigation captureViewNavigation(const UiState& state);
void restoreViewDiagnostics(UiState& state, const std::vector<ViewDiagnosticSelection>& selections);

[[nodiscard]] const UiView* findView(const UiState& state, ViewId id);
ViewId createView(UiState& state);
ViewId duplicateView(UiState& state, ViewId id);
void applyView(UiState& state, ViewId id);
void updateView(UiState& state, ViewId id);
void renameView(UiState& state, ViewId id, const std::string& name);
void removeView(UiState& state, ViewId id);
void pruneMissingViewReferences(UiState& state);
[[nodiscard]] std::vector<SceneViewRecord> sceneViewRecords(const UiState& state);
void loadSceneViews(UiState& state, const SceneDocument& document);

// An omitted ID targets the last active comparison (also retained while inspecting sources).
[[nodiscard]] const UiComparison* findComparison(const UiState& state, SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] UiComparison* findComparison(UiState& state, SceneObjectId id = invalidSceneObjectId);
// Only a single selected comparison is shown in the shared Properties pane.
[[nodiscard]] const UiComparison* selectedComparison(const UiState& state);
[[nodiscard]] ComparisonSettings comparisonSettings(const UiState& state, SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] bool comparisonContains(const UiState& state, SceneObjectId part, ComparisonSide side,
    SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] size_t missingComparisonPartCount(const UiState& state, SceneObjectId id = invalidSceneObjectId);
SceneObjectId createComparison(UiState& state, AnalysisType type = AnalysisType::mesh);
// Checks/quality/UV combine selected sources; comparison assigns up to two sources in click order.
SceneObjectId createAnalysisFromSelection(UiState& state, AnalysisTask task);
// Explicit sources let file actions create analyses without first changing the selection.
SceneObjectId createAnalysisFromObjects(UiState& state, AnalysisTask task, const std::vector<SceneObjectId>& objects);
void setAnalysisTask(UiState& state, SceneObjectId id, AnalysisTask task);
[[nodiscard]] AnalysisTask comparisonTask(const UiState& state, SceneObjectId id);
// Consolidate explicitly selected Mesh checks into source A, including saved-view references.
// Legacy untyped comparisons retain their two inputs; a legacy single B input remains inspectable.
void normalizeAnalysisSources(UiState& state, SceneObjectId id);
SceneObjectId duplicateComparison(UiState& state, SceneObjectId id);
void removeComparison(UiState& state, SceneObjectId id);
void renameComparison(UiState& state, SceneObjectId id, const std::string& name);
void setComparisonTranslation(UiState& state, SceneObjectId id, const std::array<float, 3>& translation);
void removeMissingComparisonParts(UiState& state, ComparisonSide side, SceneObjectId id = invalidSceneObjectId);
void frameComparison(UiState& state, SceneObjectId id);
// UV navigation retains the analysis inspector and uses only matching results.
[[nodiscard]] const UvFindingFocus* focusedUvFinding(const UiState& state, uint64_t resultSignature, SceneObjectId id,
    std::optional<uint64_t> geometrySignature = {});
void validateUvFindingFocus(UiState& state, const Mesh& display, uint64_t resultSignature, SceneObjectId id,
    std::optional<uint64_t> geometrySignature = {});
void selectUvFinding(UiState& state, const Mesh& display, uint64_t resultSignature, size_t index, SceneObjectId id);
void navigateUvFinding(UiState& state, const Mesh& display, uint64_t resultSignature, int step, SceneObjectId id);
// A zero/stale result signature is unavailable. Navigation wraps within one side/category.
// Callers may supply the geometry signature from a current scene-revision cache.
[[nodiscard]] const DiagnosticEdge* focusedComparisonDiagnostic(const UiState& state,
    const MeshComparison& result, uint64_t resultSignature, SceneObjectId id,
    std::optional<uint64_t> geometrySignature = {});
void resetComparisonDiagnosticFocus(UiState& state, SceneObjectId id);
void validateComparisonDiagnosticFocus(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, SceneObjectId id, std::optional<uint64_t> geometrySignature = {});
void selectComparisonDiagnostic(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, size_t index, SceneObjectId id);
void navigateComparisonDiagnostic(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, int step, SceneObjectId id);
void setComparisonSettings(UiState& state, ComparisonSettings settings, SceneObjectId id = invalidSceneObjectId);
void setAllComparisonsVisible(UiState& state, bool visible);
[[nodiscard]] size_t countVisibleComparisonDiagnostics(const ComparisonSettings& settings);
// Batch the existing saved visibility flags; hiding also clears highlighted findings.
void setComparisonDiagnosticsVisible(UiState& state, bool visible, SceneObjectId id = invalidSceneObjectId);
void setPropertiesPaneVisible(UiState& state, bool visible);
void setPropertiesPaneWidth(UiState& state, float value, float minWidth, float maxWidth);
void setScreenshotSettings(UiState& state, ScreenshotSettings settings);
void frameComparisonBounds(UiState& state, const Bounds& bounds);
[[nodiscard]] bool sceneObjectSelected(const UiState& state, SceneObjectId id);
// Plain click replaces, Ctrl-click toggles, context click preserves selection and includes the clicked object.
void selectSceneObject(UiState& state, SceneObjectId id, bool toggle = false, bool contextClick = false);
void clearSceneSelection(UiState& state);

enum class UiObjectProperty {
    translationX, translationY, translationZ,
    rotationX, rotationY, rotationZ,
    scale, opacity, vertexSize, solidMesh, triangles, vertices, red, green, blue,
    uvGrid, uvDensityU, uvDensityV, uvColorMode, uvMinimum, uvMaximum,
    lineWidth, lineDepthTest, analysisMode,
};
inline constexpr size_t uiObjectPropertyCount = static_cast<size_t>(UiObjectProperty::analysisMode) + 1;
bool setModelAnalysisMode(UiState& state, SceneObjectId id, AnalysisMode mode);
enum class UiPropertyGroup { translation, rotation, scale, transform, appearance };
struct UiPropertyValue {
    float value = 0.0f;
    bool available = false;
    bool mixed = false;
};
// Transforms and opacity are local. Parent color/render modes aggregate contained
// parts; folder vertex size aggregates contained file multipliers (or direct parts).
// Comparisons use their dedicated inspector; stale/unsupported selections are rejected.
[[nodiscard]] UiPropertyValue selectedObjectProperty(const UiState& state, UiObjectProperty property);
[[nodiscard]] std::array<UiPropertyValue, uiObjectPropertyCount> selectedObjectProperties(const UiState& state);
// Edit only this component on resolved targets, deduplicating overlaps. File/part
// vertex multipliers remain independent, including when both are selected.
void setSelectedObjectProperty(UiState& state, UiObjectProperty property, float value);
void resetSelectedObjectProperties(UiState& state, UiPropertyGroup group);
void setGroupUvGrid(UiGroupState& group, UvGridSettings settings);
void setGroupLineStyle(UiGroupState& group, LineStyle settings);
bool setObjectLineStyle(UiState& state, const std::vector<SceneObjectId>& objects,
    std::optional<float> width, std::optional<bool> depthTest);
// Edit descendant parts without changing selection. A missing color resets the palette.
bool setObjectColor(UiState& state, const std::vector<SceneObjectId>& objects,
    std::optional<std::array<float, 3>> color);
// Expand containers using existing part semantics; skip parts without complete UVs.
// Returns false when no eligible part exists. Empty objects means the whole scene.
bool setObjectUvGrid(UiState& state, const std::vector<SceneObjectId>& objects,
    std::optional<bool> enabled, std::optional<float> densityU, std::optional<float> densityV,
    std::optional<UvColorMode> mode = {}, std::optional<float> minimum = {}, std::optional<float> maximum = {});
// Visibility follows tree controls: files/folders include descendants. Selection
// and the properties pane stay intact, including when every target is hidden.
[[nodiscard]] UiPropertyValue selectedObjectVisibility(const UiState& state);
void setSelectedObjectsVisible(UiState& state, bool visible);
// Files/folders expand to their current triangular mesh parts. IDs are deduplicated.
[[nodiscard]] std::vector<SceneObjectId> comparisonObjectParts(
    const UiState& state, const std::vector<SceneObjectId>& objects);
// Sorted, unique IDs for bulk queries. Build once per traversal instead of
// repeatedly searching membership or resolving one object across the scene.
[[nodiscard]] std::vector<SceneObjectId> comparableScenePartIds(const UiState& state);
[[nodiscard]] bool fileHasComparableParts(const UiFileState& file);
[[nodiscard]] std::vector<SceneObjectId> comparisonMemberIds(const UiState& state, ComparisonSide side,
    SceneObjectId id, bool enabledOnly = true);
[[nodiscard]] size_t comparisonPartCount(const UiState& state, ComparisonSide side, SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] bool comparisonPartEnabled(const UiState& state, SceneObjectId part, ComparisonSide side,
    SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] size_t enabledComparisonPartCount(const UiState& state, ComparisonSide side, SceneObjectId id = invalidSceneObjectId);
// Isolate existing members on one side; an empty object list enables the whole side.
// Nonmembers leave the side unchanged. UV analyses support side A only.
void isolateComparisonObjects(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, SceneObjectId id);
void isolateUvObjects(UiState& state, const std::vector<SceneObjectId>& objects, SceneObjectId id);
// Toggle existing members only. Files and folders include their descendants;
// an empty object list toggles the entire side, including missing references.
void setComparisonObjectsEnabled(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side,
    bool enabled, SceneObjectId id = invalidSceneObjectId);
enum class ComparisonMembershipAction { unavailable, add, remove };
// Mixed selections add missing parts; fully included selections remove their parts.
[[nodiscard]] ComparisonMembershipAction comparisonMembershipAction(
    const UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] bool canCompareGroups(const UiState& state, SceneObjectId id = invalidSceneObjectId);
[[nodiscard]] bool canInspectComparison(const UiState& state, SceneObjectId id = invalidSceneObjectId);
// Fall back to the populated side without changing the saved two-input mode.
[[nodiscard]] ComparisonSettings effectiveComparisonSettings(const UiState& state, SceneObjectId id = invalidSceneObjectId);
// Resolve live display/focus settings using inputs from a current scene-revision cache.
[[nodiscard]] ComparisonSettings effectiveComparisonSettings(const UiState& state, SceneObjectId id,
    bool hasA, bool hasB, uint64_t geometrySignature);
// Create a comparison from one object or two distinct objects in click order.
[[nodiscard]] bool canCompareSceneSelection(const UiState& state);
bool compareSceneSelection(UiState& state, AnalysisType type = AnalysisType::mesh);
void setComparisonObjects(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, bool member,
    SceneObjectId id = invalidSceneObjectId);
void clearComparisonGroup(UiState& state, ComparisonSide side, SceneObjectId id = invalidSceneObjectId);
void swapComparisonGroups(UiState& state, SceneObjectId id = invalidSceneObjectId);

enum class UiRenderMode {
    solidMesh,
    triangles,
    vertices,
};

void setUiScale(UiState& state, float scale);

[[nodiscard]] size_t totalGroupCount(const std::vector<UiFileState>& files);
[[nodiscard]] size_t totalGroupCount(const UiState& state);
[[nodiscard]] size_t countVisibleGroups(const std::vector<UiGroupState>& groups);
[[nodiscard]] size_t countVisibleFileGroups(const UiFileState& file);
[[nodiscard]] size_t countVisibleSceneGroups(const UiState& state);
[[nodiscard]] size_t countSceneNodeGroups(const UiState& state, const UiSceneNode& node);
[[nodiscard]] size_t countVisibleSceneNodeGroups(const UiState& state, const UiSceneNode& node);
[[nodiscard]] size_t countEnabledGroupRenderMode(
    const std::vector<UiGroupState>& groups,
    UiRenderMode mode);
[[nodiscard]] size_t countEnabledSceneRenderMode(const UiState& state, UiRenderMode mode);
[[nodiscard]] size_t countEnabledSceneNodeRenderMode(
    const UiState& state,
    const UiSceneNode& node,
    UiRenderMode mode);
[[nodiscard]] bool groupRenderModeEnabled(const UiGroupState& group, UiRenderMode mode);
void setGroupRenderMode(UiGroupState& group, UiRenderMode mode, bool enabled);
void toggleGroupRenderMode(UiGroupState& group, UiRenderMode mode);
void setAllGroupRenderModes(std::vector<UiGroupState>& groups, UiRenderMode mode, bool enabled);
void setAllSceneRenderModes(UiState& state, UiRenderMode mode, bool enabled);
void setSceneNodeSubtreeRenderMode(
    UiState& state,
    UiSceneNode& node,
    UiRenderMode mode,
    bool enabled);

void setFileVisible(UiFileState& file, bool visible);
void toggleFileVisible(UiFileState& file);
void setAllSceneVisible(UiState& state, bool visible);
// Model section only: folders, files and parts, leaving analyses and annotations intact.
void setAllModelsVisible(UiState& state, bool visible);
void setSceneNodeSubtreeVisible(UiState& state, UiSceneNode& node, bool visible);
void setGroupVisible(UiGroupState& group, bool visible);
void toggleGroupVisible(UiGroupState& group);
void setGroupVisible(UiFileState& file, UiGroupState& group, bool visible);
void toggleGroupVisible(UiFileState& file, UiGroupState& group);
void setGroupVisible(UiState& state, UiFileState& file, UiGroupState& group, bool visible);
void toggleGroupVisible(UiState& state, UiFileState& file, UiGroupState& group);
void setShowOrigin(UiState& state, bool visible);
void toggleShowOrigin(UiState& state);
void setShowGrid(UiState& state, bool visible);
void setAdaptivePoints(UiState& state, bool enabled);
void setTriangleEdgeXray(UiState& state, bool enabled);
void toggleShowGrid(UiState& state);
void setShowDimensions(UiState& state, bool visible);
void setSceneUpAxis(UiState& state, SceneUpAxis upAxis);
void toggleSceneUpAxis(UiState& state);

void setMasterVertexPointSize(UiState& state, float value);
void setFileVertexSizeScale(UiFileState& file, float value);
void setGroupVertexSizeScale(UiGroupState& group, float value);
void setFileTranslation(UiFileSettings& settings, const std::array<float, 3>& value);
void setSceneNodeTranslation(UiSceneNodeSettings& settings, const std::array<float, 3>& value);
void setGroupTranslation(UiGroupState& group, const std::array<float, 3>& value);
void setFileRotationDegrees(UiFileSettings& settings, const std::array<float, 3>& value);
void setSceneNodeRotationDegrees(UiSceneNodeSettings& settings, const std::array<float, 3>& value);
void setGroupRotationDegrees(UiGroupState& group, const std::array<float, 3>& value);
void setFileScale(UiFileSettings& settings, float value);
void setSceneNodeScale(UiSceneNodeSettings& settings, float value);
void setGroupScale(UiGroupState& group, float value);
void setFileOpacity(UiFileSettings& settings, float value);
void setSceneNodeOpacity(UiSceneNodeSettings& settings, float value);
void setGroupOpacity(UiGroupState& group, float value);
void setGroupColor(UiGroupState& group, const std::array<float, 4>& value);
void resetGroupColor(UiGroupState& group, size_t colorIndex);
void resetGroupTransform(UiGroupState& group);
void resetFileTransform(UiFileSettings& settings);
void resetSceneNodeTransform(UiSceneNodeSettings& settings);

[[nodiscard]] bool groupTransformIsDefault(const UiGroupState& group);
[[nodiscard]] bool fileTransformIsDefault(const UiFileSettings& settings);
[[nodiscard]] bool sceneNodeTransformIsDefault(const UiSceneNodeSettings& settings);

void recalculateSceneBounds(UiState& state);
void frameCameraToScene(UiState& state);
void frameCameraToObject(UiState& state, SceneObjectId object);
void setUiCamera(UiState& state, const CameraPlacement& placement);
void lookAtUiCamera(UiState& state, const std::array<float, 3>& eye, const std::array<float, 3>& target);
void setCameraView(UiState& state, CameraView view);
void fitCameraToScene(UiState& state);
void fitCameraToSelection(UiState& state);
void appendFolderTreeSceneNode(
    UiState& state,
    const std::filesystem::path& root,
    size_t firstFileIndex,
    size_t fileCount);
bool removeFileFromState(UiState& state, size_t fileIndex);
// Prepare without mutating the live state; commit only after resources are ready.
[[nodiscard]] UiState prepareSceneReplacement(const UiState& current,
    std::vector<UiFileState> files, const SceneDocument& document);
void setSceneDirty(UiState& state, bool dirty);
// Notify history after a scene operation, including batches of struct-level
// setters. Does not change the saved-state indicator: tree construction can also
// be used while initializing a clean scene. No-op notifications are filtered.
void notifySceneEdit(UiState& state, SceneChange change = SceneChange::all);
// Notify an edit and provisionally mark the document dirty. clear/updateSceneDirty
// only synchronize the saved-state indicator and do not notify history.
void markSceneDirty(UiState& state, SceneChange change = SceneChange::all);
void clearSceneDirty(UiState& state);
void updateSceneDirty(UiState& state, const SceneDocument& cleanDocument);
void setViewerPaneWidth(UiState& state, float value, float minWidth, float maxWidth);
void setViewerPaneVisible(UiState& state, bool visible);
void toggleViewerPaneVisible(UiState& state);
void requestQuit(UiState& state);
void setCameraOrbiting(UiState& state, bool enabled);
void setCameraRolling(UiState& state, bool enabled);
void setCameraPanning(UiState& state, bool enabled);
void orbitUiCamera(UiState& state, float deltaX, float deltaY);
void rollUiCamera(UiState& state, float deltaX);
void panUiCamera(UiState& state, float deltaX, float deltaY, float viewportHeight);
void dollyUiCamera(UiState& state, float amount);

struct CameraNavigation {
    float yawDegrees = 0, pitchDegrees = 0, rollDegrees = 0;
    float right = 0, up = 0, forward = 0;
    float distanceFactor = 1;
};
// Angles change the stored camera angles; translation uses rolled camera-local units.
// Reject non-finite input/results without changing the camera.
void navigateUiCamera(UiState& state, const CameraNavigation& navigation);

[[nodiscard]] const UiAnnotation* findAnnotation(const UiState& state, SceneObjectId id);
[[nodiscard]] const UiAnnotation* selectedAnnotation(const UiState& state);
SceneObjectId createCrossSection(UiState& state, CrossSectionSettings settings, std::vector<SceneObjectId> sources);
void setCrossSectionSettings(UiState& state, SceneObjectId id, CrossSectionSettings settings);
[[nodiscard]] std::vector<Coordinate> annotationOriginalVertices(const UiState& state, const UiAnnotation& item);
[[nodiscard]] std::vector<std::array<float, 3>> annotationVertices(const UiState& state, const UiAnnotation& item);
SceneObjectId createAnnotation(UiState& state, SceneObjectId target, AnnotationGeometry geometry,
    std::vector<SceneObjectId> targets = {});
SceneObjectId createAnnotation(UiState& state, SceneObjectId target, AnnotationGeometryOwner geometry,
    std::vector<SceneObjectId> targets = {});
SceneObjectId duplicateAnnotation(UiState& state, SceneObjectId id);
void renameAnnotation(UiState& state, SceneObjectId id, const std::string& name);
void setAnnotationSettings(UiState& state, SceneObjectId id, AnnotationSettings settings);
void setAllAnnotationsVisible(UiState& state, bool visible);
void reshapeAnnotation(UiState& state, SceneObjectId id, AnnotationGeometry geometry);
void reshapeAnnotation(UiState& state, SceneObjectId id, AnnotationGeometryOwner geometry);
void deleteAnnotation(UiState& state, SceneObjectId id);
void validateAnnotationTargets(UiState& state, bool notifyEdit = true);
[[nodiscard]] std::vector<SceneAnnotationRecord> sceneAnnotationRecords(const UiState& state);
void loadSceneAnnotations(UiState& state, const SceneDocument& document);

} // namespace woby

namespace woby { void requestComparisonIntersections(UiState& state, SceneObjectId id, bool cancel = false); }
namespace woby { void requestDifferenceMesh(UiState& state, SceneObjectId id, bool cancel = false); }
namespace woby {
void requestComparisonDetector(UiState& state, SceneObjectId id, DiagnosticCategory category, bool cancel = false);
void setComparisonAutomaticUpdate(UiState& state, SceneObjectId id, DiagnosticCategory category, bool automatic);
}
