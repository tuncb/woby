#include "hover_pick.h"

#include "hash_utils.h"

#include "math_utils.h"

#include <algorithm>
#include <cmath>

namespace woby {

uint64_t hoverSceneSignature(const UiState& state, const std::vector<LoadedModelRuntime>& runtimes)
{
    uint64_t key = 17;
    hashCombine(key, reinterpret_cast<uintptr_t>(&state));
    hashCombine(key, state.sceneGeneration);
    hashCombine(key, state.revisions.geometry);
    hashCombine(key, state.revisions.visibility);
    hashCombine(key, state.revisions.picking);
    hashCombine(key, state.files.size()); hashCombine(key, runtimes.size());
    for (size_t i = 0; i < std::min(state.files.size(), runtimes.size()); ++i) {
        const auto& file = state.files[i]; const auto& mesh = runtimes[i].gpuMesh;
        hashCombine(key, file.objectId); hashCombine(key, file.mesh.contentRevision);
        hashCombine(key, mesh.resourceRevision);
        hashCombine(key, mesh.vertexBuffer.idx); hashCombine(key, mesh.pointIdBuffer.idx);
        hashCombine(key, mesh.triangleIndexBuffer.idx); hashCombine(key, mesh.importedLineBuffer.idx);
        hashCombine(key, reinterpret_cast<uintptr_t>(meshPointVertexIndices(mesh).data()));
        hashCombine(key, meshPointVertexIndices(mesh).size()); hashCombine(key, mesh.nodeRanges.size());
    }
    return key;
}

uint64_t hoverPickSignature(HoverPickCache& cache, const UiState& state,
    const std::vector<LoadedModelRuntime>& runtimes, MousePosition mouse, bool inside,
    uint32_t width, uint32_t height, bool homogeneousDepth)
{
    const auto scene = hoverSceneSignature(state, runtimes);
    if (!cache.sceneBuilds || scene != cache.sceneSignature) { cache.sceneSignature = scene; ++cache.sceneBuilds; }
    uint64_t key = scene;
    hashFloat(key, mouse.x); hashFloat(key, mouse.y); hashBool(key, inside);
    hashCamera(key, state.camera); hashCombine(key, static_cast<uint64_t>(state.upAxis));
    hashBounds(key, state.sceneBounds);
    hashCombine(key, width); hashCombine(key, height); hashBool(key, homogeneousDepth);
    return key;
}

bool hoverNavigationPaused(HoverNavigationState& state, const SceneCamera& camera,
    SceneUpAxis upAxis, const CameraInput& input, double nowSeconds)
{
    const bool moving = input.orbiting || input.rolling || input.panning
        || state.camera != camera || state.upAxis != upAxis;
    if (moving) { state.resumeAtSeconds = nowSeconds + 0.15; }
    state.camera = camera;
    state.upAxis = upAxis;
    return nowSeconds < state.resumeAtSeconds;
}

namespace {

constexpr float vertexHoverMinRadius = 3.0f;
constexpr float vertexHoverEpsilon = 0.000001f;

struct ProjectedVertex {
    bool visible = false;
    float x = 0.0f;
    float y = 0.0f;
    float depth = 0.0f;
};

std::array<float, 4> transformPoint4(const float* matrix, const std::array<float, 4>& point)
{
    return {
        matrix[0] * point[0] + matrix[4] * point[1] + matrix[8] * point[2] + matrix[12] * point[3],
        matrix[1] * point[0] + matrix[5] * point[1] + matrix[9] * point[2] + matrix[13] * point[3],
        matrix[2] * point[0] + matrix[6] * point[1] + matrix[10] * point[2] + matrix[14] * point[3],
        matrix[3] * point[0] + matrix[7] * point[1] + matrix[11] * point[2] + matrix[15] * point[3],
    };
}

std::array<float, 3> transformPosition(const float* matrix, const std::array<float, 3>& position)
{
    const auto transformed = transformPoint4(matrix, {position[0], position[1], position[2], 1.0f});
    if (std::abs(transformed[3]) <= vertexHoverEpsilon) {
        return {transformed[0], transformed[1], transformed[2]};
    }

    return {
        transformed[0] / transformed[3],
        transformed[1] / transformed[3],
        transformed[2] / transformed[3],
    };
}

ProjectedVertex projectPosition(
    const std::array<float, 3>& position,
    const float* model,
    const float* view,
    const float* projection,
    uint32_t viewportWidth,
    uint32_t viewportHeight,
    bool homogeneousDepth)
{
    const auto world = transformPoint4(model, {position[0], position[1], position[2], 1.0f});
    const auto eye = transformPoint4(view, world);
    const auto clip = transformPoint4(projection, eye);
    if (clip[3] <= vertexHoverEpsilon) {
        return {};
    }

    const float ndcX = clip[0] / clip[3];
    const float ndcY = clip[1] / clip[3];
    const float ndcZ = clip[2] / clip[3];
    const float minDepth = homogeneousDepth ? -1.0f : 0.0f;
    if (ndcX < -1.0f
        || ndcX > 1.0f
        || ndcY < -1.0f
        || ndcY > 1.0f
        || ndcZ < minDepth
        || ndcZ > 1.0f) {
        return {};
    }

    ProjectedVertex projected;
    projected.visible = true;
    projected.x = (ndcX * 0.5f + 0.5f) * static_cast<float>(viewportWidth);
    projected.y = (0.5f - ndcY * 0.5f) * static_cast<float>(viewportHeight);
    projected.depth = ndcZ;
    return projected;
}

void updateHoveredVertexCandidate(
    const std::array<float, 3>& localPosition,
    const std::array<float, 3>& transformedPosition,
    const ProjectedVertex& projected,
    const MousePosition& mouse,
    float hoverRadius,
    std::optional<HoveredVertex>& hoveredVertex)
{
    const float deltaX = projected.x - mouse.x;
    const float deltaY = projected.y - mouse.y;
    const float distanceSquared = deltaX * deltaX + deltaY * deltaY;
    if (distanceSquared > hoverRadius * hoverRadius) {
        return;
    }

    if (hoveredVertex.has_value()
        && (projected.depth > hoveredVertex->depth
            || (projected.depth == hoveredVertex->depth
                && distanceSquared >= hoveredVertex->distanceSquared))) {
        return;
    }

    hoveredVertex = HoveredVertex{
        localPosition,
        transformedPosition,
        projected.depth,
        distanceSquared,
    };
}

void hashSceneNodeSettings(uint64_t& seed, const UiSceneNodeSettings& settings)
{
    hashBool(seed, settings.visible);
    hashFloat(seed, settings.scale);
    hashFloat(seed, settings.opacity);
    for (const float value : settings.center) {
        hashFloat(seed, value);
    }
    for (const float value : settings.translation) {
        hashFloat(seed, value);
    }
    for (const float value : settings.rotationDegrees) {
        hashFloat(seed, value);
    }
}

void hashSceneNode(uint64_t& seed, const UiSceneNode& node)
{
    hashCombine(seed, static_cast<uint64_t>(node.kind));
    hashSceneNodeSettings(seed, node.settings);
    hashCombine(seed, node.fileIndex);
    hashCombine(seed, node.groupIndex);
    hashCombine(seed, node.children.size());
    for (const auto& child : node.children) {
        hashSceneNode(seed, child);
    }
}

std::span<const uint32_t> hoverCandidates(const GpuMesh& mesh,size_t group,const float* model,const float* view,
    const float* projection,uint32_t width,uint32_t height,bool homogeneousDepth,const MousePosition& mouse,float radius,
    std::vector<uint32_t>& scratch) {
    const auto indices=meshPointVertexIndices(mesh);
    const auto& range=mesh.nodeRanges[group];
    const size_t begin=std::min<size_t>(range.pointIndexOffset,indices.size());
    if (!mesh.pointCloud) return indices.subspan(begin,std::min<size_t>(range.pointIndexCount,indices.size()-begin));
    points::Matrix modelView,matrix;
    woby::multiplyMatrices(modelView.data(),model,view); woby::multiplyMatrices(matrix.data(),modelView.data(),projection);
    if (homogeneousDepth) for (size_t col=0;col<4;++col) matrix[col*4+2]=(matrix[col*4+2]+matrix[col*4+3])*.5f;
    const auto leaves=points::queryFootprints(*mesh.pointCloud,static_cast<uint32_t>(group),matrix,width,height,radius*2,
        {mouse.x,mouse.y,mouse.x,mouse.y});
    for (const auto& leaf:leaves.ranges) for (uint32_t i=leaf.begin;i<leaf.begin+leaf.count;++i)
        scratch.push_back(mesh.pointCloud->points[i].id-1);
    std::sort(scratch.begin(),scratch.end());
    for (auto& index:scratch) index=indices[index];
    return scratch;
}

void findHoveredGroupVertex(
    const UiFileState& file,
    const GpuMesh& gpuMesh,
    size_t nodeIndex,
    const MousePosition& mouse,
    float masterVertexPointSize,
    const float* model,
    const float* view,
    const float* projection,
    uint32_t viewportWidth,
    uint32_t viewportHeight,
    bool homogeneousDepth,
    std::optional<HoveredVertex>& hoveredVertex)
{
    if (nodeIndex >= file.groupSettings.size() || nodeIndex >= gpuMesh.nodeRanges.size()) {
        return;
    }

    const auto& settings = file.groupSettings[nodeIndex];
    if (!settings.visible || !settings.showVertices) {
        return;
    }

    float groupModel[16];
    float groupWorld[16];
    groupTransformMatrix(settings, groupModel);
    woby::multiplyMatrices(groupWorld, model, groupModel);

    const uint32_t pointSize = vertexPointSize(
        masterVertexPointSize,
        file.vertexSizeScale * settings.vertexSizeScale);
    const float hoverRadius = std::max(
        static_cast<float>(pointSize) * 0.5f,
        vertexHoverMinRadius);
    std::vector<uint32_t> scratch;
    const auto candidates=hoverCandidates(gpuMesh,nodeIndex,groupWorld,view,projection,viewportWidth,viewportHeight,
        homogeneousDepth,mouse,hoverRadius,scratch);
    for (const auto vertexIndex:candidates) {
        if (vertexIndex >= meshGeometry(file.mesh).vertices.size()) {
            continue;
        }

        const auto& localPosition = meshGeometry(file.mesh).vertices[vertexIndex].position;
        const auto projected = projectPosition(
            localPosition,
            groupWorld,
            view,
            projection,
            viewportWidth,
            viewportHeight,
            homogeneousDepth);
        if (!projected.visible) {
            continue;
        }

        updateHoveredVertexCandidate(
            localPosition,
            transformPosition(groupWorld, localPosition),
            projected,
            mouse,
            hoverRadius,
            hoveredVertex);
    }
}

void findHoveredSceneNodeVertex(
    const std::vector<UiFileState>& files,
    const std::vector<LoadedModelRuntime>& runtimes,
    const UiSceneNode& node,
    const MousePosition& mouse,
    float masterVertexPointSize,
    const float* parentModel,
    const float* view,
    const float* projection,
    uint32_t viewportWidth,
    uint32_t viewportHeight,
    bool homogeneousDepth,
    std::optional<HoveredVertex>& hoveredVertex)
{
    if (node.kind == UiSceneNodeKind::folder) {
        if (!node.settings.visible) {
            return;
        }

        float nodeModel[16];
        float model[16];
        sceneNodeTransformMatrix(node.settings, nodeModel);
        woby::multiplyMatrices(model, parentModel, nodeModel);
        for (const auto& child : node.children) {
            findHoveredSceneNodeVertex(
                files,
                runtimes,
                child,
                mouse,
                masterVertexPointSize,
                model,
                view,
                projection,
                viewportWidth,
                viewportHeight,
                homogeneousDepth,
                hoveredVertex);
        }
        return;
    }

    if (node.kind == UiSceneNodeKind::file) {
        if (node.fileIndex >= files.size() || node.fileIndex >= runtimes.size()) {
            return;
        }

        const auto& file = files[node.fileIndex];
        if (!file.fileSettings.visible) {
            return;
        }

        float fileModel[16];
        float model[16];
        fileTransformMatrix(file.fileSettings, fileModel);
        woby::multiplyMatrices(model, parentModel, fileModel);
        const auto& gpuMesh = runtimes[node.fileIndex].gpuMesh;
        if (node.children.empty()) {
            const size_t groupCount = std::min(file.groupSettings.size(), gpuMesh.nodeRanges.size());
            for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
                findHoveredGroupVertex(
                    file,
                    gpuMesh,
                    groupIndex,
                    mouse,
                    masterVertexPointSize,
                    model,
                    view,
                    projection,
                    viewportWidth,
                    viewportHeight,
                    homogeneousDepth,
                    hoveredVertex);
            }
            return;
        }

        for (const auto& child : node.children) {
            findHoveredSceneNodeVertex(
                files,
                runtimes,
                child,
                mouse,
                masterVertexPointSize,
                model,
                view,
                projection,
                viewportWidth,
                viewportHeight,
                homogeneousDepth,
                hoveredVertex);
        }
        return;
    }

    if (node.fileIndex >= files.size() || node.fileIndex >= runtimes.size()) {
        return;
    }
    findHoveredGroupVertex(
        files[node.fileIndex],
        runtimes[node.fileIndex].gpuMesh,
        node.groupIndex,
        mouse,
        masterVertexPointSize,
        parentModel,
        view,
        projection,
        viewportWidth,
        viewportHeight,
        homogeneousDepth,
        hoveredVertex);
}

} // namespace

uint64_t hoverPickSignature(
    const std::vector<UiFileState>& files,
    const std::vector<UiSceneNode>& sceneNodes,
    const std::vector<LoadedModelRuntime>& runtimes,
    const MousePosition& mouse,
    bool mouseInsideViewport,
    float masterVertexPointSize,
    const SceneCamera& camera,
    SceneUpAxis upAxis,
    const Bounds& sceneBounds,
    uint32_t viewportWidth,
    uint32_t viewportHeight,
    bool homogeneousDepth)
{
    uint64_t seed = 0xcbf29ce484222325ull;
    hashFloat(seed, mouse.x);
    hashFloat(seed, mouse.y);
    hashBool(seed, mouseInsideViewport);
    hashFloat(seed, masterVertexPointSize);
    hashCamera(seed, camera);
    hashCombine(seed, static_cast<uint64_t>(upAxis));
    hashBounds(seed, sceneBounds);
    hashCombine(seed, viewportWidth);
    hashCombine(seed, viewportHeight);
    hashBool(seed, homogeneousDepth);
    hashCombine(seed, files.size());
    hashCombine(seed, sceneNodes.size());
    hashCombine(seed, runtimes.size());

    for (const auto& node : sceneNodes) {
        hashSceneNode(seed, node);
    }

    const size_t fileCount = std::min(files.size(), runtimes.size());
    for (size_t fileIndex = 0; fileIndex < fileCount; ++fileIndex) {
        const auto& file = files[fileIndex];
        const auto& gpuMesh = runtimes[fileIndex].gpuMesh;
        hashCombine(seed, reinterpret_cast<uintptr_t>(meshGeometry(file.mesh).vertices.data()));
        hashCombine(seed, meshGeometry(file.mesh).vertices.size());
        hashCombine(seed, reinterpret_cast<uintptr_t>(meshPointVertexIndices(gpuMesh).data()));
        hashCombine(seed, meshPointVertexIndices(gpuMesh).size());
        hashCombine(seed, gpuMesh.nodeRanges.size());
        hashFileSettings(seed, file.fileSettings);
        hashFloat(seed, file.vertexSizeScale);

        const size_t groupCount = std::min(file.groupSettings.size(), gpuMesh.nodeRanges.size());
        hashCombine(seed, groupCount);
        for (size_t groupIndex = 0; groupIndex < groupCount; ++groupIndex) {
            const auto& range = gpuMesh.nodeRanges[groupIndex];
            hashCombine(seed, range.pointIndexOffset);
            hashCombine(seed, range.pointIndexCount);
            hashGroupSettings(seed, file.groupSettings[groupIndex]);
        }
    }

    return seed;
}

std::optional<HoveredVertex> findHoveredVertex(const UiState& state, std::span<const ScenePickPart> parts,
    const std::vector<LoadedModelRuntime>& runtimes, MousePosition mouse, const ScenePickView& view)
{
    std::optional<HoveredVertex> hovered;
    for (const auto& part : parts) {
        if (!part.mesh || !part.vertices || part.fileIndex >= runtimes.size() || part.fileIndex >= state.files.size()) { continue; }
        const auto& groups = state.files[part.fileIndex].groupSettings;
        if (part.groupIndex >= groups.size()) { continue; }
        const auto& gpu = runtimes[part.fileIndex].gpuMesh;
        if (part.groupIndex >= gpu.nodeRanges.size()) { continue; }
        const float radius = std::max(part.pointSize * .5f, vertexHoverMinRadius);
        std::vector<uint32_t> scratch;
        const auto candidates = hoverCandidates(gpu, part.groupIndex, part.model.data(), view.view.data(), view.projection.data(),
            view.width, view.height, view.homogeneousDepth, mouse, radius, scratch);
        for (const auto index : candidates) {
            if (index >= meshGeometry(*part.mesh).vertices.size()) { continue; }
            const auto& local = meshGeometry(*part.mesh).vertices[index].position;
            const auto projected = projectPosition(local, part.model.data(), view.view.data(), view.projection.data(),
                view.width, view.height, view.homogeneousDepth);
            if (!projected.visible) { continue; }
            updateHoveredVertexCandidate(local, transformPosition(part.model.data(), local), projected, mouse, radius, hovered);
        }
    }
    return hovered;
}

std::optional<HoveredVertex> findHoveredVertex(
    const std::vector<UiFileState>& files,
    const std::vector<UiSceneNode>& sceneNodes,
    const std::vector<LoadedModelRuntime>& runtimes,
    const MousePosition& mouse,
    float masterVertexPointSize,
    const float* view,
    const float* projection,
    uint32_t viewportWidth,
    uint32_t viewportHeight,
    bool homogeneousDepth)
{
    std::optional<HoveredVertex> hoveredVertex;
    if (!sceneNodes.empty()) {
        float identity[16];
        woby::identityMatrix(identity);
        for (const auto& node : sceneNodes) {
            findHoveredSceneNodeVertex(
                files,
                runtimes,
                node,
                mouse,
                masterVertexPointSize,
                identity,
                view,
                projection,
                viewportWidth,
                viewportHeight,
                homogeneousDepth,
                hoveredVertex);
        }
        return hoveredVertex;
    }

    const size_t fileCount = std::min(files.size(), runtimes.size());
    for (size_t fileIndex = 0; fileIndex < fileCount; ++fileIndex) {
        const auto& file = files[fileIndex];
        const auto& gpuMesh = runtimes[fileIndex].gpuMesh;
        if (!file.fileSettings.visible) {
            continue;
        }

        float fileModel[16];
        fileTransformMatrix(file.fileSettings, fileModel);
        const size_t groupCount = std::min(file.groupSettings.size(), gpuMesh.nodeRanges.size());
        for (size_t nodeIndex = 0; nodeIndex < groupCount; ++nodeIndex) {
            const auto& settings = file.groupSettings[nodeIndex];
            if (!settings.visible || !settings.showVertices) {
                continue;
            }

            float groupModel[16];
            float model[16];
            groupTransformMatrix(settings, groupModel);
            woby::multiplyMatrices(model, fileModel, groupModel);

            const uint32_t pointSize = vertexPointSize(
                masterVertexPointSize,
                file.vertexSizeScale * settings.vertexSizeScale);
            const float hoverRadius = std::max(
                static_cast<float>(pointSize) * 0.5f,
                vertexHoverMinRadius);
            std::vector<uint32_t> scratch;
            const auto candidates=hoverCandidates(gpuMesh,nodeIndex,model,view,projection,viewportWidth,viewportHeight,
                homogeneousDepth,mouse,hoverRadius,scratch);
            for (const auto vertexIndex:candidates) {
                if (vertexIndex >= meshGeometry(file.mesh).vertices.size()) {
                    continue;
                }

                const auto& localPosition = meshGeometry(file.mesh).vertices[vertexIndex].position;
                const auto projected = projectPosition(
                    localPosition,
                    model,
                    view,
                    projection,
                    viewportWidth,
                    viewportHeight,
                    homogeneousDepth);
                if (!projected.visible) {
                    continue;
                }

                updateHoveredVertexCandidate(
                    localPosition,
                    transformPosition(model, localPosition),
                    projected,
                    mouse,
                    hoverRadius,
                    hoveredVertex);
            }
        }
    }

    return hoveredVertex;
}

} // namespace woby
