#include "ui_operations.h"
#include "analysis_presentation.h"
#include "comparison_scene.h"
#include "mesh_comparison.h"
#include "uv_quality.h"
#include "utf8_path.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <stdexcept>
#include <boost/unordered/unordered_flat_map.hpp>
#include <utility>
#include <tuple>

namespace woby {
bool sceneObjectSelected(const UiState& state, SceneObjectId id)
{
    return std::find(state.selectedSceneObjects.begin(), state.selectedSceneObjects.end(), id)
        != state.selectedSceneObjects.end();
}

void selectSceneObject(UiState& state, SceneObjectId id, bool toggle, bool contextClick)
{
    if (!findSceneObject(state, id)) {
        return;
    }
    setPropertiesPaneVisible(state, true);
    if (findComparison(state, id)) {
        state.activeComparisonId = id;
    }
    const bool selected = sceneObjectSelected(state, id);
    if (contextClick && selected) {
        return;
    }
    if (contextClick) {
        state.selectedSceneObjects.push_back(id);
    } else if (!toggle) {
        state.selectedSceneObjects = {id};
    } else if (selected) {
        std::erase(state.selectedSceneObjects, id);
    } else {
        state.selectedSceneObjects.push_back(id);
    }
    if (const auto* comparison = selectedComparison(state)) {
        state.activeComparisonId = comparison->objectId;
    }
}

bool setUvProbe(UiState& state, SceneObjectId analysisId, SceneObjectId partId,
    size_t triangle, const std::array<double,3>& barycentric)
{
    auto* comparison = findComparison(state,analysisId);
    if (!comparison || comparison->settings.type != AnalysisType::uvQuality || !comparison->settings.uvLinkedSelection
        || !comparison->settings.enabled || !comparisonContains(state,partId,ComparisonSide::a,analysisId) || triangle == 0) { return false; }
    if (std::none_of(comparison->a.begin(),comparison->a.end(),[&](const auto& member) {
        return member.objectId == partId && member.enabled;
    })) { return false; }
    bool validTriangle = false;
    for (const auto& file : state.files) {
        for (size_t i=0;i<file.groupSettings.size();++i) {
            if (file.groupSettings[i].objectId == partId && i < meshGeometry(file.mesh).nodes.size()) {
                validTriangle = triangle <= meshGeometry(file.mesh).nodes[i].indexCount/3;
            }
        }
    }
    double sum = 0;
    for (double value : barycentric) { if (!std::isfinite(value) || value < -1e-8 || value > 1+1e-8) { return false; } sum += value; }
    if (!validTriangle || std::abs(sum-1) > 1e-8) { return false; }
    selectSceneObject(state,analysisId);
    comparison->uvProbe = UvProbe{comparisonGeometrySignature(state,analysisId),partId,triangle,barycentric};
    return true;
}
void clearUvProbe(UiState& state, SceneObjectId analysisId)
{
    if (auto* comparison = findComparison(state,analysisId)) { comparison->uvProbe.reset(); }
}

void clearSceneSelection(UiState& state)
{
    state.selectedSceneObjects.clear();
    for (auto& comparison : state.comparisons) { comparison.uvProbe.reset(); }
}

const UiComparison* selectedComparison(const UiState& state)
{
    return state.selectedSceneObjects.size() == 1 && state.selectedSceneObjects.front() != invalidSceneObjectId
        ? findComparison(state, state.selectedSceneObjects.front()) : nullptr;
}

namespace {
bool comparablePart(const UiFileState& file, size_t index)
{
    if (index >= meshGeometry(file.mesh).nodes.size() || index >= file.groupSettings.size()) { return false; }
    const auto& node = meshGeometry(file.mesh).nodes[index];
    return node.indexCount >= 3 && node.indexCount % 3 == 0
        && static_cast<size_t>(node.indexOffset) + node.indexCount <= meshGeometry(file.mesh).indices.size();
}

std::array<float, 3> initialComparisonTranslation(const UiState& state,
    SceneObjectId excluded = invalidSceneObjectId)
{
    const auto bounds = combineBounds(state.files, state.sceneNodes);
    float rightEdge = bounds.max[0];
    for (const auto& other : state.comparisons) {
        if (other.objectId == excluded) { continue; }
        if (const auto display = comparisonDisplayBounds(state, other.objectId)) {
            rightEdge = std::max(rightEdge, display->max[0]);
        }
    }
    const std::array<float, 3> translation{
        rightEdge - bounds.min[0] + std::max(bounds.max[0] - bounds.min[0], 1.0f) * .25f, 0, 0};
    return finitePosition(translation) ? translation : std::array<float, 3>{};
}
} // namespace

std::vector<SceneObjectId> comparisonObjectParts(const UiState& state, const std::vector<SceneObjectId>& objects)
{
    std::vector<SceneObjectId> parts;
    auto sortedObjects = objects;
    std::sort(sortedObjects.begin(), sortedObjects.end());
    const auto selected = [&sortedObjects](SceneObjectId id) {
        return id != invalidSceneObjectId && std::binary_search(sortedObjects.begin(), sortedObjects.end(), id);
    };
    const auto appendFile = [&parts](const UiFileState& file) {
        for (size_t i = 0; i < file.groupSettings.size(); ++i) {
            if (comparablePart(file, i)) { parts.push_back(file.groupSettings[i].objectId); }
        }
    };
    // Resolve files and individual parts even when no explicit scene tree exists.
    for (const auto& file : state.files) {
        if (selected(file.objectId)) { appendFile(file); }
        else {
            for (size_t i = 0; i < file.groupSettings.size(); ++i) {
                if (selected(file.groupSettings[i].objectId) && comparablePart(file, i)) {
                    parts.push_back(file.groupSettings[i].objectId);
                }
            }
        }
    }
    const auto visit = [&](auto&& self, const UiSceneNode& node, bool included) -> void {
        included = included || selected(node.objectId);
        if (included && node.fileIndex < state.files.size()) {
            const auto& file = state.files[node.fileIndex];
            if (node.kind == UiSceneNodeKind::file) { appendFile(file); }
            else if (node.kind == UiSceneNodeKind::group && comparablePart(file, node.groupIndex)) {
                parts.push_back(file.groupSettings[node.groupIndex].objectId);
            }
        }
        for (const auto& child : node.children) { self(self, child, included); }
    };
    for (const auto& node : state.sceneNodes) { visit(visit, node, false); }
    std::sort(parts.begin(), parts.end());
    parts.erase(std::unique(parts.begin(), parts.end()), parts.end());
    std::erase(parts, invalidSceneObjectId);
    return parts;
}

const UiComparison* findComparison(const UiState& state, SceneObjectId id)
{
    if (id == invalidSceneObjectId) { id = state.activeComparisonId; }
    for (const auto& comparison : state.comparisons) {
        if (comparison.objectId == id) { return &comparison; }
    }
    return nullptr;
}

UiComparison* findComparison(UiState& state, SceneObjectId id)
{
    if (id == invalidSceneObjectId) { id = state.activeComparisonId; }
    for (auto& comparison : state.comparisons) {
        if (comparison.objectId == id) { return &comparison; }
    }
    return nullptr;
}

ComparisonSettings comparisonSettings(const UiState& state, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    return comparison ? comparison->settings : ComparisonSettings{};
}

bool comparisonContains(const UiState& state, SceneObjectId part, ComparisonSide side, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison || part == invalidSceneObjectId) { return false; }
    const auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
    return std::any_of(members.begin(), members.end(), [part](const UiComparisonPart& member) {
        return member.objectId == part;
    });
}

std::vector<SceneObjectId> comparableScenePartIds(const UiState& state)
{
    std::vector<SceneObjectId> parts;
    for (const auto& file : state.files) {
        for (size_t i = 0; i < file.groupSettings.size(); ++i) {
            if (comparablePart(file, i) && file.groupSettings[i].objectId != invalidSceneObjectId) {
                parts.push_back(file.groupSettings[i].objectId);
            }
        }
    }
    std::sort(parts.begin(), parts.end());
    parts.erase(std::unique(parts.begin(), parts.end()), parts.end());
    return parts;
}

bool fileHasComparableParts(const UiFileState& file)
{
    for (size_t i = 0; i < std::min(file.groupSettings.size(), meshGeometry(file.mesh).nodes.size()); ++i) {
        if (file.groupSettings[i].objectId != invalidSceneObjectId && comparablePart(file, i)) { return true; }
    }
    return false;
}

std::vector<SceneObjectId> comparisonMemberIds(const UiState& state, ComparisonSide side,
    SceneObjectId id, bool enabledOnly)
{
    std::vector<SceneObjectId> parts;
    const auto* comparison = findComparison(state, id);
    if (!comparison) { return parts; }
    const auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
    parts.reserve(members.size());
    for (const auto& member : members) {
        if ((!enabledOnly || member.enabled) && member.objectId != invalidSceneObjectId) { parts.push_back(member.objectId); }
    }
    std::sort(parts.begin(), parts.end());
    parts.erase(std::unique(parts.begin(), parts.end()), parts.end());
    return parts;
}

namespace {
size_t countComparisonParts(const UiState& state, ComparisonSide side, SceneObjectId id, bool enabledOnly)
{
    const auto members = comparisonMemberIds(state, side, id, enabledOnly);
    if (members.empty()) { return 0; }
    size_t count = 0;
    for (const auto& file : state.files) {
        for (size_t i = 0; i < file.groupSettings.size(); ++i) {
            if (comparablePart(file, i)
                && std::binary_search(members.begin(), members.end(), file.groupSettings[i].objectId)) { ++count; }
        }
    }
    return count;
}
} // namespace

size_t comparisonPartCount(const UiState& state, ComparisonSide side, SceneObjectId id)
{
    return countComparisonParts(state, side, id, false);
}

bool comparisonPartEnabled(const UiState& state, SceneObjectId part, ComparisonSide side, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison || part == invalidSceneObjectId) { return false; }
    const auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
    return std::any_of(members.begin(), members.end(), [part](const UiComparisonPart& member) {
        return member.objectId == part && member.enabled;
    });
}

size_t enabledComparisonPartCount(const UiState& state, ComparisonSide side, SceneObjectId id)
{
    return countComparisonParts(state, side, id, true);
}

void isolateUvObjects(UiState& state, const std::vector<SceneObjectId>& objects, SceneObjectId id)
{
    const auto* analysis = findComparison(state,id);
    if (!analysis || !isUvAnalysis(analysis->settings.type)) { return; }
    isolateComparisonObjects(state, objects, ComparisonSide::a, id);
}

void isolateComparisonObjects(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, SceneObjectId id)
{
    auto* analysis = findComparison(state, id);
    if (!analysis || (isUvAnalysis(analysis->settings.type) && side != ComparisonSide::a)) { return; }
    if (isSingleSourceMeshTask(analysis->settings.task)) { side = ComparisonSide::a; }
    const auto included = comparisonObjectParts(state, objects);
    auto& members = side == ComparisonSide::a ? analysis->a : analysis->b;
    if (!objects.empty() && std::none_of(members.begin(), members.end(), [&](const auto& part) {
        return std::binary_search(included.begin(), included.end(), part.objectId);
    })) { return; }
    bool changed = false;
    for (auto& part : members) {
        const bool enabled = objects.empty() || std::binary_search(included.begin(), included.end(), part.objectId);
        changed = changed || part.enabled != enabled;
        part.enabled = enabled;
    }
    if (!changed) { return; }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::analysis);
}

void setComparisonObjectsEnabled(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side,
    bool enabled, SceneObjectId id)
{
    auto* comparison = findComparison(state, id);
    if (!comparison) { return; }
    if (isSingleSourceMeshTask(comparison->settings.task)) { side = ComparisonSide::a; }
    const auto parts = comparisonObjectParts(state, objects);
    auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
    bool changed = false;
    for (auto& member : members) {
        if (objects.empty() || std::binary_search(parts.begin(), parts.end(), member.objectId)) {
            changed = changed || member.enabled != enabled;
            member.enabled = enabled;
        }
    }
    if (!changed) { return; }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::analysis);
}

namespace {
bool hasEnabledMissingComparisonParts(const UiState& state, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison) { return false; }
    const auto available = comparableScenePartIds(state);
    for (const auto* members : {&comparison->a, &comparison->b}) {
        for (const auto& member : *members) {
            if (member.enabled && !std::binary_search(available.begin(), available.end(), member.objectId)
                && comparisonObjectParts(state, {member.objectId}).empty()) { return true; }
        }
    }
    return false;
}
} // namespace

size_t missingComparisonPartCount(const UiState& state, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison) { return 0; }
    return comparison->a.size() + comparison->b.size()
        - comparisonPartCount(state, ComparisonSide::a, id) - comparisonPartCount(state, ComparisonSide::b, id);
}

SceneObjectId createComparison(UiState& state, AnalysisType type)
{
    UiComparison comparison;
    size_t number = 1;
    do {
        comparison.name = std::string(type == AnalysisType::surfaceComparison ? "Surface comparison "
            : type == AnalysisType::uvQuality ? "UV quality " : isUvAnalysis(type) ? "UV analysis " : "Analysis ") + std::to_string(number++);
    } while (std::any_of(state.comparisons.begin(), state.comparisons.end(), [&](const UiComparison& other) {
        return other.name == comparison.name;
    }));
    comparison.settings.enabled = true;
    comparison.settings.type = type;
    if (isUvAnalysis(type)) { comparison.settings.showEdges = true; }
    if (type == AnalysisType::uvQuality) { comparison.settings.uvView = UvView::surface; comparison.settings.showEdges = false; }
    comparison.settings = normalizedComparisonSettings(comparison.settings);
    comparison.translation = initialComparisonTranslation(state);
    state.comparisons.push_back(std::move(comparison));
    assignSceneObjectIds(state);
    const auto id = state.comparisons.back().objectId;
    selectSceneObject(state, id);
    markSceneDirty(state, SceneChange::analysis);
    return id;
}

AnalysisTask comparisonTask(const UiState& state, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    return comparison ? analysisTask(comparison->settings, !comparison->a.empty() && !comparison->b.empty()) : AnalysisTask::automatic;
}

void normalizeAnalysisSources(UiState& state, SceneObjectId id)
{
    auto* comparison = findComparison(state, id);
    const auto task = comparisonTask(state, id);
    if (!comparison || !isSingleSourceMeshTask(task)) { return; }
    if (task == AnalysisTask::meshChecks && comparison->settings.task == AnalysisTask::automatic) {
        comparison->settings.diagnosticSide = comparison->a.empty() && !comparison->b.empty() ? ComparisonSide::b : ComparisonSide::a;
        return;
    }
    comparison->settings.task = task;
    comparison->settings.mode = task == AnalysisTask::meshQuality ? ComparisonMode::surfaceQuality : ComparisonMode::original;
    if (task == AnalysisTask::meshQuality) { comparison->settings.quality.onOriginal = true; }
    comparison->settings.diagnosticSide = ComparisonSide::a;
    if (comparison->b.empty()) { return; }
    boost::unordered_flat_map<SceneObjectId, size_t> sourceIndex;
    for (size_t i = 0; i < comparison->a.size(); ++i) {
        if (comparison->a[i].objectId) { sourceIndex.emplace(comparison->a[i].objectId, i); }
    }
    for (const auto& part : comparison->b) {
        const auto found = sourceIndex.find(part.objectId);
        if (part.objectId && found != sourceIndex.end()) { comparison->a[found->second].enabled |= part.enabled; }
        else {
            if (part.objectId) { sourceIndex.emplace(part.objectId, comparison->a.size()); }
            comparison->a.push_back(part); // Keep missing references separately so they remain repairable.
        }
    }
    comparison->b.clear();
    comparison->diagnosticFocus.reset();
    comparison->pendingDiagnosticFocus.reset();
    comparison->boundsCache.reset();
    for (auto& view : state.views) {
        boost::unordered_flat_map<SceneObjectId, size_t> indices;
        std::vector<UiViewPart> parts;
        parts.reserve(view.parts.size());
        for (auto part : view.parts) {
            if (part.comparisonId == id) {
                part.side = ComparisonSide::a;
                if (const auto found = indices.find(part.partId); found != indices.end()) {
                    parts[found->second].enabled |= part.enabled;
                    continue;
                }
                indices.emplace(part.partId, parts.size());
            }
            parts.push_back(part);
        }
        view.parts = std::move(parts);
        for (auto& object : view.objects) {
            if (object.objectId != id) { continue; }
            object.settings.diagnosticIndex.reset();
            object.settings.comparison.diagnosticSide = ComparisonSide::a;
            if (analysisTask(object.settings.comparison, true) == AnalysisTask::meshQuality) {
                object.settings.comparison.quality.onOriginal = true;
            }
            if (object.settings.comparison.task == AnalysisTask::meshChecks) {
                object.settings.comparison.mode = ComparisonMode::original;
            }
        }
    }
}

void setAnalysisTask(UiState& state, SceneObjectId id, AnalysisTask task)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison) { return; }
    // Changing mesh/UV domains uses a new analysis so no input is silently discarded.
    if (isUvAnalysis(comparison->settings.type) != (task == AnalysisTask::uvInspection)) { return; }
    const auto settings = settingsForAnalysisTask(comparison->settings, task);
    if (settings == comparison->settings && (!isSingleSourceMeshTask(task) || comparison->b.empty())) { return; }
    resetComparisonDiagnosticFocus(state, id);
    setComparisonSettings(state, settings, id);
}

SceneObjectId createAnalysisFromSelection(UiState& state, AnalysisTask task)
{
    return createAnalysisFromObjects(state, task, state.selectedSceneObjects);
}

SceneObjectId createAnalysisFromObjects(UiState& state, AnalysisTask task, const std::vector<SceneObjectId>& objects)
{
    if (!scenePostLoadReady(state)) { return invalidSceneObjectId; }
    if (task < AnalysisTask::meshChecks || task > AnalysisTask::uvInspection) { return invalidSceneObjectId; }
    std::vector<SceneObjectId> sources;
    for (const auto id : objects) {
        if (!comparisonObjectParts(state, {id}).empty()) { sources.push_back(id); }
    }
    if (task == AnalysisTask::surfaceComparison && sources.size() > 2) { return invalidSceneObjectId; }
    const auto id = createComparison(state, task == AnalysisTask::uvInspection ? AnalysisType::uv
        : task == AnalysisTask::surfaceComparison ? AnalysisType::surfaceComparison : AnalysisType::mesh);
    if (task == AnalysisTask::surfaceComparison) {
        if (!sources.empty()) { setComparisonObjects(state, {sources[0]}, ComparisonSide::a, true, id); }
        if (sources.size() == 2) { setComparisonObjects(state, {sources[1]}, ComparisonSide::b, true, id); }
    } else { setComparisonObjects(state, sources, ComparisonSide::a, true, id); }
    setAnalysisTask(state, id, task);
    std::string base = analysisTaskLabel(task);
    if (!sources.empty()) {
        if (const auto source = findSceneObject(state, sources[0])) { base += " - " + source->name; }
    }
    auto name = base;
    size_t suffix = 2;
    while (std::any_of(state.comparisons.begin(), state.comparisons.end(), [&](const UiComparison& other) {
        return other.objectId != id && other.name == name;
    })) { name = base + " " + std::to_string(suffix++); }
    renameComparison(state, id, name);
    if (!sources.empty()) { frameCameraToScene(state); }
    return id;
}

SceneObjectId duplicateComparison(UiState& state, SceneObjectId id)
{
    const auto* source = findComparison(state, id);
    if (!source) { return invalidSceneObjectId; }
    auto copy = *source;
    copy.diagnosticFocus.reset();
    copy.uvProbe.reset();
    copy.pendingDiagnosticFocus.reset();
    copy.uvFindingFocus.reset();
    copy.intersectionRequestRevision = 0; copy.cancelIntersections = false;
    copy.detectorRequests = {};
    copy.objectId = invalidSceneObjectId;
    copy.name += " copy";
    const auto sourceBounds = comparisonDisplayBounds(state, id);
    float rightEdge = combineBounds(state.files, state.sceneNodes).max[0];
    for (const auto& other : state.comparisons) {
        if (const auto display = comparisonDisplayBounds(state, other.objectId)) {
            rightEdge = std::max(rightEdge, display->max[0]);
        }
    }
    if (sourceBounds) {
        copy.translation[0] += rightEdge - sourceBounds->min[0]
            + std::max(sourceBounds->max[0] - sourceBounds->min[0], 1.0f) * .25f;
    }
    if (!finitePosition(copy.translation)) { copy.translation = source->translation; }
    state.comparisons.push_back(std::move(copy));
    assignSceneObjectIds(state);
    const auto created = state.comparisons.back().objectId;
    selectSceneObject(state, created);
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::analysis);
    return created;
}

void removeComparison(UiState& state, SceneObjectId id)
{
    if (id == invalidSceneObjectId || !findComparison(state, id)) { return; }
    std::erase_if(state.comparisons, [id](const UiComparison& comparison) { return comparison.objectId == id; });
    std::erase(state.selectedSceneObjects, id);
    pruneMissingViewReferences(state);
    if (state.activeComparisonId == id) {
        state.activeComparisonId = state.comparisons.empty() ? invalidSceneObjectId : state.comparisons.front().objectId;
    }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::analysis);
}

void renameComparison(UiState& state, SceneObjectId id, const std::string& name)
{
    if (auto* comparison = findComparison(state, id)) {
        const auto normalized = name.empty() ? "Analysis" : name;
        if (comparison->name == normalized) { return; }
        comparison->name = normalized;
        markSceneDirty(state, SceneChange::labels);
    }
}

void setComparisonTranslation(UiState& state, SceneObjectId id, const std::array<float, 3>& translation)
{
    if (!finitePosition(translation)) { return; }
    if (auto* comparison = findComparison(state, id)) {
        comparison->translation = translation;
        recalculateSceneBounds(state);
        markSceneDirty(state, SceneChange::presentation);
    }
}

void frameComparison(UiState& state, SceneObjectId id)
{
    resetComparisonDiagnosticFocus(state, id);
    if (auto* comparison = findComparison(state, id)) { comparison->uvFindingFocus.reset(); }
    if (const auto bounds = comparisonDisplayBounds(state, id)) { frameComparisonBounds(state, *bounds); }
}

const UvFindingFocus* focusedUvFinding(const UiState& state, uint64_t resultSignature, SceneObjectId id,
    std::optional<uint64_t> geometrySignature)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison || !comparison->settings.enabled || comparison->settings.type != AnalysisType::uvQuality
        || !comparison->uvFindingFocus || !comparison->uvFindingFocus->geometry || !resultSignature
        || comparison->uvFindingFocus->signature != resultSignature
        || resultSignature != (geometrySignature ? *geometrySignature : comparisonGeometrySignature(state, id))) { return nullptr; }
    return &*comparison->uvFindingFocus;
}

void validateUvFindingFocus(UiState& state, const Mesh& display, uint64_t resultSignature, SceneObjectId id,
    std::optional<uint64_t> geometrySignature)
{
    auto* comparison = findComparison(state, id);
    if (!comparison || !comparison->uvFindingFocus) { return; }
    auto& focus = comparison->uvFindingFocus;
    if (!comparison->settings.enabled || comparison->settings.type != AnalysisType::uvQuality
        || focus->signature != (geometrySignature ? *geometrySignature : comparisonGeometrySignature(state, id))) { focus.reset(); return; }
    if (focus->geometry || resultSignature != focus->signature) { return; }
    focus->geometry = uvFindingGeometry(display, focus->index);
    if (!focus->geometry) { focus.reset(); return; }
    std::vector<Vertex> vertices(3);
    for (size_t k = 0; k < vertices.size(); ++k) {
        vertices[k].position = (*focus->geometry)[k];
        for (size_t axis = 0; axis < 3; ++axis) { vertices[k].position[axis] += comparison->translation[axis]; }
    }
    auto bounds = calculateBounds(vertices);
    bounds.radius *= 1.2f;
    if (bounds.min == bounds.max) {
        if (const auto context = comparisonDisplayBounds(state, id)) { bounds.radius = std::max(bounds.radius, context->radius * .06f); }
    }
    auto camera = frameCameraBounds(bounds, state.upAxis);
    camera.nearPlane = std::min(camera.nearPlane, bounds.radius * .1f);
    state.camera = fitCameraBounds(camera, bounds);
}

void selectUvFinding(UiState& state, const Mesh& display, uint64_t resultSignature, size_t index, SceneObjectId id)
{
    auto* comparison = findComparison(state, id);
    if (!comparison || !comparison->settings.enabled || comparison->settings.type != AnalysisType::uvQuality
        || !resultSignature || resultSignature != comparisonGeometrySignature(state, id)
        || !display.uvQuality || index >= display.uvQuality->findings.size()) { return; }
    const auto& triangle = uvTriangleQuality(*display.uvQuality, display.uvQuality->findings[index]);
    if (comparison->settings.uvView == UvView::layout && (triangle.missing || triangle.collapsed)) {
        auto settings = comparison->settings;
        settings.uvView = UvView::surface;
        setComparisonSettings(state, settings, id);
    }
    comparison->uvFindingFocus = UvFindingFocus{comparisonGeometrySignature(state, id), index, {}};
    selectSceneObject(state, id);
    setUvProbe(state, id, triangle.partId, triangle.triangle, {1.0/3, 1.0/3, 1.0/3});
    validateUvFindingFocus(state, display, resultSignature, id);
}

void navigateUvFinding(UiState& state, const Mesh& display, uint64_t resultSignature, int step, SceneObjectId id)
{
    if (!display.uvQuality || display.uvQuality->findings.empty()) { return; }
    const auto count = display.uvQuality->findings.size();
    const auto* focus = focusedUvFinding(state, resultSignature, id);
    const size_t index = !focus ? (step < 0 ? count - 1 : 0)
        : step < 0 ? (focus->index + count - 1) % count : (focus->index + 1) % count;
    selectUvFinding(state, display, resultSignature, index, id);
}

namespace {
bool diagnosticFocusCurrent(const UiState& state, const UiComparison& comparison,
    std::optional<uint64_t> geometrySignature = {})
{
    const auto& focus = comparison.diagnosticFocus;
    return focus && comparison.settings.enabled && focus->signature != 0
        && focus->side == comparison.settings.diagnosticSide
        && focus->category == comparison.settings.diagnosticCategory
        && focus->signature == (geometrySignature ? *geometrySignature : comparisonGeometrySignature(state, comparison.objectId));
}

bool diagnosticResultSettingsCurrent(const UiComparison& comparison, const MeshComparison& result, const DiagnosticFocus& focus)
{
    if (focus.category == DiagnosticCategory::boundary || focus.category == DiagnosticCategory::nonManifold || focus.category == DiagnosticCategory::winding || focus.category == DiagnosticCategory::nonManifoldVertices || focus.category == DiagnosticCategory::holes || focus.category == DiagnosticCategory::fins) {
        const auto& surface = focus.side == ComparisonSide::a ? result.original : result.repaired;
        if (surface.topology.mode != comparison.settings.topologyMode
            || (focus.category == DiagnosticCategory::fins && surface.topology.inspection.finMaxAreaRatio != comparison.settings.topologyInspection.finMaxAreaRatio)
            || (focus.category == DiagnosticCategory::holes && surface.topology.inspection.holeSizeRatioTolerance != comparison.settings.topologyInspection.holeSizeRatioTolerance)) { return false; }
    }
    if (focus.category == DiagnosticCategory::selfIntersections) {
        const auto& surface = focus.side == ComparisonSide::a ? result.original : result.repaired;
        if (surface.intersections.phase != IntersectionPhase::complete || surface.intersections.mode != comparison.settings.topologyMode) { return false; }
    }
    if (focus.category == DiagnosticCategory::degenerateTriangles) {
        const auto& surface = focus.side == ComparisonSide::a ? result.original : result.repaired;
        if (!sameDegenerateThresholds(surface.degenerates.settings, comparison.settings.degenerates)) { return false; }
    }
    return true;
}
} // namespace

const DiagnosticEdge* focusedComparisonDiagnostic(const UiState& state,
    const MeshComparison& result, uint64_t resultSignature, SceneObjectId id, std::optional<uint64_t> geometrySignature)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison || !diagnosticFocusCurrent(state, *comparison, geometrySignature)
        || comparison->diagnosticFocus->signature != resultSignature) { return nullptr; }
    const auto& focus = *comparison->diagnosticFocus;
    if (comparisonDetectorStatus(result, focus.category).phase != IntersectionPhase::complete) { return nullptr; }
    if (!diagnosticResultSettingsCurrent(*comparison, result, focus)) { return nullptr; }
    const auto& edges = comparisonDiagnosticEdges(result, focus.side, focus.category);
    return focus.index < edges.size() ? &edges[focus.index] : nullptr;
}

void resetComparisonDiagnosticFocus(UiState& state, SceneObjectId id)
{
    if (auto* comparison = findComparison(state, id)) {
        comparison->diagnosticFocus.reset();
        comparison->pendingDiagnosticFocus.reset();
    }
}

void validateComparisonDiagnosticFocus(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, SceneObjectId id, std::optional<uint64_t> geometrySignature)
{
    if (auto* comparison = findComparison(state, id); comparison && comparison->pendingDiagnosticFocus) {
        const auto pending = *comparison->pendingDiagnosticFocus;
        if (!comparison->settings.enabled || pending.signature != (geometrySignature ? *geometrySignature : comparisonGeometrySignature(state, id))
            || pending.side != comparison->settings.diagnosticSide || pending.category != comparison->settings.diagnosticCategory) {
            resetComparisonDiagnosticFocus(state, id);
            return;
        }
        if (resultSignature != pending.signature
            || comparisonDetectorStatus(result, pending.category).phase != IntersectionPhase::complete
            || !diagnosticResultSettingsCurrent(*comparison, result, pending)) { return; }
        comparison->diagnosticFocus = pending;
        comparison->pendingDiagnosticFocus.reset();
    }
    if (!focusedComparisonDiagnostic(state, result, resultSignature, id, geometrySignature)) {
        resetComparisonDiagnosticFocus(state, id);
    }
}

void navigateComparisonDiagnostic(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, int step, SceneObjectId id)
{
    validateComparisonDiagnosticFocus(state, result, resultSignature, id);
    auto* comparison = findComparison(state, id);
    if (!comparison || !comparison->settings.enabled || resultSignature == 0
        || resultSignature != comparisonGeometrySignature(state, id)) { return; }
    const auto& settings = comparison->settings;
    if (comparisonDetectorStatus(result, settings.diagnosticCategory).phase != IntersectionPhase::complete) { return; }
    if (settings.diagnosticCategory == DiagnosticCategory::boundary || settings.diagnosticCategory == DiagnosticCategory::nonManifold || settings.diagnosticCategory == DiagnosticCategory::winding || settings.diagnosticCategory == DiagnosticCategory::nonManifoldVertices || settings.diagnosticCategory == DiagnosticCategory::holes || settings.diagnosticCategory == DiagnosticCategory::fins) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (surface.topology.mode != settings.topologyMode
            || (settings.diagnosticCategory == DiagnosticCategory::fins && surface.topology.inspection.finMaxAreaRatio != settings.topologyInspection.finMaxAreaRatio)
            || (settings.diagnosticCategory == DiagnosticCategory::holes && surface.topology.inspection.holeSizeRatioTolerance != settings.topologyInspection.holeSizeRatioTolerance)) { return; }
    }
    if (settings.diagnosticCategory == DiagnosticCategory::selfIntersections) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (surface.intersections.phase != IntersectionPhase::complete || surface.intersections.mode != settings.topologyMode) { return; }
    }
    if (settings.diagnosticCategory == DiagnosticCategory::degenerateTriangles) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (!sameDegenerateThresholds(surface.degenerates.settings, settings.degenerates)) { return; }
    }
    const auto& edges = comparisonDiagnosticEdges(result, settings.diagnosticSide, settings.diagnosticCategory);
    if (edges.empty()) { return; }
    size_t index = 0;
    if (comparison->diagnosticFocus && step != 0) {
        index = comparison->diagnosticFocus->index;
        if (step < 0) { index = index == 0 ? edges.size() - 1 : index - 1; }
        else { index = index + 1 == edges.size() ? 0 : index + 1; }
    } else if (step < 0) { index = edges.size() - 1; }
    selectComparisonDiagnostic(state, result, resultSignature, index, id);
}

void selectComparisonDiagnostic(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, size_t index, SceneObjectId id)
{
    auto* comparison = findComparison(state, id);
    if (!comparison || !comparison->settings.enabled || resultSignature == 0
        || resultSignature != comparisonGeometrySignature(state, id)) { return; }
    const auto& settings = comparison->settings;
    if (comparisonDetectorStatus(result, settings.diagnosticCategory).phase != IntersectionPhase::complete) { return; }
    if (settings.diagnosticCategory == DiagnosticCategory::boundary || settings.diagnosticCategory == DiagnosticCategory::nonManifold || settings.diagnosticCategory == DiagnosticCategory::winding || settings.diagnosticCategory == DiagnosticCategory::nonManifoldVertices || settings.diagnosticCategory == DiagnosticCategory::holes || settings.diagnosticCategory == DiagnosticCategory::fins) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (surface.topology.mode != settings.topologyMode
            || (settings.diagnosticCategory == DiagnosticCategory::fins && surface.topology.inspection.finMaxAreaRatio != settings.topologyInspection.finMaxAreaRatio)
            || (settings.diagnosticCategory == DiagnosticCategory::holes && surface.topology.inspection.holeSizeRatioTolerance != settings.topologyInspection.holeSizeRatioTolerance)) { return; }
    }
    if (settings.diagnosticCategory == DiagnosticCategory::selfIntersections) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (surface.intersections.phase != IntersectionPhase::complete || surface.intersections.mode != settings.topologyMode) { return; }
    }
    if (settings.diagnosticCategory == DiagnosticCategory::degenerateTriangles) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        if (!sameDegenerateThresholds(surface.degenerates.settings, settings.degenerates)) { return; }
    }
    const auto& edges = comparisonDiagnosticEdges(result, settings.diagnosticSide, settings.diagnosticCategory);
    if (index >= edges.size()) { return; }
    const auto& edge = edges[index];
    if (!finitePosition(edge.a) || !finitePosition(edge.b)) { return; }
    std::vector<Vertex> points(2);
    points[0].position = edge.a;
    points[1].position = edge.b;
    if (settings.diagnosticCategory == DiagnosticCategory::boundary || settings.diagnosticCategory == DiagnosticCategory::nonManifold || settings.diagnosticCategory == DiagnosticCategory::winding) {
        const auto& surface = settings.diagnosticSide == ComparisonSide::a ? result.original : result.repaired;
        const auto& topology = surface.topology;
        const auto& findings = settings.diagnosticCategory == DiagnosticCategory::boundary ? topology.boundaries
            : settings.diagnosticCategory == DiagnosticCategory::nonManifold ? topology.nonManifoldEdges : topology.windingEdges;
        if (index < findings.size()) {
            const auto& finding = findings[index];
            const auto& source = topology.sources[finding.source];
            for (const auto& use : source.edges[finding.edge].incidentFaces) {
                for (const auto vertex : source.geometry->faces[use.face].vertices) {
                    Vertex point;
                    const auto& position = source.geometry->vertices[vertex].position;
                    for (size_t k = 0; k < 3; ++k) { point.position[k] = static_cast<float>(position[k]); }
                    points.push_back(point);
                }
            }
        }
    }
    auto bounds = calculateBounds(points);
    // Frame the finding and its local context, independently of the full model's
    // size. Camera fitting adds its own margin on top of this small padding.
    bounds.radius *= 1.2f;
    if (bounds.min == bounds.max) {
        // Coincident points have no extent to fit; retain some model context.
        if (const auto resultBounds = comparisonDisplayBounds(state, id)) {
            bounds.radius = std::max(bounds.radius, resultBounds->radius * .06f);
        }
    }
    for (size_t k = 0; k < 3; ++k) {
        bounds.min[k] += comparison->translation[k];
        bounds.max[k] += comparison->translation[k];
        bounds.center[k] += comparison->translation[k];
    }
    comparison->pendingDiagnosticFocus.reset();
    comparison->diagnosticFocus = DiagnosticFocus{resultSignature, index, settings.diagnosticSide, settings.diagnosticCategory};
    auto camera = frameCameraBounds(bounds, state.upAxis);
    // The default near plane otherwise forces tiny findings far from the eye.
    camera.nearPlane = std::min(camera.nearPlane, bounds.radius * 0.1f);
    state.camera = fitCameraBounds(camera, bounds);
}

ComparisonMembershipAction comparisonMembershipAction(
    const UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, SceneObjectId id)
{
    const auto parts = comparisonObjectParts(state, objects);
    if (parts.empty()) { return ComparisonMembershipAction::unavailable; }
    for (const auto part : parts) {
        if (!comparisonContains(state, part, side, id)) { return ComparisonMembershipAction::add; }
    }
    return ComparisonMembershipAction::remove;
}

bool canCompareGroups(const UiState& state, SceneObjectId id)
{
    return enabledComparisonPartCount(state, ComparisonSide::a, id) != 0
        && enabledComparisonPartCount(state, ComparisonSide::b, id) != 0 && !hasEnabledMissingComparisonParts(state, id);
}

bool canCompareSceneSelection(const UiState& state)
{
    const auto& selection = state.selectedSceneObjects;
    return (selection.size() == 1 || (selection.size() == 2 && selection[0] != selection[1]))
        && std::all_of(selection.begin(), selection.end(), [&](SceneObjectId object) {
            return !comparisonObjectParts(state, {object}).empty();
        });
}

bool canInspectComparison(const UiState& state, SceneObjectId id)
{
    return (enabledComparisonPartCount(state, ComparisonSide::a, id) != 0
        || enabledComparisonPartCount(state, ComparisonSide::b, id) != 0) && !hasEnabledMissingComparisonParts(state, id);
}

ComparisonSettings effectiveComparisonSettings(const UiState& state, SceneObjectId id)
{
    if (isUvAnalysis(comparisonSettings(state, id).type)) { return comparisonSettings(state, id); }
    if (const auto* comparison = findComparison(state, id); comparison && diagnosticFocusCurrent(state, *comparison)) {
        return effectiveComparisonSettings(state, id, false, false, comparison->diagnosticFocus->signature);
    }
    return effectiveComparisonSettings(state, id,
        enabledComparisonPartCount(state, ComparisonSide::a, id) != 0,
        enabledComparisonPartCount(state, ComparisonSide::b, id) != 0, 0);
}

ComparisonSettings effectiveComparisonSettings(const UiState& state, SceneObjectId id,
    bool hasA, bool hasB, uint64_t geometrySignature)
{
    if (isUvAnalysis(comparisonSettings(state, id).type)) { return comparisonSettings(state, id); }
    if (const auto* comparison = findComparison(state, id); comparison && diagnosticFocusCurrent(state, *comparison, geometrySignature)) {
        auto settings = comparison->settings;
        settings.mode = settings.diagnosticSide == ComparisonSide::a ? ComparisonMode::original : ComparisonMode::repaired;
        return settings;
    }
    auto settings = comparisonSettings(state, id);
    if (settings.mode == ComparisonMode::surfaceQuality) {
        if (!hasB && hasA) { settings.quality.onOriginal = true; }
        if (!hasA && hasB) { settings.quality.onOriginal = false; }
    } else {
        if (!hasB && hasA) { settings.mode = ComparisonMode::original; }
        if (!hasA && hasB) { settings.mode = ComparisonMode::repaired; }
    }
    return settings;
}

bool compareSceneSelection(UiState& state, AnalysisType type)
{
    if (!canCompareSceneSelection(state)) { return false; }
    const auto selection = state.selectedSceneObjects;
    const auto id = createComparison(state, type);
    setComparisonObjects(state, isUvAnalysis(type) ? selection : std::vector<SceneObjectId>{selection[0]}, ComparisonSide::a, true, id);
    if (!isUvAnalysis(type) && selection.size() == 2) { setComparisonObjects(state, {selection[1]}, ComparisonSide::b, true, id); }
    frameCameraToScene(state);
    return true;
}

void requestComparisonIntersections(UiState& state, SceneObjectId id, bool cancel)
{
    if (auto* comparison = findComparison(state, id)) {
        ++comparison->intersectionRequestRevision;
        comparison->cancelIntersections = cancel;
        if (comparison->diagnosticFocus && comparison->diagnosticFocus->category == DiagnosticCategory::selfIntersections) {
            comparison->diagnosticFocus.reset();
        }
    }
}
void requestDifferenceMesh(UiState& state, SceneObjectId id, bool cancel)
{
    auto* item = findComparison(state, id);
    if (!item || isUvAnalysis(item->settings.type)) { throw std::invalid_argument("Difference mesh requires a mesh comparison."); }
    if (!cancel && (!enabledComparisonPartCount(state, ComparisonSide::a, id) || !enabledComparisonPartCount(state, ComparisonSide::b, id))) {
        throw std::invalid_argument("Difference mesh needs populated inputs A and B.");
    }
    if (!cancel) {
        auto settings = item->settings; settings.difference.created = true; settings.difference.visible = true; settings.enabled = true;
        setComparisonSettings(state, settings, id);
    }
    item = findComparison(state, id); ++item->differenceRequest.revision; item->differenceRequest.cancel = cancel;
}

void requestComparisonDetector(UiState& state, SceneObjectId id, DiagnosticCategory category, bool cancel)
{
    if (category == DiagnosticCategory::selfIntersections) { requestComparisonIntersections(state, id, cancel); return; }
    const auto index = static_cast<size_t>(category);
    if (index >= backgroundDetectorCount) { return; }
    if (auto* comparison = findComparison(state, id)) {
        auto& request = comparison->detectorRequests[index];
        ++request.revision; request.cancel = cancel;
        if (comparison->diagnosticFocus && comparison->diagnosticFocus->category == category) { comparison->diagnosticFocus.reset(); }
    }
}

void setComparisonAutomaticUpdate(UiState& state, SceneObjectId id, DiagnosticCategory category, bool automatic)
{
    if (static_cast<size_t>(category) >= diagnosticCategoryCount || !findComparison(state, id)) { return; }
    auto settings = comparisonSettings(state, id);
    if (diagnosticAutoUpdate(settings, category) == automatic) { return; }
    setDiagnosticAutoUpdate(settings, category, automatic);
    setComparisonSettings(state, settings, id);
}

size_t countVisibleComparisonDiagnostics(const ComparisonSettings& settings)
{
    const std::array visibility = {
        settings.showBoundaries, settings.showNonManifold, settings.showWinding,
        settings.duplicates.showPoints, settings.duplicates.showTriangles, settings.degenerates.show,
        settings.topologyInspection.showNonManifoldVertices, settings.topologyInspection.showHoles,
        settings.topologyInspection.showFins, settings.intersections.show
    };
    return static_cast<size_t>(std::count(visibility.begin(), visibility.end(), true));
}

void setComparisonDiagnosticsVisible(UiState& state, bool visible, SceneObjectId id)
{
    const auto* comparison = findComparison(state, id);
    if (!comparison) { return; }
    auto settings = comparison->settings;
    settings.showBoundaries = visible;
    settings.showNonManifold = visible;
    settings.showWinding = visible;
    settings.duplicates.showPoints = visible;
    settings.duplicates.showTriangles = visible;
    settings.degenerates.show = visible;
    settings.topologyInspection.showNonManifoldVertices = visible;
    settings.topologyInspection.showHoles = visible;
    settings.topologyInspection.showFins = visible;
    settings.intersections.show = visible;
    if (!visible) { resetComparisonDiagnosticFocus(state, id); }
    if (settings != comparison->settings) { setComparisonSettings(state, settings, id); }
}

void setComparisonSettings(UiState& state, ComparisonSettings settings, SceneObjectId id)
{
    if (auto* comparison = findComparison(state, id)) {
        settings = normalizedComparisonSettings(settings);
        const auto before = comparison->settings;
        if (settings == before) { return; }
        // Detector readiness/scheduling reads settings live. Only these inputs
        // change source resolution or the geometry/preparation signatures.
        const auto uvInputs = [](const ComparisonSettings& value) {
            return std::tie(value.uvView, value.uvSeparated, value.uvMetric, value.uvNormalization,
                value.uvOverlapEnabled, value.uvOverlapScope, value.uvThresholdEnabled, value.uvThreshold,
                value.uvNearCollapse, value.uvRangeEnabled, value.uvRangeMinimum, value.uvRangeMaximum);
        };
        const bool inputsChanged = before.type != settings.type || before.task != settings.task
            || before.analysisMode != settings.analysisMode
            || ((isUvAnalysis(before.type) || isUvAnalysis(settings.type)) && uvInputs(before) != uvInputs(settings));
        const bool wasEnabled = comparison->settings.enabled;
        if (settings.intersections.limits != comparison->settings.intersections.limits
            || settings.diagnosticSide != comparison->settings.diagnosticSide || settings.diagnosticCategory != comparison->settings.diagnosticCategory
            || normalizedTopologyMode(settings.topologyMode) != comparison->settings.topologyMode
            || settings.analysisMode != comparison->settings.analysisMode
            || normalizedTopologyInspectionSettings(settings.topologyInspection).finMaxAreaRatio != comparison->settings.topologyInspection.finMaxAreaRatio
            || normalizedTopologyInspectionSettings(settings.topologyInspection).holeSizeRatioTolerance != comparison->settings.topologyInspection.holeSizeRatioTolerance
            || !sameDegenerateThresholds(normalizedDegenerateSettings(settings.degenerates), comparison->settings.degenerates)) {
            resetComparisonDiagnosticFocus(state, id);
        }
        comparison->settings = settings;
        normalizeAnalysisSources(state, comparison->objectId);
        if (comparison->settings.enabled && !wasEnabled) { setPropertiesPaneVisible(state, true); }
        recalculateSceneBounds(state);
        if (!settings.enabled) {
            resetComparisonDiagnosticFocus(state, id);
            comparison->uvFindingFocus.reset();
        }
        markSceneDirty(state, SceneChange::presentation | (inputsChanged ? SceneChange::analysis : SceneChange::none));
    }
}

void setPropertiesPaneVisible(UiState& state, bool visible)
{
    state.propertiesPaneVisible = visible;
}

bool setModelAnalysisMode(UiState& state, SceneObjectId id, AnalysisMode mode)
{
    if (mode != AnalysisMode::perVolume && mode != AnalysisMode::whole) { return false; }
    for (auto& file : state.files) {
        if (file.objectId != id || id == invalidSceneObjectId) { continue; }
        if (file.fileSettings.analysisMode != mode) {
            file.fileSettings.analysisMode = mode;
            markSceneDirty(state, SceneChange::analysis);
        }
        return true;
    }
    return false;
}

void setScreenshotSettings(UiState& state, ScreenshotSettings settings)
{
    state.screenshotSettings = normalizedScreenshotSettings(settings);
}

void setComparisonObjects(UiState& state, const std::vector<SceneObjectId>& objects, ComparisonSide side, bool member,
    SceneObjectId id)
{
    const auto parts = comparisonObjectParts(state, objects);
    if (parts.empty()) { return; }
    if (!findComparison(state, id) && member && id == invalidSceneObjectId) {
        const auto selection = state.selectedSceneObjects;
        id = createComparison(state);
        state.selectedSceneObjects = selection;
    }
    auto* comparison = findComparison(state, id);
    if (!comparison) { return; }
    if (isUvAnalysis(comparison->settings.type) && side == ComparisonSide::b) { return; }
    if (isSingleSourceMeshTask(comparison->settings.task)) { side = ComparisonSide::a; }
    auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
    if (member) {
        const auto existing = comparisonMemberIds(state, side, comparison->objectId, false);
        const auto objectsByOrder = sceneObjects(state);
        boost::unordered_flat_map<SceneObjectId, const SceneObjectInfo*> objectLookup;
        objectLookup.reserve(objectsByOrder.size());
        for (const auto& object : objectsByOrder) { objectLookup.emplace(object.id, &object); }
        for (const auto part : parts) {
            if (std::binary_search(existing.begin(), existing.end(), part)) { continue; }
            const auto info = objectLookup.find(part);
            const auto file = info == objectLookup.end() ? objectLookup.end() : objectLookup.find(info->second->fileId);
            members.push_back({part, (file != objectLookup.end() ? file->second->name + " / " : "")
                + (info != objectLookup.end() ? info->second->name : "Missing part")});
        }
    } else {
        std::erase_if(members, [&](const UiComparisonPart& entry) {
            return std::binary_search(parts.begin(), parts.end(), entry.objectId);
        });
    }
    if (member) { setPropertiesPaneVisible(state, true); }
    normalizeAnalysisSources(state, comparison->objectId);
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::analysis);
}

void removeMissingComparisonParts(UiState& state, ComparisonSide side, SceneObjectId id)
{
    if (auto* comparison = findComparison(state, id)) {
        if (isSingleSourceMeshTask(comparison->settings.task)) { side = ComparisonSide::a; }
        auto& members = side == ComparisonSide::a ? comparison->a : comparison->b;
        const auto available = comparableScenePartIds(state);
        std::erase_if(members, [&](const UiComparisonPart& part) {
            return !std::binary_search(available.begin(), available.end(), part.objectId)
                && comparisonObjectParts(state, {part.objectId}).empty();
        });
        normalizeAnalysisSources(state, comparison->objectId);
        recalculateSceneBounds(state);
        markSceneDirty(state, SceneChange::analysis);
    }
}

void clearComparisonGroup(UiState& state, ComparisonSide side, SceneObjectId id)
{
    if (auto* comparison = findComparison(state, id)) {
        if (isSingleSourceMeshTask(comparison->settings.task)) { side = ComparisonSide::a; }
        (side == ComparisonSide::a ? comparison->a : comparison->b).clear();
        normalizeAnalysisSources(state, comparison->objectId);
        recalculateSceneBounds(state);
        markSceneDirty(state, SceneChange::analysis);
    }
}

void swapComparisonGroups(UiState& state, SceneObjectId id)
{
    if (auto* comparison = findComparison(state, id)) {
        if (isUvAnalysis(comparison->settings.type) || isSingleSourceMeshTask(comparison->settings.task)) { return; }
        std::swap(comparison->a, comparison->b);
        normalizeAnalysisSources(state, comparison->objectId);
        recalculateSceneBounds(state);
        markSceneDirty(state, SceneChange::analysis);
    }
}

void frameComparisonBounds(UiState& state, const Bounds& bounds)
{
    if (!finitePosition(bounds.min) || !finitePosition(bounds.max)) {
        return;
    }
    state.camera = frameCameraBounds(bounds, state.upAxis);
}

namespace {

float finiteOr(float value, float fallback)
{
    return std::isfinite(value) ? value : fallback;
}

float clampFinite(float value, float minValue, float maxValue, float fallback)
{
    return std::clamp(finiteOr(value, fallback), minValue, maxValue);
}

std::array<float, 3> finiteArrayOrZero(const std::array<float, 3>& value)
{
    return {
        finiteOr(value[0], 0.0f),
        finiteOr(value[1], 0.0f),
        finiteOr(value[2], 0.0f),
    };
}

std::array<float, 3> clampFiniteArray(
    const std::array<float, 3>& value,
    float minValue,
    float maxValue)
{
    return {
        clampFinite(value[0], minValue, maxValue, 0.0f),
        clampFinite(value[1], minValue, maxValue, 0.0f),
        clampFinite(value[2], minValue, maxValue, 0.0f),
    };
}

bool validFileIndex(const UiState& state, size_t fileIndex)
{
    return fileIndex != invalidSceneNodeIndex && fileIndex < state.files.size();
}

bool validGroupIndex(const UiState& state, size_t fileIndex, size_t groupIndex)
{
    return validFileIndex(state, fileIndex)
        && groupIndex != invalidSceneNodeIndex
        && groupIndex < state.files[fileIndex].groupSettings.size();
}

bool pruneRemovedFile(UiSceneNode& node, size_t removedFileIndex)
{
    if ((node.kind == UiSceneNodeKind::file || node.kind == UiSceneNodeKind::group)
        && node.fileIndex == removedFileIndex) {
        return false;
    }

    if ((node.kind == UiSceneNodeKind::file || node.kind == UiSceneNodeKind::group)
        && node.fileIndex != invalidSceneNodeIndex
        && node.fileIndex > removedFileIndex) {
        --node.fileIndex;
    }

    node.children.erase(
        std::remove_if(
            node.children.begin(),
            node.children.end(),
            [removedFileIndex](UiSceneNode& child) {
                return !pruneRemovedFile(child, removedFileIndex);
            }),
        node.children.end());

    return node.kind != UiSceneNodeKind::folder || !node.children.empty();
}

bool setFolderNodesVisible(UiSceneNode& node, bool visible)
{
    bool changed = false;
    if (node.kind == UiSceneNodeKind::folder) {
        changed = node.settings.visible != visible;
        node.settings.visible = visible;
    }

    for (auto& child : node.children) {
        changed = setFolderNodesVisible(child, visible) || changed;
    }
    return changed;
}

UiSceneNode& ensureFolderSceneNode(
    std::vector<UiSceneNode>& nodes,
    const std::string& name)
{
    const auto found = std::find_if(
        nodes.begin(),
        nodes.end(),
        [&name](const UiSceneNode& node) {
            return node.kind == UiSceneNodeKind::folder && node.name == name;
        });
    if (found != nodes.end()) {
        return *found;
    }

    UiSceneNode folder;
    folder.kind = UiSceneNodeKind::folder;
    folder.name = name;
    nodes.push_back(std::move(folder));
    return nodes.back();
}

std::string folderDisplayName(const std::filesystem::path& path)
{
    const std::string filename = pathToUtf8(path.filename());
    if (!filename.empty()) {
        return filename;
    }

    return pathToUtf8(path);
}

} // namespace

size_t totalGroupCount(const std::vector<UiFileState>& files)
{
    size_t groupCount = 0;
    for (const auto& file : files) {
        groupCount += file.groupSettings.size();
    }

    return groupCount;
}

size_t totalGroupCount(const UiState& state)
{
    return totalGroupCount(state.files);
}

size_t countVisibleGroups(const std::vector<UiGroupState>& groups)
{
    size_t visibleCount = 0;
    for (const auto& group : groups) {
        if (group.visible) {
            ++visibleCount;
        }
    }

    return visibleCount;
}

size_t countVisibleFileGroups(const UiFileState& file)
{
    if (!file.fileSettings.visible) {
        return 0u;
    }

    return countVisibleGroups(file.groupSettings);
}

size_t countVisibleSceneGroups(const UiState& state)
{
    if (!state.sceneNodes.empty()) {
        size_t visibleCount = 0;
        for (const auto& node : state.sceneNodes) {
            visibleCount += countVisibleSceneNodeGroups(state, node);
        }
        return visibleCount;
    }

    size_t visibleCount = 0;
    for (const auto& file : state.files) {
        visibleCount += countVisibleFileGroups(file);
    }

    return visibleCount;
}

size_t countSceneNodeGroups(const UiState& state, const UiSceneNode& node)
{
    if (node.kind == UiSceneNodeKind::group) {
        return validGroupIndex(state, node.fileIndex, node.groupIndex) ? 1u : 0u;
    }

    if (node.kind == UiSceneNodeKind::file
        && validFileIndex(state, node.fileIndex)
        && node.children.empty()) {
        return state.files[node.fileIndex].groupSettings.size();
    }

    size_t groupCount = 0;
    for (const auto& child : node.children) {
        groupCount += countSceneNodeGroups(state, child);
    }
    return groupCount;
}

size_t countVisibleSceneNodeGroups(const UiState& state, const UiSceneNode& node)
{
    if (node.kind == UiSceneNodeKind::folder && !node.settings.visible) {
        return 0u;
    }

    if (node.kind == UiSceneNodeKind::group) {
        if (!validGroupIndex(state, node.fileIndex, node.groupIndex)) {
            return 0u;
        }
        const auto& file = state.files[node.fileIndex];
        return file.fileSettings.visible && file.groupSettings[node.groupIndex].visible ? 1u : 0u;
    }

    if (node.kind == UiSceneNodeKind::file) {
        if (!validFileIndex(state, node.fileIndex)) {
            return 0u;
        }
        const auto& file = state.files[node.fileIndex];
        if (!file.fileSettings.visible) {
            return 0u;
        }
        if (node.children.empty()) {
            return countVisibleFileGroups(file);
        }
    }

    size_t visibleCount = 0;
    for (const auto& child : node.children) {
        visibleCount += countVisibleSceneNodeGroups(state, child);
    }
    return visibleCount;
}

size_t countEnabledGroupRenderMode(const std::vector<UiGroupState>& groups, UiRenderMode mode)
{
    size_t enabledCount = 0;
    for (const auto& group : groups) {
        if (groupRenderModeEnabled(group, mode)) {
            ++enabledCount;
        }
    }

    return enabledCount;
}

size_t countEnabledSceneRenderMode(const UiState& state, UiRenderMode mode)
{
    if (!state.sceneNodes.empty()) {
        size_t enabledCount = 0;
        for (const auto& node : state.sceneNodes) {
            enabledCount += countEnabledSceneNodeRenderMode(state, node, mode);
        }
        return enabledCount;
    }

    size_t enabledCount = 0;
    for (const auto& file : state.files) {
        enabledCount += countEnabledGroupRenderMode(file.groupSettings, mode);
    }

    return enabledCount;
}

size_t countEnabledSceneNodeRenderMode(
    const UiState& state,
    const UiSceneNode& node,
    UiRenderMode mode)
{
    if (node.kind == UiSceneNodeKind::group) {
        if (!validGroupIndex(state, node.fileIndex, node.groupIndex)) {
            return 0u;
        }
        return groupRenderModeEnabled(state.files[node.fileIndex].groupSettings[node.groupIndex], mode) ? 1u : 0u;
    }

    if (node.kind == UiSceneNodeKind::file
        && validFileIndex(state, node.fileIndex)
        && node.children.empty()) {
        return countEnabledGroupRenderMode(state.files[node.fileIndex].groupSettings, mode);
    }

    size_t enabledCount = 0;
    for (const auto& child : node.children) {
        enabledCount += countEnabledSceneNodeRenderMode(state, child, mode);
    }
    return enabledCount;
}

bool groupRenderModeEnabled(const UiGroupState& group, UiRenderMode mode)
{
    switch (mode) {
    case UiRenderMode::solidMesh:
        return group.showSolidMesh;
    case UiRenderMode::triangles:
        return group.showTriangles;
    case UiRenderMode::vertices:
        return group.showVertices;
    }

    return false;
}

void setGroupRenderMode(UiGroupState& group, UiRenderMode mode, bool enabled)
{
    switch (mode) {
    case UiRenderMode::solidMesh:
        group.showSolidMesh = enabled;
        break;
    case UiRenderMode::triangles:
        group.showTriangles = enabled;
        break;
    case UiRenderMode::vertices:
        group.showVertices = enabled;
        break;
    }
}

void toggleGroupRenderMode(UiGroupState& group, UiRenderMode mode)
{
    setGroupRenderMode(group, mode, !groupRenderModeEnabled(group, mode));
}

void setAllGroupRenderModes(std::vector<UiGroupState>& groups, UiRenderMode mode, bool enabled)
{
    for (auto& group : groups) {
        setGroupRenderMode(group, mode, enabled);
    }
}

void setUiScale(UiState& state, float scale)
{
    state.uiScale = std::clamp(finiteOr(scale, 1.0f), 1.0f, 2.0f);
}

void setAllSceneRenderModes(UiState& state, UiRenderMode mode, bool enabled)
{
    if (mode == UiRenderMode::vertices && !scenePostLoadReady(state)) { return; }
    bool changed = false;
    for (auto& file : state.files) {
        for (const auto& group : file.groupSettings) {
            changed = changed || groupRenderModeEnabled(group, mode) != enabled;
        }
        setAllGroupRenderModes(file.groupSettings, mode, enabled);
    }
    if (changed) {
        markSceneDirty(state, SceneChange::appearance | SceneChange::visibility);
    }
}

void setSceneNodeSubtreeRenderMode(
    UiState& state,
    UiSceneNode& node,
    UiRenderMode mode,
    bool enabled)
{
    notifySceneEdit(state, SceneChange::appearance | SceneChange::visibility);
    if (node.kind == UiSceneNodeKind::group) {
        if (validGroupIndex(state, node.fileIndex, node.groupIndex)) {
            setGroupRenderMode(state.files[node.fileIndex].groupSettings[node.groupIndex], mode, enabled);
        }
        return;
    }

    if (node.kind == UiSceneNodeKind::file
        && validFileIndex(state, node.fileIndex)
        && node.children.empty()) {
        setAllGroupRenderModes(state.files[node.fileIndex].groupSettings, mode, enabled);
        return;
    }

    for (auto& child : node.children) {
        setSceneNodeSubtreeRenderMode(state, child, mode, enabled);
    }
}

void setFileVisible(UiFileState& file, bool visible)
{
    file.fileSettings.visible = visible;
    for (auto& group : file.groupSettings) {
        group.visible = visible;
    }
}

void toggleFileVisible(UiFileState& file)
{
    setFileVisible(file, countVisibleFileGroups(file) != file.groupSettings.size());
}

static bool setAllModelVisibility(UiState& state, bool visible)
{
    bool changed = false;
    for (auto& node : state.sceneNodes) {
        changed = setFolderNodesVisible(node, visible) || changed;
    }
    for (auto& file : state.files) {
        changed = changed || file.fileSettings.visible != visible;
        for (const auto& group : file.groupSettings) {
            changed = changed || group.visible != visible;
        }
        setFileVisible(file, visible);
    }
    refreshSceneTreeFolderVisibility(state);
    return changed;
}

static bool setAllComparisonVisibility(UiState& state, bool visible)
{
    bool changed = false;
    for (auto& comparison : state.comparisons) {
        changed = changed || comparison.settings.enabled != visible;
        comparison.settings.enabled = visible;
        if (!visible) {
            comparison.diagnosticFocus.reset();
            comparison.pendingDiagnosticFocus.reset();
            comparison.uvFindingFocus.reset();
        }
    }
    return changed;
}

void setAllModelsVisible(UiState& state, bool visible)
{
    if (!setAllModelVisibility(state, visible)) { return; }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::visibility);
}

void setAllComparisonsVisible(UiState& state, bool visible)
{
    if (!setAllComparisonVisibility(state, visible)) { return; }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::visibility);
}

void setAllSceneVisible(UiState& state, bool visible)
{
    const bool modelsChanged = setAllModelVisibility(state, visible);
    const bool comparisonsChanged = setAllComparisonVisibility(state, visible);
    if (!modelsChanged && !comparisonsChanged) { return; }
    recalculateSceneBounds(state);
    markSceneDirty(state, SceneChange::visibility);
}

static void setSceneNodeSubtreeVisibleRecursive(UiState& state, UiSceneNode& node, bool visible)
{
    if (node.kind == UiSceneNodeKind::folder) {
        node.settings.visible = visible;
    } else if (node.kind == UiSceneNodeKind::file) {
        if (validFileIndex(state, node.fileIndex)) {
            setFileVisible(state.files[node.fileIndex], visible);
        }
    } else if (validGroupIndex(state, node.fileIndex, node.groupIndex)) {
        auto& file = state.files[node.fileIndex];
        setGroupVisible(file, file.groupSettings[node.groupIndex], visible);
    }

    for (auto& child : node.children) {
        setSceneNodeSubtreeVisibleRecursive(state, child, visible);
    }
}

void setSceneNodeSubtreeVisible(UiState& state, UiSceneNode& node, bool visible)
{
    setSceneNodeSubtreeVisibleRecursive(state, node, visible);
    refreshSceneTreeFolderVisibility(state);
    notifySceneEdit(state, SceneChange::visibility);
}

void setGroupVisible(UiGroupState& group, bool visible)
{
    group.visible = visible;
}

void toggleGroupVisible(UiGroupState& group)
{
    setGroupVisible(group, !group.visible);
}

void setGroupVisible(UiFileState& file, UiGroupState& group, bool visible)
{
    setGroupVisible(group, visible);
    if (visible) {
        file.fileSettings.visible = true;
        return;
    }

    if (countVisibleGroups(file.groupSettings) == 0u) {
        file.fileSettings.visible = false;
    }
}

void toggleGroupVisible(UiFileState& file, UiGroupState& group)
{
    setGroupVisible(file, group, !group.visible);
}

void setGroupVisible(UiState& state, UiFileState& file, UiGroupState& group, bool visible)
{
    setGroupVisible(file, group, visible);
    refreshSceneTreeFolderVisibility(state);
    notifySceneEdit(state, SceneChange::visibility);
}

void toggleGroupVisible(UiState& state, UiFileState& file, UiGroupState& group)
{
    setGroupVisible(state, file, group, !group.visible);
}

void setShowOrigin(UiState& state, bool visible)
{
    if (state.showOrigin != visible) {
        state.showOrigin = visible;
        markSceneDirty(state, SceneChange::appearance);
    }
}

void toggleShowOrigin(UiState& state)
{
    setShowOrigin(state, !state.showOrigin);
}

void setShowGrid(UiState& state, bool visible)
{
    if (state.showGrid != visible) {
        state.showGrid = visible;
        markSceneDirty(state, SceneChange::appearance);
    }
}

void setAdaptivePoints(UiState& state, bool enabled)
{
    if (state.adaptivePoints != enabled) {
        state.adaptivePoints = enabled;
        markSceneDirty(state, SceneChange::appearance);
    }
}

void setTriangleEdgeXray(UiState& state, bool enabled)
{
    if (state.triangleEdgeXray != enabled) {
        state.triangleEdgeXray = enabled;
        markSceneDirty(state, SceneChange::appearance | SceneChange::picking);
    }
}

void toggleShowGrid(UiState& state)
{
    setShowGrid(state, !state.showGrid);
}

void setShowDimensions(UiState& state, bool visible)
{
    if (state.showDimensions != visible) {
        state.showDimensions = visible;
        markSceneDirty(state, SceneChange::appearance);
    }
}

void setSceneUpAxis(UiState& state, SceneUpAxis upAxis)
{
    if (state.upAxis != upAxis) {
        state.upAxis = upAxis;
        recalculateSceneBounds(state);
        frameCameraToScene(state);
        markSceneDirty(state, SceneChange::presentation);
    }
}

void toggleSceneUpAxis(UiState& state)
{
    setSceneUpAxis(
        state,
        state.upAxis == SceneUpAxis::z ? SceneUpAxis::y : SceneUpAxis::z);
}

void setMasterVertexPointSize(UiState& state, float value)
{
    const float clampedValue = clampFinite(
        value,
        minVertexPointSize,
        maxVertexPointSize,
        defaultMasterVertexPointSize);
    if (state.masterVertexPointSize != clampedValue) {
        state.masterVertexPointSize = clampedValue;
        markSceneDirty(state, SceneChange::appearance | SceneChange::picking);
    }
}

void setFileVertexSizeScale(UiFileState& file, float value)
{
    file.vertexSizeScale = clampFinite(value, minVertexSizeScale, maxVertexSizeScale, 1.0f);
}

void setGroupVertexSizeScale(UiGroupState& group, float value)
{
    group.vertexSizeScale = clampFinite(value, minVertexSizeScale, maxVertexSizeScale, 1.0f);
}

void setFileTranslation(UiFileSettings& settings, const std::array<float, 3>& value)
{
    settings.translation = finiteArrayOrZero(value);
}

void setSceneNodeTranslation(UiSceneNodeSettings& settings, const std::array<float, 3>& value)
{
    settings.translation = finiteArrayOrZero(value);
}

void setGroupTranslation(UiGroupState& group, const std::array<float, 3>& value)
{
    group.translation = finiteArrayOrZero(value);
}

void setFileRotationDegrees(UiFileSettings& settings, const std::array<float, 3>& value)
{
    settings.rotationDegrees = clampFiniteArray(value, minRotationDegrees, maxRotationDegrees);
}

void setSceneNodeRotationDegrees(UiSceneNodeSettings& settings, const std::array<float, 3>& value)
{
    settings.rotationDegrees = clampFiniteArray(value, minRotationDegrees, maxRotationDegrees);
}

void setGroupRotationDegrees(UiGroupState& group, const std::array<float, 3>& value)
{
    group.rotationDegrees = clampFiniteArray(value, minRotationDegrees, maxRotationDegrees);
}

void setFileScale(UiFileSettings& settings, float value)
{
    settings.scale = clampFinite(value, minGroupScale, maxGroupScale, 1.0f);
}

void setSceneNodeScale(UiSceneNodeSettings& settings, float value)
{
    settings.scale = clampFinite(value, minGroupScale, maxGroupScale, 1.0f);
}

void setGroupScale(UiGroupState& group, float value)
{
    group.scale = clampFinite(value, minGroupScale, maxGroupScale, 1.0f);
}

void setFileOpacity(UiFileSettings& settings, float value)
{
    settings.opacity = clampFinite(value, minGroupOpacity, maxGroupOpacity, 1.0f);
}

void setSceneNodeOpacity(UiSceneNodeSettings& settings, float value)
{
    settings.opacity = clampFinite(value, minGroupOpacity, maxGroupOpacity, 1.0f);
}

void setGroupOpacity(UiGroupState& group, float value)
{
    group.opacity = clampFinite(value, minGroupOpacity, maxGroupOpacity, 1.0f);
}

void setGroupColor(UiGroupState& group, const std::array<float, 4>& value)
{
    group.color = {
        clampFinite(value[0], 0.0f, 1.0f, 1.0f),
        clampFinite(value[1], 0.0f, 1.0f, 1.0f),
        clampFinite(value[2], 0.0f, 1.0f, 1.0f),
        clampFinite(value[3], 0.0f, 1.0f, 1.0f),
    };
}

void resetGroupColor(UiGroupState& group, size_t colorIndex)
{
    group.color = defaultGroupColor(colorIndex);
}

void resetGroupTransform(UiGroupState& group)
{
    group.scale = 1.0f;
    group.opacity = 1.0f;
    group.translation = {};
    group.rotationDegrees = {};
}

void resetFileTransform(UiFileSettings& settings)
{
    settings.scale = 1.0f;
    settings.opacity = 1.0f;
    settings.translation = {};
    settings.rotationDegrees = {};
}

void resetSceneNodeTransform(UiSceneNodeSettings& settings)
{
    settings.scale = 1.0f;
    settings.opacity = 1.0f;
    settings.translation = {};
    settings.rotationDegrees = {};
}

bool groupTransformIsDefault(const UiGroupState& group)
{
    return group.scale == 1.0f
        && group.opacity == 1.0f
        && group.translation == std::array<float, 3>{}
        && group.rotationDegrees == std::array<float, 3>{};
}

bool fileTransformIsDefault(const UiFileSettings& settings)
{
    return settings.scale == 1.0f
        && settings.opacity == 1.0f
        && settings.translation == std::array<float, 3>{}
        && settings.rotationDegrees == std::array<float, 3>{};
}

bool sceneNodeTransformIsDefault(const UiSceneNodeSettings& settings)
{
    return settings.scale == 1.0f
        && settings.opacity == 1.0f
        && settings.translation == std::array<float, 3>{}
        && settings.rotationDegrees == std::array<float, 3>{};
}

void recalculateSceneBounds(UiState& state)
{
    synchronizeCoordinateFrames(state);
    state.sceneBounds = combineBounds(state.files, state.sceneNodes);
    if (state.comparisons.empty()) { return; }
    std::vector<Vertex> corners;
    if (countVisibleSceneGroups(state) != 0) {
        corners.resize(2);
        corners[0].position = state.sceneBounds.min;
        corners[1].position = state.sceneBounds.max;
    }
    bool hasComparisonBounds = false;
    for (const auto& comparison : state.comparisons) {
        if (!comparison.settings.enabled) { continue; }
        if (const auto bounds = comparisonDisplayBounds(state, comparison.objectId)) {
            hasComparisonBounds = true;
            Vertex first, last;
            first.position = bounds->min;
            last.position = bounds->max;
            corners.push_back(first);
            corners.push_back(last);
        }
    }
    if (hasComparisonBounds) { state.sceneBounds = calculateBounds(corners); }
}

void frameCameraToScene(UiState& state)
{
    state.camera = frameCameraBounds(state.sceneBounds, state.upAxis);
}

void setCameraView(UiState& state, CameraView view)
{
    state.camera = cameraWithView(state.camera, view);
}

void fitCameraToScene(UiState& state)
{
    state.camera = fitCameraBounds(state.camera, state.sceneBounds);
}

void fitCameraToSelection(UiState& state)
{
    if (const auto bounds = selectedSceneBounds(state)) {
        state.camera = fitCameraBounds(state.camera, *bounds);
    }
}

void appendFolderTreeSceneNode(
    UiState& state,
    const std::filesystem::path& root,
    size_t firstFileIndex,
    size_t fileCount)
{
    UiSceneNode rootNode;
    rootNode.kind = UiSceneNodeKind::folder;
    rootNode.name = folderDisplayName(root);

    const std::filesystem::path absoluteRoot = std::filesystem::absolute(root).lexically_normal();
    for (size_t offset = 0; offset < fileCount; ++offset) {
        const size_t fileIndex = firstFileIndex + offset;
        if (fileIndex >= state.files.size()) {
            break;
        }

        const std::filesystem::path absoluteFile =
            std::filesystem::absolute(state.files[fileIndex].path).lexically_normal();
        std::filesystem::path relativePath = absoluteFile.lexically_relative(absoluteRoot);
        if (relativePath.empty()) {
            relativePath = absoluteFile.filename();
        }

        std::vector<UiSceneNode>* children = &rootNode.children;
        for (const auto& part : relativePath.parent_path()) {
            const std::string name = pathToUtf8(part);
            if (name.empty() || name == "." || name == "..") {
                continue;
            }
            children = &ensureFolderSceneNode(*children, name).children;
        }

        children->push_back(createFileSceneNode(state.files[fileIndex], fileIndex));
    }

    state.sceneNodes.push_back(std::move(rootNode));
    assignSceneObjectIds(state);
    refreshSceneTreeFolderCenters(state);
    notifySceneEdit(state);
}

bool removeFileFromState(UiState& state, size_t fileIndex)
{
    if (fileIndex >= state.files.size()) {
        return false;
    }

    state.files.erase(state.files.begin() + static_cast<std::ptrdiff_t>(fileIndex));
    state.sceneNodes.erase(
        std::remove_if(
            state.sceneNodes.begin(),
            state.sceneNodes.end(),
            [fileIndex](UiSceneNode& node) {
                return !pruneRemovedFile(node, fileIndex);
            }),
        state.sceneNodes.end());
    std::erase_if(state.selectedSceneObjects, [&state](SceneObjectId id) {
        return !findSceneObject(state, id).has_value();
    });
    pruneMissingViewReferences(state);
    validateAnnotationTargets(state);
    recalculateSceneBounds(state);
    frameCameraToScene(state);
    markSceneDirty(state);
    return true;
}

UiState prepareSceneReplacement(const UiState& current,
    std::vector<UiFileState> files, const SceneDocument& document)
{
    UiState prepared;
    prepared.running = current.running;
    prepared.uiScale = current.uiScale;
    prepared.viewerPaneWidth = current.viewerPaneWidth;
    prepared.viewerPaneVisible = current.viewerPaneVisible;
    prepared.propertiesPaneVisible = current.propertiesPaneVisible;
    prepared.propertiesPaneWidth = current.propertiesPaneWidth;
    prepared.nextObjectId = current.nextObjectId;
    prepared.nextViewId = current.nextViewId;
    prepared.sceneGeneration = current.sceneGeneration + 1;
    prepared.files = std::move(files);
    prepared.coordinateOrigin = document.coordinateOrigin;
    synchronizeCoordinateFrames(prepared);
    // Every replacement receives fresh IDs, even when reopening the same file.
    for (auto& file : prepared.files) {
        file.objectId = invalidSceneObjectId;
        for (auto& group : file.groupSettings) {
            group.objectId = invalidSceneObjectId;
        }
    }
    applySceneNodeRecords(prepared, document.nodes);
    setSceneUpAxis(prepared, document.upAxis);
    setShowOrigin(prepared, document.showOrigin);
    setShowGrid(prepared, document.showGrid);
    setTriangleEdgeXray(prepared, document.triangleEdgeXray);
    setAdaptivePoints(prepared, document.adaptivePoints);
    setShowDimensions(prepared, document.showDimensions);
    setMasterVertexPointSize(prepared, document.masterVertexPointSize);
    for (const auto& record : document.comparisons) {
        UiComparison comparison;
        comparison.name = record.name.empty() ? "Analysis" : record.name;
        comparison.settings = normalizedComparisonSettings(record.settings);
        comparison.translation = record.translation && finitePosition(*record.translation)
            ? *record.translation : std::array<float, 3>{};
        const auto loadParts = [&](const std::vector<SceneComparisonPartRecord>& references) {
            std::vector<UiComparisonPart> result;
            for (const auto& reference : references) {
                UiComparisonPart part{invalidSceneObjectId, reference.name, reference.enabled};
                if (reference.fileIndex >= 0 && static_cast<size_t>(reference.fileIndex) < prepared.files.size()
                    && reference.groupIndex >= 0) {
                    const auto f = static_cast<size_t>(reference.fileIndex);
                    const auto g = static_cast<size_t>(reference.groupIndex);
                    const auto& file = prepared.files[f];
                    if (comparablePart(file, g) && f < document.files.size() && g < document.files[f].groups.size()
                        && meshGeometry(file.mesh).nodes[g].name == document.files[f].groups[g].name) {
                        part.objectId = file.groupSettings[g].objectId;
                    }
                }
                if (part.objectId == invalidSceneObjectId || std::none_of(result.begin(), result.end(), [&](const auto& other) {
                    return other.objectId == part.objectId;
                })) { result.push_back(std::move(part)); }
            }
            return result;
        };
        comparison.a = loadParts(record.a);
        comparison.b = loadParts(record.b);
        prepared.comparisons.push_back(std::move(comparison));
    }
    assignSceneObjectIds(prepared);
    for (size_t index = 0; index < document.comparisons.size(); ++index) {
        if (!document.comparisons[index].translation) {
            auto& comparison = prepared.comparisons[index];
            comparison.translation = initialComparisonTranslation(prepared, comparison.objectId);
        }
    }
    loadSceneAnnotations(prepared, document);
    loadSceneViews(prepared, document);
    for (const auto& comparison : prepared.comparisons) { normalizeAnalysisSources(prepared, comparison.objectId); }
    if (!prepared.comparisons.empty()) { prepared.activeComparisonId = prepared.comparisons.front().objectId; }
    recalculateSceneBounds(prepared);
    prepared.camera = document.camera ? normalizedSceneCamera(*document.camera)
        : frameCameraBounds(prepared.sceneBounds, prepared.upAxis);
    if (!document.coordinateOrigin && prepared.coordinateOrigin) {
        const auto rebaseCamera = [&](SceneCamera& camera) {
            const Coordinate target{camera.target[0], camera.target[1], camera.target[2]};
            camera.target = renderPosition(relativePosition(target, *prepared.coordinateOrigin));
        };
        if (document.camera) { rebaseCamera(prepared.camera); }
        for (auto& view : prepared.views) { rebaseCamera(view.scene.camera); }
    }
    clearSceneDirty(prepared);
    return prepared;
}

void setSceneDirty(UiState& state, bool dirty)
{
    state.isDirty = dirty;
}

void notifySceneEdit(UiState& state, SceneChange change)
{
    const auto includes = [&](SceneChange domain) { return (static_cast<uint32_t>(change) & static_cast<uint32_t>(domain)) != 0; };
    if (includes(SceneChange::geometry)) { ++state.revisions.geometry; }
    if (includes(SceneChange::appearance)) { ++state.revisions.appearance; }
    if (includes(SceneChange::labels)) { ++state.revisions.labels; }
    if (includes(SceneChange::analysis)) { ++state.revisions.analysis; }
    if (includes(SceneChange::visibility)) { ++state.revisions.visibility; }
    if (includes(SceneChange::annotations)) { ++state.revisions.annotations; }
    if (includes(SceneChange::presentation)) { ++state.revisions.presentation; }
    if (includes(SceneChange::picking)) { ++state.revisions.picking; }
    ++state.sceneEditRevision;
}

void markSceneDirty(UiState& state, SceneChange change)
{
    notifySceneEdit(state, change);
    setSceneDirty(state, true);
    const bool affectsAnalysis = (static_cast<uint32_t>(change) & static_cast<uint32_t>(SceneChange::geometry | SceneChange::analysis)) != 0;
    if (!affectsAnalysis) { return; }
    for (auto& comparison : state.comparisons) {
        if (!comparison.pendingDiagnosticFocus && !comparison.diagnosticFocus && !comparison.uvFindingFocus) { continue; }
        const auto signature = comparisonGeometrySignature(state, comparison.objectId);
        if (comparison.pendingDiagnosticFocus) {
            const auto& pending = *comparison.pendingDiagnosticFocus;
            if (!comparison.settings.enabled || pending.signature != signature
                || pending.side != comparison.settings.diagnosticSide || pending.category != comparison.settings.diagnosticCategory) {
                comparison.pendingDiagnosticFocus.reset();
            }
        }
        if (comparison.diagnosticFocus && !diagnosticFocusCurrent(state, comparison, signature)) {
            comparison.diagnosticFocus.reset();
        }
        if (comparison.uvFindingFocus && (!comparison.settings.enabled || comparison.settings.type != AnalysisType::uvQuality
                || comparison.uvFindingFocus->signature != signature)) {
            comparison.uvFindingFocus.reset();
        }
    }
}

void clearSceneDirty(UiState& state)
{
    setSceneDirty(state, false);
}

void updateSceneDirty(UiState& state, const SceneDocument& cleanDocument)
{
    setSceneDirty(state, !sceneContentEqual(createSceneDocument(state), cleanDocument));
}

void setViewerPaneWidth(UiState& state, float value, float minWidth, float maxWidth)
{
    state.viewerPaneWidth = std::clamp(
        finiteOr(value, minWidth),
        minWidth,
        std::max(minWidth, maxWidth));
}

void setPropertiesPaneWidth(UiState& state, float value, float minWidth, float maxWidth)
{
    state.propertiesPaneWidth = std::clamp(
        finiteOr(value, minWidth), minWidth, std::max(minWidth, maxWidth));
}

void setViewerPaneVisible(UiState& state, bool visible)
{
    state.viewerPaneVisible = visible;
}

void toggleViewerPaneVisible(UiState& state)
{
    setViewerPaneVisible(state, !state.viewerPaneVisible);
}

void requestQuit(UiState& state)
{
    state.running = false;
}

void setCameraOrbiting(UiState& state, bool enabled)
{
    state.cameraInput.orbiting = enabled;
}

void setCameraRolling(UiState& state, bool enabled)
{
    state.cameraInput.rolling = enabled;
}

void setCameraPanning(UiState& state, bool enabled)
{
    state.cameraInput.panning = enabled;
}

void orbitUiCamera(UiState& state, float deltaX, float deltaY)
{
    orbitCamera(state.camera, deltaX, deltaY, state.upAxis);
}

void rollUiCamera(UiState& state, float deltaX)
{
    rollCamera(state.camera, deltaX);
}

void panUiCamera(UiState& state, float deltaX, float deltaY, float viewportHeight)
{
    panCamera(state.camera, deltaX, deltaY, viewportHeight, state.upAxis);
}

void dollyUiCamera(UiState& state, float amount)
{
    dollyCamera(state.camera, amount);
}

void setUiCamera(UiState& state, const CameraPlacement& placement)
{
    state.camera = cameraWithPlacement(state.camera, placement);
}

void lookAtUiCamera(UiState& state, const std::array<float, 3>& eye, const std::array<float, 3>& target)
{
    state.camera = cameraLookingAt(state.camera, eye, target, state.upAxis);
}

void frameCameraToObject(UiState& state, SceneObjectId object)
{
    const auto bounds = sceneObjectBounds(state, {object});
    if (!bounds) { throw std::invalid_argument("Object has no visible geometry to frame."); }
    state.camera = fitCameraBounds(state.camera, *bounds);
}

void navigateUiCamera(UiState& state, const CameraNavigation& navigation)
{
    for (float value : {navigation.yawDegrees, navigation.pitchDegrees, navigation.rollDegrees,
        navigation.right, navigation.up, navigation.forward, navigation.distanceFactor}) {
        if (!std::isfinite(value)) { throw std::invalid_argument("Camera navigation requires finite values."); }
    }
    if (navigation.distanceFactor <= 0) { throw std::invalid_argument("Camera distance factor must be positive."); }
    constexpr float degreesToRadians = 0.017453292519943295f;
    auto camera = state.camera;
    const float yawSign = state.upAxis == SceneUpAxis::y ? -1.0f : 1.0f;
    orbitCamera(camera, std::fmod(navigation.yawDegrees, 360.0f) * degreesToRadians / (0.006f * yawSign),
        std::clamp(navigation.pitchDegrees, -180.0f, 180.0f) * degreesToRadians / 0.006f, state.upAxis);
    rollCamera(camera, std::fmod(navigation.rollDegrees, 360.0f) * degreesToRadians / 0.006f);
    moveCameraLocal(camera, navigation.right, navigation.up, navigation.forward, state.upAxis);
    camera.distance = std::max(0.001f, camera.distance * navigation.distanceFactor);
    const auto eye = cameraEye(camera, state.upAxis);
    for (float value : {camera.target[0], camera.target[1], camera.target[2], camera.distance,
        camera.yawRadians, camera.pitchRadians, camera.rollRadians, eye.x, eye.y, eye.z}) {
        if (!std::isfinite(value)) { throw std::invalid_argument("Camera navigation exceeds the finite coordinate range."); }
    }
    state.camera = camera;
}

} // namespace woby
