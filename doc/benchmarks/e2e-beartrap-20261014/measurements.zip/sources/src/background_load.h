#pragma once

#include "scene_file.h"
#include "scene_mesh_preparation.h"
#include "ui_state.h"

#include <filesystem>
#include <functional>
#include <string>
#include <vector>

namespace woby {

struct BackgroundLoadProgress {
    ModelLoadProgress model;
    std::filesystem::path currentPath;
    size_t completedCount = 0;
    size_t totalCount = 0;
    float currentFileFraction = 0.0f;
};

using BackgroundLoadProgressCallback = std::function<void(const BackgroundLoadProgress&)>;
using BackgroundLoadCancelCallback = std::function<bool()>;

struct ModelInputOutcome {
    std::filesystem::path path;
    std::string state = "not-started";
    std::string error;
};

struct ModelBatchCpuLoadResult {
    std::vector<ModelInputOutcome> outcomes;
    std::vector<UiFileState> files;
    std::vector<SceneMeshPreparation> preparations;
    size_t requestedCount = 0;
    size_t addedCount = 0;
    size_t skippedCount = 0;
    size_t failedCount = 0;
    bool canceled = false;
    std::string lastError;
    std::string status;
};

struct SceneCpuLoadResult {
    std::filesystem::path scenePath;
    SceneDocument document;
    std::vector<UiFileState> files;
    std::vector<SceneMeshPreparation> preparations;
    bool canceled = false;
};

[[nodiscard]] ModelBatchCpuLoadResult loadModelBatchCpu(
    const std::vector<std::filesystem::path>& modelPaths,
    size_t firstColorIndex,
    const BackgroundLoadProgressCallback& progress,
    const BackgroundLoadCancelCallback& shouldCancel,
    bool prepareRenderData = false, bool deferPreparation = false);

[[nodiscard]] SceneCpuLoadResult loadSceneCpu(
    const std::filesystem::path& scenePath,
    const BackgroundLoadProgressCallback& progress,
    const BackgroundLoadCancelCallback& shouldCancel,
    bool prepareRenderData = false, bool deferPreparation = false);

} // namespace woby
