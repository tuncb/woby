#pragma once

#include "model_mesh.h"
#include "comparison_settings.h"
#include "surface_mesh_quality.h"

#include <cstddef>
#include <stop_token>
#include <vector>

namespace woby
{

// CPU meshes use 32-bit indices, while individual GPU buffers use 32-bit byte
// sizes. Distance face records have a separate GPU representation limit.
[[nodiscard]] uint32_t comparisonBufferBytes(size_t count, size_t elementBytes);
void validateComparisonMeshSize(size_t vertexCount, size_t triangleCount);
void validateComparisonDistanceSize(size_t vertexCount, size_t triangleCount);

struct DiagnosticEdge
{
    std::array<float, 3> a{}, b{};
};

struct MeshDiagnostics
{
    std::vector<DiagnosticEdge> boundaryEdges;
    std::vector<DiagnosticEdge> nonManifoldEdges;
    std::vector<DiagnosticEdge> inconsistentWindingEdges;
    size_t degenerateTriangles = 0;
    size_t duplicateTriangles = 0;
};

struct ComparisonAnalysisInput {
    std::shared_ptr<const DuplicateInput> source;
    std::array<double, 3> origin{};
    std::shared_ptr<const AnalysisGeometry> geometry;
    MeshTopology incidence; // Only immutable graph owners; no finding vectors.
};
struct SurfaceComparison
{
    ComparisonAnalysisInput analysis;
    // Immutable finding snapshots for threshold/display workers. Each snapshot
    // contains only its own finding family and shared incidence owners.
    std::array<std::shared_ptr<const MeshTopology>, 2> topologyDisplayInputs;
    std::vector<std::array<float, 3>> duplicatePointDisplay, duplicateTriangleDisplayEdges, duplicateTriangleDisplayFill;
    std::vector<std::array<float, 3>> degenerateDisplayEdges, degenerateDisplayFill, intersectionDisplayFill;
    Mesh source;
    // Four subtriangles per source face, each colored by its centroid distance.
    // Display records do not own a mesh or indices. CPU queries use source.
    std::vector<DistanceFace> distanceFaces;
    std::vector<double> distances;
    std::vector<double> sampleAreas;
    double maximum = 0;
    double mean = 0;
    double percentile95 = 0;
    MeshDiagnostics diagnostics;
    MeshTopology topology;
    std::vector<DiagnosticEdge> topologyBoundaries, topologyNonManifold, topologyWinding;
    std::vector<DiagnosticEdge> nonManifoldVertexBounds, nonManifoldVertexMarkers, holeBounds, holeEdges, finBounds, finEdges;
    std::vector<std::array<float, 3>> finFill;
    SurfaceMeshQuality quality;
    // Worker-prepared display data, released after successful GPU upload.
    std::vector<SurfaceQualityFace> qualityFaces;
    MeshDuplicates duplicates;
    MeshDegenerates degenerates;
    MeshIntersections intersections;
    std::vector<DiagnosticEdge> intersectionBounds, intersectionEdges;
    std::vector<DiagnosticEdge> degenerateBounds;
    // Bounds diagonals used by shared finding navigation; not rendered as edges.
    std::vector<DiagnosticEdge> duplicatePointBounds, duplicateTriangleBounds;
};

struct DetectorStatus {
    IntersectionPhase phase = IntersectionPhase::notChecked;
    bool hasResult = false;
    std::array<size_t, 2> knownCounts{};
    std::string error;
};

struct MeshComparison
{
    SurfaceComparison original;
    SurfaceComparison repaired;
    std::array<DetectorStatus, backgroundDetectorCount> detectors{};
    std::array<QualityDistribution, surfaceQualityMetricCount> qualityDistributions{};
};

// Independent, retained CPU results for one immutable geometry revision.
enum ComparisonStage : uint32_t {
    comparisonSource = 1u << 0,
    comparisonTopology = 1u << 1,
    comparisonDuplicatePoints = 1u << 2,
    comparisonDuplicateTriangles = 1u << 3,
    comparisonQuality = 1u << 4,
    comparisonDistance = 1u << 5,
    comparisonDegenerates = 1u << 6,
    comparisonIntersections = 1u << 7
};
inline constexpr uint32_t comparisonDetectors = comparisonTopology | comparisonDuplicatePoints
    | comparisonDuplicateTriangles | comparisonDegenerates;
[[nodiscard]] DetectorStatus comparisonDetectorStatus(const MeshComparison& result, DiagnosticCategory category);
[[nodiscard]] const char* detectorPhaseName(IntersectionPhase phase);
// Retain previous counts, but prevent stale findings from being inspected or drawn.
void invalidateComparisonDetectors(MeshComparison& result, uint32_t stages);
struct ComparisonCacheStatus {
    uint64_t signature = 0;
    uint32_t completed = 0;
    DegenerateSettings degenerates;
    TopologyMode topologyMode = TopologyMode::originalIndex;
};
[[nodiscard]] uint32_t requestedComparisonStages(const ComparisonSettings& settings, bool bothInputs,
    bool fullResults = false);
[[nodiscard]] uint32_t comparisonDiagnosticStage(DiagnosticCategory category);
[[nodiscard]] uint32_t nextComparisonStage(uint32_t missing);
// Returns true when a geometry change invalidates the retained stages.
bool resetComparisonCache(ComparisonCacheStatus& cache, uint64_t signature);
// Invalidates only the threshold-dependent detector stage.
bool resetComparisonDegenerateCache(ComparisonCacheStatus& cache, DegenerateSettings settings);
bool resetComparisonTopologyCache(ComparisonCacheStatus& cache, TopologyMode mode);
[[nodiscard]] std::array<ComparisonAnalysisInput, 2> comparisonAnalysisInputs(const MeshComparison& result, bool includeIncidence = true);
[[nodiscard]] uint32_t topologyFindingStage(DiagnosticCategory category);
[[nodiscard]] MeshComparison computeComparisonStages(const Mesh& original, const Mesh& repaired,
    uint32_t stages, std::stop_token stop = {}, DegenerateSettings degenerates = {}, TopologyMode topologyMode = TopologyMode::originalIndex, IntersectionLimits intersectionLimits = {},
    const std::array<ComparisonAnalysisInput, 2>& analysisInputs = {}, uint32_t topologyFindings = topologyAllFindings,
    TopologyInspectionSettings topologySettings = {});
// Rejects stale worker results; moves only the stages produced by that worker.
bool applyComparisonStages(MeshComparison& result, ComparisonCacheStatus& cache, MeshComparison update,
    uint64_t signature, uint32_t stages);
using TopologyDisplayInputs = std::array<std::array<std::shared_ptr<const MeshTopology>, 2>, 2>;
[[nodiscard]] MeshComparison prepareComparisonTopologyDisplay(const TopologyDisplayInputs& inputs,
    TopologyInspectionSettings settings, std::stop_token stop = {});
void applyComparisonTopologyDisplay(MeshComparison& result, MeshComparison update);
bool setComparisonTopologyInspectionSettings(MeshComparison& result, TopologyInspectionSettings settings);
void prepareComparisonDiagnosticDisplay(SurfaceComparison& surface, const Mesh& mesh, uint32_t stages, std::stop_token stop = {});
void setComparisonDuplicateEnabled(MeshComparison& result, const DuplicateSettings& settings);
void setComparisonIntersectionSettings(MeshComparison& result, IntersectionSettings settings);
void setComparisonDegenerateSettings(MeshComparison& result, DegenerateSettings settings);

[[nodiscard]] const std::vector<DiagnosticEdge>& comparisonDiagnosticEdges(
    const MeshComparison& result, ComparisonSide side, DiagnosticCategory category);

[[nodiscard]] const DuplicateResult& comparisonDuplicates(
    const MeshComparison& result, ComparisonSide side, DiagnosticCategory category);

[[nodiscard]] double pointTriangleDistance(const std::array<float, 3> &point, const std::array<float, 3> &a,
                                           const std::array<float, 3> &b, const std::array<float, 3> &c);
[[nodiscard]] MeshDiagnostics inspectMesh(const Mesh &mesh, std::stop_token stop = {});
// One empty mesh requests topology inspection only; no distance samples are produced.
[[nodiscard]] MeshComparison compareMeshes(const Mesh &original, const Mesh &repaired, std::stop_token stop = {}, DegenerateSettings degenerates = {}, TopologyMode topologyMode = TopologyMode::originalIndex);
[[nodiscard]] double surfacePercentAboveTolerance(const SurfaceComparison &surface, double tolerance);

} // namespace woby
