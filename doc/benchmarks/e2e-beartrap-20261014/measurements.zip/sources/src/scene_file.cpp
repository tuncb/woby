#include "uv_quality.h"
#include "scene_file.h"
#include "analysis_presentation.h"
#include "utf8_path.h"

#include <algorithm>
#include <tuple>
#include <cctype>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string_view>
#include <random>
#include <system_error>
#include <type_traits>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <cerrno>
#include <unistd.h>
#endif

namespace woby {
namespace {

std::string lowercase(std::string value)
{
    for (char& character : value) {
        character = static_cast<char>(std::tolower(static_cast<unsigned char>(character)));
    }

    return value;
}

bool isWobyPath(const std::filesystem::path& path)
{
    return lowercase(pathToUtf8(path.extension())) == ".woby";
}

std::string trim(std::string_view value)
{
    size_t first = 0;
    while (first < value.size() && std::isspace(static_cast<unsigned char>(value[first]))) {
        ++first;
    }

    size_t last = value.size();
    while (last > first && std::isspace(static_cast<unsigned char>(value[last - 1u]))) {
        --last;
    }

    return std::string(value.substr(first, last - first));
}

std::string stripTomlComment(std::string_view line)
{
    bool inString = false;
    bool escaped = false;
    for (size_t index = 0; index < line.size(); ++index) {
        const char character = line[index];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (inString && character == '\\') {
            escaped = true;
            continue;
        }
        if (character == '"') {
            inString = !inString;
            continue;
        }
        if (!inString && character == '#') {
            return std::string(line.substr(0, index));
        }
    }

    return std::string(line);
}

std::string escapeTomlString(std::string_view value)
{
    std::string escaped;
    for (char character : value) {
        switch (character) {
        case '\b':
            escaped += "\\b";
            break;
        case '\t':
            escaped += "\\t";
            break;
        case '\n':
            escaped += "\\n";
            break;
        case '\f':
            escaped += "\\f";
            break;
        case '\r':
            escaped += "\\r";
            break;
        case '"':
            escaped += "\\\"";
            break;
        case '\\':
            escaped += "\\\\";
            break;
        default:
            escaped += character;
            break;
        }
    }

    return escaped;
}

std::string parseTomlString(std::string_view value)
{
    const std::string text = trim(value);
    if (text.size() < 2u || text.front() != '"' || text.back() != '"') {
        throw std::runtime_error("Expected TOML string value.");
    }

    std::string result;
    bool escaped = false;
    for (size_t index = 1u; index + 1u < text.size(); ++index) {
        const char character = text[index];
        if (escaped) {
            switch (character) {
            case 'b':
                result += '\b';
                break;
            case 't':
                result += '\t';
                break;
            case 'n':
                result += '\n';
                break;
            case 'f':
                result += '\f';
                break;
            case 'r':
                result += '\r';
                break;
            case '"':
                result += '"';
                break;
            case '\\':
                result += '\\';
                break;
            default:
                throw std::runtime_error("Unsupported TOML string escape.");
            }
            escaped = false;
            continue;
        }
        if (character == '\\') {
            escaped = true;
            continue;
        }

        result += character;
    }
    if (escaped) {
        throw std::runtime_error("Unterminated TOML string escape.");
    }

    return result;
}

SceneUpAxis parseSceneUpAxis(std::string_view value)
{
    const std::string text = parseTomlString(value);
    if (text == "z") {
        return SceneUpAxis::z;
    }
    if (text == "y") {
        return SceneUpAxis::y;
    }

    throw std::runtime_error("Expected up axis \"z\" or \"y\".");
}

const char* sceneUpAxisName(SceneUpAxis upAxis)
{
    return upAxis == SceneUpAxis::y ? "y" : "z";
}

SceneNodeKind parseSceneNodeKind(std::string_view value)
{
    const std::string text = parseTomlString(value);
    if (text == "folder") {
        return SceneNodeKind::folder;
    }
    if (text == "file") {
        return SceneNodeKind::file;
    }
    if (text == "group") {
        return SceneNodeKind::group;
    }

    throw std::runtime_error("Expected scene node kind \"folder\", \"file\", or \"group\".");
}

const char* sceneNodeKindName(SceneNodeKind kind)
{
    switch (kind) {
    case SceneNodeKind::folder:
        return "folder";
    case SceneNodeKind::file:
        return "file";
    case SceneNodeKind::group:
        return "group";
    }

    return "folder";
}

template<typename T = float>
T parseTomlFloat(std::string_view value)
{
    const std::string text = trim(value);
    size_t parsedCount = 0;
    const T result = [&] {
        if constexpr (std::is_same_v<T, double>) { return std::stod(text, &parsedCount); }
        else { return std::stof(text, &parsedCount); }
    }();
    if (!trim(std::string_view(text).substr(parsedCount)).empty()) {
        throw std::runtime_error("Expected TOML float value.");
    }

    return result;
}

size_t parseIntersectionBudget(std::string_view value)
{
    const auto text = trim(value);
    size_t used = 0;
    const auto budget = std::stoll(text, &used);
    if (budget < 0 || budget > 2147483647 || used != text.size()) { throw std::runtime_error("Intersection budgets must be integers from 0 to 2147483647 (0 means unlimited)."); }
    return static_cast<size_t>(budget);
}

int parseTomlInteger(std::string_view value)
{
    const std::string text = trim(value);
    size_t parsedCount = 0;
    const int result = std::stoi(text, &parsedCount);
    if (!trim(std::string_view(text).substr(parsedCount)).empty()) {
        throw std::runtime_error("Expected TOML integer value.");
    }

    return result;
}

bool parseTomlBool(std::string_view value)
{
    const std::string text = trim(value);
    if (text == "true") {
        return true;
    }
    if (text == "false") {
        return false;
    }

    throw std::runtime_error("Expected TOML boolean value.");
}

template<typename T = float>
std::vector<T> parseTomlFloatArray(std::string_view value)
{
    const std::string text = trim(value);
    if (text.size() < 2u || text.front() != '[' || text.back() != ']') {
        throw std::runtime_error("Expected TOML float array.");
    }

    std::vector<T> values;
    std::string item;
    std::istringstream stream{std::string(text.substr(1u, text.size() - 2u))};
    while (std::getline(stream, item, ',')) {
        const std::string trimmedItem = trim(item);
        if (!trimmedItem.empty()) {
            values.push_back(parseTomlFloat<T>(trimmedItem));
        }
    }

    return values;
}

std::array<float, 3> parseTomlFloat3(std::string_view value)
{
    const auto values = parseTomlFloatArray(value);
    if (values.size() != 3u) {
        throw std::runtime_error("Expected TOML array with 3 floats.");
    }

    return {values[0], values[1], values[2]};
}

std::array<float, 4> parseTomlFloat4(std::string_view value)
{
    const auto values = parseTomlFloatArray(value);
    if (values.size() != 4u) {
        throw std::runtime_error("Expected TOML array with 4 floats.");
    }

    return {values[0], values[1], values[2], values[3]};
}

void writeTomlFloat(std::ostream& stream, float value)
{
    stream << std::setprecision(9) << value;
}
void writeTomlFloat(std::ostream& stream, double value)
{
    stream << std::setprecision(17) << value;
}

template<typename T>
void writeTomlFloat3(std::ostream& stream, const std::array<T, 3>& value)
{
    stream << '[';
    writeTomlFloat(stream, value[0]);
    stream << ", ";
    writeTomlFloat(stream, value[1]);
    stream << ", ";
    writeTomlFloat(stream, value[2]);
    stream << ']';
}

void writeTomlFloat4(std::ostream& stream, const std::array<float, 4>& value)
{
    stream << '[';
    writeTomlFloat(stream, value[0]);
    stream << ", ";
    writeTomlFloat(stream, value[1]);
    stream << ", ";
    writeTomlFloat(stream, value[2]);
    stream << ", ";
    writeTomlFloat(stream, value[3]);
    stream << ']';
}

std::filesystem::path sceneStoredPath(
    const std::filesystem::path& scenePath,
    const std::filesystem::path& modelPath)
{
    const std::filesystem::path basePath = std::filesystem::absolute(scenePath).parent_path().lexically_normal();
    const std::filesystem::path absoluteModelPath = std::filesystem::absolute(modelPath).lexically_normal();
    if (basePath.root_name() != absoluteModelPath.root_name()) {
        return absoluteModelPath;
    }

    std::filesystem::path relativePath = absoluteModelPath.lexically_relative(basePath);
    if (relativePath.empty()) {
        relativePath = absoluteModelPath.filename();
    }

    return relativePath;
}

void assignSceneFileValue(SceneFileRecord& record, const std::string& key, std::string_view value)
{
    if (key == "path") {
        record.path = woby::pathFromUtf8(parseTomlString(value));
    } else if (key == "coordinate_origin") {
        const auto origin = parseTomlFloatArray<double>(value);
        if (origin.size() != 3) { throw std::runtime_error("Expected 3 mesh origin coordinates."); }
        for (double v : origin) { if (!std::isfinite(v)) { throw std::runtime_error("Non-finite mesh origin."); } }
        record.coordinateOrigin = {origin[0], origin[1], origin[2]};
    } else if (key == "analysis_mode") {
        record.settings.analysisMode = parseModelAnalysisMode(parseTomlString(value));
    } else if (key == "importer_id") {
        record.importerId = parseTomlString(value);
    } else if (key == "visible") {
        record.settings.visible = parseTomlBool(value);
    } else if (key == "scale") {
        record.settings.scale = parseTomlFloat(value);
    } else if (key == "opacity") {
        record.settings.opacity = parseTomlFloat(value);
    } else if (key == "translation") {
        record.settings.translation = parseTomlFloat3(value);
    } else if (key == "rotation_degrees") {
        record.settings.rotationDegrees = parseTomlFloat3(value);
    } else if (key == "vertex_size_scale") {
        record.vertexSizeScale = parseTomlFloat(value);
    }
}

void assignSceneGroupValue(SceneGroupRecord& record, const std::string& key, std::string_view value)
{
    if (key == "name") {
        record.name = parseTomlString(value);
    } else if (key == "primitive") {
        const auto primitive = parseTomlString(value);
        if (primitive != "triangles" && primitive != "lines" && primitive != "points") { throw std::runtime_error("Invalid group primitive."); }
        record.lineGroup = primitive == "lines";
        record.pointGroup = primitive == "points";
    } else if (key == "line_width") {
        record.settings.lines.width = normalizedLineStyle({parseTomlFloat(value), true}).width;
    } else if (key == "line_depth_test") {
        record.settings.lines.depthTest = parseTomlBool(value);
    } else if (key == "visible") {
        record.settings.visible = parseTomlBool(value);
    } else if (key == "analysis_a") {
        record.settings.comparison.a = parseTomlBool(value);
    } else if (key == "analysis_b") {
        record.settings.comparison.b = parseTomlBool(value);
    } else if (key == "uv_color") {
        const auto mode = parseTomlString(value);
        if (mode != "grid" && mode != "u" && mode != "v") { throw std::runtime_error("Unknown UV coloring mode."); }
        record.settings.uvGrid.mode = mode == "u" ? UvColorMode::u : mode == "v" ? UvColorMode::v : UvColorMode::grid;
    } else if (key == "uv_minimum") { record.settings.uvGrid.minimum = parseTomlFloat(value);
    } else if (key == "uv_maximum") { record.settings.uvGrid.maximum = parseTomlFloat(value);
    } else if (key == "uv_grid") {
        record.settings.uvGrid.enabled = parseTomlBool(value);
    } else if (key == "uv_density_u") {
        record.settings.uvGrid.densityU = normalizedUvGrid({false, parseTomlFloat(value), 10.0f}).densityU;
    } else if (key == "uv_density_v") {
        record.settings.uvGrid.densityV = normalizedUvGrid({false, 10.0f, parseTomlFloat(value)}).densityV;
    } else if (key == "show_solid_mesh") {
        record.settings.showSolidMesh = parseTomlBool(value);
    } else if (key == "show_triangles") {
        record.settings.showTriangles = parseTomlBool(value);
    } else if (key == "show_vertices") {
        record.settings.showVertices = parseTomlBool(value);
    } else if (key == "scale") {
        record.settings.scale = parseTomlFloat(value);
    } else if (key == "opacity") {
        record.settings.opacity = parseTomlFloat(value);
    } else if (key == "vertex_size_scale") {
        record.settings.vertexSizeScale = parseTomlFloat(value);
    } else if (key == "translation") {
        record.settings.translation = parseTomlFloat3(value);
    } else if (key == "rotation_degrees") {
        record.settings.rotationDegrees = parseTomlFloat3(value);
    } else if (key == "color") {
        record.settings.color = parseTomlFloat4(value);
    }
}

void assignSceneNodeValue(SceneNodeRecord& record, const std::string& key, std::string_view value)
{
    if (key == "kind") {
        record.kind = parseSceneNodeKind(value);
    } else if (key == "name") {
        record.name = parseTomlString(value);
    } else if (key == "parent") {
        record.parentIndex = parseTomlInteger(value);
    } else if (key == "file_index") {
        record.fileIndex = parseTomlInteger(value);
    } else if (key == "group_index") {
        record.groupIndex = parseTomlInteger(value);
    } else if (key == "visible") {
        record.settings.visible = parseTomlBool(value);
    } else if (key == "scale") {
        record.settings.scale = parseTomlFloat(value);
    } else if (key == "opacity") {
        record.settings.opacity = parseTomlFloat(value);
    } else if (key == "translation") {
        record.settings.translation = parseTomlFloat3(value);
    } else if (key == "rotation_degrees") {
        record.settings.rotationDegrees = parseTomlFloat3(value);
    }
}

void assignCameraValue(SceneCamera& camera, const std::string& key, std::string_view value)
{
    if (key == "target") { camera.target = parseTomlFloat3(value);
    } else if (key == "yaw_radians") { camera.yawRadians = parseTomlFloat(value);
    } else if (key == "pitch_radians") { camera.pitchRadians = parseTomlFloat(value);
    } else if (key == "roll_radians") { camera.rollRadians = parseTomlFloat(value);
    } else if (key == "distance") { camera.distance = parseTomlFloat(value);
    } else if (key == "vertical_fov_degrees") { camera.verticalFovDegrees = parseTomlFloat(value);
    } else if (key == "near_plane") { camera.nearPlane = parseTomlFloat(value);
    } else if (key == "automatic_near_plane") { camera.automaticNearPlane = parseTomlBool(value);
    }
    // Report invalid numbers at their source line; clamp only after
    // all fields are read so near-plane limits are order-independent.
    (void)normalizedSceneCamera(camera);
}

void assignComparisonValue(SceneComparisonRecord& record, const std::string& key, std::string_view value)
{
    if (key == "name") { record.name = parseTomlString(value);
    } else if (key == "translation") { record.translation = parseTomlFloat3(value);
    } else if (key == "analysis_enabled") {
        record.settings.enabled = parseTomlBool(value);
    } else if (key == "analysis_task") {
        const auto task = parseTomlString(value);
        bool found = false;
        for (const auto candidate : {AnalysisTask::automatic, AnalysisTask::meshChecks, AnalysisTask::meshQuality,
                AnalysisTask::surfaceComparison, AnalysisTask::uvInspection}) {
            if (task == analysisTaskKey(candidate)) { record.settings.task = candidate; found = true; break; }
        }
        if (!found) { throw std::runtime_error("Unknown analysis task."); }
    } else if (key == "analysis_type") {
        const auto type = parseTomlString(value);
        if (type == "mesh") { record.settings.type = AnalysisType::mesh; }
        else if (type == "surface_comparison") { record.settings.type = AnalysisType::surfaceComparison; }
        else if (type == "uv") { record.settings.type = AnalysisType::uv; }
        else if (type == "uv_quality") { record.settings.type = AnalysisType::uvQuality; }
        else { throw std::runtime_error("Unknown analysis type."); }
    } else if (key == "analysis_uv_separated") { record.settings.uvSeparated = parseTomlBool(value);
    } else if (key == "analysis_uv_linked_selection") { record.settings.uvLinkedSelection = parseTomlBool(value);
    } else if (key == "analysis_uv_threshold_enabled") { record.settings.uvThresholdEnabled = parseTomlBool(value);
    } else if (key == "analysis_uv_threshold") { record.settings.uvThreshold = parseTomlFloat(value);
    } else if (key == "analysis_uv_near_collapse") { record.settings.uvNearCollapse = parseTomlFloat(value);
    } else if (key == "analysis_uv_overlap_enabled") { record.settings.uvOverlapEnabled = parseTomlBool(value);
    } else if (key == "analysis_uv_range_enabled") { record.settings.uvRangeEnabled = parseTomlBool(value);
    } else if (key == "analysis_uv_range_minimum") { record.settings.uvRangeMinimum = parseTomlFloat(value);
    } else if (key == "analysis_uv_range_maximum") { record.settings.uvRangeMaximum = parseTomlFloat(value);
    } else if (key == "analysis_uv_overlap_scope") {
        const auto scope = parseTomlString(value);
        if (scope != "per_patch" && scope != "selected_patches") { throw std::runtime_error("Unknown UV overlap scope."); }
        record.settings.uvOverlapScope = scope == "selected_patches" ? UvOverlapScope::selectedPatches : UvOverlapScope::perPatch;
    } else if (key == "analysis_uv_metric") {
        const auto metric = parseTomlString(value);
        record.settings.uvMetric = parseUvQualityMetric(metric);
    } else if (key == "analysis_uv_normalization") {
        const auto mode = parseTomlString(value);
        if (mode != "per_patch" && mode != "absolute") { throw std::runtime_error("Unknown UV area normalization."); }
        record.settings.uvNormalization = mode == "absolute" ? UvAreaNormalization::absolute : UvAreaNormalization::perPatch;
    } else if (key == "analysis_uv_view") {
        const auto view = parseTomlString(value);
        if (view == "layout") { record.settings.uvView = UvView::layout; }
        else if (view == "surface") { record.settings.uvView = UvView::surface; }
        else { throw std::runtime_error("Unknown UV view."); }
    } else if (key == "analysis_uv_color") {
        const auto mode = parseTomlString(value);
        if (mode != "grid" && mode != "u" && mode != "v") { throw std::runtime_error("Unknown UV coloring mode."); }
        record.settings.uvGrid.mode = mode == "u" ? UvColorMode::u : mode == "v" ? UvColorMode::v : UvColorMode::grid;
    } else if (key == "analysis_uv_minimum") { record.settings.uvGrid.minimum = parseTomlFloat(value);
    } else if (key == "analysis_uv_maximum") { record.settings.uvGrid.maximum = parseTomlFloat(value);
    } else if (key == "analysis_uv_grid") {
        record.settings.uvGrid.enabled = parseTomlBool(value);
    } else if (key == "analysis_uv_density_u") {
        record.settings.uvGrid.densityU = normalizedUvGrid({false, parseTomlFloat(value), 10}).densityU;
    } else if (key == "analysis_uv_density_v") {
        record.settings.uvGrid.densityV = normalizedUvGrid({false, 10, parseTomlFloat(value)}).densityV;
    } else if (key == "analysis_mode") {
        const auto mode = parseTomlString(value);
        if (mode == "distance") { record.settings.mode = ComparisonMode::distance; }
        else if (mode == "a") { record.settings.mode = ComparisonMode::original; }
        else if (mode == "b") { record.settings.mode = ComparisonMode::repaired; }
        else if (mode == "overlay") { record.settings.mode = ComparisonMode::overlay; }
        else if (mode == "surface_quality") { record.settings.mode = ComparisonMode::surfaceQuality; }
        else { throw std::runtime_error("Unknown analysis mode."); }
    } else if (key == "analysis_distance_on_a") {
        record.settings.distanceOnOriginal = parseTomlBool(value);
    } else if (key == "diagnostic_side") {
        const auto side = parseTomlString(value);
        if (side == "a") { record.settings.diagnosticSide = ComparisonSide::a; }
        else if (side == "b") { record.settings.diagnosticSide = ComparisonSide::b; }
        else { throw std::runtime_error("Unknown diagnostic side."); }
    } else if (key == "diagnostic_category") {
        const auto category = parseTomlString(value);
        if (category == "boundary") { record.settings.diagnosticCategory = DiagnosticCategory::boundary; }
        else if (category == "non_manifold") { record.settings.diagnosticCategory = DiagnosticCategory::nonManifold; }
        else if (category == "non_manifold_vertices") { record.settings.diagnosticCategory = DiagnosticCategory::nonManifoldVertices; }
        else if (category == "fins") { record.settings.diagnosticCategory = DiagnosticCategory::fins; }
        else if (category == "holes") { record.settings.diagnosticCategory = DiagnosticCategory::holes; }
        else if (category == "winding") { record.settings.diagnosticCategory = DiagnosticCategory::winding; }
        else if (category == "duplicate_points") { record.settings.diagnosticCategory = DiagnosticCategory::duplicatePoints; }
        else if (category == "self_intersections") { record.settings.diagnosticCategory = DiagnosticCategory::selfIntersections; }
        else if (category == "degenerate_triangles") { record.settings.diagnosticCategory = DiagnosticCategory::degenerateTriangles; }
        else if (category == "duplicate_triangles") { record.settings.diagnosticCategory = DiagnosticCategory::duplicateTriangles; }
        else { throw std::runtime_error("Unknown diagnostic category."); }
    } else if (key == "analysis_auto_update_boundaries") { record.settings.autoUpdateBoundaries = parseTomlBool(value);
    } else if (key == "analysis_auto_update_non_manifold_edges") { record.settings.autoUpdateNonManifold = parseTomlBool(value);
    } else if (key == "analysis_auto_update_winding") { record.settings.autoUpdateWinding = parseTomlBool(value);
    } else if (key == "analysis_non_manifold_vertices_enabled") { record.settings.topologyInspection.nonManifoldVertices = parseTomlBool(value);
    } else if (key == "analysis_show_non_manifold_vertices") { record.settings.topologyInspection.showNonManifoldVertices = parseTomlBool(value);
    } else if (key == "analysis_fins_enabled") { record.settings.topologyInspection.fins = parseTomlBool(value);
    } else if (key == "analysis_show_fins") { record.settings.topologyInspection.showFins = parseTomlBool(value);
    } else if (key == "analysis_fin_max_area_ratio") { record.settings.topologyInspection.finMaxAreaRatio = parseTomlFloat(value);
    } else if (key == "analysis_holes_enabled") { record.settings.topologyInspection.holes = parseTomlBool(value);
    } else if (key == "analysis_show_holes") { record.settings.topologyInspection.showHoles = parseTomlBool(value);
    } else if (key == "analysis_hole_size_ratio_tolerance") { record.settings.topologyInspection.holeSizeRatioTolerance = parseTomlFloat(value);
    } else if (key == "analysis_processing_mode") { record.settings.analysisMode = parseAnalysisMode(parseTomlString(value));
    } else if (key == "topology_mode") { record.settings.topologyMode = parseTopologyMode(parseTomlString(value));
    } else if (key == "analysis_show_winding") { record.settings.showWinding = parseTomlBool(value);
    } else if ((key == "self_intersections_enabled" || key == "self_intersections_auto_update")) { record.settings.intersections.autoUpdate = parseTomlBool(value);
    } else if (key == "intersection_pair_limit") { record.settings.intersections.limits.pairs = parseIntersectionBudget(value);
    } else if (key == "intersection_candidate_limit") { record.settings.intersections.limits.candidateTests = parseIntersectionBudget(value);
    } else if (key == "show_self_intersections") { record.settings.intersections.show = parseTomlBool(value);
    } else if (key == "degenerate_triangles_enabled") { record.settings.degenerates.enabled = parseTomlBool(value);
    } else if (key == "show_degenerate_triangles") { record.settings.degenerates.show = parseTomlBool(value);
    } else if (key == "needle_threshold_ratio") { record.settings.degenerates.needleThresholdRatio = parseTomlFloat(value);
    } else if (key == "cap_min_angle_degrees") { record.settings.degenerates.capMinAngleDegrees = parseTomlFloat(value);
    } else if (key == "duplicate_points_enabled") { record.settings.duplicates.points = parseTomlBool(value);
    } else if (key == "duplicate_triangles_enabled") { record.settings.duplicates.triangles = parseTomlBool(value);
    } else if (key == "show_duplicate_points") { record.settings.duplicates.showPoints = parseTomlBool(value);
    } else if (key == "show_duplicate_triangles") { record.settings.duplicates.showTriangles = parseTomlBool(value);
    } else if (key == "analysis_tolerance") {
        record.settings.tolerance = parseTomlFloat(value);
    } else if (key == "quality_metric") {
        record.settings.quality.metric = parseSurfaceQualityMetric(parseTomlString(value));
    } else if (key == "quality_on_a") {
        record.settings.quality.onOriginal = parseTomlBool(value);
    } else if (key == "quality_minimum_enabled") {
        record.settings.quality.minimumEnabled = parseTomlBool(value);
    } else if (key == "quality_maximum_enabled") {
        record.settings.quality.maximumEnabled = parseTomlBool(value);
    } else if (key == "quality_minimum_size") {
        record.settings.quality.minimumSize = parseTomlFloat(value);
    } else if (key == "quality_maximum_size") {
        record.settings.quality.maximumSize = parseTomlFloat(value);
    } else if (key == "difference_created") { record.settings.difference.created = parseTomlBool(value);
    } else if (key == "difference_visible") { record.settings.difference.visible = parseTomlBool(value);
    } else if (key == "difference_show_a") { record.settings.difference.showA = parseTomlBool(value);
    } else if (key == "difference_show_b") { record.settings.difference.showB = parseTomlBool(value);
    } else if (key == "difference_show_walls") { record.settings.difference.showWalls = parseTomlBool(value);
    } else if (key == "difference_opacity") { record.settings.difference.opacity = parseTomlFloat(value);
    } else if (key == "analysis_color_range") {
        record.settings.colorRange = parseTomlFloat(value);
    } else if (key == "analysis_color_minimum") {
        record.settings.colorMinimum = parseTomlFloat(value);
    } else if (key == "analysis_color_range_mode") {
        auto mode = parseTomlString(value);
        // Retain the selected percentage from early area-percentile menu keys.
        if (mode == "area90") { mode = "max90"; }
        else if (mode == "area95") { mode = "max95"; }
        else if (mode == "area975") { mode = "max975"; }
        else if (mode == "area99") { mode = "max99"; }
        const auto found = std::find(comparisonColorRangeKeys.begin(), comparisonColorRangeKeys.end(), mode);
        if (found == comparisonColorRangeKeys.end()) { throw std::runtime_error("Unknown comparison color range mode."); }
        record.settings.colorRangeMode = static_cast<ComparisonColorRange>(found - comparisonColorRangeKeys.begin());
    } else if (key == "analysis_show_edges") {
        record.settings.showEdges = parseTomlBool(value);
    } else if (key == "analysis_show_boundaries") {
        record.settings.showBoundaries = parseTomlBool(value);
    } else if (key == "analysis_show_non_manifold") {
        record.settings.showNonManifold = parseTomlBool(value);
    }
}

void writeComparisonSettings(std::ostream& stream, const ComparisonSettings& settings)
{
    const auto comparison = normalizedComparisonSettings(settings);
    const char* mode = "distance";
    switch (comparison.mode) {
    case ComparisonMode::distance: break;
    case ComparisonMode::original: mode = "a"; break;
    case ComparisonMode::repaired: mode = "b"; break;
    case ComparisonMode::overlay: mode = "overlay"; break;
    case ComparisonMode::surfaceQuality: mode = "surface_quality"; break;
    }
    stream << "analysis_enabled = " << (comparison.enabled ? "true" : "false") << "\n";
    stream << "analysis_type = \"" << analysisTypeKey(comparison.type) << "\"\n";
    stream << "analysis_task = \"" << analysisTaskKey(comparison.task) << "\"\n";
    stream << "analysis_uv_separated = " << (comparison.uvSeparated ? "true" : "false") << "\n";
    stream << "analysis_uv_linked_selection = " << (comparison.uvLinkedSelection ? "true" : "false") << "\n";
    stream << "analysis_uv_metric = \"" << uvQualityMetricKey(comparison.uvMetric) << "\"\n";
    stream << "analysis_uv_normalization = \"" << (comparison.uvNormalization == UvAreaNormalization::absolute ? "absolute" : "per_patch") << "\"\n";
    stream << "analysis_uv_threshold_enabled = " << (comparison.uvThresholdEnabled ? "true" : "false") << "\n";
    stream << "analysis_uv_threshold = " << comparison.uvThreshold << "\n";
    stream << "analysis_uv_near_collapse = " << comparison.uvNearCollapse << "\n";
    stream << "analysis_uv_overlap_enabled = " << (comparison.uvOverlapEnabled ? "true" : "false") << "\n";
    stream << "analysis_uv_range_enabled = " << (comparison.uvRangeEnabled ? "true" : "false") << "\n";
    stream << "analysis_uv_range_minimum = " << comparison.uvRangeMinimum << "\n";
    stream << "analysis_uv_range_maximum = " << comparison.uvRangeMaximum << "\n";
    stream << "analysis_uv_overlap_scope = \"" << (comparison.uvOverlapScope == UvOverlapScope::selectedPatches ? "selected_patches" : "per_patch") << "\"\n";
    stream << "analysis_uv_view = \"" << (comparison.uvView == UvView::layout ? "layout" : "surface") << "\"\n";
    stream << "analysis_uv_color = \"" << uvColorModeKey(comparison.uvGrid.mode) << "\"\n";
    stream << "analysis_uv_minimum = " << comparison.uvGrid.minimum << "\n";
    stream << "analysis_uv_maximum = " << comparison.uvGrid.maximum << "\n";
    stream << "analysis_uv_grid = " << (comparison.uvGrid.enabled ? "true" : "false") << "\n";
    stream << "analysis_uv_density_u = " << comparison.uvGrid.densityU << "\n";
    stream << "analysis_uv_density_v = " << comparison.uvGrid.densityV << "\n";
    stream << "analysis_mode = \"" << mode << "\"\n";
    stream << "analysis_distance_on_a = " << (comparison.distanceOnOriginal ? "true" : "false") << "\n";
    stream << "diagnostic_side = \"" << (comparison.diagnosticSide == ComparisonSide::a ? "a" : "b") << "\"\n";
    const char* category = comparison.diagnosticCategory == DiagnosticCategory::boundary ? "boundary"
        : comparison.diagnosticCategory == DiagnosticCategory::nonManifoldVertices ? "non_manifold_vertices"
        : comparison.diagnosticCategory == DiagnosticCategory::fins ? "fins"
        : comparison.diagnosticCategory == DiagnosticCategory::holes ? "holes"
        : comparison.diagnosticCategory == DiagnosticCategory::nonManifold ? "non_manifold"
        : comparison.diagnosticCategory == DiagnosticCategory::selfIntersections ? "self_intersections"
        : comparison.diagnosticCategory == DiagnosticCategory::degenerateTriangles ? "degenerate_triangles"
        : comparison.diagnosticCategory == DiagnosticCategory::duplicatePoints ? "duplicate_points"
        : comparison.diagnosticCategory == DiagnosticCategory::duplicateTriangles ? "duplicate_triangles" : "winding";
    stream << "diagnostic_category = \"" << category << "\"\n";
    stream << "analysis_tolerance = "; writeTomlFloat(stream, comparison.tolerance); stream << "\n";
    stream << "analysis_color_range = "; writeTomlFloat(stream, comparison.colorRange); stream << "\n";
    stream << "difference_created = " << (comparison.difference.created ? "true" : "false") << "\n";
    stream << "difference_visible = " << (comparison.difference.visible ? "true" : "false") << "\n";
    stream << "difference_show_a = " << (comparison.difference.showA ? "true" : "false") << "\n";
    stream << "difference_show_b = " << (comparison.difference.showB ? "true" : "false") << "\n";
    stream << "difference_show_walls = " << (comparison.difference.showWalls ? "true" : "false") << "\n";
    stream << "difference_opacity = "; writeTomlFloat(stream, comparison.difference.opacity); stream << "\n";
    stream << "analysis_color_minimum = "; writeTomlFloat(stream, comparison.colorMinimum); stream << "\n";
    stream << "analysis_color_range_mode = \"" << comparisonColorRangeKeys[static_cast<size_t>(comparison.colorRangeMode)] << "\"\n";
    stream << "analysis_show_edges = " << (comparison.showEdges ? "true" : "false") << "\n";
    stream << "analysis_show_boundaries = " << (comparison.showBoundaries ? "true" : "false") << "\n";
    stream << "analysis_show_non_manifold = " << (comparison.showNonManifold ? "true" : "false") << "\n";

    stream << "analysis_non_manifold_vertices_enabled = " << (comparison.topologyInspection.nonManifoldVertices ? "true" : "false") << "\n";
    stream << "analysis_auto_update_boundaries = " << (comparison.autoUpdateBoundaries ? "true" : "false") << "\n";
    stream << "analysis_auto_update_non_manifold_edges = " << (comparison.autoUpdateNonManifold ? "true" : "false") << "\n";
    stream << "analysis_auto_update_winding = " << (comparison.autoUpdateWinding ? "true" : "false") << "\n";
    stream << "analysis_show_non_manifold_vertices = " << (comparison.topologyInspection.showNonManifoldVertices ? "true" : "false") << "\n";
    stream << "analysis_fins_enabled = " << (comparison.topologyInspection.fins ? "true" : "false") << "\n";
    stream << "analysis_show_fins = " << (comparison.topologyInspection.showFins ? "true" : "false") << "\n";
    stream << "analysis_fin_max_area_ratio = " << comparison.topologyInspection.finMaxAreaRatio << "\n";
    stream << "analysis_holes_enabled = " << (comparison.topologyInspection.holes ? "true" : "false") << "\n";
    stream << "analysis_show_holes = " << (comparison.topologyInspection.showHoles ? "true" : "false") << "\n";
    stream << "analysis_hole_size_ratio_tolerance = " << comparison.topologyInspection.holeSizeRatioTolerance << "\n";
    stream << "analysis_processing_mode = \"" << analysisModeName(comparison.analysisMode) << "\"\n";
    stream << "topology_mode = \"" << topologyModeName(comparison.topologyMode) << "\"\n";
    stream << "analysis_show_winding = " << (comparison.showWinding ? "true" : "false") << "\n";
    stream << "self_intersections_auto_update = " << (comparison.intersections.autoUpdate ? "true" : "false") << "\n";
    stream << "intersection_pair_limit = " << comparison.intersections.limits.pairs << "\n";
    stream << "intersection_candidate_limit = " << comparison.intersections.limits.candidateTests << "\n";
    stream << "show_self_intersections = " << (comparison.intersections.show ? "true" : "false") << "\n";
    stream << "degenerate_triangles_enabled = " << (comparison.degenerates.enabled ? "true" : "false") << "\n";
    stream << "show_degenerate_triangles = " << (comparison.degenerates.show ? "true" : "false") << "\n";
    stream << "needle_threshold_ratio = " << comparison.degenerates.needleThresholdRatio << "\n";
    stream << "cap_min_angle_degrees = " << comparison.degenerates.capMinAngleDegrees << "\n";
    stream << "duplicate_points_enabled = " << (comparison.duplicates.points ? "true" : "false") << "\n";
    stream << "duplicate_triangles_enabled = " << (comparison.duplicates.triangles ? "true" : "false") << "\n";
    stream << "show_duplicate_points = " << (comparison.duplicates.showPoints ? "true" : "false") << "\n";
    stream << "show_duplicate_triangles = " << (comparison.duplicates.showTriangles ? "true" : "false") << "\n";

    stream << "quality_metric = \"" << surfaceQualityMetricKey(comparison.quality.metric) << "\"\n";
    stream << "quality_on_a = " << (comparison.quality.onOriginal ? "true" : "false") << "\n";
    stream << "quality_minimum_enabled = " << (comparison.quality.minimumEnabled ? "true" : "false") << "\n";
    stream << "quality_maximum_enabled = " << (comparison.quality.maximumEnabled ? "true" : "false") << "\n";
    stream << "quality_minimum_size = "; writeTomlFloat(stream, comparison.quality.minimumSize); stream << "\n";
    stream << "quality_maximum_size = "; writeTomlFloat(stream, comparison.quality.maximumSize); stream << "\n";
}

void writeCamera(std::ostream& stream, const SceneCamera& value)
{
    const auto camera = normalizedSceneCamera(value);
    stream << "target = ";
    writeTomlFloat3(stream, camera.target);
    stream << "\nyaw_radians = ";
    writeTomlFloat(stream, camera.yawRadians);
    stream << "\npitch_radians = ";
    writeTomlFloat(stream, camera.pitchRadians);
    stream << "\nroll_radians = ";
    writeTomlFloat(stream, camera.rollRadians);
    stream << "\ndistance = ";
    writeTomlFloat(stream, camera.distance);
    stream << "\nvertical_fov_degrees = ";
    writeTomlFloat(stream, camera.verticalFovDegrees);
    stream << "\nnear_plane = ";
    writeTomlFloat(stream, camera.nearPlane);
    stream << "\nautomatic_near_plane = " << (camera.automaticNearPlane ? "true" : "false");
    stream << "\n";
}

void writeAppearance(std::ostream& stream, const SceneGroupSettings& settings)
{
    stream << "uv_color = \"" << uvColorModeKey(settings.uvGrid.mode) << "\"\n";
    stream << "uv_minimum = " << settings.uvGrid.minimum << "\n";
    stream << "uv_maximum = " << settings.uvGrid.maximum << "\n";
    stream << "uv_grid = " << (settings.uvGrid.enabled ? "true" : "false") << "\n";
    stream << "line_width = ";
    writeTomlFloat(stream, settings.lines.width);
    stream << "\nline_depth_test = " << (settings.lines.depthTest ? "true" : "false") << "\n";
    stream << "uv_density_u = ";
    writeTomlFloat(stream, settings.uvGrid.densityU);
    stream << "\nuv_density_v = ";
    writeTomlFloat(stream, settings.uvGrid.densityV);
    stream << "\n";
    stream << "visible = " << (settings.visible ? "true" : "false") << "\n";
    stream << "show_solid_mesh = " << (settings.showSolidMesh ? "true" : "false") << "\n";
    stream << "show_triangles = " << (settings.showTriangles ? "true" : "false") << "\n";
    stream << "show_vertices = " << (settings.showVertices ? "true" : "false") << "\n";
    stream << "scale = ";
    writeTomlFloat(stream, settings.scale);
    stream << "\n";
    stream << "opacity = ";
    writeTomlFloat(stream, settings.opacity);
    stream << "\n";
    stream << "vertex_size_scale = ";
    writeTomlFloat(stream, settings.vertexSizeScale);
    stream << "\n";
    stream << "translation = ";
    writeTomlFloat3(stream, settings.translation);
    stream << "\n";
    stream << "rotation_degrees = ";
    writeTomlFloat3(stream, settings.rotationDegrees);
    stream << "\n";
    stream << "color = ";
    writeTomlFloat4(stream, settings.color);
    stream << "\n";
}

} // namespace

std::filesystem::path sceneAbsolutePath(
    const std::filesystem::path& scenePath,
    const std::filesystem::path& storedPath)
{
    if (storedPath.is_absolute()) {
        return storedPath.lexically_normal();
    }

    return (std::filesystem::absolute(scenePath).parent_path() / storedPath).lexically_normal();
}

std::filesystem::path sceneSavePathWithExtension(std::filesystem::path path)
{
    if (!isWobyPath(path)) {
        path += ".woby";
    }

    return path;
}

bool sceneContentEqual(const SceneDocument& a, const SceneDocument& b)
{
    // The live camera is excluded so ordinary navigation stays transient.
    // Named checkpoints, including their cameras, are editable document content.
    return std::tie(a.annotations, a.views, a.comparisons, a.comparison, a.masterVertexPointSize, a.showOrigin,
               a.showGrid, a.showDimensions, a.triangleEdgeXray, a.adaptivePoints, a.upAxis, a.files, a.nodes, a.coordinateOrigin)
        == std::tie(b.annotations, b.views, b.comparisons, b.comparison, b.masterVertexPointSize, b.showOrigin,
               b.showGrid, b.showDimensions, b.triangleEdgeXray, b.adaptivePoints, b.upAxis, b.files, b.nodes, b.coordinateOrigin);
}

SceneDocument readSceneDocument(const std::filesystem::path& scenePath)
{
    std::ifstream stream(scenePath);
    if (!stream) {
        throw std::runtime_error("Failed to open scene file: " + pathToUtf8(scenePath));
    }

    enum class Section {
        root,
        annotation,
        annotationSegment,
        annotationSource,
        view,
        viewCamera,
        viewObject,
        viewPart,
        camera,
        file,
        group,
        node,
        comparison,
        comparisonA,
        comparisonB,
    };

    SceneDocument document;
    std::vector<AnnotationGeometry> annotationDrafts;
    Section section = Section::root;
    bool viewCameraSeen = false;
    int sceneVersion = 2;
    size_t lineNumber = 0;

    std::string line;
    while (std::getline(stream, line)) {
        ++lineNumber;
        const std::string text = trim(stripTomlComment(line));
        if (text.empty()) {
            continue;
        }

        try {
            if (text == "[[annotations]]") {
                document.annotations.emplace_back(); annotationDrafts.emplace_back(); section = Section::annotation; continue;
            }
            if (text == "[[annotations.sources]]") {
                if (document.annotations.empty()) { throw std::runtime_error("Annotation source appeared before annotation."); }
                auto& item = document.annotations.back();
                if (annotationDrafts.back().sources.size() >= 100000) { throw std::runtime_error("Too many annotation sources."); }
                annotationDrafts.back().sources.emplace_back(); item.targets.emplace_back();
                section = Section::annotationSource; continue;
            }
            if (text == "[[annotations.segments]]") {
                if (document.annotations.empty()) { throw std::runtime_error("Annotation segment appeared before annotation."); }
                if (annotationDrafts.back().segments.size() >= 1000000) { throw std::runtime_error("Too many annotation segments."); }
                annotationDrafts.back().segments.emplace_back(); section = Section::annotationSegment; continue;
            }
            if (text == "[[views]]") {
                document.views.emplace_back();
                document.views.back().scene.camera.automaticNearPlane = false;
                viewCameraSeen = false;
                section = Section::view;
                continue;
            }
            if (text == "[views.camera]" || text == "[[views.objects]]" || text == "[[views.parts]]") {
                if (document.views.empty()) { throw std::runtime_error("View child appeared before view."); }
                if (text == "[views.camera]") {
                    if (viewCameraSeen) { throw std::runtime_error("Duplicate view camera table."); }
                    viewCameraSeen = true;
                    section = Section::viewCamera;
                }
                else if (text == "[[views.parts]]") {
                    document.views.back().parts.emplace_back();
                    section = Section::viewPart;
                }
                else {
                    document.views.back().objects.emplace_back();
                    section = Section::viewObject;
                }
                continue;
            }
            if (text == "[camera]") {
                if (document.camera) { throw std::runtime_error("Duplicate camera table."); }
                document.camera.emplace();
                document.camera->automaticNearPlane = false;
                section = Section::camera;
                continue;
            }
            if (text == "[[analyses]]") {
                document.comparisons.emplace_back();
                section = Section::comparison;
                continue;
            }
            if (text == "[[analyses.a]]" || text == "[[analyses.b]]") {
                if (document.comparisons.empty()) { throw std::runtime_error("Analysis input appeared before analysis."); }
                const bool a = text == "[[analyses.a]]";
                (a ? document.comparisons.back().a : document.comparisons.back().b).emplace_back();
                section = a ? Section::comparisonA : Section::comparisonB;
                continue;
            }
            if (text == "[[files]]") {
                document.files.emplace_back();
                section = Section::file;
                continue;
            }
            if (text == "[[files.groups]]") {
                if (document.files.empty()) {
                    throw std::runtime_error("Group table appeared before any file table.");
                }
                document.files.back().groups.emplace_back();
                section = Section::group;
                continue;
            }
            if (text == "[[nodes]]") {
                document.nodes.emplace_back();
                section = Section::node;
                continue;
            }

            const size_t separator = text.find('=');
            if (separator == std::string::npos) {
                throw std::runtime_error("Expected TOML key/value pair.");
            }

            const std::string key = trim(std::string_view(text).substr(0, separator));
            const std::string value = trim(std::string_view(text).substr(separator + 1u));
            if (section == Section::root) {
                if (key == "version") {
                    const int version = parseTomlInteger(value);
                    sceneVersion = version;
                    if (version != 2 && version != 3 && version != 4 && version != 5 && version != 6 && version != 7 && version != 8 && version != 9 && version != 10 && version != 11 && version != 12 && version != 13 && version != 14 && version != 15 && version != 16 && version != 17 && version != 18 && version != 19 && version != 20 && version != 21 && version != 22 && version != 23 && version != 24) {
                        throw std::runtime_error("Unsupported scene version.");
                    }
                } else if (key == "coordinate_origin") {
                    const auto origin = parseTomlFloatArray<double>(value);
                    if (origin.size() != 3) { throw std::runtime_error("Expected 3 origin coordinates."); }
                    for (double v : origin) { if (!std::isfinite(v)) { throw std::runtime_error("Non-finite scene origin."); } }
                    document.coordinateOrigin = {origin[0], origin[1], origin[2]};
                } else if (key == "master_vertex_point_size") {
                    document.masterVertexPointSize = parseTomlFloat(value);
                } else if (key == "show_origin") {
                    document.showOrigin = parseTomlBool(value);
                } else if (key == "show_grid") {
                    document.showGrid = parseTomlBool(value);
                } else if (key == "adaptive_points") {
                    document.adaptivePoints = parseTomlBool(value);
                } else if (key == "triangle_edge_xray") {
                    document.triangleEdgeXray = parseTomlBool(value);
                } else if (key == "show_dimensions") {
                    document.showDimensions = parseTomlBool(value);
                } else if (key == "up_axis") {
                    document.upAxis = parseSceneUpAxis(value);
                } else if (key == "analysis_enabled") {
                    document.comparison.enabled = parseTomlBool(value);
                } else if (key == "analysis_mode") {
                    const auto mode = parseTomlString(value);
                    if (mode == "distance") { document.comparison.mode = ComparisonMode::distance; }
                    else if (mode == "a") { document.comparison.mode = ComparisonMode::original; }
                    else if (mode == "b") { document.comparison.mode = ComparisonMode::repaired; }
                    else if (mode == "overlay") { document.comparison.mode = ComparisonMode::overlay; }
                    else { throw std::runtime_error("Unknown analysis mode."); }
                } else if (key == "analysis_distance_on_a") {
                    document.comparison.distanceOnOriginal = parseTomlBool(value);
                } else if (key == "analysis_tolerance") {
                    document.comparison.tolerance = parseTomlFloat(value);
                } else if (key == "analysis_color_range") {
                    document.comparison.colorRange = parseTomlFloat(value);
                } else if (key == "analysis_show_edges") {
                    document.comparison.showEdges = parseTomlBool(value);
                } else if (key == "analysis_show_boundaries") {
                    document.comparison.showBoundaries = parseTomlBool(value);
                } else if (key == "analysis_show_non_manifold") {
                    document.comparison.showNonManifold = parseTomlBool(value);
                }
            } else if (section == Section::annotation) {
                auto& item = document.annotations.back();
                if (key == "name") { item.settings.name = parseTomlString(value); }
                else if (key == "note") { item.settings.note = parseTomlString(value); }
                else if (key == "target_name") { item.targetName = parseTomlString(value); }
                else if (key == "file_index") { item.fileIndex = parseTomlInteger(value); }
                else if (key == "group_index") { item.groupIndex = parseTomlInteger(value); }
                else if (key == "visible") { item.settings.visible = parseTomlBool(value); }
                else if (key == "locked") { item.settings.locked = parseTomlBool(value); }
                else if (key == "width") { item.settings.width = parseTomlFloat(value); }
                else if (key == "color") { item.settings.color = parseTomlFloat4(value); }
                else if (key == "fingerprint") { annotationDrafts.back().fingerprint = parseTomlString(value); }
                else if (key == "homogeneous_depth") { annotationDrafts.back().homogeneousDepth = parseTomlBool(value); }
                else if (key == "shape") {
                    const auto shape = parseTomlString(value);
                    if (shape == "line") { annotationDrafts.back().shape = AnnotationShape::line; }
                    else if (shape == "rectangle") { annotationDrafts.back().shape = AnnotationShape::rectangle; }
                    else if (shape == "section") { if (!item.section) { item.section.emplace(); } }
                    else { throw std::runtime_error("Unknown annotation shape."); }
                } else if (key.starts_with("section_")) {
                    if (!item.section) { item.section.emplace(); }
                    auto& s = *item.section;
                    if (key == "section_a") { s.a = parseTomlFloat3(value); }
                    else if (key == "section_b") { s.b = parseTomlFloat3(value); }
                    else if (key == "section_lift") { s.lift = parseTomlFloat(value); }
                    else if (key == "section_up") {
                        const auto up = parseTomlString(value);
                        if (up != "y" && up != "z") { throw std::runtime_error("Invalid section up axis."); }
                        s.upAxis = up == "y" ? SceneUpAxis::y : SceneUpAxis::z;
                    }
                    else if (key == "section_plane") { s.showPlane = parseTomlBool(value); }
                    else if (key == "section_connections") { s.showConnections = parseTomlBool(value); }
                    else if (key == "section_differences") { s.showDifferences = parseTomlBool(value); }
                    else if (key == "section_face_on") { s.faceOn = parseTomlBool(value); }
                    else if (key == "section_reference") { s.reference = parseTomlInteger(value); }
                    else if (key == "section_compared") { s.compared = parseTomlInteger(value); }
                    else if (key == "section_visibility") {
                        s.sourceVisible.clear();
                        for (auto v : parseTomlFloatArray(value)) { s.sourceVisible.push_back(v != 0); }
                    }
                } else if (key == "projector") {
                    const auto values = parseTomlFloatArray<double>(value);
                    if (values.size() != 16) { throw std::runtime_error("Expected 16 annotation projector values."); }
                    std::copy(values.begin(), values.end(), annotationDrafts.back().projector.begin());
                } else if (key == "start" || key == "end") {
                    const auto values = parseTomlFloatArray(value);
                    if (values.size() != 2) { throw std::runtime_error("Expected 2 annotation control coordinates."); }
                    auto& control = key == "start" ? annotationDrafts.back().start : annotationDrafts.back().end;
                    control = {values[0], values[1]};
                }
            } else if (section == Section::annotationSource) {
                auto& item = document.annotations.back();
                auto& source = annotationDrafts.back().sources.back();
                auto& target = item.targets.back();
                if (key == "file_index") { target.fileIndex = parseTomlInteger(value); }
                else if (key == "group_index") { target.groupIndex = parseTomlInteger(value); }
                else if (key == "fingerprint") { source.fingerprint = parseTomlString(value); }
                else if (key == "projector") {
                    const auto values = parseTomlFloatArray<double>(value);
                    if (values.size() != 16) { throw std::runtime_error("Expected 16 annotation source transform values."); }
                    std::copy(values.begin(), values.end(), source.projector.begin());
                } else if (key == "to_primary") {
                    const auto values = parseTomlFloatArray(value);
                    if (values.size() != 16) { throw std::runtime_error("Expected 16 annotation source transform values."); }
                    std::copy(values.begin(), values.end(), source.toPrimary.begin());
                }
            } else if (section == Section::annotationSegment) {
                auto& segment = annotationDrafts.back().segments.back();
                if (key == "triangle" || key == "end_triangle" || key == "source" || key == "end_source") {
                    const int triangle = parseTomlInteger(value);
                    if (triangle < 0) { throw std::runtime_error("Invalid annotation triangle."); }
                    if (key == "triangle") { segment.triangle = static_cast<uint32_t>(triangle); }
                    else if (key == "end_triangle") { segment.endTriangle = static_cast<uint32_t>(triangle); }
                    else if (key == "source") { segment.source = static_cast<uint32_t>(triangle); }
                    else { segment.endSource = static_cast<uint32_t>(triangle); }
                } else if (key == "a") { segment.a = parseTomlFloat3(value); }
                else if (key == "b") { segment.b = parseTomlFloat3(value); }
            } else if (section == Section::view) {
                auto& view = document.views.back();
                if (key == "name") { view.name = parseTomlString(value); }
                else if (key == "show_origin") { view.scene.showOrigin = parseTomlBool(value); }
                else if (key == "show_grid") { view.scene.showGrid = parseTomlBool(value); }
                else if (key == "show_dimensions") { view.scene.showDimensions = parseTomlBool(value); }
                else if (key == "adaptive_points") { view.scene.adaptivePoints = parseTomlBool(value); }
                else if (key == "triangle_edge_xray") { view.scene.triangleEdgeXray = parseTomlBool(value); }
                else if (key == "up_axis") { view.scene.upAxis = parseSceneUpAxis(value); }
                else if (key == "master_vertex_point_size") { view.scene.masterVertexPointSize = parseTomlFloat(value); }
            } else if (section == Section::viewCamera) {
                assignCameraValue(document.views.back().scene.camera, key, value);
            } else if (section == Section::viewPart) {
                auto& part = document.views.back().parts.back();
                if (key == "analysis_index") { part.comparisonIndex = parseTomlInteger(value); }
                else if (key == "file_index") { part.fileIndex = parseTomlInteger(value); }
                else if (key == "group_index") { part.groupIndex = parseTomlInteger(value); }
                else if (key == "enabled") { part.enabled = parseTomlBool(value); }
                else if (key == "side") {
                    const auto side = parseTomlString(value);
                    if (side == "a") { part.side = ComparisonSide::a; }
                    else if (side == "b") { part.side = ComparisonSide::b; }
                    else { throw std::runtime_error("Unknown view analysis side."); }
                }
            } else if (section == Section::viewObject) {
                auto& object = document.views.back().objects.back();
                if (key == "kind") {
                    const auto kind = parseTomlString(value);
                    if (kind == "folder") { object.kind = ViewObjectKind::folder; }
                    else if (kind == "file") { object.kind = ViewObjectKind::file; }
                    else if (kind == "group") { object.kind = ViewObjectKind::group; }
                    else if (kind == "analysis") { object.kind = ViewObjectKind::comparison; }
                    else if (kind == "annotation") { object.kind = ViewObjectKind::annotation; }
                    else { throw std::runtime_error("Unknown view object kind."); }
                } else if (key == "index") { object.index = parseTomlInteger(value); }
                else if (key == "group_index") { object.groupIndex = parseTomlInteger(value); }
                else if (key == "diagnostic_index") {
                    const int index = parseTomlInteger(value);
                    if (index < 0) { throw std::runtime_error("Invalid view diagnostic index."); }
                    object.settings.diagnosticIndex = static_cast<size_t>(index);
                }
                else if (key == "selection_order") { object.settings.selectionOrder = parseTomlInteger(value); }
                else if (key.starts_with("analysis_") || key.starts_with("quality_") || key == "topology_mode"
                    || key.starts_with("duplicate_") || key.starts_with("show_duplicate_")
                    || key == "degenerate_triangles_enabled" || key == "show_degenerate_triangles"
                    || key == "needle_threshold_ratio" || key == "cap_min_angle_degrees"
                    || key == "intersection_pair_limit" || key == "intersection_candidate_limit"
                    || key == "self_intersections_enabled" || key == "self_intersections_auto_update" || key == "show_self_intersections"
                    || key == "diagnostic_category" || key == "diagnostic_side") {
                    SceneComparisonRecord comparison;
                    comparison.settings = object.settings.comparison;
                    assignComparisonValue(comparison, key, value);
                    object.settings.comparison = comparison.settings;
                } else {
                    SceneGroupRecord group;
                    group.settings = object.settings.appearance;
                    assignSceneGroupValue(group, key, value);
                    object.settings.appearance = group.settings;
                }
            } else if (section == Section::camera) {
                assignCameraValue(*document.camera, key, value);
            } else if (section == Section::comparison) {
                assignComparisonValue(document.comparisons.back(), key, value);
            } else if (section == Section::comparisonA || section == Section::comparisonB) {
                auto& comparison = document.comparisons.back();
                auto& part = (section == Section::comparisonA ? comparison.a : comparison.b).back();
                if (key == "file_index") { part.fileIndex = parseTomlInteger(value); }
                else if (key == "group_index") { part.groupIndex = parseTomlInteger(value); }
                else if (key == "name") { part.name = parseTomlString(value); }
                else if (key == "enabled") { part.enabled = parseTomlBool(value); }
            } else if (section == Section::file) {
                assignSceneFileValue(document.files.back(), key, value);
            } else if (section == Section::group) {
                assignSceneGroupValue(document.files.back().groups.back(), key, value);
            } else {
                assignSceneNodeValue(document.nodes.back(), key, value);
            }
        } catch (const std::exception& exception) {
            throw std::runtime_error(
                pathToUtf8(scenePath)
                + ":"
                + std::to_string(lineNumber)
                + ": "
                + exception.what());
        }
    }

    // Older scenes used one switch for both overlays, including saved views.
    if (sceneVersion < 10) {
        document.comparison.showWinding = document.comparison.showNonManifold;
        for (auto& comparison : document.comparisons) { comparison.settings.showWinding = comparison.settings.showNonManifold; }
        for (auto& view : document.views) {
            for (auto& object : view.objects) { object.settings.comparison.showWinding = object.settings.comparison.showNonManifold; }
        }
    }

    if (document.camera) { document.camera = normalizedSceneCamera(*document.camera); }
    for (auto& view : document.views) { view.scene.camera = normalizedSceneCamera(view.scene.camera); }

    for (const auto& file : document.files) {
        if (file.path.empty()) {
            throw std::runtime_error("Scene contains a file entry without a path.");
        }
    }

    for (size_t nodeIndex = 0; nodeIndex < document.nodes.size(); ++nodeIndex) {
        const auto& node = document.nodes[nodeIndex];
        if (node.parentIndex >= static_cast<int>(nodeIndex)) {
            throw std::runtime_error("Scene node parent must appear before its child.");
        }
        if (node.kind == SceneNodeKind::file
            && (node.fileIndex < 0 || node.fileIndex >= static_cast<int>(document.files.size()))) {
            throw std::runtime_error("Scene file node references an invalid file index.");
        }
        if (node.kind == SceneNodeKind::group) {
            if (node.fileIndex < 0 || node.fileIndex >= static_cast<int>(document.files.size())) {
                throw std::runtime_error("Scene group node references an invalid file index.");
            }

            const auto& file = document.files[static_cast<size_t>(node.fileIndex)];
            if (node.groupIndex < 0 || node.groupIndex >= static_cast<int>(file.groups.size())) {
                throw std::runtime_error("Scene group node references an invalid group index.");
            }
        }
    }

    for (size_t i = 0; i < document.annotations.size(); ++i) {
        auto& item = document.annotations[i];
        if (item.section) { item.section = normalizedCrossSectionSettings(*item.section, item.targets.size()); }
        else { validateAnnotationGeometry(annotationDrafts[i]); }
        item.geometry = item.section ? AnnotationGeometryOwner{} : shareAnnotationGeometry(std::move(annotationDrafts[i]));
        item.settings = normalizedAnnotationSettings(std::move(item.settings));
        if (!item.section && item.targets.size() != item.geometry->sources.size()) { throw std::runtime_error("Invalid annotation source count."); }
        for (const auto& target : item.targets) {
            if (target.fileIndex == -1 && target.groupIndex == -1) { continue; }
            if (target.fileIndex < 0 || static_cast<size_t>(target.fileIndex) >= document.files.size()
                || target.groupIndex < 0 || static_cast<size_t>(target.groupIndex) >= document.files[static_cast<size_t>(target.fileIndex)].groups.size()) {
                throw std::runtime_error("Annotation references an invalid source part.");
            }
        }
        if (!item.targets.empty() && item.targets.front() != SceneAnnotationTarget{item.fileIndex, item.groupIndex}) {
            throw std::runtime_error("Invalid annotation primary source.");
        }
        if (item.fileIndex == -1 && item.groupIndex == -1) { continue; }
        if (item.fileIndex < 0 || static_cast<size_t>(item.fileIndex) >= document.files.size()
            || item.groupIndex < 0 || static_cast<size_t>(item.groupIndex) >= document.files[static_cast<size_t>(item.fileIndex)].groups.size()) {
            throw std::runtime_error("Annotation references an invalid source part.");
        }
    }
    // Migrate v2-v4 membership into one object, then discard legacy input fields.
    SceneComparisonRecord legacy;
    legacy.name = "Analysis 1";
    legacy.settings = normalizedComparisonSettings(document.comparison);
    for (size_t f = 0; f < document.files.size(); ++f) {
        auto& file = document.files[f];
        for (size_t g = 0; g < file.groups.size(); ++g) {
            auto& group = file.groups[g];
            const SceneComparisonPartRecord part{static_cast<int>(f), static_cast<int>(g),
                pathToUtf8(file.path.filename()) + " / " + group.name};
            if (group.settings.comparison.a) { legacy.a.push_back(part); }
            if (group.settings.comparison.b) { legacy.b.push_back(part); }
            group.settings.comparison = {};
        }
    }
    if (document.comparisons.empty() && (!legacy.a.empty() || !legacy.b.empty()
        || document.comparison != ComparisonSettings{})) {
        document.comparisons.push_back(std::move(legacy));
    }
    document.comparison = {};
    for (auto& comparison : document.comparisons) {
        if (comparison.name.empty()) { comparison.name = "Analysis"; }
        comparison.settings = normalizedComparisonSettings(comparison.settings);
        if (comparison.translation && !std::all_of(comparison.translation->begin(), comparison.translation->end(), [](float v) { return std::isfinite(v); })) {
            comparison.translation = std::array<float, 3>{};
        }
        for (auto* members : {&comparison.a, &comparison.b}) {
            for (const auto& part : *members) {
                if (part.fileIndex == -1 && part.groupIndex == -1) { continue; }
                if (part.fileIndex < 0 || static_cast<size_t>(part.fileIndex) >= document.files.size()
                    || part.groupIndex < 0 || static_cast<size_t>(part.groupIndex)
                        >= document.files[static_cast<size_t>(part.fileIndex)].groups.size()) {
                    throw std::runtime_error("Analysis references an invalid source part.");
                }
            }
            std::sort(members->begin(), members->end(), [](const auto& a, const auto& b) {
                return std::tie(a.fileIndex, a.groupIndex, a.name) < std::tie(b.fileIndex, b.groupIndex, b.name);
            });
            members->erase(std::unique(members->begin(), members->end(), [](const auto& a, const auto& b) {
                return a.fileIndex == b.fileIndex && a.groupIndex == b.groupIndex
                    && (a.fileIndex >= 0 || a.name == b.name);
            }), members->end());
        }
    }
    return document;
}

void writeSceneDocument(const std::filesystem::path& scenePath, const SceneDocument& document, bool overwrite)
{
    // Serialize before touching the destination. Relative paths use its final location.
    std::ostringstream stream;
    stream.exceptions(std::ios::badbit | std::ios::failbit);

    stream << "# woby scene\n";
    stream << "version = 24\n";
    if (document.coordinateOrigin) {
        for (double v : *document.coordinateOrigin) { if (!std::isfinite(v)) { throw std::runtime_error("Non-finite scene origin."); } }
        stream << "coordinate_origin = "; writeTomlFloat3(stream, *document.coordinateOrigin); stream << '\n';
    }
    stream << "master_vertex_point_size = ";
    writeTomlFloat(stream, document.masterVertexPointSize);
    stream << "\n";
    stream << "show_origin = " << (document.showOrigin ? "true" : "false") << "\n";
    stream << "show_grid = " << (document.showGrid ? "true" : "false") << "\n";
    stream << "adaptive_points = " << (document.adaptivePoints ? "true" : "false") << "\n";
    stream << "triangle_edge_xray = " << (document.triangleEdgeXray ? "true" : "false") << "\n";
    stream << "show_dimensions = " << (document.showDimensions ? "true" : "false") << "\n";
    stream << "up_axis = \"" << sceneUpAxisName(document.upAxis) << "\"\n\n";

    if (document.camera) {
        stream << "[camera]\n";
        writeCamera(stream, *document.camera);
    }

    for (const auto& file : document.files) {
        const std::filesystem::path storedModelPath = sceneStoredPath(scenePath, file.path);
        stream << "\n[[files]]\n";
        const auto encodedPath = storedModelPath.generic_u8string();
        const std::string pathText(reinterpret_cast<const char*>(encodedPath.data()), encodedPath.size());
        stream << "path = \"" << escapeTomlString(pathText) << "\"\n";
        if (!file.importerId.empty()) {
            stream << "importer_id = \"" << escapeTomlString(file.importerId) << "\"\n";
        }
        if (file.coordinateOrigin) {
            for (double v : *file.coordinateOrigin) { if (!std::isfinite(v)) { throw std::runtime_error("Non-finite mesh origin."); } }
            stream << "coordinate_origin = "; writeTomlFloat3(stream, *file.coordinateOrigin); stream << '\n';
        }
        stream << "analysis_mode = \"" << analysisModeName(file.settings.analysisMode) << "\"\n";
        stream << "visible = " << (file.settings.visible ? "true" : "false") << "\n";
        stream << "scale = ";
        writeTomlFloat(stream, file.settings.scale);
        stream << "\n";
        stream << "opacity = ";
        writeTomlFloat(stream, file.settings.opacity);
        stream << "\n";
        stream << "translation = ";
        writeTomlFloat3(stream, file.settings.translation);
        stream << "\n";
        stream << "rotation_degrees = ";
        writeTomlFloat3(stream, file.settings.rotationDegrees);
        stream << "\n";
        stream << "vertex_size_scale = ";
        writeTomlFloat(stream, file.vertexSizeScale);
        stream << "\n";

        for (const auto& group : file.groups) {
            stream << "\n[[files.groups]]\n";
            stream << "name = \"" << escapeTomlString(group.name) << "\"\n";
            stream << "primitive = \"" << (group.pointGroup ? "points" : group.lineGroup ? "lines" : "triangles") << "\"\n";
            writeAppearance(stream, group.settings);
        }
    }

    for (const auto& node : document.nodes) {
        stream << "\n[[nodes]]\n";
        stream << "kind = \"" << sceneNodeKindName(node.kind) << "\"\n";
        stream << "name = \"" << escapeTomlString(node.name) << "\"\n";
        stream << "parent = " << node.parentIndex << "\n";
        stream << "file_index = " << node.fileIndex << "\n";
        stream << "group_index = " << node.groupIndex << "\n";
        stream << "visible = " << (node.settings.visible ? "true" : "false") << "\n";
        stream << "scale = ";
        writeTomlFloat(stream, node.settings.scale);
        stream << "\n";
        stream << "opacity = ";
        writeTomlFloat(stream, node.settings.opacity);
        stream << "\n";
        stream << "translation = ";
        writeTomlFloat3(stream, node.settings.translation);
        stream << "\n";
        stream << "rotation_degrees = ";
        writeTomlFloat3(stream, node.settings.rotationDegrees);
        stream << "\n";
    }
    for (const auto& item : document.annotations) {
        if (!item.section) { validateAnnotationGeometry(*item.geometry); }
        stream << "\n[[annotations]]\n";
        stream << "name = \"" << escapeTomlString(item.settings.name) << "\"\n";
        stream << "note = \"" << escapeTomlString(item.settings.note) << "\"\n";
        stream << "target_name = \"" << escapeTomlString(item.targetName) << "\"\n";
        stream << "file_index = " << item.fileIndex << "\ngroup_index = " << item.groupIndex << "\n";
        stream << "visible = " << (item.settings.visible ? "true" : "false") << "\n";
        stream << "locked = " << (item.settings.locked ? "true" : "false") << "\n";
        stream << "width = "; writeTomlFloat(stream, item.settings.width); stream << "\n";
        stream << "color = "; writeTomlFloat4(stream, item.settings.color); stream << "\n";
        if (item.section) {
            const auto s = normalizedCrossSectionSettings(*item.section, item.targets.size());
            stream << "shape = \"section\"\nsection_a = "; writeTomlFloat3(stream, s.a);
            stream << "\nsection_b = "; writeTomlFloat3(stream, s.b);
            stream << "\nsection_lift = "; writeTomlFloat(stream, s.lift);
            stream << "\nsection_up = \"" << (s.upAxis == SceneUpAxis::z ? "z" : "y") << "\"\n";
            stream << "section_plane = " << (s.showPlane ? "true" : "false") << "\n";
            stream << "section_connections = " << (s.showConnections ? "true" : "false") << "\n";
            stream << "section_differences = " << (s.showDifferences ? "true" : "false") << "\n";
            stream << "section_face_on = " << (s.faceOn ? "true" : "false") << "\n";
            stream << "section_reference = " << s.reference << "\nsection_compared = " << s.compared << "\n";
            stream << "section_visibility = [";
            for (size_t i = 0; i < s.sourceVisible.size(); ++i) { if (i) { stream << ", "; } stream << (s.sourceVisible[i] ? 1 : 0); }
            stream << "]\n";
            for (const auto& target : item.targets) {
                stream << "\n[[annotations.sources]]\nfile_index = " << target.fileIndex << "\ngroup_index = " << target.groupIndex << "\n";
            }
            continue;
        }
        stream << "shape = \"" << (item.geometry->shape == AnnotationShape::line ? "line" : "rectangle") << "\"\n";
        stream << "fingerprint = \"" << escapeTomlString(item.geometry->fingerprint) << "\"\n";
        stream << "homogeneous_depth = " << (item.geometry->homogeneousDepth ? "true" : "false") << "\n";
        const auto array = [&](const char* key, const auto& values) {
            stream << key << " = [";
            for (size_t i = 0; i < values.size(); ++i) { if (i) { stream << ", "; } writeTomlFloat(stream, values[i]); }
            stream << "]\n";
        };
        array("projector", item.geometry->projector); array("start", item.geometry->start); array("end", item.geometry->end);
        if (item.targets.size() != item.geometry->sources.size()) { throw std::runtime_error("Invalid annotation source count."); }
        for (size_t i = 0; i < item.geometry->sources.size(); ++i) {
            const auto& source = item.geometry->sources[i];
            stream << "\n[[annotations.sources]]\nfile_index = " << item.targets[i].fileIndex
                << "\ngroup_index = " << item.targets[i].groupIndex << "\n";
            stream << "fingerprint = \"" << escapeTomlString(source.fingerprint) << "\"\n";
            array("projector", source.projector);
            array("to_primary", source.toPrimary);
        }
        for (const auto& segment : item.geometry->segments) {
            stream << "\n[[annotations.segments]]\ntriangle = " << segment.triangle << "\n";
            if (segment.endTriangle) { stream << "end_triangle = " << *segment.endTriangle << "\n"; }
            if (!item.geometry->sources.empty()) { stream << "source = " << segment.source << "\n"; }
            if (segment.endSource) { stream << "end_source = " << *segment.endSource << "\n"; }
            array("a", segment.a); array("b", segment.b);
        }
    }
    for (const auto& record : document.comparisons) {
        stream << "\n[[analyses]]\n";
        stream << "name = \"" << escapeTomlString(record.name) << "\"\n";
        if (record.translation) {
            stream << "translation = "; writeTomlFloat3(stream, *record.translation); stream << "\n";
        }
        writeComparisonSettings(stream, record.settings);

        for (const auto side : {ComparisonSide::a, ComparisonSide::b}) {
            for (const auto& part : side == ComparisonSide::a ? record.a : record.b) {
                stream << (side == ComparisonSide::a ? "\n[[analyses.a]]\n" : "\n[[analyses.b]]\n");
                stream << "file_index = " << part.fileIndex << "\n";
                stream << "group_index = " << part.groupIndex << "\n";
                stream << "name = \"" << escapeTomlString(part.name) << "\"\n";
                stream << "enabled = " << (part.enabled ? "true" : "false") << "\n";
            }
        }
    }
    for (const auto& view : document.views) {
        stream << "\n[[views]]\nname = \"" << escapeTomlString(view.name) << "\"\n";
        stream << "show_origin = " << (view.scene.showOrigin ? "true" : "false") << "\n";
        stream << "show_grid = " << (view.scene.showGrid ? "true" : "false") << "\n";
        stream << "adaptive_points = " << (view.scene.adaptivePoints ? "true" : "false") << "\n";
        stream << "triangle_edge_xray = " << (view.scene.triangleEdgeXray ? "true" : "false") << "\n";
        stream << "show_dimensions = " << (view.scene.showDimensions ? "true" : "false") << "\n";
        stream << "up_axis = \"" << sceneUpAxisName(view.scene.upAxis) << "\"\n";
        stream << "master_vertex_point_size = "; writeTomlFloat(stream, view.scene.masterVertexPointSize);
        stream << "\n[views.camera]\n";
        writeCamera(stream, view.scene.camera);
        for (const auto& object : view.objects) {
            const char* kind = "group";
            switch (object.kind) {
            case ViewObjectKind::folder: kind = "folder"; break;
            case ViewObjectKind::file: kind = "file"; break;
            case ViewObjectKind::group: break;
            case ViewObjectKind::comparison: kind = "analysis"; break;
            case ViewObjectKind::annotation: kind = "annotation"; break;
            }
            stream << "\n[[views.objects]]\nkind = \"" << kind << "\"\n";
            stream << "index = " << object.index << "\ngroup_index = " << object.groupIndex << "\n";
            stream << "selection_order = " << object.settings.selectionOrder << "\n";
            writeAppearance(stream, object.settings.appearance);
            if (object.kind == ViewObjectKind::comparison) {
                if (object.settings.diagnosticIndex) {
                    stream << "diagnostic_index = " << *object.settings.diagnosticIndex << "\n";
                }
                writeComparisonSettings(stream, object.settings.comparison);
            }
        }
        for (const auto& part : view.parts) {
            stream << "\n[[views.parts]]\nanalysis_index = " << part.comparisonIndex << "\n";
            stream << "file_index = " << part.fileIndex << "\ngroup_index = " << part.groupIndex << "\n";
            stream << "side = \"" << (part.side == ComparisonSide::a ? "a" : "b") << "\"\n";
            stream << "enabled = " << (part.enabled ? "true" : "false") << "\n";
        }
    }
    const auto contents = stream.str();
    // An exclusively created sibling directory owns the temporary file. Both the
    // file and destination are on the same filesystem, including on Windows.
    std::filesystem::path temporaryDirectory;
    std::random_device random;
    for (int attempt = 0; attempt < 32; ++attempt) {
        auto candidate = scenePath.parent_path() / (".woby-save-" + std::to_string(random())
            + "-" + std::to_string(random()));
        if (std::filesystem::create_directory(candidate)) {
            temporaryDirectory = std::move(candidate);
            break;
        }
    }
    if (temporaryDirectory.empty()) {
        throw std::runtime_error("Cannot create a temporary scene file.");
    }
    const auto temporaryPath = temporaryDirectory / "scene.tmp";
    try {
        std::ofstream output;
        output.exceptions(std::ios::badbit | std::ios::failbit);
        output.open(temporaryPath, std::ios::binary | std::ios::trunc);
        output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
        output.flush();
        output.close();
#ifdef _WIN32
        if (!MoveFileExW(temporaryPath.c_str(), scenePath.c_str(), overwrite ? MOVEFILE_REPLACE_EXISTING : 0)) {
            const auto code = GetLastError();
            const auto error = code == ERROR_FILE_EXISTS || code == ERROR_ALREADY_EXISTS
                ? std::make_error_code(std::errc::file_exists)
                : std::error_code(static_cast<int>(code), std::system_category());
            throw std::filesystem::filesystem_error("Cannot install saved scene", scenePath, error);
        }
#else
        if (overwrite) {
            std::filesystem::rename(temporaryPath, scenePath);
        } else if (::link(temporaryPath.c_str(), scenePath.c_str()) != 0) {
            throw std::filesystem::filesystem_error("Cannot install saved scene", scenePath,
                std::error_code(errno, std::generic_category()));
        }
#endif
    } catch (...) {
        std::error_code ignored;
        std::filesystem::remove(temporaryPath, ignored);
        std::filesystem::remove(temporaryDirectory, ignored);
        throw;
    }
    // Cleanup failure cannot turn an already committed save into a failed save.
    std::error_code ignored;
    std::filesystem::remove(temporaryPath, ignored);
    std::filesystem::remove(temporaryDirectory, ignored);
}

} // namespace woby
