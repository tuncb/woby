#include "comparison_scene.h"
#include "math_utils.h"
#include "scene_pick.h"
#include "scene_queries.h"
#include "point_cloud.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace woby {
namespace {
using Point = std::array<double, 3>;
using Clip = std::array<double, 4>;

PickMatrix identity()
{
    return woby::identityMatrix();
}
PickMatrix compose(const PickMatrix& parent, const PickMatrix& child)
{
    // Compose a child transform in its parent's coordinates.
    return woby::multiplyMatrices(parent, child);
}
template<typename Scalar>
Clip transform(const std::array<Scalar, 16>& m, const Clip& p)
{
    Clip result{};
    for (size_t row = 0; row < 4; ++row) {
        for (size_t column = 0; column < 4; ++column) { result[row] += m[column * 4 + row] * p[column]; }
    }
    return result;
}
std::array<double, 16> composeDouble(const PickMatrix& parent, const PickMatrix& child)
{
    std::array<double, 16> result{};
    for (size_t column = 0; column < 4; ++column) {
        for (size_t row = 0; row < 4; ++row) {
            for (size_t k = 0; k < 4; ++k) {
                result[column * 4 + row] += static_cast<double>(child[k * 4 + row]) * parent[column * 4 + k];
            }
        }
    }
    return result;
}
Point position(const PickMatrix& m, const Point& p)
{
    const auto q = transform(m, {p[0], p[1], p[2], 1});
    return {q[0] / q[3], q[1] / q[3], q[2] / q[3]};
}
Point subtract(const Point& a, const Point& b) { return {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
Point cross(const Point& a, const Point& b)
{
    return {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
}
double dot(const Point& a, const Point& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
bool selected(const UiState& state, SceneObjectId id)
{
    return std::find(state.selectedSceneObjects.begin(), state.selectedSceneObjects.end(), id) != state.selectedSceneObjects.end();
}

void appendGroup(std::vector<ScenePickPart>& parts, const UiState& state, size_t fileIndex,
    size_t groupIndex, const PickMatrix& parent, float opacity, bool parentSelected, bool includeHidden)
{
    if (fileIndex >= state.files.size()) { return; }
    const auto& file = state.files[fileIndex];
    if (groupIndex >= meshGeometry(file.mesh).nodes.size() || groupIndex >= file.groupSettings.size()) { return; }
    const auto& group = file.groupSettings[groupIndex];
    const auto& node = meshGeometry(file.mesh).nodes[groupIndex];
    opacity *= group.opacity;
    if (!includeHidden && (!group.visible || (opacity <= 0.0f && !group.showVertices)
        || (node.pointIndexCount ? !group.showVertices : (!node.lineIndexCount && !group.showSolidMesh && !group.showTriangles && !group.showVertices)))) { return; }
    PickMatrix local;
    groupTransformMatrix(group, local.data());
    ScenePickPart part;
    part.fileIndex = fileIndex; part.groupIndex = groupIndex;
    part.sourceMesh = true;
    part.objectId = group.objectId;
    part.mesh = &file.mesh;
    part.indexOffset = node.indexOffset;
    part.indexCount = node.indexCount;
    part.lineIndexOffset = node.lineIndexOffset;
    part.lineIndexCount = node.lineIndexCount;
    part.pointIndexOffset = node.pointIndexOffset;
    part.pointIndexCount = node.pointIndexCount;
    part.lineWidth = node.lineIndexCount ? group.lines.width : 0;
    part.model = compose(parent, local);
    if (group.localBoundsValid) { part.bounds = group.localBounds; }
    part.solid = node.indexCount && group.showSolidMesh;
    part.edges = node.lineIndexCount || (node.indexCount && group.showTriangles);
    part.edgeXray = node.lineIndexCount ? !group.lines.depthTest : state.triangleEdgeXray;
    part.vertices = group.showVertices && postLoadReady(file);
    if (!includeHidden && !postLoadReady(file) && !node.lineIndexCount
        && (node.pointIndexCount || (!group.showSolidMesh && !group.showTriangles))) { return; }
    if (!includeHidden && !postLoadGroupDrawable(file, group)) { return; }
    part.opacity = opacity;
    part.pointSize = std::round(std::clamp(state.masterVertexPointSize * file.vertexSizeScale * group.vertexSizeScale,
        minVertexPointSize, maxVertexPointSize));
    part.selected = parentSelected || selected(state, group.objectId);
    parts.push_back(part);
}

void appendNode(std::vector<ScenePickPart>& parts, const UiState& state, const UiSceneNode& node,
    const PickMatrix& parent, float opacity, bool parentSelected, bool includeHidden)
{
    const bool nodeSelected = parentSelected || selected(state, node.objectId);
    if (node.kind == UiSceneNodeKind::group) {
        appendGroup(parts, state, node.fileIndex, node.groupIndex, parent, opacity, nodeSelected, includeHidden);
        return;
    }
    PickMatrix local;
    if (node.kind == UiSceneNodeKind::folder) {
        if (!includeHidden && (!node.settings.visible || !postLoadNodeDrawable(state, node))) { return; }
        opacity *= node.settings.opacity;
        sceneNodeTransformMatrix(node.settings, local.data());
    } else {
        if (node.fileIndex >= state.files.size()) { return; }
        const auto& file = state.files[node.fileIndex];
        if (!includeHidden && !file.fileSettings.visible) { return; }
        opacity *= file.fileSettings.opacity;
        fileTransformMatrix(file.fileSettings, local.data());
    }
    const auto model = compose(parent, local);
    if (node.kind == UiSceneNodeKind::file && node.children.empty()) {
        for (size_t i = 0; i < state.files[node.fileIndex].groupSettings.size(); ++i) {
            appendGroup(parts, state, node.fileIndex, i, model, opacity, nodeSelected, includeHidden);
        }
    } else {
        for (const auto& child : node.children) { appendNode(parts, state, child, model, opacity, nodeSelected, includeHidden); }
    }
}

bool intersectsBounds(const Bounds& bounds, const Point& origin, const Point& direction)
{
    double near = 0, far = std::numeric_limits<double>::infinity();
    for (size_t axis = 0; axis < 3; ++axis) {
        if (direction[axis] == 0) {
            if (origin[axis] < bounds.min[axis] || origin[axis] > bounds.max[axis]) { return false; }
        } else {
            double a = (bounds.min[axis] - origin[axis]) / direction[axis];
            double b = (bounds.max[axis] - origin[axis]) / direction[axis];
            if (a > b) { std::swap(a, b); }
            near = std::max(near, a);
            far = std::min(far, b);
            if (near > far) { return false; }
        }
    }
    return true;
}

bool intersectsPickBlock(const MeshAnnotationBlock& block, const Point& origin, const Point& direction)
{
    Bounds bounds;
    for (size_t axis = 0; axis < 3; ++axis) {
        const double scale = std::max({1.0, std::abs(double{block.minimum[axis]}),
            std::abs(double{block.maximum[axis]})});
        const float padding = static_cast<float>(scale * 1e-6);
        bounds.min[axis] = block.minimum[axis] - padding;
        bounds.max[axis] = block.maximum[axis] + padding;
    }
    return intersectsBounds(bounds, origin, direction);
}

std::optional<double> triangleHit(const Point& origin, const Point& direction, const std::array<Point, 3>& p, std::array<double,3>& barycentric)
{
    const auto a = subtract(p[1], p[0]), b = subtract(p[2], p[0]);
    const auto h = cross(direction, b);
    const double determinant = dot(a, h);
    const double scale = std::sqrt(dot(a, a) * dot(h, h));
    // Both faces are pickable: the scene renderer does not cull back faces.
    if (!std::isfinite(determinant) || std::abs(determinant) <= scale * 1e-12) { return {}; }
    const auto s = subtract(origin, p[0]);
    const double u = dot(s, h) / determinant;
    const auto q = cross(s, a);
    const double v = dot(direction, q) / determinant;
    const double t = dot(b, q) / determinant;
    if (u < -1e-9 || v < -1e-9 || u + v > 1.0 + 1e-9 || t < 0) { return {}; }
    barycentric = {1-u-v,u,v};
    return t;
}

double clipPlane(const Clip& p, size_t plane, bool homogeneous)
{
    switch (plane) {
    case 0: return p[3] + p[0];
    case 1: return p[3] - p[0];
    case 2: return p[3] + p[1];
    case 3: return p[3] - p[1];
    case 4: return homogeneous ? p[3] + p[2] : p[2];
    default: return p[3] - p[2];
    }
}
bool inside(const Clip& p, bool homogeneous)
{
    if (!std::all_of(p.begin(), p.end(), [](double value) { return std::isfinite(value); }) || p[3] <= 0) { return false; }
    for (size_t plane = 0; plane < 6; ++plane) { if (clipPlane(p, plane, homogeneous) < 0) { return false; } }
    return true;
}
Point screen(const Clip& p, const ScenePickView& view)
{
    return {(p[0] / p[3] * .5 + .5) * view.width, (.5 - p[1] / p[3] * .5) * view.height, p[2] / p[3]};
}
std::optional<double> edgeHit(Clip a, Clip b, const ScenePickView& view, PickPoint point, float width = 0)
{
    // Clip before the perspective divide, including edges crossing the near plane.
    for (size_t plane = 0; plane < 6; ++plane) {
        const double da = clipPlane(a, plane, view.homogeneousDepth), db = clipPlane(b, plane, view.homogeneousDepth);
        if (da < 0 && db < 0) { return {}; }
        if ((da < 0) != (db < 0)) {
            Clip cut;
            const double t = da / (da - db);
            for (size_t k = 0; k < 4; ++k) { cut[k] = a[k] + t * (b[k] - a[k]); }
            if (da < 0) { a = cut; } else { b = cut; }
        }
    }
    if (a[3] <= 0 || b[3] <= 0) { return {}; }
    const auto pa = screen(a, view), pb = screen(b, view);
    const double dx = pb[0] - pa[0], dy = pb[1] - pa[1];
    const double length = dx * dx + dy * dy;
    if (width > 0 && length < 1e-12) { return {}; }
    const double t = length > 0 ? std::clamp(((point[0] - pa[0]) * dx + (point[1] - pa[1]) * dy) / length, 0.0, 1.0) : 0;
    const double x = pa[0] + t * dx - point[0], y = pa[1] + t * dy - point[1];
    const double radius = std::max(3.0 * view.pixelScale, double(width) * .5);
    if (x * x + y * y > radius * radius) { return {}; }
    const double depth = pa[2] + t * (pb[2] - pa[2]);
    return std::isfinite(depth) ? std::optional<double>(depth) : std::nullopt;
}
void closest(std::optional<double>& best, std::optional<double> value)
{
    if (value && (!best || *value < *best)) { best = value; }
}
} // namespace

void beginScenePointer(ScenePointerGesture& gesture, PickPoint point, bool alt, bool toggle, bool selectionEnabled)
{
    gesture = {true, false, alt, toggle, point, selectionEnabled};
}
bool moveScenePointer(ScenePointerGesture& gesture, PickPoint point)
{
    const float dx = point[0] - gesture.start[0], dy = point[1] - gesture.start[1];
    if (gesture.active && dx * dx + dy * dy >= 16.0f) { gesture.dragging = true; }
    return gesture.active && gesture.dragging;
}
std::optional<SceneClick> endScenePointer(ScenePointerGesture& gesture, PickPoint point, bool allowed)
{
    moveScenePointer(gesture, point);
    const bool click = gesture.active && !gesture.dragging && !gesture.alt && allowed && gesture.selectionEnabled;
    const bool toggle = gesture.toggle;
    gesture = {};
    return click ? std::optional<SceneClick>({point, toggle}) : std::nullopt;
}

ScenePickView scenePickView(const SceneCamera& camera, SceneUpAxis upAxis, const Bounds& bounds,
    uint32_t width, uint32_t height, bool homogeneousDepth, float pixelScale)
{
    ScenePickView result;
    result.width = std::max(width, 1u);
    result.height = std::max(height, 1u);
    result.homogeneousDepth = homogeneousDepth;
    result.pixelScale = pixelScale;
    const float aspect = static_cast<float>(result.width) / static_cast<float>(result.height);
    const auto depth = cameraDepthRange(camera, bounds, upAxis);
    woby::lookAtMatrix(result.view.data(), cameraEye(camera, upAxis), cameraLookAt(camera), cameraUp(camera, upAxis));
    woby::perspectiveMatrix(result.projection.data(), cameraViewportFov(camera, aspect), aspect,
        depth.nearPlane, depth.farPlane, homogeneousDepth);
    // Build reversed Z directly; subtracting forward depth from 1 would retain
    // its rounding error. Both native backends use a [0, 1] clip volume.
    woby::perspectiveMatrix(result.renderProjection.data(), cameraViewportFov(camera, aspect), aspect,
        depth.farPlane, depth.nearPlane, false);
    return result;
}

std::vector<ScenePickPart> scenePickParts(const UiState& state, bool includeHidden)
{
    std::vector<ScenePickPart> result;
    scenePickParts(state, result, includeHidden);
    return result;
}

void scenePickParts(const UiState& state, std::vector<ScenePickPart>& result, bool includeHidden)
{
    result.clear();
    if (!state.sceneNodes.empty()) {
        for (const auto& node : state.sceneNodes) { appendNode(result, state, node, identity(), 1, false, includeHidden); }
    } else {
        for (size_t i = 0; i < state.files.size(); ++i) {
            const auto& file = state.files[i];
            if (!includeHidden && !file.fileSettings.visible) { continue; }
            PickMatrix model;
            fileTransformMatrix(file.fileSettings, model.data());
            for (size_t j = 0; j < file.groupSettings.size(); ++j) {
                appendGroup(result, state, i, j, model, file.fileSettings.opacity, selected(state, file.objectId), includeHidden);
            }
        }
    }
}

void appendComparisonPickParts(std::vector<ScenePickPart>& parts, const UiComparison& comparison,
    const ComparisonSettings& settings, const MeshComparison& result, bool isSelected)
{
    if (!comparison.settings.enabled) { return; }
    const bool original = settings.mode == ComparisonMode::original ||
        (settings.mode == ComparisonMode::distance && settings.distanceOnOriginal) ||
        (settings.mode == ComparisonMode::surfaceQuality && settings.quality.onOriginal);
    const auto& surface = original ? result.original : result.repaired;
    ScenePickPart part;
    part.objectId = comparison.objectId;
    // Distance display subdivides this same surface. Picking and dimensions
    // use its source triangles; no sampled geometry or identity indices exist.
    part.mesh = &surface.source;
    part.indexCount = meshGeometry(surface.source).indices.size();
    part.bounds = surface.source.bounds;
    woby::translationMatrix(part.model.data(), comparison.translation[0], comparison.translation[1], comparison.translation[2]);
    part.solid = true;
    part.edges = settings.showEdges;
    part.edgeXray = false;
    part.surfaceLessEqual = true;
    part.selected = isSelected;
    if (isUvAnalysis(settings.type) && settings.uvLinkedSelection) {
        for (const auto& node : meshGeometry(surface.source).nodes) {
            auto patch = part;
            patch.objectId = node.sourceObjectId ? node.sourceObjectId : comparison.objectId;
            patch.analysisId = comparison.objectId;
            patch.indexOffset = node.indexOffset; patch.indexCount = node.indexCount;
            patch.bounds.reset();
            parts.push_back(patch);
        }
        return;
    }
    parts.push_back(part);
    if (settings.mode == ComparisonMode::overlay) {
        auto overlay = part;
        overlay.mesh = &result.original.source;
        overlay.indexCount = meshGeometry(result.original.source).indices.size();
        overlay.bounds = result.original.source.bounds;
        overlay.solid = false;
        overlay.edges = true;
        overlay.edgeXray = true;
        parts.push_back(overlay);
    }
    const auto appendEdges = [&](std::span<const DiagnosticEdge> edges) {
        if (edges.empty()) { return; }
        auto lines = part;
        lines.mesh = nullptr;
        lines.solid = false;
        lines.edges = false;
        lines.edgeXray = true;
        lines.selected = false;
        lines.diagnosticEdges = edges;
        parts.push_back(lines);
    };
    if (settings.topologyInspection.nonManifoldVertices && settings.topologyInspection.showNonManifoldVertices) { appendEdges(surface.nonManifoldVertexMarkers); }
    if (settings.intersections.show && surface.intersections.phase == IntersectionPhase::complete) { appendEdges(surface.intersectionEdges); }
    if (settings.topologyInspection.fins && settings.topologyInspection.showFins) { appendEdges(surface.finEdges); }
    if (settings.topologyInspection.holes && settings.topologyInspection.showHoles) { appendEdges(surface.holeEdges); }
    if (settings.showBoundaries) { appendEdges(surface.topology.sources.empty() ? surface.diagnostics.boundaryEdges : surface.topologyBoundaries); }
    if (settings.showNonManifold) {
        appendEdges(surface.topology.sources.empty() ? surface.diagnostics.nonManifoldEdges : surface.topologyNonManifold);
    }
    if (settings.showWinding) {
        appendEdges(surface.topology.sources.empty() ? surface.diagnostics.inconsistentWindingEdges : surface.topologyWinding);
    }
}

SceneObjectId pickSceneObject(std::span<const ScenePickPart> parts, const ScenePickView& view, PickPoint point, SceneTriangleHit* detail)
{
    if (detail) { *detail = {}; }
    if (view.width == 0 || view.height == 0 || !std::isfinite(point[0]) || !std::isfinite(point[1]) ||
        point[0] < 0 || point[1] < 0 || point[0] >= view.width || point[1] >= view.height) { return invalidSceneObjectId; }
    PickMatrix inverse;
    // Inverting a combined float matrix can erase a tiny near distance next to
    // a large camera translation. Unproject in view space, then move to world
    // space with double intermediates to preserve the separation of ray points.
    woby::inverseMatrix(inverse.data(), view.projection.data());
    PickMatrix inverseView;
    woby::inverseMatrix(inverseView.data(), view.view.data());
    const double x = 2.0 * point[0] / view.width - 1.0, y = 1.0 - 2.0 * point[1] / view.height;
    const auto near = position(inverseView, position(inverse, {x, y, view.homogeneousDepth ? -1.0 : 0.0}));
    // With a very large far/near ratio, float projection coefficients can put
    // the far endpoint at infinity. Use an interior point to define the ray,
    // then check each hit against the renderer's clip volume.
    const auto middle = position(inverseView, position(inverse, {x, y, view.homogeneousDepth ? 0.0 : 0.5}));
    double depthBuffer = 1.0;
    SceneObjectId hit = invalidSceneObjectId;
    struct Candidate {
        const ScenePickPart* part;
        std::optional<double> surface, edge, point;
        SceneTriangleHit detail;
    };
    std::vector<Candidate> candidates;
    candidates.reserve(parts.size());
    const auto hiddenLineDepth = [](const ScenePickPart& part) {
        return part.sourceMesh && !part.lineIndexCount && !part.solid && part.edges
            && !part.edgeXray && part.opacity >= .999f;
    };
    const auto surface = [&](const Candidate& candidate) {
        const auto& part = *candidate.part;
        if (part.opacity > 0 && candidate.surface && (part.surfaceLessEqual ? *candidate.surface <= depthBuffer : *candidate.surface < depthBuffer)) {
            if (part.solid) {
                hit = part.objectId;
                if (detail) { *detail = candidate.detail; }
            }
            if (part.opacity >= .999f) { depthBuffer = *candidate.surface; }
        }
    };
    const auto edge = [&](const Candidate& candidate) {
        const auto& part = *candidate.part;
        if (part.opacity > 0 && candidate.edge && (part.edgeXray || *candidate.edge <= depthBuffer + 1e-7)) {
            if (detail && (detail->partId != part.objectId || detail->analysisId != part.analysisId)) { *detail = {}; }
            hit = part.objectId;
            if (part.lineIndexCount && !part.edgeXray && part.opacity >= .999f) { depthBuffer = *candidate.edge; }
        }
    };
    const auto vertex = [&](const Candidate& candidate) {
        const auto& part = *candidate.part;
        if (candidate.point && *candidate.point <= depthBuffer + 1e-7) {
            if (detail && (detail->partId != part.objectId || detail->analysisId != part.analysisId)) { *detail = {}; }
            hit = part.objectId;
            depthBuffer = *candidate.point;
        }
    };
    for (int layer = 0; layer < 3; ++layer) {
        candidates.clear();
        for (const auto& part : parts) {
            if (layer != (part.annotationOverlay ? 2 : part.lineIndexCount ? 1 : 0)) { continue; }
            if (part.objectId == invalidSceneObjectId || (part.opacity <= 0 && !part.vertices)) { continue; }
            // Keep the projection's near term when composing with translated
            // geometry; float composition otherwise rounds visible hits to the
            // cleared far depth and rejects them during CPU selection.
            const auto mvp = composeDouble(compose(part.model, view.view), view.projection);
            woby::inverseMatrix(inverse.data(), part.model.data());
            const auto origin = position(inverse, near), end = position(inverse, middle);
            const auto direction = subtract(end, origin);
            const bool testSurface = part.opacity > 0 && (part.solid || hiddenLineDepth(part)) && (!part.bounds || intersectsBounds(*part.bounds, origin, direction));
            if (!testSurface && !part.edges && !part.vertices && part.diagnosticEdges.empty()) { continue; }
            std::optional<double> surfaceDepth, edgeDepth, pointDepth;
            SceneTriangleHit surfaceHit;
            const auto clip = [&](const Point& p) { return transform(mvp, {p[0], p[1], p[2], 1}); };
            if (part.mesh) {
                const auto& mesh = *part.mesh;
                if (part.pointIndexCount && part.vertices) {
                    std::vector<uint32_t> candidatesAtCursor;
                    auto indices=scenePartIndices(part);
                    if (part.pointCloud) {
                        const auto reversed=compose(part.model,compose(view.view,view.renderProjection));
                        const float diameter=std::max(part.pointSize,6.0f*view.pixelScale);
                        const auto leaves=points::queryFootprints(*part.pointCloud,static_cast<uint32_t>(part.groupIndex),reversed,
                            view.width,view.height,diameter,{point[0],point[1],point[0],point[1]});
                        for (const auto& leaf:leaves.ranges) for (uint32_t i=leaf.begin;i<leaf.begin+leaf.count;++i)
                            candidatesAtCursor.push_back(part.pointCloud->sourceVertices[part.pointCloud->points[i].id-1]);
                        indices=candidatesAtCursor;
                    }
                    for (const auto index : indices) {
                        if (index >= meshGeometry(mesh).vertices.size()) { continue; }
                        const auto p = clip(meshPosition(mesh, index));
                        if (!inside(p, view.homogeneousDepth)) { continue; }
                        const auto xy = screen(p, view);
                        const double radius = std::max(part.pointSize * .5, 3.0 * view.pixelScale);
                        if (std::hypot(xy[0] - point[0], xy[1] - point[1]) <= radius) { closest(pointDepth, xy[2]); }
                    }
                }
                if (part.lineIndexCount) {
                    const auto indices = scenePartIndices(part);
                    for (size_t i = 0; i + 1 < indices.size(); i += 2) {
                        if (indices[i] >= meshGeometry(mesh).vertices.size() || indices[i+1] >= meshGeometry(mesh).vertices.size()) { continue; }
                        const auto a = clip(meshPosition(mesh, indices[i])), b = clip(meshPosition(mesh, indices[i+1]));
                        closest(edgeDepth, edgeHit(a, b, view, point, part.lineWidth));
                        if (part.vertices) {
                            for (const auto& p : {a, b}) {
                                if (!inside(p, view.homogeneousDepth)) { continue; }
                                const auto xy = screen(p, view);
                                const double radius = std::max(part.pointSize * .5, 3.0 * view.pixelScale);
                                if (std::hypot(xy[0]-point[0], xy[1]-point[1]) <= radius) { closest(pointDepth, xy[2]); }
                            }
                        }
                    }
                }
                const size_t begin = std::min(part.indexOffset, meshGeometry(mesh).indices.size());
                const size_t finish = begin + std::min(part.indexCount, meshGeometry(mesh).indices.size() - begin);
                const auto visitTriangle = [&](size_t i) {
                    std::array<Point, 3> triangle;
                    bool valid = true;
                    for (size_t k = 0; k < 3; ++k) {
                        const auto index = meshGeometry(mesh).indices[i + k];
                        if (index >= meshGeometry(mesh).vertices.size() || !finitePosition(meshGeometry(mesh).vertices[index].position)) { valid = false; break; }
                        const auto& p = meshGeometry(mesh).vertices[index].position;
                        triangle[k] = {p[0], p[1], p[2]};
                    }
                    if (!valid) { return; }
                    if (testSurface) {
                        std::array<double,3> barycentric{};
                        if (const auto t = triangleHit(origin, direction, triangle, barycentric)) {
                            const auto p = clip({origin[0] + *t * direction[0], origin[1] + *t * direction[1], origin[2] + *t * direction[2]});
                            if (inside(p, view.homogeneousDepth) && (!surfaceDepth || p[2]/p[3] < *surfaceDepth)) {
                                surfaceDepth = p[2]/p[3];
                                surfaceHit = {part.objectId,part.analysisId,(i-part.indexOffset)/3+1,barycentric};
                            }
                        }
                    }
                    if (part.edges || part.vertices) {
                        const std::array<Clip, 3> projected = {clip(triangle[0]), clip(triangle[1]), clip(triangle[2])};
                        for (size_t k = 0; k < 3; ++k) {
                            if (part.edges) { closest(edgeDepth, edgeHit(projected[k], projected[(k + 1) % 3], view, point)); }
                            if (part.vertices && inside(projected[k], view.homogeneousDepth)) {
                                const auto p = screen(projected[k], view);
                                const double dx = p[0] - point[0], dy = p[1] - point[1];
                                const double radius = std::max(part.pointSize * .5, 3.0 * view.pixelScale);
                                if (dx * dx + dy * dy <= radius * radius) { closest(pointDepth, p[2]); }
                            }
                        }
                    }
                };
                bool useBlocks = testSurface && !part.edges && !part.vertices && mesh.annotationCache
                    && mesh.annotationCache->vertexCount == meshGeometry(mesh).vertices.size()
                    && mesh.annotationCache->indexCount == meshGeometry(mesh).indices.size()
                    && mesh.annotationCache->vertexData == meshGeometry(mesh).vertices.data()
                    && mesh.annotationCache->indexData == meshGeometry(mesh).indices.data();
                if (useBlocks) {
                    useBlocks = std::any_of(meshGeometry(mesh).nodes.begin(), meshGeometry(mesh).nodes.end(), [&](const auto& node) {
                        return node.indexOffset == part.indexOffset && node.indexCount == part.indexCount;
                    });
                }
                if (useBlocks) {
                    for (const auto& block : mesh.annotationCache->blocks) {
                        if (block.begin < begin || block.end > finish || !intersectsPickBlock(block, origin, direction)) { continue; }
                        for (size_t i = block.begin; i + 2 < block.end; i += 3) { visitTriangle(i); }
                    }
                } else {
                    for (size_t i = begin; i + 2 < finish; i += 3) { visitTriangle(i); }
                }
            }
            for (const auto& line : part.diagnosticEdges) {
                closest(edgeDepth, edgeHit(clip({line.a[0], line.a[1], line.a[2]}),
                    clip({line.b[0], line.b[1], line.b[2]}), view, point));
            }
            candidates.push_back({&part, surfaceDepth, edgeDepth, pointDepth, surfaceHit});
        }
        if (layer == 0) {
            // Mirror the source renderer without traversing triangles per pass.
            for (const auto& candidate : candidates) {
                if (hiddenLineDepth(*candidate.part)) { surface(candidate); }
            }
            for (const bool opaque : {true, false}) {
                for (const auto& candidate : candidates) {
                    const auto& part = *candidate.part;
                    if (part.sourceMesh && part.solid && (part.opacity >= .999f) == opaque) { surface(candidate); }
                }
            }
            for (const auto& candidate : candidates) { if (candidate.part->sourceMesh) { edge(candidate); } }
            for (const auto& candidate : candidates) { if (candidate.part->sourceMesh) { vertex(candidate); } }
        }
        // Analysis overlays, imported lines, and annotations keep their existing
        // stable submission order after the source scene's opaque visibility.
        for (const auto& candidate : candidates) {
            if (layer == 0 && candidate.part->sourceMesh) { continue; }
            surface(candidate); edge(candidate); vertex(candidate);
        }
    }
    return hit;
}

std::span<const uint32_t> scenePartIndices(const ScenePickPart& part)
{
    if (!part.mesh) { return {}; }
    const auto& indices = part.pointIndexCount ? meshGeometry(*part.mesh).pointIndices : part.lineIndexCount ? meshGeometry(*part.mesh).lineIndices : meshGeometry(*part.mesh).indices;
    const auto begin = std::min(part.pointIndexCount ? part.pointIndexOffset : part.lineIndexCount ? part.lineIndexOffset : part.indexOffset, indices.size());
    const auto count = std::min(part.pointIndexCount ? part.pointIndexCount : part.lineIndexCount ? part.lineIndexCount : part.indexCount, indices.size() - begin);
    return std::span<const uint32_t>(indices).subspan(begin, count);
}

std::vector<SceneObjectId> sceneSelectionPath(const UiState& state, SceneObjectId id)
{
    std::vector<SceneObjectId> path;
    if (id == invalidSceneObjectId) { return path; }
    const auto visit = [&](const auto& self, const UiSceneNode& node) -> bool {
        path.push_back(node.objectId);
        if (node.objectId == id) { return true; }
        for (const auto& child : node.children) { if (self(self, child)) { return true; } }
        path.pop_back();
        return false;
    };
    for (const auto& node : state.sceneNodes) { if (visit(visit, node)) { break; } }
    return path;
}

std::vector<std::array<float, 3>> sceneSelectionLines(std::span<const ScenePickPart> parts)
{
    std::vector<std::array<float, 3>> lines;
    sceneSelectionLines(parts, lines);
    return lines;
}

void sceneSelectionLines(std::span<const ScenePickPart> parts, std::vector<std::array<float, 3>>& lines)
{
    lines.clear();
    for (const auto& part : parts) {
        if (!part.selected || !part.mesh || (part.indexCount == 0 && part.lineIndexCount == 0 && part.pointIndexCount == 0)) { continue; }
        auto bounds = part.bounds;
        if (!bounds) {
            const auto& mesh = *part.mesh;
            for (const auto index : scenePartIndices(part)) {
                if (index >= meshGeometry(mesh).vertices.size() || !finitePosition(meshGeometry(mesh).vertices[index].position)) { continue; }
                const auto& p = meshGeometry(mesh).vertices[index].position;
                if (!bounds) { bounds = Bounds{p, p, p, 0}; }
                for (size_t k = 0; k < 3; ++k) { bounds->min[k] = std::min(bounds->min[k], p[k]); bounds->max[k] = std::max(bounds->max[k], p[k]); }
            }
        }
        if (!bounds) { continue; }
        std::array<std::array<float, 3>, 8> corners;
        bool valid = true;
        for (size_t i = 0; i < corners.size(); ++i) {
            Point local;
            for (size_t k = 0; k < 3; ++k) { local[k] = (i & (size_t{1} << k)) ? bounds->max[k] : bounds->min[k]; }
            const auto p = position(part.model, local);
            for (size_t k = 0; k < 3; ++k) { corners[i][k] = static_cast<float>(p[k]); }
            valid = valid && finitePosition(corners[i]);
        }
        if (!valid) { continue; }
        for (size_t i = 0; i < corners.size(); ++i) {
            for (size_t k = 0; k < 3; ++k) {
                const size_t other = i ^ (size_t{1} << k);
                if (i < other) { lines.push_back(corners[i]); lines.push_back(corners[other]); }
            }
        }
    }
}
void uvProbeLines(std::span<const ScenePickPart> parts, const UiState& state,
    std::vector<std::array<float,3>>& lines, SceneQueryRuntime* queries)
{
    lines.clear();
    for (const auto& comparison : state.comparisons) {
        if (!comparison.settings.enabled || !comparison.settings.uvLinkedSelection || !comparison.uvProbe
            || comparison.uvProbe->signature != (queries ? updateSceneComparisonQuery(*queries, state, comparison.objectId).inputs.signature
                : comparisonGeometrySignature(state,comparison.objectId))) { continue; }
        const auto& probe = *comparison.uvProbe;
        for (const auto& part : parts) {
            if (part.objectId != probe.partId || (part.analysisId && part.analysisId != comparison.objectId)
                || !part.mesh || probe.triangle == 0 || probe.triangle > part.indexCount/3) { continue; }
            const auto offset = part.indexOffset+(probe.triangle-1)*3;
            if (offset+2 >= meshGeometry(*part.mesh).indices.size()) { continue; }
            std::array<Point,3> p;
            Point center{};
            for (size_t k=0;k<3;++k) {
                p[k] = position(part.model,meshPosition(*part.mesh,meshGeometry(*part.mesh).indices[offset+k]));
                for (size_t j=0;j<3;++j) { center[j] += p[k][j]*probe.barycentric[k]; }
            }
            double size = 0;
            for (size_t k=0;k<3;++k) {
                lines.push_back(renderPosition(p[k])); lines.push_back(renderPosition(p[(k+1)%3]));
                const auto edge = subtract(p[k],p[(k+1)%3]); size = std::max(size,std::sqrt(dot(edge,edge))*.025);
            }
            for (size_t k=0;k<3;++k) {
                auto a = center, b = center; a[k] -= size; b[k] += size;
                lines.push_back(renderPosition(a)); lines.push_back(renderPosition(b));
            }
        }
    }
}
} // namespace woby
