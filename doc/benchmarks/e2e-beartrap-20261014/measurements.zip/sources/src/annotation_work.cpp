#include "annotation_work.h"
#include <algorithm>
#include <stdexcept>

namespace woby {
void cancelAnnotationWork(const std::shared_ptr<AnnotationWork>& work)
{
    if (work) { work->cancel.request_stop(); }
}
void submitAnnotationWork(AnnotationExecutor& executor, const std::shared_ptr<AnnotationWork>& work)
{
    if (!executor.worker.joinable()) {
        executor.worker = std::jthread([&executor](std::stop_token stop) {
            for (;;) {
                std::shared_ptr<AnnotationWork> task;
                {
                    std::unique_lock lock(executor.mutex);
                    executor.wake.wait(lock, stop, [&] { return executor.pending != nullptr; });
                    if (stop.stop_requested()) { return; }
                    task = std::move(executor.pending);
                    executor.active = task;
                }
                std::stop_callback shutdown(stop, [&] { task->cancel.request_stop(); });
                try {
                    if (!task->cancel.stop_requested()) { task->compute(task->cancel.get_token()); }
                } catch (const std::exception& error) { task->error = error.what(); }
                catch (...) { task->error = "Annotation computation failed."; }
                task->compute = {}; // Release owned inputs before advertising completion.
                task->done.store(true, std::memory_order_release);
                {
                    std::lock_guard lock(executor.mutex);
                    executor.active.reset();
                }
            }
        });
    }
    {
        std::lock_guard lock(executor.mutex);
        cancelAnnotationWork(executor.active);
        cancelAnnotationWork(executor.pending);
        executor.pending = work;
    }
    executor.wake.notify_one();
}
AnnotationPartsSnapshot snapshotAnnotationParts(std::span<const ScenePickPart> parts)
{
    AnnotationPartsSnapshot result;
    std::vector<const Mesh*> originals;
    size_t copyBytes = 0;
    // Check the whole request before copying: many small parts must not turn
    // the bounded fallback into an unbounded UI-thread scene copy.
    for (const auto& part : parts) {
        if (!part.mesh || std::find(originals.begin(), originals.end(), part.mesh) != originals.end()) { continue; }
        originals.push_back(part.mesh);
        if (part.mesh->draft) {
            copyBytes += meshGeometry(*part.mesh).vertices.size() * sizeof(Vertex) + meshGeometry(*part.mesh).indices.size() * sizeof(uint32_t);
            if (copyBytes > annotationInlineSnapshotBytes) { throw std::runtime_error("Annotation geometry is still being prepared."); }
        }
    }
    originals.clear();
    for (auto part : parts) {
        if (!part.mesh) { continue; }
        const auto found = std::find(originals.begin(), originals.end(), part.mesh);
        size_t index = static_cast<size_t>(found - originals.begin());
        if (found == originals.end()) {
            const auto& mesh = *part.mesh;
            if (mesh.draft && meshGeometry(mesh).indices.size() >= 50000 * 3) {
                throw std::runtime_error("Annotation geometry is still being prepared.");
            }
            auto owner = std::make_shared<Mesh>();
            if (mesh.draft) {
                // Keep the bounded fallback for small, unfinished test/tool
                // meshes. Published scene meshes always take the shared path.
                auto& geometry = editMeshGeometry(*owner);
                geometry.vertices = meshGeometry(mesh).vertices;
                geometry.indices = meshGeometry(mesh).indices;
                geometry.nodes = meshGeometry(mesh).nodes;
            } else {
                *owner = mesh;
            }
            publishMeshGeometry(*owner);
            owner->sourceData.reset();
            owner->duplicateInput.reset();
            owner->uvQuality.reset();
            owner->freeform.reset();
            originals.push_back(part.mesh); result.owners.push_back(std::move(owner));
        }
        part.mesh = result.owners[index].get();
        part.diagnosticEdges = {}; // No borrowed scene storage crosses the worker boundary.
        result.parts.push_back(part);
    }
    return result;
}
AnnotationWorkIdentity annotationWorkIdentity(const UiState& state)
{
    AnnotationWorkIdentity result;
    result.owner = &state; result.generation = state.sceneGeneration;
    result.geometry = state.revisions.geometry; result.visibility = state.revisions.visibility;
    result.annotations = state.revisions.annotations; result.upAxis = state.upAxis;
    result.camera = state.camera; result.bounds = state.sceneBounds; result.selection = state.selectedSceneObjects;
    for (const auto& file : state.files) {
        const auto& mesh = file.mesh;
        result.sources.push_back({mesh.contentRevision, file.objectId, meshGeometry(mesh).vertices.data(), meshGeometry(mesh).indices.data(), meshGeometry(mesh).vertices.size(), meshGeometry(mesh).indices.size(), mesh.annotationCache});
    }
    return result;
}
bool annotationWorkCurrent(const AnnotationWorkIdentity& identity, const UiState& state, bool selection)
{
    if (identity.owner != &state || identity.generation != state.sceneGeneration
        || identity.geometry != state.revisions.geometry || identity.visibility != state.revisions.visibility
        || identity.annotations != state.revisions.annotations || identity.upAxis != state.upAxis
        || identity.camera != state.camera || identity.bounds.min != state.sceneBounds.min || identity.bounds.max != state.sceneBounds.max
        || identity.bounds.center != state.sceneBounds.center || identity.bounds.radius != state.sceneBounds.radius
        || (selection && identity.selection != state.selectedSceneObjects)
        || identity.sources.size() != state.files.size()) { return false; }
    for (size_t i = 0; i < identity.sources.size(); ++i) {
        const auto& source = identity.sources[i]; const auto& mesh = state.files[i].mesh;
        if (source.contentRevision != mesh.contentRevision || source.fileId != state.files[i].objectId
            || source.vertices != meshGeometry(mesh).vertices.data() || source.indices != meshGeometry(mesh).indices.data()
            || source.vertexCount != meshGeometry(mesh).vertices.size() || source.indexCount != meshGeometry(mesh).indices.size()
            // Publishing the first cache does not change a small owned snapshot.
            // Replacing/invalidating an existing cache still rejects old work.
            || (source.cache && source.cache != mesh.annotationCache)) { return false; }
    }
    return true;
}
} // namespace woby
