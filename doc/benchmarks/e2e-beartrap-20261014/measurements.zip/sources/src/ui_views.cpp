#include "ui_views.h"
#include "ui_operations.h"
#include "ui_icon_controls.h"

#include <algorithm>
#include <imgui.h>
#include <imgui_stdlib.h>

namespace woby {

float viewListHeight(float preferredHeight, float automaticHeight,
    float minimumHeight, float availableHeight)
{
    const float maximum = std::max(1.0f, availableHeight);
    return std::clamp(preferredHeight > 0.0f ? preferredHeight : automaticHeight,
        std::min(minimumHeight, maximum), maximum);
}

void drawViews(UiState& state, ViewNameEdit& edit, ViewListLayout& layout, float reservedHeight, bool flowing)
{
    if (edit.generation != state.sceneGeneration || (edit.id && !findView(state, edit.id))) {
        edit = {};
        edit.generation = state.sceneGeneration;
    }
    const float button = renderModeButtonSize();
    const float spacing = ImGui::GetStyle().ItemSpacing.x;
    ImGui::PushID("views");
    bool open = false;
    if (ImGui::BeginTable("header", 2, ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("label", ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn("add", ImGuiTableColumnFlags_WidthFixed, button);
        ImGui::TableNextRow();
        ImGui::TableNextColumn();
        open = ImGui::CollapsingHeader("Views", ImGuiTreeNodeFlags_DefaultOpen);
        ImGui::TableNextColumn();
        if (drawRenderModeIconButton("add", "+", "Create a view from the current scene", RenderModeState::off, false)) {
            createView(state);
        }
        ImGui::EndTable();
    }
    if (open) {
        const float rows = static_cast<float>(std::clamp(state.views.size(), size_t{1}, size_t{5}));
        const float automaticHeight = rows * (button + ImGui::GetStyle().ItemSpacing.y)
            + ImGui::GetStyle().WindowPadding.y;
        constexpr float dividerHeight = 8.0f;
        const float minimumHeight = button + ImGui::GetStyle().ItemSpacing.y
            + ImGui::GetStyle().WindowPadding.y;
        const float availableHeight = ImGui::GetContentRegionAvail().y - reservedHeight
            - dividerHeight - ImGui::GetStyle().ItemSpacing.y;
        const float height = flowing ? automaticHeight : viewListHeight(layout.preferredHeight, automaticHeight,
            minimumHeight, availableHeight);
        if (ImGui::BeginChild("view_rows", ImVec2(0, height))) {
            if (state.views.empty()) { ImGui::TextDisabled("Use + to save the current view."); }
            const auto beginRename = [&](ViewId id) {
                if (const auto* view = findView(state, id)) {
                    edit.id = id;
                    edit.text = view->name;
                    edit.focus = true;
                }
            };
            if (ImGui::IsWindowFocused() && !ImGui::GetIO().WantTextInput && !ImGui::IsAnyItemActive()
                && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopupId)
                && ImGui::IsKeyPressed(ImGuiKey_F2, false)) { beginRename(state.activeViewId); }
            for (const auto& view : state.views) {
                const auto id = view.id;
                ImGui::PushID(std::to_string(id).c_str());
                const float nameWidth = std::max(1.0f, ImGui::GetContentRegionAvail().x - button - spacing);
                bool changed = false;
                if (edit.id == id) {
                    const bool focusing = edit.focus;
                    if (focusing) { ImGui::SetKeyboardFocusHere(); edit.focus = false; }
                    ImGui::SetNextItemWidth(nameWidth);
                    const bool entered = ImGui::InputText("##name", &edit.text,
                        ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_AutoSelectAll);
                    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) { edit.id = 0; }
                    else if (entered || (!focusing && ImGui::IsItemDeactivated())) {
                        renameView(state, id, edit.text);
                        edit.id = 0;
                    }
                } else {
                    if (drawSceneItemButton((view.name + "###name").c_str(), nameWidth, state.activeViewId == id)) {
                        applyView(state, id);
                    }
                    if (ImGui::IsItemHovered()) {
                        ImGui::SetTooltip("Restore this view. Double-click to rename.");
                        if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) { beginRename(id); }
                    }
                    if (ImGui::BeginPopupContextItem("view_menu")) {
                        if (ImGui::MenuItem("Restore view")) { applyView(state, id); }
                        if (ImGui::MenuItem("Save current state to view")) { updateView(state, id); }
                        ImGui::Separator();
                        if (ImGui::MenuItem("Rename", "F2")) { beginRename(id); }
                        if (ImGui::MenuItem("Duplicate")) { duplicateView(state, id); changed = true; }
                        if (ImGui::MenuItem("Delete view")) { removeView(state, id); changed = true; }
                        ImGui::EndPopup();
                    }
                }
                if (!changed) {
                    ImGui::SameLine();
                    if (drawRenderModeIconButton("save", "\xef\x83\x87",
                        "Save current state to this view. Save the .woby file to keep it on disk.",
                        RenderModeState::off, false)) { updateView(state, id); }
                }
                ImGui::PopID();
                if (changed) { break; }
            }
        }
        ImGui::EndChild();
        if (!flowing) {
            ImGui::InvisibleButton("views_objects_divider", ImVec2(-1.0f, dividerHeight));
            const bool hovered = ImGui::IsItemHovered();
            const bool active = ImGui::IsItemActive();
            const ImVec2 dividerMin = ImGui::GetItemRectMin();
            const ImVec2 dividerMax = ImGui::GetItemRectMax();
            const float dividerY = (dividerMin.y + dividerMax.y) * 0.5f;
            ImGui::GetWindowDrawList()->AddLine(
                ImVec2(dividerMin.x, dividerY), ImVec2(dividerMax.x, dividerY),
                ImGui::GetColorU32(active ? ImGuiCol_SeparatorActive
                    : hovered ? ImGuiCol_SeparatorHovered : ImGuiCol_Separator));
            if (hovered || active) { ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeNS); }
            if (hovered) {
                ImGui::SetTooltip("Drag to resize Views and Objects. Double-click to reset.");
                if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
                    layout.preferredHeight = 0.0f;
                }
            }
            if (active && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
                layout.preferredHeight = viewListHeight(height + ImGui::GetIO().MouseDelta.y,
                    automaticHeight, minimumHeight, availableHeight);
            }
        }
    }
    ImGui::PopID();
}

} // namespace woby
