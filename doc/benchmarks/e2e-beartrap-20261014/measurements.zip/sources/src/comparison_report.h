#pragma once

#include "comparison_settings.h"
#include "mesh_comparison.h"

#include <array>
#include <string>
#include <vector>

namespace woby {

struct ScreenshotSettings {
    int width = 1920;
    int height = 1800;
    bool resultsOnly = false;
    bool legend = true;
    bool comparisonName = true;
    bool sources = true;
    bool direction = true;
    bool tolerance = true;
    friend bool operator==(const ScreenshotSettings&, const ScreenshotSettings&) = default;
};

[[nodiscard]] ScreenshotSettings normalizedScreenshotSettings(ScreenshotSettings settings);
[[nodiscard]] std::string measurementNumber(double value);
// Round a finite, nonnegative measured distance upward to the display precision.
[[nodiscard]] float fittedComparisonColorRange(double maximum, float tolerance);
[[nodiscard]] ComparisonSettings fittedComparisonSettings(ComparisonSettings settings, const SurfaceComparison& surface);
[[nodiscard]] ComparisonSettings editedComparisonColorLimit(ComparisonSettings settings, bool lower, double value);
// Unlit palette, shared by numeric legends. Matches shaders/native/woby.slang.
[[nodiscard]] std::array<float, 4> comparisonHeatmapColor(double distance, const ComparisonSettings& settings);
[[nodiscard]] std::vector<std::string> comparisonReportLines(
    const std::string& name, const std::string& a, const std::string& b,
    const ComparisonSettings& settings, const MeshComparison& result, const ScreenshotSettings& options);

} // namespace woby
