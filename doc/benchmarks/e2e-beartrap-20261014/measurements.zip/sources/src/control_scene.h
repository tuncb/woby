#pragma once

#include "control_protocol.h"
#include "ui_state.h"
#include "mesh_comparison.h"
#include <functional>

namespace woby {
using ObjectIdFormatter = std::function<std::string(SceneObjectId)>;
nlohmann::json controlSceneInfo(const UiState& state);
nlohmann::json controlCameraInfo(const UiState& state);
nlohmann::json controlSceneTree(const UiState& state, const ObjectIdFormatter& formatId);
nlohmann::json controlObjectDetails(const UiState& state, SceneObjectId id, const ObjectIdFormatter& formatId);
nlohmann::json controlAnnotationDetails(const UiState& state, const UiAnnotation& item);
[[nodiscard]] bool annotationControlReady(const UiState& state, ControlAction action);
struct AnnotationCommandResult;
nlohmann::json applyControlAnnotationOperation(UiState& state, const SceneDocument& cleanDocument,
    const ControlOperation& command, const ObjectIdFormatter& formatId, const AnnotationCommandResult* computed = nullptr);
// Summarizes an immutable measurement snapshot; no renderer or timing dependencies.
nlohmann::json controlComparisonResults(const MeshComparison& result, double tolerance, bool includeDetectors = true,
    const ObjectIdFormatter& formatId = {});
// Bounded UV triangle records and transient linked selection; all IDs use the session formatter.
nlohmann::json controlUvTrianglePage(const UvQuality& quality, size_t offset, size_t limit, const ObjectIdFormatter& formatId);
nlohmann::json controlUvProbe(UiState& state, const MeshComparison* result, uint64_t resultSignature,
    const ControlOperation& command, const ObjectIdFormatter& formatId);
// Uses the same finding focus and camera framing as the Diagnostics list.
nlohmann::json controlFocusComparisonDiagnostic(UiState& state, const MeshComparison& result,
    uint64_t resultSignature, const ControlOperation& command);
// Main-thread adapter for logical operations; runtime/file operations are dispatched elsewhere.
nlohmann::json applyControlSceneOperation(UiState& state, const SceneDocument& cleanDocument,
    const ControlOperation& command, const ObjectIdFormatter& formatId, float minPaneWidth, float maxPaneWidth);
} // namespace woby
