#include "adaptive_points.h"
#include "graphics_helpers.h"
#include "math_utils.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>

namespace woby {
namespace {
bool same(const AdaptivePointKey& a,const AdaptivePointKey& b) {
    return a.cloud==b.cloud && a.sourceGroup==b.sourceGroup && a.group.model==b.group.model
        && a.group.color==b.group.color && a.group.pointSize==b.group.pointSize
        && a.group.firstId==b.group.firstId && a.group.endId==b.group.endId;
}
void appendTasks(std::vector<graphics::OpaquePointTask>& tasks,const AdaptivePointDraw& draw,
    const points::Selection& selection,uint32_t group,bool query=false) {
    for (const auto& range:selection.ranges) {
        if (range.group!=draw.key.sourceGroup) continue;
        const auto& chunks=range.proxy?draw.mesh->proxyChunks:draw.mesh->pointChunks;
        for (uint32_t used=0;used<range.count;) {
            const uint32_t offset=range.begin+used,chunk=offset/pointChunkSize;
            const uint32_t count=std::min({4096u,range.count-used,pointChunkSize-offset%pointChunkSize});
            tasks.push_back({chunks.at(chunk),offset%pointChunkSize,count,group,query}); used+=count;
        }
    }
}
points::Selection sourceRange(const AdaptivePointKey& key) {
    points::Selection result;
    for (const auto root:key.cloud->roots) {
        const auto& n=key.cloud->nodes[root];
        if (n.group==key.sourceGroup) { result.ranges.push_back({n.begin,n.count,n.group,false}); result.points+=n.count; }
    }
    return result;
}
void destroyPointPrograms(AdaptivePointRuntime& runtime) {
    for (auto* program:{&runtime.clear,&runtime.raster,&runtime.resolve,&runtime.resolveIds,&runtime.batchClear,&runtime.ids,&runtime.merge}) {
        if (graphics::isValid(*program)) graphics::destroy(*program);
        *program={};
    }
    runtime.loadedBackend=graphics::PointBackend::automatic;
}
} // namespace

void prepareAdaptivePoints(AdaptivePointRuntime& runtime,const std::filesystem::path& assets,
    const ScenePickView& view,bool adaptive,double now,bool queryEnabled,std::array<float,2> query) {
    runtime.draws.clear(); runtime.active=false; runtime.submitted=0;
    runtime.width=view.width; runtime.height=view.height; runtime.now=now; runtime.adaptive=adaptive;
    runtime.queryEnabled=queryEnabled; runtime.query=query;
    woby::multiplyMatrices(runtime.projection.data(),view.view.data(),view.renderProjection.data());
    const auto* caps=graphics::getCaps();
    runtime.backend=graphics::selectPointBackend(caps->supported,runtime.preference);
    if (uint64_t(view.width)*view.height*4*sizeof(uint64_t)>UINT32_MAX) runtime.backend=graphics::PointBackend::quads;
    runtime.enabled=!runtime.unavailable && view.width && view.height;
    if (!runtime.enabled) { runtime.keys.clear(); return; }
    if (runtime.loadedBackend!=runtime.backend) destroyPointPrograms(runtime);
    if (!graphics::isValid(runtime.resolve)) {
        try {
            const auto path=assets/"shaders"/rendererShaderFolder(caps->rendererType);
            if (runtime.backend==graphics::PointBackend::quads) {
                runtime.resolve=loadProgram(assets,"vs_point_sprite.bin","fs_point_sprite.bin");
                runtime.resolveIds=loadProgram(assets,"vs_point_sprite.bin","fs_marker_point.bin");
            } else {
                runtime.clear=graphics::createProgram(loadShader(path/"cs_opaque_clear.bin"),true);
                const bool split=runtime.backend==graphics::PointBackend::atomic32;
                runtime.raster=graphics::createProgram(loadShader(path/(split?"cs_opaque_depth.bin":"cs_opaque_raster.bin")),true);
                if (split) {
                    runtime.batchClear=graphics::createProgram(loadShader(path/"cs_opaque_batch_clear.bin"),true);
                    runtime.ids=graphics::createProgram(loadShader(path/"cs_opaque_ids.bin"),true);
                    runtime.merge=graphics::createProgram(loadShader(path/"cs_opaque_merge.bin"),true);
                }
                runtime.resolve=loadProgram(assets,"vs_opaque_resolve.bin","fs_opaque_color.bin");
                runtime.resolveIds=loadProgram(assets,"vs_opaque_resolve.bin","fs_opaque_resolve.bin");
            }
            runtime.loadedBackend=runtime.backend;
        } catch (const std::exception& error) {
            destroyPointPrograms(runtime);
            runtime.error=error.what(); runtime.unavailable=true; runtime.enabled=false;
        }
    }
}
bool queueAdaptivePoints(AdaptivePointRuntime& runtime,const GpuMesh& mesh,const SceneDrawItem& item,uint32_t firstId) {
    if (!runtime.enabled || !mesh.pointCloud || item.importedLines || !firstId) return false;
    const auto& source=mesh.pointCloud->groups.at(item.groupIndex);
    AdaptivePointDraw draw;
    draw.mesh=&mesh; draw.key.cloud=mesh.pointCloud; draw.key.sourceGroup=static_cast<uint32_t>(item.groupIndex);
    auto& group=draw.key.group;
    group.model=item.model; group.color=item.color;
    group.color[3]=1;
    for (size_t i=0;i<3;++i) group.color[i]=std::min(1.0f,group.color[i]*1.5f);
    group.firstId=firstId; group.endId=firstId+source.endId-source.firstId;
    group.sourceFirstId=source.firstId; group.pointSize=item.pointSize;
    runtime.draws.push_back(std::move(draw)); return true;
}
void submitAdaptivePoints(AdaptivePointRuntime& runtime,graphics::ViewId view,bool markerIds) {
    if (runtime.draws.empty()) {
        runtime.keys.clear(); runtime.full.clear(); runtime.navigation.clear(); runtime.cursors.clear();
        if (runtime.pending.valid() && runtime.pending.wait_for(std::chrono::seconds(0))==std::future_status::ready) (void)runtime.pending.get();
        runtime.total=runtime.refined=0; return;
    }
    const auto* stats=graphics::getStats();
    // Delayed timings from an explicitly full-detail frame must not throttle
    // the interactive budget when the user switches adaptive detail back on.
    if (runtime.adaptive && stats->pointRasterBudgeted && stats->pointRasterCount && stats->pointRasterFrame!=runtime.lastTiming) {
        runtime.lastTiming=stats->pointRasterFrame;
        runtime.budget=points::adjustedBudget(runtime.budget,
            stats->pointRasterMs,8,2000000);
    }
    const bool resized=runtime.width!=runtime.previousWidth || runtime.height!=runtime.previousHeight;
    const bool keysChanged=runtime.keys.size()!=runtime.draws.size() || !std::equal(runtime.keys.begin(),runtime.keys.end(),runtime.draws.begin(),
            [](const auto& key,const auto& draw) { return same(key,draw.key); });
    const bool quads=runtime.backend==graphics::PointBackend::quads;
    const bool changed=resized || runtime.backend!=runtime.previousBackend || runtime.adaptive!=runtime.previousAdaptive || runtime.projection!=runtime.previousProjection || keysChanged;
    bool reset=changed || (!quads && !graphics::isValid(runtime.winners));
    if (!quads && (resized || !graphics::isValid(runtime.winners))) {
        const auto replacement=graphics::createVertexBufferStorage(static_cast<uint32_t>(uint64_t(runtime.width)*runtime.height*4*sizeof(uint64_t)),{sizeof(uint64_t)});
        if (graphics::isValid(runtime.winners)) graphics::destroy(runtime.winners);
        runtime.winners=replacement;
    }
    if (runtime.backend==graphics::PointBackend::atomic32 && (resized || !graphics::isValid(runtime.batch))) {
        const auto replacement=graphics::createVertexBufferStorage(static_cast<uint32_t>(uint64_t(runtime.width)*runtime.height*4*sizeof(uint64_t)),{sizeof(uint64_t)});
        if (graphics::isValid(runtime.batch)) graphics::destroy(runtime.batch);
        runtime.batch=replacement;
    }
    if (runtime.backend!=graphics::PointBackend::atomic32 && graphics::isValid(runtime.batch)) {
        graphics::destroy(runtime.batch); runtime.batch={};
    }
    if (quads && graphics::isValid(runtime.winners)) { graphics::destroy(runtime.winners); runtime.winners={}; }
    if (changed) {
        ++runtime.epoch; runtime.lastChange=runtime.now; runtime.queryValid=false;
        runtime.keys.clear(); runtime.full.clear(); runtime.total=runtime.refined=0;
        for (const auto& draw:runtime.draws) {
            runtime.keys.push_back(draw.key); runtime.full.push_back(sourceRange(draw.key)); runtime.total+=runtime.full.back().points;
        }
        runtime.cursors.assign(runtime.keys.size(),{});
        if (keysChanged) { runtime.navigation.clear(); runtime.navigationBudget=0; }
        runtime.previousProjection=runtime.projection; runtime.previousWidth=runtime.width; runtime.previousHeight=runtime.height;
        runtime.previousAdaptive=runtime.adaptive;
        runtime.previousBackend=runtime.backend;
    }
    const bool navigating=runtime.adaptive && runtime.now-runtime.lastChange<.15;
    std::vector<graphics::OpaquePointTask> tasks;
    if (runtime.pending.valid() && runtime.pending.wait_for(std::chrono::seconds(0))==std::future_status::ready) {
        auto result=runtime.pending.get();
        // Navigation cuts supplement the coarse preview. Once full-source
        // refinement starts, a late cut would only submit those points again.
        if (result.epoch==runtime.epoch && navigating) {
            for (size_t i=0;i<result.selections.size();++i)
                appendTasks(tasks,runtime.draws[i],result.selections[i],static_cast<uint32_t>(i));
        }
    }
    if (changed && runtime.adaptive && !runtime.pending.valid() && runtime.keys.size()<=32) {
        const auto keys=runtime.keys; const auto matrix=runtime.projection;
        const auto width=runtime.width,height=runtime.height,budget=runtime.budget;
        const auto epoch=runtime.epoch;
        runtime.pending=std::async(std::launch::async,[keys,matrix,width,height,budget,epoch] {
            AdaptivePointCut result; result.epoch=epoch;
            for (const auto& key:keys) {
                auto groups=key.cloud->groups;
                for (auto& group:groups) group.enabled=false;
                groups[key.sourceGroup].enabled=true; groups[key.sourceGroup].model=key.group.model;
                result.selections.push_back(points::selectDetail(*key.cloud,groups,matrix,width,height,key.group.pointSize,
                    std::max(1u,budget/static_cast<uint32_t>(keys.size())),std::min(1.0f,key.group.pointSize*.5f)));
            }
            return result;
        });
    }
    if (navigating) {
        // A cut always covers every spatial region, including during fast turns.
        // It is cached between changes; the GPU rejects complete offscreen circles.
        const bool newCut=runtime.navigation.empty() || runtime.navigationBudget!=runtime.budget;
        if (newCut) {
            runtime.navigationBudget=runtime.budget; runtime.navigation.clear();
            for (const auto& key:runtime.keys)
                runtime.navigation.push_back(points::navigationDetail(*key.cloud,std::max(1u,runtime.budget/static_cast<uint32_t>(runtime.keys.size())),key.sourceGroup));
        }
        if (reset || newCut || quads) {
            for (size_t i=0;i<runtime.draws.size();++i)
                appendTasks(tasks,runtime.draws[i],runtime.navigation[i],static_cast<uint32_t>(i));
        }
    } else if (quads) {
        // Hardware targets are redrawn each frame. Progressive accumulation is
        // a compute-backend property, independent of navigation selection.
        for (size_t i=0;i<runtime.draws.size();++i)
            appendTasks(tasks,runtime.draws[i],runtime.full[i],static_cast<uint32_t>(i));
        runtime.refined=runtime.total;
    } else {
        uint32_t remaining=runtime.adaptive?runtime.budget:UINT32_MAX;
        for (size_t i=0;i<runtime.draws.size() && remaining;++i) {
            const auto selection=points::nextRefinement(runtime.full[i],runtime.cursors[i],remaining);
            appendTasks(tasks,runtime.draws[i],selection,static_cast<uint32_t>(i));
            runtime.refined+=selection.points; remaining-=static_cast<uint32_t>(selection.points);
        }
    }
    std::array<uint32_t,4> query{};
    const bool newQuery=!runtime.queryValid || runtime.query!=runtime.previousQuery;
    if (runtime.queryEnabled && runtime.refined<runtime.total && newQuery) {
        runtime.previousQuery=runtime.query; runtime.queryValid=true;
        float radius=5;
        for (const auto& key:runtime.keys) radius=std::max(radius,key.group.pointSize+5);
        const auto bound=[](float v,uint32_t maximum) { return static_cast<uint32_t>(std::clamp(v,0.0f,float(maximum))); };
        query={bound(std::floor(runtime.query[0]-radius),runtime.width),bound(std::floor(runtime.query[1]-radius),runtime.height),
            bound(std::ceil(runtime.query[0]+radius+1),runtime.width),bound(std::ceil(runtime.query[1]+radius+1),runtime.height)};
        const std::array<float,4> rectangle{float(query[0]),float(query[1]),float(query[2]),float(query[3])};
        runtime.queryRectangle=query; runtime.querySelections.clear();
        for (size_t i=0;i<runtime.draws.size();++i) {
            const auto& draw=runtime.draws[i]; points::Matrix matrix;
            woby::multiplyMatrices(matrix.data(),draw.key.group.model.data(),runtime.projection.data());
            runtime.querySelections.push_back(points::queryFootprints(*draw.key.cloud,draw.key.sourceGroup,matrix,runtime.width,runtime.height,
                draw.key.group.pointSize,rectangle));
        }
    }
    if (runtime.queryEnabled && runtime.refined<runtime.total && (quads || newQuery)) {
        query=runtime.queryRectangle;
        for (size_t i=0;i<runtime.draws.size();++i)
            appendTasks(tasks,runtime.draws[i],runtime.querySelections[i],static_cast<uint32_t>(i),true);
    }
    std::vector<graphics::OpaquePointGroup> groups; groups.reserve(runtime.keys.size());
    for (const auto& key:runtime.keys) groups.push_back(key.group);
    for (const auto& task:tasks) runtime.submitted+=task.count;
    const graphics::PointPrograms programs{runtime.clear,runtime.raster,markerIds?runtime.resolveIds:runtime.resolve,
        runtime.batchClear,runtime.ids,runtime.merge};
    graphics::submitOpaquePoints(view,runtime.backend,runtime.winners,runtime.batch,programs,groups,tasks,query,reset,
        runtime.adaptive && (!quads || navigating));
    runtime.active=true; runtime.draws.clear();
}
void destroyAdaptivePoints(AdaptivePointRuntime& runtime) {
    if (runtime.pending.valid()) { runtime.pending.wait(); runtime.pending={}; }
    destroyPointPrograms(runtime);
    if (graphics::isValid(runtime.winners)) graphics::destroy(runtime.winners);
    if (graphics::isValid(runtime.batch)) graphics::destroy(runtime.batch);
    runtime={};
}
void attachPointHierarchies(std::span<ScenePickPart> parts,const std::vector<LoadedModelRuntime>& runtimes) {
    for (auto& part:parts) if (part.sourceMesh && part.fileIndex<runtimes.size())
        part.pointCloud=runtimes[part.fileIndex].gpuMesh.pointCloud.get();
}
} // namespace woby
