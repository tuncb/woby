#include "profile.h"
#include "graphics_helpers.h"
#include "renderer_startup.h"
#include "background_load.h"
#include "post_loading.h"
#include "camera.h"
#include "scene_viewport.h"
#include "command_line.h"
#include "console.h"
#include "file_discovery.h"
#include "hover_pick.h"
#include "marker_pick.h"
#include "adaptive_points.h"
#include "comparison_view.h"
#include "difference_runtime.h"
#include "comparison_scene.h"
#include "imgui_graphics.h"
#include "model_load.h"
#include "native_dialogs.h"
#include "performance_log.h"
#include "performance_capture.h"
#include "scene_file.h"
#include "scene_inspector.h"
#include "scene_scale_overlay.h"
#include "scene_lifecycle.h"
#include "scene_history.h"
#include "scene_history_load.h"
#include "scene_history_restore.h"
#include "ui_history_controls.h"
#include "scene_renderer.h"
#include "annotation_ui.h"
#include "annotation_preparation.h"
#include "annotation_command.h"
#include "scene_screenshot.h"
#include "ui_operations.h"
#include "ui_state.h"
#include "ui_views.h"
#include "ui_layout.h"
#include "ui_icon_controls.h"
#include "ui_popup_controls.h"
#include "settings_dialog.h"
#include "main_menu.h"
#include "recent_files_runtime.h"
#include "utf8_path.h"
#include "automation.h"
#include "control_scene.h"
#include "analysis_results.h"
#include "control_importers.h"

#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include "graphics.h"
#include "math_utils.h"
#include <imgui.h>
#include <imgui_impl_sdl3.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/spdlog.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <thread>
#include <type_traits>
#include <utility>
#include <unordered_map>
#include <vector>

namespace {

using woby::RenderModeState;
using woby::uiSize;
using woby::renderModeButtonSize;
using woby::drawRenderModeIconButton;
using woby::drawTriStateMasterIconButton;
using woby::drawTriStateVisibilityButton;
using woby::drawVisibilityButton;
using woby::setLastItemTooltip;

constexpr uint32_t resetFlags = WOBY_GPU_RESET_VSYNC | WOBY_GPU_RESET_MSAA_X4;
constexpr woby::graphics::ViewId clearView = 0;
constexpr woby::graphics::ViewId sceneView = 1;
constexpr woby::graphics::ViewId helperView = 5;
constexpr woby::graphics::ViewId imguiView = 255;
constexpr float minSceneViewportWidth = 160.0f;
constexpr float viewerPaneBackgroundRed = 0.20f;
constexpr float viewerPaneBackgroundGreen = 0.21f;
constexpr float viewerPaneBackgroundBlue = 0.22f;
constexpr float viewerPaneBackgroundAlpha = 1.0f;
constexpr float popupBackgroundRed = 0.20f;
constexpr float popupBackgroundGreen = 0.21f;
constexpr float popupBackgroundBlue = 0.22f;
constexpr float popupBackgroundAlpha = 1.0f;
constexpr float appFontSize = 17.0f;
constexpr const char* appFontFilename = "RobotoMonoNerdFont-Regular.ttf";
constexpr ImWchar appFontGlyphRanges[] = {
    0xf0c7,
    0xf0c7,
    0xf013,
    0xf013,
    0xf01e,
    0xf01e,
    0xf021,
    0xf021,
    0xf05a,
    0xf05a,
    0xf04b,
    0xf04b,
    0xf04d,
    0xf04d,
    0xf00d,
    0xf00d,
    0xf030,
    0xf030,
    0xf065,
    0xf065,
    0xf192,
    0xf192,
    0xf068,
    0xf068,
    0xf06e,
    0xf070,
    0xf080,
    0xf080,
    0xf0b2,
    0xf0b2,
    0xf0e2,
    0xf0e2,
    0xf1b2,
    0xf1b2,
    0xf02c1,
    0xf02c1,
    0xf0b43,
    0xf0b43,
    0xf0930,
    0xf0930,
    0xeba0,
    0xeba0,
    0xed75,
    0xed75,
    0xed95,
    0xed95,
    0xea7f,
    0xea7f,
    0xea80,
    0xea80,
    0,
};
using woby::solidMeshIcon;
using woby::trianglesIcon;
using woby::verticesIcon;
constexpr const char* frameSceneIcon = "\xef\x81\xa5";
constexpr const char* originIcon = "\xf3\xb0\xad\x83";
constexpr const char* gridIcon = "\xf3\xb0\x8b\x81";
constexpr const char* viewerPanePinnedIcon = "\xee\xae\xa0";
constexpr const char* viewerPaneUnpinnedIcon = "\xf3\xb0\xa4\xb0";
constexpr float viewerPaneTogglePaneMargin = 6.0f;
constexpr float toastDurationSeconds = 8.0f;
constexpr float toastMargin = 12.0f;

woby::graphics::PlatformData platformDataFromSdlWindow(SDL_Window* window)
{
    return {window};
}

std::filesystem::path assetRoot()
{
    const char* basePath = SDL_GetBasePath();
    if (basePath == nullptr) {
        return std::filesystem::current_path() / "assets";
    }

    return woby::pathFromUtf8(basePath) / "assets";
}

void loadAppFont(const std::filesystem::path& assets)
{
    const std::filesystem::path fontPath = assets / "fonts" / appFontFilename;
    if (!std::filesystem::exists(fontPath)) {
        throw std::runtime_error("App font not found: " + woby::pathToUtf8(fontPath));
    }

    ImGuiIO& io = ImGui::GetIO();
    const auto textPath = assets / "fonts" / "Lato-Regular.ttf";
    ImFont* font = io.Fonts->AddFontFromFileTTF(woby::pathToUtf8(textPath).c_str(), appFontSize);
    if (!font) { throw std::runtime_error("Failed to load UI font: " + woby::pathToUtf8(textPath)); }
    ImFontConfig icons;
    icons.MergeMode = true;
    if (!io.Fonts->AddFontFromFileTTF(woby::pathToUtf8(fontPath).c_str(), appFontSize, &icons, appFontGlyphRanges)) {
        throw std::runtime_error("Failed to load icon font: " + woby::pathToUtf8(fontPath));
    }

    io.FontDefault = font;
}

void getDrawableSize(SDL_Window* window, uint32_t& width, uint32_t& height)
{
    int pixelWidth = 0;
    int pixelHeight = 0;
    SDL_GetWindowSizeInPixels(window, &pixelWidth, &pixelHeight);
    width = static_cast<uint32_t>(std::max(pixelWidth, 1));
    height = static_cast<uint32_t>(std::max(pixelHeight, 1));
}

using LoadedModelFile = woby::UiFileState;
using woby::GpuNodeRange;
using woby::HoverPickCache;
using woby::HoveredVertex;
using woby::LoadedModelRuntime;
using woby::MousePosition;
using woby::ModelFileDialogState;
using woby::SceneFileDialogState;
using woby::SceneScreenshotDialogState;
using woby::SceneScreenshotRuntime;
using woby::completeSceneScreenshotReadback;
using woby::destroyGpuMesh;
using woby::destroyModelRuntimes;
using woby::destroySceneScreenshotFramebuffer;
using woby::failSceneScreenshotCapture;
using woby::findHoveredVertex;
using woby::hoverPickSignature;
using woby::helperLineVertexLayout;
using woby::meshVertexLayout;
using woby::requestSceneScreenshotCapture;
using woby::submitSceneFiles;
using woby::submitSceneHelpers;
using woby::submitSceneScreenshotCapture;
using woby::vertexPointSize;

struct DragDropState {
    std::vector<std::filesystem::path> batchPaths;
    std::vector<std::filesystem::path> pendingPaths;
    bool active = false;
};

struct ToastMessage {
    std::string text;
    std::chrono::steady_clock::time_point startedAt{};
};

struct ResolvedModelInputGroup {
    bool folderTree = false;
    std::filesystem::path root;
    size_t firstPathIndex = 0;
    size_t pathCount = 0;
};

struct ResolvedModelInputs {
    std::vector<std::filesystem::path> paths;
    std::vector<ResolvedModelInputGroup> groups;
};

enum class AsyncLoadKind {
    appendModel,
    initialModels,
    appendFolderTree,
    openScene,
};

struct AsyncLoadOutcome {
    AsyncLoadKind kind = AsyncLoadKind::appendModel;
    std::filesystem::path folderTreeRoot;
    woby::ModelBatchCpuLoadResult modelBatch;
    woby::SceneCpuLoadResult scene;
    std::string error;
    bool failed = false;
};

struct BackgroundLoadRuntime {
    ~BackgroundLoadRuntime()
    {
        cancelRequested.store(true);
        if (worker.joinable()) {
            worker.join();
        }
    }

    std::mutex mutex;
    std::thread worker;
    std::optional<AsyncLoadOutcome> outcome;
    woby::BackgroundLoadProgress progress;
    std::atomic_bool cancelRequested = false;
    AsyncLoadKind kind = AsyncLoadKind::appendModel;
    bool active = false;
};

struct GpuFinalizeRuntime {
    AsyncLoadKind kind = AsyncLoadKind::appendModel;
    std::filesystem::path folderTreeRoot;
    std::filesystem::path scenePath;
    woby::SceneDocument sceneDocument;
    ResolvedModelInputs initialInputs;
    std::vector<LoadedModelFile> files;
    std::vector<woby::SceneMeshPreparation> preparations;
    std::vector<std::optional<woby::GpuMeshUpload>> uploads;
    std::vector<std::string> uploadErrors;
    uint64_t sceneGeneration = 0;
    bool cancelRequested = false;
    std::vector<LoadedModelFile> finalizedFiles;
    std::vector<LoadedModelRuntime> finalizedRuntimes;
    size_t sourceFailedCount = 0;
    size_t sourceSkippedCount = 0;
    size_t gpuFailedCount = 0;
    std::vector<woby::ModelInputOutcome> gpuFailures;
    std::string lastError;
    size_t nextFileIndex = 0;
    bool active = false;
};

struct AutomationAppendRuntime {
    woby::AutomationCommandId id = 0;
    size_t firstFileIndex = 0;
    std::vector<woby::ModelInputOutcome> outcomes;
    bool canceled = false;
    bool postLoadPending = false;
    uint64_t generation = 0;
};

struct AutomationComparisonRuntime {
    std::filesystem::path exportPath;
    woby::IntersectionLimits intersectionLimits;
    woby::AutomationCommandId id = 0;
    std::string target;
    double tolerance = 0;
    woby::SceneObjectId objectId = woby::invalidSceneObjectId;
    uint64_t signature = 0, sceneGeneration = 0;
    uint32_t stages = 0;
    woby::DegenerateSettings degenerates;
    woby::TopologyInspectionSettings topologyInspection;
    woby::TopologyMode topologyMode = woby::TopologyMode::originalIndex;
};

struct AutomationDifferenceRuntime {
    woby::AutomationCommandId id = 0;
    woby::SceneObjectId objectId = 0;
    uint64_t generation = 0, request = 0;
    bool exporting = false;
};

bool isAppendModelLoadKind(AsyncLoadKind kind)
{
    return kind == AsyncLoadKind::appendModel || kind == AsyncLoadKind::initialModels || kind == AsyncLoadKind::appendFolderTree;
}

const char* backgroundLoadDescription(AsyncLoadKind kind)
{
    switch (kind) {
    case AsyncLoadKind::initialModels:
    case AsyncLoadKind::appendModel:
        return "Loading model files...";
    case AsyncLoadKind::appendFolderTree:
        return "Loading folder tree...";
    case AsyncLoadKind::openScene:
        return "Opening scene...";
    }

    return "Processing files...";
}

const char* backgroundLoadFailurePrefix(AsyncLoadKind kind)
{
    switch (kind) {
    case AsyncLoadKind::initialModels:
    case AsyncLoadKind::appendModel:
        return "Open model files failed: ";
    case AsyncLoadKind::appendFolderTree:
        return "Open folder tree failed: ";
    case AsyncLoadKind::openScene:
        return "Open scene failed: ";
    }

    return "Processing files failed: ";
}

struct CanvasLayout {
    float width = 1.0f;
    float height = 1.0f;
    float top = 0.0f;
    float leftWidth = 0.0f;
    float maxLeftWidth = 0.0f;
    float rightWidth = 0.0f;
    float maxRightWidth = 0.0f;
    float rightEdge = 1.0f;
    woby::SceneViewport viewport;
};

CanvasLayout canvasLayout(SDL_Window* window, const woby::UiState& state)
{
    int windowWidth = 1;
    int windowHeight = 1;
    SDL_GetWindowSize(window, &windowWidth, &windowHeight);
    CanvasLayout layout;
    layout.width = static_cast<float>(std::max(windowWidth, 1));
    layout.height = static_cast<float>(std::max(windowHeight, 1));
    layout.top = std::min(ImGui::GetFrameHeight(), layout.height - 1.0f);
    layout.rightEdge = layout.width;
    const float reservedScene = std::min(minSceneViewportWidth, layout.width * 0.2f);
    const float reservedLeft = state.viewerPaneVisible
        ? std::min(state.viewerPaneWidth, std::max(layout.width - reservedScene - uiSize(300.0f), 0.0f))
        : 0.0f;
    layout.maxRightWidth = std::max(layout.width - reservedLeft - reservedScene, 0.0f);
    layout.rightWidth = std::clamp(state.propertiesPaneWidth, 0.0f, layout.maxRightWidth);
    const float reservedRight = state.propertiesPaneVisible ? layout.width - layout.rightEdge + layout.rightWidth : 0.0f;
    layout.maxLeftWidth = std::max(layout.width - reservedRight
        - std::min(minSceneViewportWidth, layout.width * 0.2f), 0.0f);
    layout.leftWidth = state.viewerPaneVisible
        ? std::clamp(state.viewerPaneWidth, 0.0f, layout.maxLeftWidth) : 0.0f;
    uint32_t pixelWidth = 1;
    uint32_t pixelHeight = 1;
    getDrawableSize(window, pixelWidth, pixelHeight);
    layout.viewport = woby::sceneViewport(pixelWidth, pixelHeight, layout.width, layout.leftWidth, reservedRight, layout.top, layout.height);
    return layout;
}

woby::FrameEnvironment frameEnvironment(SDL_Window* window, const woby::UiState& ui, const woby::SceneViewport& viewport)
{
    woby::FrameEnvironment result;
    if (!window) { return result; }
    SDL_GetWindowSize(window, &result.windowWidth, &result.windowHeight);
    SDL_GetWindowSizeInPixels(window, &result.drawableWidth, &result.drawableHeight);
    result.viewportX = viewport.x; result.viewportY = viewport.y;
    result.viewportWidth = viewport.width; result.viewportHeight = viewport.height;
    result.windowFlags = SDL_GetWindowFlags(window);
    result.displayId = SDL_GetDisplayForWindow(window);
    result.pixelDensity = SDL_GetWindowPixelDensity(window);
    result.displayScale = SDL_GetWindowDisplayScale(window);
    result.uiScale = ui.uiScale;
    result.sceneEditRevision = ui.sceneEditRevision;
    result.sceneGeneration = ui.sceneGeneration;
    result.scenePaneVisible = ui.viewerPaneVisible; result.scenePaneWidth = ui.viewerPaneWidth;
    result.propertiesPaneVisible = ui.propertiesPaneVisible; result.propertiesPaneWidth = ui.propertiesPaneWidth;
    if (const auto* stats = woby::graphics::getStats()) {
        result.submittedWidth = stats->drawableWidth; result.submittedHeight = stats->drawableHeight;
        result.presentationSubmitted = stats->presentationSubmitted;
        result.mailbox = stats->mailboxPresentation;
        result.refreshRate = stats->displayRefreshRate;
        result.pacingPeriodNanoseconds = stats->pacingPeriodNanoseconds;
    }
    return result;
}

nlohmann::json frameEnvironmentInfo(const woby::FrameEnvironment& env)
{
    return {{"window", {{"width", env.windowWidth}, {"height", env.windowHeight}, {"flags", env.windowFlags},
                {"visible", (env.windowFlags & SDL_WINDOW_HIDDEN) == 0},
                {"minimized", (env.windowFlags & SDL_WINDOW_MINIMIZED) != 0},
                {"focused", (env.windowFlags & SDL_WINDOW_INPUT_FOCUS) != 0}}},
        {"drawable", {{"width", env.drawableWidth}, {"height", env.drawableHeight}}},
        {"viewport", {{"x", env.viewportX}, {"y", env.viewportY}, {"width", env.viewportWidth}, {"height", env.viewportHeight}}},
        {"sceneEditRevision", env.sceneEditRevision}, {"sceneGeneration", env.sceneGeneration},
        {"display", {{"id", env.displayId}, {"pixelDensity", env.pixelDensity}, {"scale", env.displayScale},
                {"refreshRateHz", env.refreshRate}}}, {"uiScale", env.uiScale},
        {"pane", {{"visible", env.scenePaneVisible}, {"width", env.scenePaneWidth}}},
        {"propertiesPane", {{"visible", env.propertiesPaneVisible}, {"width", env.propertiesPaneWidth}}},
        {"presentation", {{"submitted", env.presentationSubmitted}, {"width", env.submittedWidth}, {"height", env.submittedHeight},
                {"policy", env.mailbox ? "mailbox" : "backend_default"}, {"physicalVisibility", "unknown"}}},
        {"pacing", {{"periodNanoseconds", env.pacingPeriodNanoseconds},
                {"targetFps", env.pacingPeriodNanoseconds ? 1e9 / static_cast<double>(env.pacingPeriodNanoseconds) : 0.0},
                {"resetFlags", resetFlags}, {"msaaSamples", 4}}}};
}

nlohmann::json frameTimingInfo(const woby::FrameTimings& timing)
{
    nlohmann::json result = {{"frameIndex", timing.frameIndex}, {"frameMilliseconds", timing.totalMilliseconds},
        {"cpuFrameMilliseconds", timing.graphicsCpuFrameMilliseconds}, {"cpuSubmitMilliseconds", timing.graphicsCpuSubmitMilliseconds},
        {"gpuFrameMilliseconds", timing.hasGraphicsGpuFrameMilliseconds ? nlohmann::json(timing.graphicsGpuFrameMilliseconds) : nlohmann::json(nullptr)}};
    result["stagesMilliseconds"] = nlohmann::json::object();
    for (size_t stage = 0; stage < timing.stageMilliseconds.size(); ++stage) {
        result["stagesMilliseconds"][woby::frameStageName(static_cast<woby::FrameStage>(stage))] = timing.stageMilliseconds[stage];
    }
    return result;
}

MousePosition mousePositionInPixels(SDL_Window* window, float mouseWindowX, float mouseWindowY)
{
    int windowWidth = 0;
    int windowHeight = 0;
    SDL_GetWindowSize(window, &windowWidth, &windowHeight);

    uint32_t drawableWidth = 0;
    uint32_t drawableHeight = 0;
    getDrawableSize(window, drawableWidth, drawableHeight);

    const float widthScale = static_cast<float>(drawableWidth) / static_cast<float>(std::max(windowWidth, 1));
    const float heightScale = static_cast<float>(drawableHeight) / static_cast<float>(std::max(windowHeight, 1));
    return {
        mouseWindowX * widthScale,
        mouseWindowY * heightScale,
    };
}

MousePosition mousePositionInPixels(SDL_Window* window)
{
    float x = 0, y = 0;
    SDL_GetMouseState(&x, &y);
    return mousePositionInPixels(window, x, y);
}

std::string fileDisplayName(const std::filesystem::path& path)
{
    const auto filename = woby::pathToUtf8(path.filename());
    if (!filename.empty()) {
        return filename;
    }

    return woby::pathToUtf8(path);
}

std::filesystem::path normalizedPath(const std::filesystem::path& path)
{
    return std::filesystem::absolute(path).lexically_normal();
}

std::string appWindowTitle(
    const std::optional<std::filesystem::path>& currentScenePath,
    bool isDirty,
    const std::string& instanceId)
{
    std::string title = "woby " WOBY_VERSION " [" + instanceId + "] - ";
    title += currentScenePath.has_value()
        ? fileDisplayName(currentScenePath.value())
        : "untitled";
    if (isDirty) {
        title += '*';
    }

    return title;
}

struct WindowTitleCache {
    std::optional<std::filesystem::path> path;
    bool dirty = false;
    bool initialized = false;
};

void updateAppWindowTitle(
    SDL_Window* window,
    const std::optional<std::filesystem::path>& currentScenePath,
    bool isDirty,
    const std::string& instanceId, WindowTitleCache& cache)
{
    if (window && (!cache.initialized || cache.path != currentScenePath || cache.dirty != isDirty)) {
        SDL_SetWindowTitle(window, appWindowTitle(currentScenePath, isDirty, instanceId).c_str());
        cache.path = currentScenePath;
        cache.dirty = isDirty;
        cache.initialized = true;
    }
}

void drawClippedTextItem(const char* id, const char* text, float width, bool selected, const char* prefix = "")
{
    const float itemWidth = std::max(width, 1.0f);
    const float itemHeight = ImGui::GetFrameHeight();
    ImGui::InvisibleButton(id, ImVec2(itemWidth, itemHeight));

    const ImGuiStyle& style = ImGui::GetStyle();
    const ImVec2 itemMin = ImGui::GetItemRectMin();
    const ImVec2 itemMax = ImGui::GetItemRectMax();
    if (selected || ImGui::IsItemHovered()) {
        ImGui::GetWindowDrawList()->AddRectFilled(itemMin, itemMax,
            ImGui::GetColorU32(selected ? ImGuiCol_Header : ImGuiCol_HeaderHovered));
    }
    ImVec2 textPosition(itemMin.x, itemMin.y + style.FramePadding.y);
    const ImVec4 clipRect(itemMin.x, itemMin.y, itemMax.x, itemMax.y);

    if (*prefix) {
        ImGui::GetWindowDrawList()->AddText(ImGui::GetFont(), ImGui::GetFontSize(), textPosition,
            ImGui::GetColorU32(ImGuiCol_Text), prefix, nullptr, 0.0f, &clipRect);
        textPosition.x += ImGui::CalcTextSize(prefix).x;
    }

    ImGui::GetWindowDrawList()->AddText(
        ImGui::GetFont(),
        ImGui::GetFontSize(),
        textPosition,
        ImGui::GetColorU32(ImGuiCol_Text),
        text,
        nullptr,
        0.0f,
        &clipRect);
}

void setStyleColor(ImGuiCol colorIndex, float red, float green, float blue, float alpha)
{
    ImVec4 color = ImGui::GetStyleColorVec4(colorIndex);
    color.x = red;
    color.y = green;
    color.z = blue;
    color.w = alpha;
    ImGui::GetStyle().Colors[colorIndex] = color;
}

void configureAppStyle()
{
    ImGui::StyleColorsDark();
    setStyleColor(
        ImGuiCol_WindowBg,
        viewerPaneBackgroundRed,
        viewerPaneBackgroundGreen,
        viewerPaneBackgroundBlue,
        viewerPaneBackgroundAlpha);
    setStyleColor(
        ImGuiCol_ChildBg,
        viewerPaneBackgroundRed,
        viewerPaneBackgroundGreen,
        viewerPaneBackgroundBlue,
        viewerPaneBackgroundAlpha);
    setStyleColor(
        ImGuiCol_PopupBg,
        popupBackgroundRed,
        popupBackgroundGreen,
        popupBackgroundBlue,
        popupBackgroundAlpha);
    auto& style = ImGui::GetStyle();
    style.FrameRounding = 3.0f;
    style.FrameBorderSize = 1.0f;
    style.FramePadding = ImVec2(8.0f, 5.0f);
    style.ItemSpacing = ImVec2(8.0f, 6.0f);
    style.Colors[ImGuiCol_Text] = ImVec4(.94f, .95f, .96f, 1);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(.65f, .67f, .70f, 1);
    style.Colors[ImGuiCol_Button] = ImVec4(.28f, .29f, .31f, 1);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(.36f, .38f, .40f, 1);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(.42f, .44f, .47f, 1);
    style.Colors[ImGuiCol_Header] = ImVec4(.29f, .31f, .33f, 1);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(.36f, .38f, .40f, 1);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(.42f, .44f, .47f, 1);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(.14f, .15f, .17f, 1);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(.23f, .25f, .28f, 1);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(.29f, .31f, .34f, 1);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(.40f, .78f, .92f, 1);
    style.Colors[ImGuiCol_SliderGrab] = style.Colors[ImGuiCol_CheckMark];
}

std::filesystem::path uiPreferencePath()
{
    char* directory = SDL_GetPrefPath("woby", "woby");
    if (!directory) { return {}; }
    auto path = woby::pathFromUtf8(directory) / "ui-scale.txt";
    SDL_free(directory);
    return path;
}

void updateUiScale(SDL_Window* window, woby::UiState& state, const ImGuiStyle& baseStyle)
{
    const float scale = woby::logicalUiScale(state.uiScale,
        SDL_GetWindowDisplayScale(window), SDL_GetWindowPixelDensity(window));
    auto& style = ImGui::GetStyle();
    if (style.FontScaleMain == scale) { return; }
    const float ratio = scale / style.FontScaleMain;
    woby::setViewerPaneWidth(state, state.viewerPaneWidth * ratio, 380.0f * scale, 10000.0f);
    woby::setPropertiesPaneWidth(state, state.propertiesPaneWidth * ratio, 300.0f * scale, 10000.0f);
    style = woby::scaledUiStyle(baseStyle, scale);
}

float renderModeButtonRowWidth()
{
    const ImGuiStyle& style = ImGui::GetStyle();
    return renderModeButtonSize() * 3.0f + style.ItemSpacing.x * 2.0f;
}

float minimumViewerPaneWidth()
{
    return uiSize(380.0f);
}

void drawViewerPaneToggleButton(woby::UiState& state)
{
    if (drawRenderModeIconButton(
            "toggle_viewer_pane",
            state.viewerPaneVisible ? viewerPanePinnedIcon : viewerPaneUnpinnedIcon,
            state.viewerPaneVisible ? "Hide left pane (Ctrl+B)" : "Show left pane (Ctrl+B)",
            state.viewerPaneVisible ? RenderModeState::on : RenderModeState::off,
            false)) {
        woby::toggleViewerPaneVisible(state);
    }
}

void drawPropertiesPaneToggleButton(woby::UiState& state)
{
    if (drawRenderModeIconButton(
            "toggle_properties_pane",
            state.propertiesPaneVisible ? viewerPanePinnedIcon : viewerPaneUnpinnedIcon,
            state.propertiesPaneVisible ? "Hide properties pane" : "Show properties pane",
            state.propertiesPaneVisible ? RenderModeState::on : RenderModeState::off,
            false)) {
        woby::setPropertiesPaneVisible(state, !state.propertiesPaneVisible);
    }
}

void drawCameraToolbar(woby::UiState& state, const woby::SceneSelectionQueries& selection)
{
    const std::array<std::pair<const char*, woby::CameraView>, 6> views = {{
        {"Top", woby::CameraView::top}, {"Bottom", woby::CameraView::bottom},
        {"Front", woby::CameraView::front}, {"Back", woby::CameraView::back},
        {"Left", woby::CameraView::left}, {"Right", woby::CameraView::right},
    }};
    for (const auto& [label, view] : views) {
        if (woby::drawCameraViewButton(label, view, label)) { woby::setCameraView(state, view); }
        ImGui::SameLine();
    }
    if (drawRenderModeIconButton("fit_all", frameSceneIcon,
            "Fit all - frame the scene (R)", RenderModeState::off,
            state.files.empty() && state.comparisons.empty())) {
        woby::fitCameraToScene(state);
    }
    ImGui::SameLine();
    const bool selectionAvailable = selection.bounds.has_value();
    if (drawRenderModeIconButton("fit_selection", frameSceneIcon,
            "Fit selection", RenderModeState::off, !selectionAvailable)) {
        woby::fitCameraToSelection(state);
    }
    const auto low = ImGui::GetItemRectMin();
    const float centerX = low.x + renderModeButtonSize() * 0.5f;
    const float centerY = low.y + renderModeButtonSize() * 0.5f;
    const float radius = uiSize(3.0f);
    ImGui::GetWindowDrawList()->AddRect(ImVec2(centerX - radius, centerY - radius),
        ImVec2(centerX + radius, centerY + radius),
        ImGui::GetColorU32(ImGuiCol_TextDisabled, selectionAvailable ? 1.0f : ImGui::GetStyle().DisabledAlpha));
}

void drawPropertiesPane(woby::UiState& state, woby::ComparisonRuntimes& runtimes,
    const CanvasLayout& layout, woby::SceneInspectorRuntime& inspector)
{
    if (!state.propertiesPaneVisible) { return; }
    ImGui::SetNextWindowBgAlpha(1.0f);
    ImGui::SetNextWindowPos(ImVec2(layout.rightEdge, layout.top), ImGuiCond_Always, ImVec2(1.0f, 0.0f));
    ImGui::SetNextWindowSize(ImVec2(layout.rightWidth, layout.height - layout.top), ImGuiCond_Always);
    ImGui::SetNextWindowSizeConstraints(
        ImVec2(std::min(uiSize(300.0f), layout.rightWidth), layout.height - layout.top),
        ImVec2(layout.maxRightWidth, layout.height - layout.top));
    if (ImGui::Begin("##PropertiesPane", nullptr, ImGuiWindowFlags_NoTitleBar
        | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
        woby::setPropertiesPaneWidth(state, ImGui::GetWindowSize().x, uiSize(300.0f), layout.maxRightWidth);
        drawPropertiesPaneToggleButton(state);
        ImGui::SameLine();
        ImGui::TextUnformatted("Properties");
        ImGui::Separator();
        if (woby::selectedAnnotation(state)) {
            ImGui::BeginDisabled(!woby::scenePostLoadReady(state));
            woby::drawAnnotationInspector(state, inspector.sharedQueries);
            ImGui::EndDisabled();
        } else if (woby::selectedComparison(state)) {
            ImGui::BeginDisabled(!woby::scenePostLoadReady(state));
            woby::drawComparisonPanelContents(state, runtimes);
            ImGui::EndDisabled();
        } else {
            woby::drawSceneInspector(state, inspector);
        }
    }
    ImGui::End();
}

void drawPaneToggles(woby::UiState& state, float windowWidth, float top)
{
    const auto flags = ImGuiWindowFlags_NoDecoration
        | ImGuiWindowFlags_AlwaysAutoResize
        | ImGuiWindowFlags_NoMove
        | ImGuiWindowFlags_NoSavedSettings
        | ImGuiWindowFlags_NoFocusOnAppearing;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4.0f, 4.0f));
    if (!state.viewerPaneVisible) {
        ImGui::SetNextWindowBgAlpha(1.0f);
        ImGui::SetNextWindowPos(ImVec2(viewerPaneTogglePaneMargin, top + viewerPaneTogglePaneMargin), ImGuiCond_Always);
        if (ImGui::Begin("##ShowViewerPane", nullptr, flags)) {
            drawViewerPaneToggleButton(state);
            ImGui::SameLine();
            ImGui::TextUnformatted("Scene controls");
        }
        ImGui::End();
    }
    if (!state.propertiesPaneVisible) {
        ImGui::SetNextWindowBgAlpha(1.0f);
        ImGui::SetNextWindowPos(
            ImVec2(windowWidth - viewerPaneTogglePaneMargin, top + viewerPaneTogglePaneMargin),
            ImGuiCond_Always, ImVec2(1.0f, 0.0f));
        if (ImGui::Begin("##ShowPropertiesPane", nullptr, flags)) {
            drawPropertiesPaneToggleButton(state);
            ImGui::SameLine();
            ImGui::TextUnformatted("Properties");
        }
        ImGui::End();
    }
    ImGui::PopStyleVar();
}

void pushRenderModeControlHeight()
{
    const ImGuiStyle& style = ImGui::GetStyle();
    const float paddingY = std::max(
        (renderModeButtonSize() - ImGui::GetFontSize()) * 0.5f,
        0.0f);
    ImGui::PushStyleVar(
        ImGuiStyleVar_FramePadding,
        ImVec2(style.FramePadding.x, paddingY));
}

bool drawSceneItemInteraction(woby::UiState& state, woby::SceneObjectId id,
    bool treeNode, bool removableFile = false)
{
    if (woby::sceneObjectSelected(state, id)) {
        woby::drawSceneItemOutline();
    }
    // Ordinary clicks select on release so source drags keep the comparison inspector visible.
    // TreeNodeEx does not activate labels with Ctrl held, so Ctrl-clicks must be
    // handled on mouse-down instead of waiting for IsItemDeactivated().
    char selectionLabel[48];
    std::snprintf(selectionLabel, sizeof(selectionLabel), "source_click_%llu", static_cast<unsigned long long>(id));
    const auto selectionKey = ImGui::GetID(selectionLabel);
    auto* storage = ImGui::GetStateStorage();
    if (ImGui::IsItemClicked(ImGuiMouseButton_Left)) {
        const bool select = !treeNode || !ImGui::IsItemToggledOpen();
        const bool toggle = ImGui::GetIO().KeyCtrl;
        storage->SetBool(selectionKey, select && !toggle);
        if (select && toggle) {
            woby::selectSceneObject(state, id, true);
        }
    }
    const auto dragDelta = ImGui::GetMouseDragDelta(ImGuiMouseButton_Left);
    if (ImGui::IsItemDeactivated() && ImGui::IsItemHovered() && ImGui::IsMouseReleased(ImGuiMouseButton_Left)
        && storage->GetBool(selectionKey) && dragDelta.x == 0.0f && dragDelta.y == 0.0f) {
        woby::selectSceneObject(state, id);
    }
    if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
        woby::selectSceneObject(state, id, false, true);
    }
    if (ImGui::BeginDragDropSource()) {
        const auto sources = woby::sceneObjectSelected(state, id)
            ? state.selectedSceneObjects : std::vector<woby::SceneObjectId>{id};
        const auto parts = woby::comparisonObjectParts(state, sources);
        if (!parts.empty()) {
            ImGui::SetDragDropPayload(woby::comparisonSourcePayload, parts.data(),
                parts.size() * sizeof(woby::SceneObjectId));
            ImGui::Text("Add %zu parts to analysis input A or B", parts.size());
        } else {
            ImGui::TextUnformatted("This source has no triangular mesh parts.");
        }
        ImGui::EndDragDropSource();
    }
    bool removeFile = false;
    if (ImGui::BeginPopupContextItem("scene_item_context")) {
        if (ImGui::BeginMenu("Create analysis", woby::scenePostLoadReady(state) && !woby::comparisonObjectParts(state, state.selectedSceneObjects).empty())) {
            woby::drawAnalysisCreationMenu(state);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Analysis membership", !state.comparisons.empty())) {
            for (const auto& comparisonObject : state.comparisons) {
                ImGui::PushID(std::to_string(comparisonObject.objectId).c_str());
                if (ImGui::BeginMenu(comparisonObject.name.c_str())) {
                    const bool singleSource = woby::isUvAnalysis(comparisonObject.settings.type)
                        || woby::isSingleSourceMeshTask(woby::comparisonTask(state, comparisonObject.objectId));
                    const auto sourceSide = !woby::isUvAnalysis(comparisonObject.settings.type) && comparisonObject.a.empty()
                        && !comparisonObject.b.empty() ? woby::ComparisonSide::b : woby::ComparisonSide::a;
                    for (const auto side : {woby::ComparisonSide::a, woby::ComparisonSide::b}) {
                        if (singleSource && side != sourceSide) { continue; }
                        const auto action = woby::comparisonMembershipAction(state, state.selectedSceneObjects, side, comparisonObject.objectId);
                        const bool remove = action == woby::ComparisonMembershipAction::remove;
                        const char* label = singleSource
                            ? (remove ? "Remove from sources" : "Add to sources") : side == woby::ComparisonSide::a
                            ? (remove ? "Remove from A" : "Add to A") : (remove ? "Remove from B" : "Add to B");
                        if (ImGui::MenuItem(label, nullptr, false, action != woby::ComparisonMembershipAction::unavailable)) {
                            woby::setComparisonObjects(state, state.selectedSceneObjects, side, !remove, comparisonObject.objectId);
                            woby::selectSceneObject(state, comparisonObject.objectId);
                        }
                    }
                    ImGui::EndMenu();
                }
                ImGui::PopID();
            }
            ImGui::EndMenu();
        }
        if (removableFile) {
            ImGui::Separator();
            removeFile = ImGui::MenuItem("Remove file from scene");
        }
        ImGui::EndPopup();
    }
    return removeFile;
}

void drawGroupControls(
    woby::UiState& state,
    const woby::MeshNode& node,
    const GpuNodeRange& range,
    LoadedModelFile& file,
    size_t nodeIndex, const woby::SceneTreeQueries& queries)
{
    ImGui::PushID(static_cast<int>(nodeIndex));
    auto& settings = file.groupSettings[nodeIndex];
    if (drawVisibilityButton("visible", settings.visible, "part")) {
        woby::toggleGroupVisible(state, file, settings);
    }
    ImGui::SameLine();
    const bool memberA = woby::sceneTreeMember(queries, settings.objectId, woby::ComparisonSide::a);
    const bool memberB = woby::sceneTreeMember(queries, settings.objectId, woby::ComparisonSide::b);
    const char* badge = memberA ? (memberB ? "[A B] " : "[A] ") : (memberB ? "[B] " : "");
    drawClippedTextItem("##name", woby::meshNodeDisplayName(node).c_str(), ImGui::GetContentRegionAvail().x,
        woby::sceneObjectSelected(state, settings.objectId), badge);
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
        if (node.pointIndexCount) {
            ImGui::SetTooltip("%s\nPoints: %u", woby::meshNodeDisplayName(node).c_str(), node.pointIndexCount);
        } else {
            ImGui::SetTooltip(node.lineIndexCount ? "%s\nVertices: %u  Line segments: %u" : "%s\nVertices: %u  Triangles: %u",
                woby::meshNodeDisplayName(node).c_str(), range.pointIndexCount, node.lineIndexCount ? node.lineIndexCount / 2u : node.indexCount / 3u);
        }
    }
    drawSceneItemInteraction(state, settings.objectId, false);
    ImGui::PopID();
}

void drawSceneTreeNode(
    woby::UiState& state,
    std::vector<LoadedModelRuntime>& runtimes,
    woby::UiSceneNode& node,
    std::optional<size_t>& removeFileIndex,
    std::span<const woby::SceneObjectId> revealPath, const woby::SceneTreeQueries& queries)
{
    if (node.kind == woby::UiSceneNodeKind::folder) {
        const size_t groupCount = woby::sceneTreeSummary(queries, node.objectId).parts;
        const size_t visibleCount = woby::sceneTreeSummary(queries, node.objectId).visible;
        if (drawTriStateVisibilityButton(
                "visible",
                "Folder",
                visibleCount,
                groupCount)) {
            woby::setSceneNodeSubtreeVisible(state, node, visibleCount != groupCount);
        }
        ImGui::SameLine();
        const ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_SpanAvailWidth
            | ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick
            | (woby::sceneObjectSelected(state, node.objectId) ? ImGuiTreeNodeFlags_Selected : 0);
        if (std::find(revealPath.begin(), revealPath.end(), node.objectId) != revealPath.end()) { ImGui::SetNextItemOpen(true); }
        const bool folderOpen = ImGui::TreeNodeEx(node.name.c_str(), flags);
        drawSceneItemInteraction(state, node.objectId, true);
        if (folderOpen) {
            for (size_t childIndex = 0; childIndex < node.children.size(); ++childIndex) {
                ImGui::PushID(static_cast<int>(childIndex));
                drawSceneTreeNode(state, runtimes, node.children[childIndex], removeFileIndex, revealPath, queries);
                ImGui::PopID();
            }
            ImGui::TreePop();
        }
        return;
    }

    if (node.kind == woby::UiSceneNodeKind::file) {
        if (node.fileIndex >= state.files.size()) {
            return;
        }

        auto& file = state.files[node.fileIndex];
        const ImGuiStyle& style = ImGui::GetStyle();
        const float rowStartX = ImGui::GetCursorPosX();
        const float analysisControlStartX = rowStartX + ImGui::GetContentRegionAvail().x - renderModeButtonSize();
        const size_t fileGroupCount = woby::sceneTreeSummary(queries, node.objectId).parts;
        const size_t fileVisibleCount = woby::sceneTreeSummary(queries, node.objectId).visible;
        if (drawTriStateVisibilityButton(
                "visible",
                "File",
                fileVisibleCount,
                fileGroupCount)) {
            woby::setSceneNodeSubtreeVisible(state, node, fileVisibleCount != fileGroupCount);
        }
        ImGui::SameLine();
        // Reserve the analysis button's column for drawing and hit testing.
        const ImVec2 labelClipMin = ImGui::GetWindowDrawList()->GetClipRectMin();
        ImVec2 labelClipMax = ImGui::GetWindowDrawList()->GetClipRectMax();
        labelClipMax.x = ImGui::GetCursorScreenPos().x + analysisControlStartX
            - ImGui::GetCursorPosX() - style.ItemSpacing.x;
        ImGui::PushClipRect(labelClipMin, labelClipMax, true);
        const ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_SpanAvailWidth
            | ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick
            | (woby::sceneObjectSelected(state, node.objectId) ? ImGuiTreeNodeFlags_Selected : 0);
        if (std::find(revealPath.begin(), revealPath.end(), node.objectId) != revealPath.end()) { ImGui::SetNextItemOpen(true); }
        const bool fileTreeOpen = ImGui::TreeNodeEx("file", flags, "%s", node.name.c_str());
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) {
            ImGui::SetTooltip("%s\nVertices: %zu  Triangles: %zu", woby::pathToUtf8(file.path).c_str(),
                meshGeometry(file.mesh).vertices.size(), meshGeometry(file.mesh).indices.size() / 3u);
        }
        if (drawSceneItemInteraction(state, node.objectId, true, true)) {
            removeFileIndex = node.fileIndex;
        }
        ImGui::PopClipRect();
        ImGui::SameLine(analysisControlStartX, 0.0f);
        const bool canAnalyze = woby::postLoadReady(file) && woby::fileHasComparableParts(file);
        if (woby::drawRenderModeIconButton("analysis", "\xef\x82\x80", "Create analysis for this file",
                woby::RenderModeState::off, !canAnalyze)) {
            ImGui::OpenPopup("analysis_type");
        }
        ImGui::SetNextWindowPos({ImGui::GetItemRectMin().x, ImGui::GetItemRectMax().y}, ImGuiCond_Appearing);
        if (ImGui::BeginPopup("analysis_type")) {
            woby::drawAnalysisCreationMenu(state, {node.objectId});
            ImGui::EndPopup();
        }
        if (fileTreeOpen) {
            for (size_t childIndex = 0; childIndex < node.children.size(); ++childIndex) {
                ImGui::PushID(static_cast<int>(childIndex));
                drawSceneTreeNode(state, runtimes, node.children[childIndex], removeFileIndex, revealPath, queries);
                ImGui::PopID();
            }
            ImGui::TreePop();
        }
        return;
    }

    if (node.fileIndex >= state.files.size() || node.fileIndex >= runtimes.size()) {
        return;
    }

    auto& file = state.files[node.fileIndex];
    const auto& gpuMesh = runtimes[node.fileIndex].gpuMesh;
    if (node.groupIndex >= meshGeometry(file.mesh).nodes.size() || node.groupIndex >= gpuMesh.nodeRanges.size()) {
        return;
    }

    drawGroupControls(
        state,
        meshGeometry(file.mesh).nodes[node.groupIndex],
        gpuMesh.nodeRanges[node.groupIndex],
        file,
        node.groupIndex, queries);
    if (!revealPath.empty() && revealPath.back() == node.objectId) { ImGui::SetScrollHereY(.5f); }
}

struct SdlDeleter {
    void operator()(SDL_Window* window) const noexcept
    {
        if (window != nullptr) {
            SDL_DestroyWindow(window);
        }
    }
};

double elapsedMilliseconds(woby::PerformanceClock::time_point start);

void appendFolderModelPaths(
    const std::filesystem::path& folder,
    std::vector<std::filesystem::path>& modelPaths)
{
    const auto start = woby::PerformanceClock::now();
    const std::vector<std::filesystem::path> folderPaths = woby::collectModelPathsRecursive(folder);
    spdlog::info(
        "perf folder_scan path=\"{}\" model_count={} duration_ms={}",
        woby::pathToUtf8(folder),
        folderPaths.size(),
        elapsedMilliseconds(start));
    if (folderPaths.empty()) {
        throw std::runtime_error("Folder did not contain model files recursively: " + woby::pathToUtf8(folder));
    }

    modelPaths.insert(modelPaths.end(), folderPaths.begin(), folderPaths.end());
}

spdlog::level::level_enum toSpdlogLevel(woby::LogLevel level)
{
    switch (level) {
    case woby::LogLevel::off:
        return spdlog::level::off;
    case woby::LogLevel::trace:
        return spdlog::level::trace;
    case woby::LogLevel::debug:
        return spdlog::level::debug;
    case woby::LogLevel::info:
        return spdlog::level::info;
    case woby::LogLevel::warn:
        return spdlog::level::warn;
    case woby::LogLevel::error:
        return spdlog::level::err;
    case woby::LogLevel::critical:
        return spdlog::level::critical;
    }

    throw std::runtime_error("Unsupported log level.");
}

void initializeLogging(const woby::AppArguments& arguments)
{
    if (arguments.logLevel == woby::LogLevel::off) {
        spdlog::set_level(spdlog::level::off);
        return;
    }

    const spdlog::level::level_enum level = toSpdlogLevel(arguments.logLevel);
    const auto logger = spdlog::basic_logger_mt("woby", arguments.logFile.value().string());
    logger->set_level(level);
    logger->flush_on(level);
    spdlog::set_default_logger(logger);
    spdlog::set_level(level);
    spdlog::info("woby version {}", WOBY_VERSION);
}

double elapsedMilliseconds(woby::PerformanceClock::time_point start)
{
    return woby::millisecondsBetween(start, woby::PerformanceClock::now());
}

double timerTicksToMilliseconds(int64_t ticks, int64_t frequency)
{
    if (frequency <= 0) {
        return 0.0;
    }

    return (static_cast<double>(ticks) * 1000.0) / static_cast<double>(frequency);
}

void copyGraphicsStats(woby::FrameTimings& timings)
{
    const woby::graphics::Stats* stats = woby::graphics::getStats();
    if (stats == nullptr) {
        return;
    }

    timings.graphicsCpuFrameMilliseconds = timerTicksToMilliseconds(stats->cpuTimeFrame, stats->cpuTimerFreq);
    timings.graphicsCpuSubmitMilliseconds =
        timerTicksToMilliseconds(stats->cpuTimeEnd - stats->cpuTimeBegin, stats->cpuTimerFreq);
    if (stats->gpuTimerFreq > 0 && stats->gpuTimeEnd > stats->gpuTimeBegin) {
        timings.graphicsGpuFrameMilliseconds =
            timerTicksToMilliseconds(stats->gpuTimeEnd - stats->gpuTimeBegin, stats->gpuTimerFreq);
        timings.hasGraphicsGpuFrameMilliseconds = true;
    }
}

void recordFrameStage(
    woby::FrameTimings& timings,
    woby::FrameStage stage,
    woby::PerformanceClock::time_point& stageStart)
{
    const auto now = woby::PerformanceClock::now();
    timings.stageMilliseconds[static_cast<size_t>(stage)] += woby::millisecondsBetween(stageStart, now);
    stageStart = now;
}

ResolvedModelInputs resolveModelInputs(const woby::AppArguments& options)
{
    ResolvedModelInputs inputs;

    for (const auto& inputPath : options.inputPaths) {
        ResolvedModelInputGroup group;
        group.folderTree = inputPath.folderTree;
        group.root = inputPath.path;
        group.firstPathIndex = inputs.paths.size();

        if (inputPath.folder) {
            appendFolderModelPaths(inputPath.path, inputs.paths);
            group.pathCount = inputs.paths.size() - group.firstPathIndex;
            inputs.groups.push_back(std::move(group));
            continue;
        }

        inputs.paths.push_back(inputPath.path);
        group.pathCount = 1u;
        inputs.groups.push_back(std::move(group));
    }

    return inputs;
}

void appendSceneNodesForResolvedInputs(
    woby::UiState& state,
    const ResolvedModelInputs& inputs,
    size_t firstFileIndex)
{
    for (const auto& group : inputs.groups) {
        if (group.pathCount == 0u) {
            continue;
        }

        if (group.folderTree) {
            woby::appendFolderTreeSceneNode(
                state,
                group.root,
                firstFileIndex + group.firstPathIndex,
                group.pathCount);
            continue;
        }

        for (size_t offset = 0; offset < group.pathCount; ++offset) {
            const size_t fileIndex = firstFileIndex + group.firstPathIndex + offset;
            if (fileIndex < state.files.size()) {
                state.sceneNodes.push_back(woby::createFileSceneNode(state.files[fileIndex], fileIndex));
            }
        }
    }

    woby::assignSceneObjectIds(state);
    woby::refreshSceneTreeFolderCenters(state);
}

void rememberAddedModels(woby::RecentFilesRuntime& recentFiles, const woby::UiState& state, size_t firstFileIndex)
{
    const size_t retainedStart = state.files.size() > woby::recentFileLimit
        ? state.files.size() - woby::recentFileLimit : 0;
    for (size_t i = std::max(firstFileIndex, retainedStart); i < state.files.size(); ++i) {
        woby::rememberRecentFile(recentFiles, woby::RecentFileKind::model, state.files[i].path);
    }
}

void removeModelFile(
    woby::UiState& state,
    std::vector<LoadedModelRuntime>& runtimes,
    size_t fileIndex, woby::AnnotationPreparationRuntime& preparation)
{
    if (fileIndex >= runtimes.size()) {
        return;
    }

    woby::cancelAnnotationPreparation(preparation);
    woby::graphics::cancelBufferUpload(runtimes[fileIndex].featureUpload);
    destroyGpuMesh(runtimes[fileIndex].gpuMesh);
    runtimes.erase(runtimes.begin() + static_cast<std::ptrdiff_t>(fileIndex));
    (void)woby::removeFileFromState(state, fileIndex);
}

void pushDroppedPath(DragDropState& state, const char* data)
{
    if (data == nullptr) {
        return;
    }

    if (state.active) {
        state.batchPaths.push_back(woby::pathFromUtf8(data));
    } else {
        state.pendingPaths.push_back(woby::pathFromUtf8(data));
    }
}

void finishDropBatch(DragDropState& state)
{
    state.pendingPaths.insert(
        state.pendingPaths.end(),
        state.batchPaths.begin(),
        state.batchPaths.end());
    state.batchPaths.clear();
    state.active = false;
}

std::vector<std::filesystem::path> takePendingDropPaths(DragDropState& state)
{
    std::vector<std::filesystem::path> paths;
    paths.swap(state.pendingPaths);
    return paths;
}

struct DroppedPathClassification {
    std::vector<std::filesystem::path> modelPaths;
    std::vector<std::filesystem::path> scenePaths;
    size_t unsupportedCount = 0;
    size_t emptyFolderCount = 0;
    size_t failedFolderCount = 0;
    std::string lastFolderError;
};

DroppedPathClassification classifyDroppedPaths(
    const std::vector<std::filesystem::path>& paths)
{
    const auto start = woby::PerformanceClock::now();
    DroppedPathClassification classification;

    for (const auto& path : paths) {
        std::error_code error;
        if (std::filesystem::is_directory(path, error)) {
            try {
                const std::vector<std::filesystem::path> folderModelPaths =
                    woby::collectModelPathsRecursive(path);
                if (folderModelPaths.empty()) {
                    ++classification.emptyFolderCount;
                } else {
                    classification.modelPaths.insert(
                        classification.modelPaths.end(),
                        folderModelPaths.begin(),
                        folderModelPaths.end());
                }
            } catch (const std::exception& exception) {
                ++classification.failedFolderCount;
                classification.lastFolderError = exception.what();
            }
            continue;
        }

        if (woby::isModelPath(path)) {
            classification.modelPaths.push_back(path);
            continue;
        }

        if (woby::isWobyPath(path)) {
            classification.scenePaths.push_back(path);
            continue;
        }

        ++classification.unsupportedCount;
    }

    spdlog::info(
        "perf dropped_path_classification input_count={} model_count={} scene_count={} unsupported_count={} empty_folder_count={} failed_folder_count={} duration_ms={}",
        paths.size(),
        classification.modelPaths.size(),
        classification.scenePaths.size(),
        classification.unsupportedCount,
        classification.emptyFolderCount,
        classification.failedFolderCount,
        elapsedMilliseconds(start));
    return classification;
}

void appendDropClassificationStatus(
    std::string& status,
    const DroppedPathClassification& classification)
{
    if (classification.unsupportedCount > 0u) {
        status += ", skipped " + std::to_string(classification.unsupportedCount) + " unsupported";
    }
    if (classification.emptyFolderCount > 0u) {
        status += ", skipped " + std::to_string(classification.emptyFolderCount) + " empty folder";
        if (classification.emptyFolderCount != 1u) {
            status += "s";
        }
    }
    if (classification.failedFolderCount > 0u) {
        status += ", failed " + std::to_string(classification.failedFolderCount) + " folder";
        if (classification.failedFolderCount != 1u) {
            status += "s";
        }
        if (!classification.lastFolderError.empty()) {
            status += ": " + classification.lastFolderError;
        }
    }
}

void resetSceneToUntitled(
    woby::UiState& state,
    std::vector<LoadedModelRuntime>& runtimes,
    std::optional<std::filesystem::path>& currentScenePath,
    woby::SceneDocument& cleanSceneDocument, woby::AnnotationPreparationRuntime& preparation)
{
    woby::cancelAnnotationPreparation(preparation);
    auto document = woby::createSceneDocument(woby::UiState{});
    document.camera.reset(); // New scenes frame the default display bounds.
    auto prepared = woby::prepareSceneReplacement(state, {}, document);
    auto clean = woby::createSceneDocument(prepared);
    destroyModelRuntimes(runtimes);
    state = std::move(prepared);
    cleanSceneDocument = std::move(clean);
    currentScenePath.reset();
}

std::filesystem::path saveSceneToPath(
    const std::filesystem::path& requestedScenePath,
    woby::UiState& state,
    std::optional<std::filesystem::path>& currentScenePath,
    woby::SceneDocument& cleanSceneDocument)
{
    if (const auto error = woby::saveSceneState(state, currentScenePath, cleanSceneDocument, requestedScenePath, true)) {
        throw std::runtime_error(error->message);
    }
    return *currentScenePath;
}

void setToastMessage(ToastMessage& toast, std::string text)
{
    toast.text = std::move(text);
    toast.startedAt = std::chrono::steady_clock::now();
}

void resetBackgroundLoadProgress(
    BackgroundLoadRuntime& load,
    AsyncLoadKind kind,
    size_t totalCount)
{
    std::lock_guard<std::mutex> lock(load.mutex);
    load.progress = woby::BackgroundLoadProgress{};
    load.progress.totalCount = totalCount;
    load.kind = kind;
    load.outcome.reset();
}

void updateBackgroundLoadProgress(
    BackgroundLoadRuntime& load,
    const woby::BackgroundLoadProgress& progress)
{
    std::lock_guard<std::mutex> lock(load.mutex);
    load.progress = progress;
}

bool startAppendModelBackgroundLoad(
    BackgroundLoadRuntime& load,
    std::vector<std::filesystem::path> modelPaths,
    size_t firstColorIndex,
    AsyncLoadKind kind = AsyncLoadKind::appendModel,
    std::filesystem::path folderTreeRoot = {})
{
    if (load.active) {
        return false;
    }

    if (load.worker.joinable()) {
        load.worker.join();
    }

    resetBackgroundLoadProgress(load, kind, modelPaths.size());
    load.cancelRequested.store(false);
    load.active = true;
    try {
        load.worker = std::thread([
            &load,
            modelPaths = std::move(modelPaths),
            firstColorIndex,
            kind,
            folderTreeRoot = std::move(folderTreeRoot)
        ]() mutable {
            AsyncLoadOutcome outcome;
            outcome.kind = kind;
            outcome.folderTreeRoot = std::move(folderTreeRoot);
            try {
                outcome.modelBatch = woby::loadModelBatchCpu(
                    modelPaths,
                    firstColorIndex,
                    [&load](const woby::BackgroundLoadProgress& progress) {
                        updateBackgroundLoadProgress(load, progress);
                    },
                    [&load]() {
                        return load.cancelRequested.load();
                    }, true, true);
            } catch (const std::exception& exception) {
                outcome.failed = true;
                outcome.error = exception.what();
            }

            std::lock_guard<std::mutex> lock(load.mutex);
            load.outcome = std::move(outcome);
        });
    } catch (...) {
        load.active = false;
        throw;
    }
    return true;
}

bool startAppendFolderTreeBackgroundLoad(
    BackgroundLoadRuntime& load,
    const std::filesystem::path& folder,
    size_t firstColorIndex,
    std::string& status)
{
    if (load.active) {
        return false;
    }

    std::vector<std::filesystem::path> modelPaths;
    try {
        appendFolderModelPaths(folder, modelPaths);
    } catch (const std::exception& exception) {
        status = std::string("Open folder tree failed: ") + exception.what();
        return true;
    }

    return startAppendModelBackgroundLoad(
        load,
        std::move(modelPaths),
        firstColorIndex,
        AsyncLoadKind::appendFolderTree,
        normalizedPath(folder));
}

bool startOpenSceneBackgroundLoad(
    BackgroundLoadRuntime& load,
    const std::filesystem::path& requestedScenePath)
{
    if (load.active) {
        return false;
    }

    if (load.worker.joinable()) {
        load.worker.join();
    }

    const std::filesystem::path scenePath = normalizedPath(requestedScenePath);
    resetBackgroundLoadProgress(load, AsyncLoadKind::openScene, 0u);
    load.cancelRequested.store(false);
    load.active = true;
    try {
        load.worker = std::thread([&load, scenePath]() {
            AsyncLoadOutcome outcome;
            outcome.kind = AsyncLoadKind::openScene;
            try {
                outcome.scene = woby::loadSceneCpu(
                    scenePath,
                    [&load](const woby::BackgroundLoadProgress& progress) {
                        updateBackgroundLoadProgress(load, progress);
                    },
                    [&load]() {
                        return load.cancelRequested.load();
                    }, true, true);
            } catch (const std::exception& exception) {
                outcome.failed = true;
                outcome.error = exception.what();
            }

            std::lock_guard<std::mutex> lock(load.mutex);
            load.outcome = std::move(outcome);
        });
    } catch (...) {
        load.active = false;
        throw;
    }
    return true;
}

std::optional<AsyncLoadOutcome> takeBackgroundLoadOutcome(BackgroundLoadRuntime& load)
{
    std::optional<AsyncLoadOutcome> outcome;
    {
        std::lock_guard<std::mutex> lock(load.mutex);
        outcome = std::move(load.outcome);
        load.outcome.reset();
    }

    if (!outcome.has_value()) {
        return {};
    }

    if (load.worker.joinable()) {
        load.worker.join();
    }
    load.active = false;
    if (load.cancelRequested.exchange(false)) {
        if (outcome->kind == AsyncLoadKind::openScene) { outcome->scene.canceled = true; }
        else { outcome->modelBatch.canceled = true; outcome->modelBatch.status = "Loading canceled"; }
    }
    return outcome;
}

void startGpuFinalize(GpuFinalizeRuntime& finalize, AsyncLoadOutcome outcome, const woby::UiState& state, const woby::graphics::VertexLayout& layout, const ResolvedModelInputs& initialInputs)
{
    finalize = GpuFinalizeRuntime{};
    if (outcome.kind == AsyncLoadKind::initialModels) { finalize.initialInputs = initialInputs; }
    finalize.kind = outcome.kind;
    finalize.folderTreeRoot = std::move(outcome.folderTreeRoot);
    if (isAppendModelLoadKind(outcome.kind)) {
        finalize.files = std::move(outcome.modelBatch.files);
        finalize.preparations = std::move(outcome.modelBatch.preparations);
        finalize.sourceFailedCount = outcome.modelBatch.failedCount;
        finalize.sourceSkippedCount = outcome.modelBatch.skippedCount;
        finalize.lastError = std::move(outcome.modelBatch.lastError);
    } else {
        finalize.scenePath = std::move(outcome.scene.scenePath);
        finalize.sceneDocument = std::move(outcome.scene.document);
        finalize.files = std::move(outcome.scene.files);
        finalize.preparations = std::move(outcome.scene.preparations);
    }
    finalize.sceneGeneration = state.sceneGeneration;
    finalize.uploads.resize(finalize.files.size());
    finalize.uploadErrors.resize(finalize.files.size());
    for (size_t i = 0; i < finalize.files.size(); ++i) {
        try { finalize.uploads[i] = woby::beginGpuMeshUpload(std::move(finalize.preparations[i]), finalize.files[i].mesh, layout); }
        catch (const std::exception& error) { finalize.uploadErrors[i] = error.what(); }
    }
    finalize.finalizedFiles.reserve(finalize.files.size());
    finalize.finalizedRuntimes.reserve(finalize.files.size());
    finalize.active = true;
}

std::string appendFinalizeStatus(const GpuFinalizeRuntime& finalize)
{
    const size_t failedCount = finalize.sourceFailedCount + finalize.gpuFailedCount;
    std::string status = "Added " + std::to_string(finalize.finalizedFiles.size()) + " model file";
    if (finalize.finalizedFiles.size() != 1u) {
        status += "s";
    }
    if (finalize.sourceSkippedCount > 0u) {
        status += ", skipped " + std::to_string(finalize.sourceSkippedCount) + " non-model";
    }
    if (failedCount > 0u) {
        status += ", failed " + std::to_string(failedCount);
        if (!finalize.lastError.empty()) {
            status += ": " + finalize.lastError;
        }
    }
    return status;
}

void abortGpuFinalize(GpuFinalizeRuntime& finalize)
{
    for (auto& upload : finalize.uploads) { if (upload) { woby::abortGpuMeshUpload(*upload); } }
    destroyModelRuntimes(finalize.finalizedRuntimes);
    finalize = GpuFinalizeRuntime{};
}

void commitGpuFinalize(
    GpuFinalizeRuntime& finalize,
    woby::UiState& state,
    std::vector<LoadedModelRuntime>& runtimes,
    std::optional<std::filesystem::path>& currentScenePath,
    woby::SceneDocument& cleanSceneDocument,
    ToastMessage& toast)
{
    if (isAppendModelLoadKind(finalize.kind)) {
        const bool addedAnyFiles = !finalize.finalizedFiles.empty();
        const size_t firstFileIndex = state.files.size();
        state.files.insert(
            state.files.end(),
            std::make_move_iterator(finalize.finalizedFiles.begin()),
            std::make_move_iterator(finalize.finalizedFiles.end()));
        runtimes.insert(
            runtimes.end(),
            std::make_move_iterator(finalize.finalizedRuntimes.begin()),
            std::make_move_iterator(finalize.finalizedRuntimes.end()));
        if (addedAnyFiles) {
            if (finalize.kind == AsyncLoadKind::initialModels) {
                appendSceneNodesForResolvedInputs(state, finalize.initialInputs, firstFileIndex);
            } else if (finalize.kind == AsyncLoadKind::appendFolderTree) {
                woby::appendFolderTreeSceneNode(
                    state,
                    finalize.folderTreeRoot,
                    firstFileIndex,
                    finalize.finalizedFiles.size());
            } else {
                woby::appendDefaultSceneNodesForFiles(state, firstFileIndex);
            }
            woby::recalculateSceneBounds(state);
            woby::frameCameraToScene(state);
            woby::markSceneDirty(state);
        }
        setToastMessage(toast, appendFinalizeStatus(finalize));
    } else {
        auto prepared = woby::prepareSceneReplacement(state, std::move(finalize.finalizedFiles), finalize.sceneDocument);
        auto clean = woby::createSceneDocument(prepared);
        auto path = finalize.scenePath;
        auto message = "Opened scene " + fileDisplayName(finalize.scenePath);
        destroyModelRuntimes(runtimes);
        runtimes = std::move(finalize.finalizedRuntimes);
        state = std::move(prepared);
        currentScenePath = std::move(path);
        cleanSceneDocument = std::move(clean);
        setToastMessage(toast, std::move(message));
    }

    finalize = GpuFinalizeRuntime{};
}

std::optional<std::string> processGpuFinalizeStep(
    GpuFinalizeRuntime& finalize,
    woby::UiState& state,
    std::vector<LoadedModelRuntime>& runtimes,
    std::optional<std::filesystem::path>& currentScenePath,
    woby::SceneDocument& cleanSceneDocument,
    ToastMessage& toast)
{
    if (!finalize.active) {
        return {};
    }

    if (finalize.cancelRequested || finalize.sceneGeneration != state.sceneGeneration) {
        abortGpuFinalize(finalize);
        setToastMessage(toast, "Loading canceled");
        return std::string("Loading canceled");
    }

    if (finalize.nextFileIndex >= finalize.files.size()) {
        try {
            commitGpuFinalize(finalize, state, runtimes, currentScenePath, cleanSceneDocument, toast);
            return std::string{};
        } catch (const std::exception& exception) {
            const std::string error = exception.what();
            setToastMessage(toast, "Open scene failed: " + error);
            abortGpuFinalize(finalize);
            return error;
        }
    }

    while (finalize.nextFileIndex < finalize.files.size()) {
        auto& upload = finalize.uploads[finalize.nextFileIndex];
        auto& file = finalize.files[finalize.nextFileIndex];
        try {
            if (!finalize.uploadErrors[finalize.nextFileIndex].empty()) { throw std::runtime_error(finalize.uploadErrors[finalize.nextFileIndex]); }
            if (!woby::pollGpuMeshUpload(*upload)) { return {}; }
            const auto stats = woby::graphics::bufferUploadStats(upload->ticket);
            spdlog::info("perf model_gpu_finalize path=\"{}\" bytes={} upload_ms={} submissions={} waits={} staging_bytes={} peak_staging_bytes={}",
                woby::pathToUtf8(file.path), stats.uploadedBytes, stats.milliseconds, stats.submissions, stats.waits, stats.stagingBytes, stats.peakStagingBytes);
            LoadedModelRuntime runtime;
            runtime.requestedFeatures = upload->features;
            runtime.gpuMesh = std::move(upload->mesh);
            finalize.finalizedRuntimes.push_back(std::move(runtime));
            finalize.finalizedFiles.push_back(std::move(file));
            upload.reset();
            ++finalize.nextFileIndex;
        } catch (const std::exception& exception) {
            if (upload) { woby::abortGpuMeshUpload(*upload); upload.reset(); }
            ++finalize.nextFileIndex; ++finalize.gpuFailedCount;
            finalize.lastError = exception.what();
            finalize.gpuFailures.push_back({file.path, "failed", exception.what()});
            if (!isAppendModelLoadKind(finalize.kind) || finalize.kind == AsyncLoadKind::initialModels) {
                const std::string error = exception.what();
                setToastMessage(toast, "Open scene failed: " + error);
                abortGpuFinalize(finalize);
                return error;
            }
        }
    }
    return {};
}

void openSceneOrRequestDirtyWarning(
    const std::filesystem::path& scenePath,
    woby::UiState& state,
    BackgroundLoadRuntime& backgroundLoad,
    GpuFinalizeRuntime& gpuFinalize,
    SceneFileDialogState& sceneFileDialogState,
    ToastMessage& toast,
    std::optional<std::filesystem::path>& pendingDirtyOpenScenePath,
    bool& requestDirtyOpenWarning)
{
    if (backgroundLoad.active || gpuFinalize.active) {
        setSceneFileDialogStatus(sceneFileDialogState, "Already processing files");
        return;
    }

    if (state.isDirty) {
        pendingDirtyOpenScenePath = normalizedPath(scenePath);
        requestDirtyOpenWarning = true;
        return;
    }

    if (!startOpenSceneBackgroundLoad(backgroundLoad, scenePath)) {
        setSceneFileDialogStatus(
            sceneFileDialogState,
            "Open scene failed: already processing files");
    } else {
        setToastMessage(toast, "Opening scene " + fileDisplayName(scenePath));
    }
}

void processDroppedPaths(
    const std::vector<std::filesystem::path>& paths,
    woby::UiState& state,
    BackgroundLoadRuntime& backgroundLoad,
    GpuFinalizeRuntime& gpuFinalize,
    SceneFileDialogState& sceneFileDialogState,
    ToastMessage& toast,
    std::optional<std::filesystem::path>& pendingDirtyOpenScenePath,
    bool& requestDirtyOpenWarning)
{
    const auto start = woby::PerformanceClock::now();
    const DroppedPathClassification classification = classifyDroppedPaths(paths);
    const size_t extraPathCount = classification.modelPaths.size()
        + classification.unsupportedCount
        + classification.emptyFolderCount
        + classification.failedFolderCount;

    if (!classification.scenePaths.empty()) {
        if (classification.scenePaths.size() != 1u || extraPathCount > 0u) {
            setToastMessage(toast, "Drop one .woby scene file by itself");
            spdlog::info(
                "perf dropped_paths_processed input_count={} duration_ms={}",
                paths.size(),
                elapsedMilliseconds(start));
            return;
        }

        openSceneOrRequestDirtyWarning(
            classification.scenePaths[0],
            state,
            backgroundLoad,
            gpuFinalize,
            sceneFileDialogState,
            toast,
            pendingDirtyOpenScenePath,
            requestDirtyOpenWarning);
        spdlog::info(
            "perf dropped_paths_processed input_count={} duration_ms={}",
            paths.size(),
            elapsedMilliseconds(start));
        return;
    }

    std::string status;
    if (classification.modelPaths.empty()) {
        status = "No model files added";
    } else {
        if (!startAppendModelBackgroundLoad(
                backgroundLoad,
                classification.modelPaths,
                woby::totalGroupCount(state))) {
            status = "Already processing files";
        }
    }
    appendDropClassificationStatus(status, classification);
    if (!status.empty()) {
        setToastMessage(toast, std::move(status));
    }
    spdlog::info(
        "perf dropped_paths_processed input_count={} duration_ms={}",
        paths.size(),
        elapsedMilliseconds(start));
}

void drawToastMessage(const ToastMessage& toast, const woby::SceneViewport& viewport, uint32_t drawableWidth,
    float messageOffset)
{
    const float elapsed = std::chrono::duration<float>(std::chrono::steady_clock::now() - toast.startedAt).count();
    if (toast.text.empty() || elapsed >= toastDurationSeconds) {
        return;
    }
    const float alpha = std::clamp((toastDurationSeconds - elapsed) / 0.35f, 0.0f, 1.0f);
    // Rendering uses drawable pixels; ImGui positions use logical window coordinates.
    const float windowScale = ImGui::GetIO().DisplaySize.x / static_cast<float>(std::max(drawableWidth, 1u));
    const float centerX = (static_cast<float>(viewport.x) + static_cast<float>(viewport.width) * 0.5f) * windowScale;
    const float textWidth = std::max(1.0f, static_cast<float>(viewport.width) * windowScale
        - uiSize(toastMargin * 2.0f + 24.0f));
    ImGui::SetNextWindowBgAlpha(0.86f * alpha);
    ImGui::SetNextWindowPos(ImVec2(centerX, messageOffset + uiSize(toastMargin)), ImGuiCond_Always, ImVec2(0.5f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(uiSize(12.0f), uiSize(8.0f)));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, alpha));
    if (ImGui::Begin("##ToastMessage", nullptr, ImGuiWindowFlags_NoDecoration
        | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings
        | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoInputs)) {
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + textWidth);
        ImGui::TextUnformatted(toast.text.c_str());
        ImGui::PopTextWrapPos();
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();
}

bool drawProcessingDialog(BackgroundLoadRuntime& backgroundLoad, GpuFinalizeRuntime& gpuFinalize)
{
    bool backgroundActive = false;
    bool finalizingActive = gpuFinalize.active;
    AsyncLoadKind kind = AsyncLoadKind::appendModel;
    woby::BackgroundLoadProgress progress;
    {
        std::lock_guard<std::mutex> lock(backgroundLoad.mutex);
        backgroundActive = backgroundLoad.active;
        kind = backgroundLoad.kind;
        progress = backgroundLoad.progress;
    }

    if (!backgroundActive && !finalizingActive) {
        return false;
    }

    ImGui::OpenPopup("Processing files");
    bool modalOpen = false;
    if (ImGui::BeginPopupModal(
            "Processing files",
            nullptr,
            ImGuiWindowFlags_AlwaysAutoResize)) {
        modalOpen = true;
        if (backgroundActive) {
            ImGui::TextUnformatted(backgroundLoadDescription(kind));
            if (!progress.currentPath.empty()) {
                ImGui::Text(
                    "%s",
                    fileDisplayName(progress.currentPath).c_str());
            }
            ImGui::TextUnformatted(woby::modelLoadStageName(progress.model.stage));
            if (progress.model.total) {
                const float stageFraction = std::min(1.0f, static_cast<float>(progress.model.completed) / static_cast<float>(progress.model.total));
                ImGui::ProgressBar(stageFraction, ImVec2(320.0f, 0.0f));
            } else {
                ImGui::TextDisabled("In progress...");
            }
            if (progress.totalCount > 0u) {
                const float fraction = (static_cast<float>(std::min(progress.completedCount, progress.totalCount)) + progress.currentFileFraction)
                    / static_cast<float>(progress.totalCount);
                ImGui::ProgressBar(
                    fraction,
                    ImVec2(260.0f, 0.0f),
                    (std::to_string(std::min(progress.totalCount, progress.completedCount
                        + (progress.model.stage == woby::ModelLoadStage::ready ? 1u : 0u)))
                        + " / " + std::to_string(progress.totalCount) + " files prepared").c_str());
            } else {
                ImGui::TextUnformatted("Preparing...");
            }
            if (ImGui::Button("Cancel") || ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                backgroundLoad.cancelRequested.store(true);
            }
            setLastItemTooltip("Cancel loading (Esc).");
        } else if (finalizingActive) {
            ImGui::TextUnformatted("Finalizing GPU resources...");
            if (gpuFinalize.nextFileIndex < gpuFinalize.files.size()) {
                ImGui::Text(
                    "%s",
                    fileDisplayName(gpuFinalize.files[gpuFinalize.nextFileIndex].path).c_str());
            }
            if (!gpuFinalize.files.empty()) {
                const auto* upload = gpuFinalize.nextFileIndex < gpuFinalize.uploads.size() && gpuFinalize.uploads[gpuFinalize.nextFileIndex]
                    ? &*gpuFinalize.uploads[gpuFinalize.nextFileIndex] : nullptr;
                const float currentFraction = upload && upload->totalBytes
                    ? static_cast<float>(woby::graphics::bufferUploadStats(upload->ticket).uploadedBytes) / static_cast<float>(upload->totalBytes) : 0.0f;
                const float fraction = (static_cast<float>(std::min(gpuFinalize.nextFileIndex, gpuFinalize.files.size())) + currentFraction)
                    / static_cast<float>(gpuFinalize.files.size());
                ImGui::ProgressBar(
                    fraction,
                    ImVec2(260.0f, 0.0f),
                    (std::to_string(gpuFinalize.nextFileIndex) + " / " + std::to_string(gpuFinalize.files.size())).c_str());
            } else {
                ImGui::TextUnformatted("Committing scene...");
            }
            if (ImGui::Button("Cancel") || ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                gpuFinalize.cancelRequested = true;
            }
        }
        ImGui::EndPopup();
    }

    return modalOpen;
}

void drawHoveredVertexOverlay(const std::optional<HoveredVertex>& hoveredVertex,
    const woby::SceneViewport& viewport, uint32_t drawableWidth, bool asynchronous)
{
    if (!hoveredVertex.has_value()) {
        return;
    }

    const float windowScale = ImGui::GetIO().DisplaySize.x / static_cast<float>(std::max(drawableWidth, 1u));
    ImGui::SetNextWindowBgAlpha(1.0f);
    ImGui::SetNextWindowPos(
        ImVec2(
            static_cast<float>(viewport.x + viewport.width) * windowScale - uiSize(toastMargin),
            static_cast<float>(viewport.y + viewport.height) * windowScale - uiSize(toastMargin)),
        ImGuiCond_Always,
        ImVec2(1.0f, 1.0f));

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12.0f, 8.0f));
    if (ImGui::Begin(
            "##HoveredVertex",
            nullptr,
            ImGuiWindowFlags_NoDecoration
                | ImGuiWindowFlags_AlwaysAutoResize
                | ImGuiWindowFlags_NoMove
                | ImGuiWindowFlags_NoSavedSettings
                | ImGuiWindowFlags_NoFocusOnAppearing
                | ImGuiWindowFlags_NoInputs)) {
        if (asynchronous) { ImGui::TextUnformatted("Coordinates (asynchronous)"); }
        const auto& local = hoveredVertex->localPosition;
        const auto& transformed = hoveredVertex->transformedPosition;
        ImGui::Text(
            "Local: %.4f, %.4f, %.4f",
            static_cast<double>(local[0]),
            static_cast<double>(local[1]),
            static_cast<double>(local[2]));
        ImGui::Text(
            "Transformed: %.4f, %.4f, %.4f",
            static_cast<double>(transformed[0]),
            static_cast<double>(transformed[1]),
            static_cast<double>(transformed[2]));
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

} // namespace

int main(int argc, char** argv)
{
    woby::initializeConsole();
    // Even argument-validation failures in headless launches must never open a dialog.
    const bool headlessLaunchRequested = std::any_of(argv + 1, argv + argc,
        [](const char* argument) { return std::string_view(argument) == "--headless"; });
    bool sdlInitialized = false;
    bool graphicsInitialized = false;
    // Readback memory must outlive graphics shutdown, including exception paths.
    woby::GpuMarkerPicker markerPicker;
    woby::AdaptivePointRuntime adaptivePoints;
    woby::AutomationOwner automation(nullptr, &woby::stopAutomation);

    try {
        const auto commandLine = woby::parseCommandLine(argc, argv);
        const bool headless = commandLine.headless;
        if (commandLine.showHelp) {
            woby::printCommandLineHelp();
            return 0;
        }
        if (commandLine.update.command != woby::UpdateCommand::none) {
            return woby::runUpdateCommand(commandLine.update, WOBY_VERSION);
        }
        if (commandLine.control.command != woby::ControlCommand::none) {
            return woby::runAutomationCommand(commandLine.control);
        }
        initializeLogging(commandLine);
        const auto startupStart = woby::PerformanceClock::now();
        if (commandLine.showVersion) {
            std::printf("%s\n", WOBY_VERSION);
            spdlog::shutdown();
            return 0;
        }

        auto deploymentGuard = woby::guardViewerDeployment();
        woby::UpdateUiRuntime updateRuntime;
        woby::FileAssociationsRuntime fileAssociations;
        bool fileAssociationSettingsOpen = false;
        updateRuntime.state.currentVersion = WOBY_VERSION;
        updateRuntime.state.managedDeployment = std::filesystem::is_regular_file(
            woby::updateExecutablePath().parent_path() / woby::packageManifestName);
        automation = woby::startAutomation(commandLine.instanceId, {}, headless);
        const std::string instanceId = woby::automationInstanceId(*automation);

        const auto sdlStart = woby::PerformanceClock::now();
        if (!SDL_Init(headless ? 0 : SDL_INIT_VIDEO)) {
            throw std::runtime_error(std::string("SDL_Init failed: ") + SDL_GetError());
        }
        sdlInitialized = true;

        std::filesystem::path importerSettingsPath;
        std::vector<std::filesystem::path> rememberedImporters;
        std::vector<woby::ImporterLoadFailure> importerLoadFailures;
        const auto reportImporterError = [&](const woby::ImporterLoadFailure& failure) {
            importerLoadFailures.push_back(failure);
            const auto message = failure.path.empty() ? failure.details
                : woby::pathToUtf8(failure.path) + ": " + failure.details;
            std::fprintf(stderr, "%s\n", message.c_str());
            spdlog::warn("{}", message);
        };
        // CLI entries take precedence over saved registrations; each folder is sorted.
        const auto tryLoadImporter = [&](const std::filesystem::path& path) {
            try { woby::loadImporter(path); }
            catch (const std::exception& error) { reportImporterError(woby::importerLoadFailure(path, error)); }
        };
        for (const auto& source : commandLine.pluginPaths) {
            if (source.folder) {
                try {
                    for (const auto& path : woby::discoverImporterFiles(source.path)) { tryLoadImporter(path); }
                } catch (const std::exception& error) { reportImporterError(woby::importerLoadFailure(source.path, error)); }
            } else {
                tryLoadImporter(source.path);
            }
        }
        if (char* preferencePath = SDL_GetPrefPath("woby", "woby")) {
            importerSettingsPath = woby::pathFromUtf8(preferencePath) / "importers.txt";
            SDL_free(preferencePath);
            try {
                rememberedImporters = woby::readImporterSettings(importerSettingsPath);
                for (const auto& path : rememberedImporters) { tryLoadImporter(path); }
            } catch (const std::exception& error) { reportImporterError(woby::importerLoadFailure(importerSettingsPath, error)); }
        } else {
            reportImporterError(woby::importerLoadFailure({},
                std::runtime_error("Importer settings directory is unavailable; registrations are session-only.")));
        }
        std::filesystem::path portableImporterFolder;
        try {
            portableImporterFolder = woby::updateExecutablePath().parent_path() / "importers";
            for (const auto& error : woby::loadPortableImporters(portableImporterFolder)) { reportImporterError(error); }
        } catch (const std::exception& error) { reportImporterError(woby::importerLoadFailure(portableImporterFolder, error)); }

        const auto requestedSize = commandLine.windowSize.value_or(commandLine.drawableSize.value_or(std::array<int, 2>{1280, 720}));
        const SDL_WindowFlags windowFlags = (commandLine.windowSize || commandLine.drawableSize ? 0 : SDL_WINDOW_RESIZABLE)
            | (commandLine.hiddenWindow ? SDL_WINDOW_HIDDEN : 0);
        SDL_Window* rawWindow = headless ? nullptr
            : SDL_CreateWindow(("woby " WOBY_VERSION " [" + instanceId + "]").c_str(), requestedSize[0], requestedSize[1], windowFlags |
#if defined(__APPLE__)
                SDL_WINDOW_METAL
#else
                SDL_WINDOW_VULKAN
#endif
            );
        if (!headless && rawWindow == nullptr) {
            throw std::runtime_error(std::string("SDL_CreateWindow failed: ") + SDL_GetError());
        }

        std::unique_ptr<SDL_Window, SdlDeleter> window(rawWindow);
        if (window && commandLine.windowSize) {
            int actualWidth = 0, actualHeight = 0;
            if (!SDL_SyncWindow(window.get()) || !SDL_GetWindowSize(window.get(), &actualWidth, &actualHeight)
                || actualWidth != requestedSize[0] || actualHeight != requestedSize[1]) {
                throw std::runtime_error("Requested logical window size is unavailable.");
            }
        }
        if (window && commandLine.drawableSize) {
            int logicalWidth = 0, logicalHeight = 0, pixelWidth = 0, pixelHeight = 0;
            if (!SDL_GetWindowSize(window.get(), &logicalWidth, &logicalHeight)
                || !SDL_GetWindowSizeInPixels(window.get(), &pixelWidth, &pixelHeight)
                || pixelWidth <= 0 || pixelHeight <= 0) {
                throw std::runtime_error("Cannot determine drawable pixel density.");
            }
            const int targetWidth = static_cast<int>(std::lround(static_cast<double>(requestedSize[0]) * logicalWidth / pixelWidth));
            const int targetHeight = static_cast<int>(std::lround(static_cast<double>(requestedSize[1]) * logicalHeight / pixelHeight));
            if (!SDL_SetWindowSize(window.get(), targetWidth, targetHeight) || !SDL_SyncWindow(window.get())
                || !SDL_GetWindowSizeInPixels(window.get(), &pixelWidth, &pixelHeight)
                || pixelWidth != requestedSize[0] || pixelHeight != requestedSize[1]) {
                throw std::runtime_error("Requested drawable size is unavailable; check display scaling and desktop bounds.");
            }
        }

        const auto assets = assetRoot();
        if (window) {
            const auto iconPath = woby::pathToUtf8(assets / "icons" / "woby.bmp");
            SDL_Surface* icon = SDL_LoadBMP(iconPath.c_str());
            if (icon != nullptr) {
                if (!SDL_SetWindowIcon(window.get(), icon)) {
                    spdlog::warn("Could not set window icon: {}", SDL_GetError());
                }
                SDL_DestroySurface(icon);
            } else {
                spdlog::warn("Could not load window icon: {}", SDL_GetError());
            }
        }

        uint32_t width = 0;
        uint32_t height = 0;
        if (window) { getDrawableSize(window.get(), width, height); }
        woby::logDuration("startup_sdl_window", elapsedMilliseconds(sdlStart));

        const auto graphicsStart = woby::PerformanceClock::now();
        woby::graphics::Init init;
        init.modelUploadStagingBytes = uint64_t(commandLine.uploadBufferMiB.value_or(16)) * 1024 * 1024;
        init.type = woby::graphics::RendererType::Count;
        if (headless) {
            // Use a backend with a windowless device and packaged shaders.
#if defined(_WIN32)
            init.type = woby::graphics::RendererType::Vulkan;
#elif defined(__linux__)
            init.type = woby::graphics::RendererType::Vulkan;
#else
            throw std::runtime_error("Headless mode currently supports Windows (Vulkan) and Linux (Vulkan).");
#endif
        } else {
            init.platformData = platformDataFromSdlWindow(window.get());
        }
        init.resolution.width = width;
        init.resolution.height = height;
        init.resolution.reset = headless ? WOBY_GPU_RESET_NONE : resetFlags;

        if (!woby::graphics::init(init)) {
            spdlog::error("{}", woby::graphics::initializationError());
            throw std::runtime_error(woby::graphics::initializationError());
        }
        graphicsInitialized = true;
        // Fail before importing any model or creating shader-dependent resources.
        woby::validateRendererStartup();
        if (headless) { woby::validateSceneScreenshotRenderer(); }

        woby::graphics::setViewClear(clearView, WOBY_GPU_CLEAR_COLOR | WOBY_GPU_CLEAR_DEPTH, 0x20242aff, 1.0f, 0);
        woby::graphics::setViewTransform(clearView, nullptr, nullptr, true);
        woby::graphics::setViewClear(sceneView, WOBY_GPU_CLEAR_NONE, 0x00000000, 1.0f, 0);
        woby::graphics::setViewClear(helperView, WOBY_GPU_CLEAR_NONE, 0x00000000, 1.0f, 0);
        woby::graphics::setDebug(headless ? WOBY_GPU_DEBUG_NONE : WOBY_GPU_DEBUG_TEXT);
        woby::logDuration("startup_graphics", elapsedMilliseconds(graphicsStart));

        const auto modelPathsStart = woby::PerformanceClock::now();
        const auto modelInputs = resolveModelInputs(commandLine);
        woby::logDuration("startup_resolve_model_paths", elapsedMilliseconds(modelPathsStart));
        const auto layout = meshVertexLayout();
        const auto helperLayout = helperLineVertexLayout();
        woby::UiState ui;
        woby::RecentFilesRuntime recentFiles;
        if (!headless) { woby::startRecentFiles(recentFiles); }
        // Destroyed before ui on every exit, including exception unwinding.
        woby::AnnotationPreparationRuntime annotationPreparation;
        woby::PostLoadRuntime postLoading;
        woby::ComparisonRuntimes comparison;
        woby::ComparisonNameEdit comparisonNameEdit;
        woby::AnnotationNameEdit annotationNameEdit;
        woby::ViewNameEdit viewNameEdit;
        woby::ViewListLayout viewListLayout;
        std::vector<LoadedModelRuntime> runtimes;
        std::optional<std::filesystem::path> currentScenePath;
        woby::SceneDocument cleanSceneDocument = woby::createSceneDocument(ui);

        const auto initialLoadStart = woby::PerformanceClock::now();
        bool initialLoading = commandLine.scenePath.has_value() || !modelInputs.paths.empty();
        bool initialModelsStarted = modelInputs.paths.empty();
        woby::SceneHistory sceneHistory;
        woby::resetSceneHistory(sceneHistory, ui);

        const auto shaderStart = woby::PerformanceClock::now();
        const auto presentationProgram = woby::loadProgram(assets, "vs_marker_screen.bin", "fs_marker_composite.bin");
        auto triangleEdgePrograms = woby::createTriangleEdgePrograms(assets);
        auto transparentSurfacePrograms = woby::createTransparentSurfacePrograms(assets);
        woby::graphics::ProgramHandle meshProgram = woby::loadProgram(assets, "vs_mesh.bin", "fs_mesh.bin");
        woby::graphics::ProgramHandle colorProgram = woby::loadProgram(assets, "vs_color.bin", "fs_color.bin");
        const auto lineSpriteProgram = woby::loadProgram(assets, "vs_line_sprite.bin", "fs_color.bin");
        woby::graphics::ProgramHandle annotationProgram = woby::loadProgram(assets, "vs_annotation.bin", "fs_color.bin");
        woby::graphics::ProgramHandle pointSpriteProgram = woby::loadProgram(assets, "vs_point_sprite.bin", "fs_point_sprite.bin");
        comparison.program = woby::loadProgram(assets, "vs_comparison.bin", "fs_comparison.bin");
        woby::logDuration("startup_shaders", elapsedMilliseconds(shaderStart));

        const auto imguiStart = woby::PerformanceClock::now();
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        loadAppFont(assets);
        configureAppStyle();
        const ImGuiStyle baseStyle = ImGui::GetStyle();
        const auto preferencePath = uiPreferencePath();
        if (headless) {
            // Export labels use ImGui's fonts/draw lists, without a platform backend.
            auto& io = ImGui::GetIO();
            io.IniFilename = nullptr;
            io.LogFilename = nullptr;
            io.DisplaySize = ImVec2(static_cast<float>(ui.screenshotSettings.width), static_cast<float>(ui.screenshotSettings.height));
        } else {
            float savedUiScale = 1.0f;
            if (std::ifstream preference{preferencePath}; preference >> savedUiScale) { woby::setUiScale(ui, savedUiScale); }
            updateUiScale(window.get(), ui, baseStyle);
            if (!ImGui_ImplSDL3_InitForOther(window.get())) {
                throw std::runtime_error("ImGui_ImplSDL3_InitForOther failed.");
            }
        }
        woby::imgui_graphics::init(assets, imguiView);
        woby::logDuration("startup_imgui", elapsedMilliseconds(imguiStart));

        ui.viewerPaneWidth = minimumViewerPaneWidth();
        woby::logDuration("startup_total", elapsedMilliseconds(startupStart));
        auto& running = ui.running;
        auto& files = ui.files;
        auto& sceneBounds = ui.sceneBounds;
        auto& camera = ui.camera;
        auto& cameraInput = ui.cameraInput;
        auto& masterVertexPointSize = ui.masterVertexPointSize;
        auto& viewerPaneWidth = ui.viewerPaneWidth;
        static ModelFileDialogState modelFileDialogState;
        static SceneFileDialogState sceneFileDialogState;
        static SceneScreenshotDialogState sceneScreenshotDialogState;
        BackgroundLoadRuntime backgroundLoad;
        GpuFinalizeRuntime gpuFinalize;
        woby::SceneHistoryRestore historyRestore;
        std::optional<woby::AutomationCommandId> automationHistory;
        SceneScreenshotRuntime sceneScreenshot;
        std::optional<woby::AutomationCommandId> automationScreenshotCommandId;
        std::optional<woby::AutomationCommandId> automationOpenCommandId;
        bool automationOpenPostLoad = false;
        uint64_t automationOpenGeneration = 0;
        std::optional<AutomationAppendRuntime> automationAppend;
        std::optional<AutomationComparisonRuntime> automationComparison;
        std::vector<AutomationDifferenceRuntime> automationDifferences;
        woby::AnalysisExportRuntime analysisExport;
        const woby::ObjectIdFormatter formatObjectId = [&](woby::SceneObjectId id) { return woby::automationObjectId(*automation, id); };
        const auto measurementScene = [&]() {
            nlohmann::json snapshot = {{"stats", woby::controlSceneInfo(ui)}, {"tree", woby::controlSceneTree(ui, formatObjectId)},
                {"camera", woby::controlCameraInfo(ui)}, {"analysisInputs", nlohmann::json::array()},
                {"annotationInputs", nlohmann::json::array()}};
            for (const auto& item : ui.comparisons) {
                const auto details = woby::controlObjectDetails(ui, item.objectId, formatObjectId);
                snapshot["analysisInputs"].push_back({{"id", formatObjectId(item.objectId)}, {"a", details["a"]}, {"b", details["b"]}});
            }
            for (const auto& item : ui.annotations) {
                const auto details = woby::controlObjectDetails(ui, item.objectId, formatObjectId);
                snapshot["annotationInputs"].push_back({{"id", formatObjectId(item.objectId)}, {"sourceIds", details["sourceIds"]}});
            }
            return snapshot;
        };
        uint64_t measuredFirstFrame = 0;
        bool measuredFirstComplete = false;
        auto completeAppend = [&]() {
            if (!automationAppend) { return; }
            nlohmann::json outcomes = nlohmann::json::array(), addedIds = nlohmann::json::array();
            std::unordered_map<std::filesystem::path, woby::SceneObjectId> addedFiles;
            addedFiles.reserve(ui.files.size() - std::min(ui.files.size(), automationAppend->firstFileIndex));
            for (size_t index = automationAppend->firstFileIndex; index < ui.files.size(); ++index) {
                addedFiles.try_emplace(ui.files[index].path, ui.files[index].objectId);
            }
            size_t failed = 0, skipped = 0;
            for (const auto& input : automationAppend->outcomes) {
                nlohmann::json result = {{"path", woby::pathToUtf8(input.path)}, {"state", input.state}};
                if (!input.error.empty()) { result["error"] = input.error; }
                if (input.state == "failed") { ++failed; }
                if (input.state == "skipped") { ++skipped; }
                if (automationAppend->canceled && (input.state == "loaded" || input.state == "not-started")) { result["state"] = "canceled"; }
                else if (input.state == "loaded") {
                    if (const auto file = addedFiles.find(input.path); file != addedFiles.end()) {
                        result["state"] = "added";
                        result["id"] = formatObjectId(file->second);
                        addedIds.push_back(result["id"]);
                    }
                }
                outcomes.push_back(std::move(result));
            }
            woby::updateSceneDirty(ui, cleanSceneDocument);
            woby::completeAutomationCommand(*automation, automationAppend->id, woby::AutomationControlResult{
                {{"outcomes", outcomes}, {"addedIds", addedIds}, {"requestedCount", outcomes.size()},
                    {"addedCount", addedIds.size()}, {"failedCount", failed}, {"skippedCount", skipped},
                    {"canceled", automationAppend->canceled}, {"dirty", ui.isDirty}}});
            obj_profile::mark("model_add_rpc_complete");
            automationAppend.reset();
        };
        auto completeLifecycleError = [&](woby::AutomationCommandId id, const woby::SceneLifecycleError& error) {
            woby::completeAutomationCommand(*automation, id,
                woby::AutomationCommandError{error.message, error.code, error, currentScenePath, ui.isDirty});
        };
        DragDropState dragDropState;
        std::optional<std::filesystem::path> pendingDirtyOpenScenePath;
        bool requestDirtyOpenWarning = false;
        bool requestDirtyQuitWarning = false;
        bool requestDirtyNewWarning = false;
        ToastMessage toast;
        if (!importerLoadFailures.empty()) {
            setToastMessage(toast, woby::importerLoadFailureSummary(importerLoadFailures));
        }
        uint64_t observedModelFileDialogStatusVersion = 0;
        uint64_t observedSceneFileDialogStatusVersion = 0;
        uint64_t observedSceneScreenshotDialogStatusVersion = 0;
        auto previousFrame = std::chrono::steady_clock::now();
        auto fpsWindowStart = previousFrame;
        int fpsFrameCount = 0;
        float fps = 0.0f;
        woby::FrameTimingAccumulator frameTimingAccumulator;
        woby::FrameTimings lastFrameTimings;
        woby::FrameCapture frameCapture;
        woby::FrameEnvironment lastFrameEnvironment;
        nlohmann::json captureScene;
        uint64_t frameIndex = 0;
        HoverPickCache hoverPickCache;
        woby::HoverNavigationState hoverNavigation{camera, ui.upAxis};
        woby::SceneInspectorRuntime inspector;
        woby::SceneRenderScratch renderScratch;
        inspector.sharedQueries = &renderScratch.queries;
        inspector.comparisons = &comparison;
        WindowTitleCache windowTitleCache;
        woby::ScenePointerGesture scenePointer;
        woby::AnnotationInteraction annotationInteraction;
        annotationInteraction.queries = &renderScratch.queries;
        woby::AnnotationExecutor annotationExecutor, annotationPointerExecutor;
        annotationInteraction.executor = &annotationPointerExecutor;
        std::optional<woby::AnnotationCommand> annotationCommand;
        woby::AutomationCommandId annotationCommandId = 0;
        std::optional<woby::ScenePickView> presentedPickView;
        woby::SceneViewport presentedViewport;
        bool scenePointerAvailable = false;
        std::vector<woby::SceneObjectId> canvasSelectionPath;
        const auto selectAt = [&](const woby::ScenePickView& view, woby::PickPoint point, bool toggle) {
            std::vector<woby::ScenePickPart> parts;
            woby::resolveSceneParts(renderScratch.queries, ui, parts);
            woby::appendVisibleComparisonPickParts(parts, ui, comparison);
            woby::appendSceneAnnotationParts(renderScratch.queries, ui, parts);
            woby::SceneTriangleHit triangle;
            woby::attachPointHierarchies(parts, runtimes);
            const auto id = woby::pickSceneObject(parts, view, point, &triangle);
            const auto analysisId = triangle.analysisId ? triangle.analysisId : ui.activeComparisonId;
            if (!toggle && triangle.triangle && woby::setUvProbe(ui,analysisId,triangle.partId,triangle.triangle,triangle.barycentric)) {
                canvasSelectionPath = woby::sceneSelectionPath(ui,triangle.partId);
                return;
            }
            if (id != woby::invalidSceneObjectId) {
                woby::selectSceneObject(ui, id, toggle);
                canvasSelectionPath = woby::sceneObjectSelected(ui, id)
                    ? woby::sceneSelectionPath(ui, id) : std::vector<woby::SceneObjectId>{};
            } else if (!toggle) {
                woby::clearSceneSelection(ui);
                canvasSelectionPath.clear();
            }
        };
        bool documentShortcutHeld = false;
        if (commandLine.scenePath) {
            startOpenSceneBackgroundLoad(backgroundLoad, *commandLine.scenePath);
        } else if (!modelInputs.paths.empty()) {
            startAppendModelBackgroundLoad(backgroundLoad, modelInputs.paths, 0, AsyncLoadKind::initialModels);
            initialModelsStarted = true;
        } else { woby::setAutomationReady(*automation); }
        while (running) {
            if (!backgroundLoad.active && !gpuFinalize.active && !historyRestore.active) {
                const bool preparationFailed = !annotationPreparation.error.empty();
                woby::updateAnnotationPreparation(annotationPreparation, ui);
                if (!preparationFailed && !annotationPreparation.error.empty()) {
                    setToastMessage(toast, "Annotation preparation failed: " + annotationPreparation.error);
                }
            }
            if (!woby::annotationPreparationReady(ui)) {
                woby::cancelAnnotationPointer(annotationInteraction);
                scenePointer.selectionEnabled = false;
            }
            woby::pollUiUpdate(updateRuntime);
            woby::pollFileAssociations(fileAssociations);
            if (updateRuntime.state.closeRequested) {
                woby::requestQuit(ui);
                break;
            }
            woby::FrameTimings frameTimings;
            frameTimings.frameIndex = ++frameIndex;
            const auto frameStart = woby::PerformanceClock::now();
            auto stageStart = frameStart;

            bool annotationEscapeConsumed = false;
            std::optional<woby::PickPoint> annotationMotion;
            SDL_Event event;
            while (!headless && SDL_PollEvent(&event)) {
                ImGui_ImplSDL3_ProcessEvent(&event);

                if (event.type == SDL_EVENT_QUIT) {
                    if (ui.isDirty) {
                        requestDirtyQuitWarning = true;
                    } else {
                        woby::requestQuit(ui);
                    }
                }
                if (event.type == SDL_EVENT_DROP_BEGIN) {
                    dragDropState.batchPaths.clear();
                    dragDropState.active = true;
                }
                if (event.type == SDL_EVENT_DROP_FILE) {
                    pushDroppedPath(dragDropState, event.drop.data);
                }
                if (event.type == SDL_EVENT_DROP_COMPLETE) {
                    finishDropBatch(dragDropState);
                }
                if (event.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED) {
                    woby::cancelAnnotationPointer(annotationInteraction);
                    scenePointer = {};
                    presentedPickView.reset();
                    getDrawableSize(window.get(), width, height);
                    woby::graphics::reset(width, height, resetFlags);
                }
                if (event.type == SDL_EVENT_WINDOW_FOCUS_LOST) {
                    woby::cancelAnnotationPointer(annotationInteraction);
                    scenePointer = {};
                    woby::setCameraOrbiting(ui, false);
                    woby::setCameraRolling(ui, false);
                    woby::setCameraPanning(ui, false);
                }
                if (event.type == SDL_EVENT_WINDOW_FOCUS_GAINED && fileAssociationSettingsOpen) {
                    woby::startFileAssociationAction(fileAssociations, {woby::FileAssociationAction::refresh});
                }
                const auto inputLayout = canvasLayout(window.get(), ui);
                const bool buttonEvent = event.type == SDL_EVENT_MOUSE_BUTTON_DOWN || event.type == SDL_EVENT_MOUSE_BUTTON_UP;
                const auto inputMouse = buttonEvent
                    ? mousePositionInPixels(window.get(), event.button.x, event.button.y)
                    : mousePositionInPixels(window.get());
                const bool canvasInput = woby::contains(inputLayout.viewport, inputMouse.x, inputMouse.y);
                const bool pointerAllowed = scenePointerAvailable && !backgroundLoad.active && !gpuFinalize.active
                    && !modelFileDialogIsOpen(modelFileDialogState) && !sceneFileDialogIsOpen(sceneFileDialogState)
                    && !sceneScreenshotDialogIsOpen(sceneScreenshotDialogState) && !ImGui::GetIO().WantCaptureMouse;
                if (event.type == SDL_EVENT_KEY_DOWN && event.key.key == SDLK_ESCAPE
                    && (annotationInteraction.tool || annotationInteraction.sectionTool || annotationInteraction.dragging)) {
                    woby::cancelAnnotationPointer(annotationInteraction);
                    annotationEscapeConsumed = true;
                    scenePointer = {};
                    continue;
                }
                if (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN && event.button.button == SDL_BUTTON_LEFT
                    && canvasInput && pointerAllowed && presentedPickView) {
                    if (woby::beginAnnotationPointer(ui, annotationInteraction, *presentedPickView,
                            {inputMouse.x - static_cast<float>(presentedViewport.x), inputMouse.y - static_cast<float>(presentedViewport.y)})) {
                        scenePointer = {};
                        woby::setCameraOrbiting(ui, false); woby::setCameraRolling(ui, false); woby::setCameraPanning(ui, false);
                        continue;
                    }
                }
                if (annotationInteraction.dragging) {
                    if (annotationInteraction.sectionStart
                        && (event.type == SDL_EVENT_KEY_DOWN || event.type == SDL_EVENT_KEY_UP)
                        && (event.key.key == SDLK_LSHIFT || event.key.key == SDLK_RSHIFT)) {
                        annotationMotion = annotationMotion.value_or(annotationInteraction.pointerEnd);
                        continue;
                    }
                    if (event.type == SDL_EVENT_MOUSE_MOTION) {
                        const auto p = mousePositionInPixels(window.get(), event.motion.x, event.motion.y);
                        annotationMotion = woby::PickPoint{p.x - static_cast<float>(presentedViewport.x), p.y - static_cast<float>(presentedViewport.y)};
                        continue;
                    }
                    if (event.type == SDL_EVENT_MOUSE_BUTTON_UP && event.button.button == SDL_BUTTON_LEFT) {
                        annotationMotion.reset();
                        woby::moveAnnotationPointer(ui, annotationInteraction, {inputMouse.x - static_cast<float>(presentedViewport.x), inputMouse.y - static_cast<float>(presentedViewport.y)},
                            (SDL_GetModState() & SDL_KMOD_SHIFT) != 0u);
                        woby::endAnnotationPointer(ui, annotationInteraction, pointerAllowed && canvasInput);
                        continue;
                    }
                    if (event.type == SDL_EVENT_MOUSE_WHEEL || buttonEvent) { continue; }
                }
                if (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN && canvasInput && pointerAllowed) {
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        if (!cameraInput.panning) {
                            const auto modifiers = SDL_GetModState();
                            woby::beginScenePointer(scenePointer, {event.button.x, event.button.y},
                                (modifiers & SDL_KMOD_ALT) != 0u, (modifiers & SDL_KMOD_CTRL) != 0u,
                                woby::annotationPreparationReady(ui));
                        }
                    }
                    if (event.button.button == SDL_BUTTON_RIGHT || event.button.button == SDL_BUTTON_MIDDLE) {
                        scenePointer = {};
                        woby::setCameraOrbiting(ui, false);
                        woby::setCameraRolling(ui, false);
                        woby::setCameraPanning(ui, true);
                    }
                }
                if (event.type == SDL_EVENT_MOUSE_BUTTON_UP) {
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        const auto click = woby::endScenePointer(scenePointer, {event.button.x, event.button.y},
                            pointerAllowed && presentedPickView && woby::contains(presentedViewport, inputMouse.x, inputMouse.y)
                                && woby::annotationPreparationReady(ui));
                        if (click) {
                            // Resolve against the displayed camera/layout before selection opens Properties.
                            const woby::PickPoint point{inputMouse.x - static_cast<float>(presentedViewport.x), inputMouse.y - static_cast<float>(presentedViewport.y)};
                            selectAt(*presentedPickView, point, click->toggle);
                        }
                        woby::setCameraOrbiting(ui, false);
                        woby::setCameraRolling(ui, false);
                    }
                    if (event.button.button == SDL_BUTTON_RIGHT || event.button.button == SDL_BUTTON_MIDDLE) {
                        woby::setCameraPanning(ui, false);
                    }
                }
                if (event.type == SDL_EVENT_MOUSE_MOTION) {
                    const bool wasDragging = scenePointer.dragging;
                    if (scenePointer.active && (!scenePointerAvailable || backgroundLoad.active || gpuFinalize.active || historyRestore.active)) {
                        scenePointer = {};
                        woby::setCameraOrbiting(ui, false);
                        woby::setCameraRolling(ui, false);
                    }
                    const bool dragging = woby::moveScenePointer(scenePointer, {event.motion.x, event.motion.y});
                    if (dragging) {
                        woby::setCameraOrbiting(ui, !scenePointer.alt);
                        woby::setCameraRolling(ui, scenePointer.alt);
                    }
                    const float dx = dragging && !wasDragging ? event.motion.x - scenePointer.start[0] : event.motion.xrel;
                    const float dy = dragging && !wasDragging ? event.motion.y - scenePointer.start[1] : event.motion.yrel;
                    if (cameraInput.orbiting) {
                        woby::orbitUiCamera(ui, dx, dy);
                    }
                    if (cameraInput.rolling) {
                        woby::rollUiCamera(ui, dx);
                    }
                    if (cameraInput.panning) {
                        const float aspect = static_cast<float>(inputLayout.viewport.width) / static_cast<float>(inputLayout.viewport.height);
                        const float panScale = 1.0f / std::min(aspect, 1.0f);
                        woby::panUiCamera(ui, event.motion.xrel * panScale, event.motion.yrel * panScale, inputLayout.height - inputLayout.top);
                    }
                }
                if (event.type == SDL_EVENT_MOUSE_WHEEL && canvasInput && !ImGui::GetIO().WantCaptureMouse) {
                    const float wheelY = event.wheel.direction == SDL_MOUSEWHEEL_FLIPPED
                        ? -event.wheel.y
                        : event.wheel.y;
                    woby::dollyUiCamera(ui, -wheelY * 0.12f);
                }
            }
            if (annotationMotion && annotationInteraction.dragging) {
                woby::moveAnnotationPointer(ui, annotationInteraction, *annotationMotion, (SDL_GetModState() & SDL_KMOD_SHIFT) != 0u);
            }
            recordFrameStage(frameTimings, woby::FrameStage::events, stageStart);

            if (window) { getDrawableSize(window.get(), width, height); }

            if (auto outcome = takeBackgroundLoadOutcome(backgroundLoad); outcome.has_value()) {
                if (initialLoading && (outcome->failed || outcome->modelBatch.failedCount)) {
                    throw std::runtime_error(outcome->failed ? outcome->error : outcome->modelBatch.lastError);
                }
                if (outcome->failed) {
                    if (automationAppend) {
                        woby::completeAutomationCommand(*automation, automationAppend->id, woby::AutomationCommandError{outcome->error});
                        automationAppend.reset();
                    }
                    setToastMessage(toast, std::string(backgroundLoadFailurePrefix(outcome->kind)) + outcome->error);
                    if (automationOpenCommandId) {
                        completeLifecycleError(*automationOpenCommandId, {"open_failed", outcome->error, -32016});
                        automationOpenCommandId.reset();
                    }
                } else if (isAppendModelLoadKind(outcome->kind)) {
                    if (automationAppend) {
                        automationAppend->outcomes = outcome->modelBatch.outcomes;
                        automationAppend->canceled = outcome->modelBatch.canceled;
                    }
                    if (outcome->modelBatch.canceled || outcome->modelBatch.files.empty()) {
                        setToastMessage(toast, outcome->modelBatch.status);
                        completeAppend();
                    } else {
                        try { startGpuFinalize(gpuFinalize, std::move(outcome.value()), ui, layout, modelInputs); }
                        catch (const std::exception& error) {
                            abortGpuFinalize(gpuFinalize);
                            if (automationAppend) {
                                woby::completeAutomationCommand(*automation, automationAppend->id, woby::AutomationCommandError{error.what()});
                                automationAppend.reset();
                            } else { setToastMessage(toast, error.what()); }
                        }
                    }
                } else if (outcome->scene.canceled) {
                    setToastMessage(toast, "Open scene canceled");
                    if (automationOpenCommandId) {
                        completeLifecycleError(*automationOpenCommandId, {"scene_canceled", "Open scene canceled.", -32017});
                        automationOpenCommandId.reset();
                    }
                } else {
                    try {
                        startGpuFinalize(gpuFinalize, std::move(outcome.value()), ui, layout, modelInputs);
                    } catch (const std::exception& exception) {
                        abortGpuFinalize(gpuFinalize);
                        setToastMessage(toast, std::string("Open scene failed: ") + exception.what());
                        if (automationOpenCommandId) {
                            completeLifecycleError(*automationOpenCommandId, {"open_failed", exception.what(), -32016});
                            automationOpenCommandId.reset();
                        }
                    }
                }
            }

            const bool finalizeCanceled = gpuFinalize.active && gpuFinalize.cancelRequested;
            const auto finalizingKind = gpuFinalize.kind;
            const size_t firstAddedFile = ui.files.size();
            if (finalizeCanceled && automationAppend) { automationAppend->canceled = true; }
            const auto previousGpuFailures = gpuFinalize.gpuFailures.size();
            if (gpuFinalize.active && gpuFinalize.kind == AsyncLoadKind::openScene) {
                woby::cancelAnnotationPreparation(annotationPreparation);
            }
            const auto finalized = processGpuFinalizeStep(
                gpuFinalize,
                ui,
                runtimes,
                currentScenePath,
                cleanSceneDocument,
                toast);
            if (initialLoading && finalized && !finalized->empty() && !finalizeCanceled) { throw std::runtime_error(*finalized); }
            if (initialLoading && !backgroundLoad.active && !gpuFinalize.active && !initialModelsStarted) {
                startAppendModelBackgroundLoad(backgroundLoad, modelInputs.paths, woby::totalGroupCount(ui), AsyncLoadKind::initialModels);
                initialModelsStarted = true;
            }
            if (measuredFirstFrame && !measuredFirstComplete && woby::graphics::completedFrameToken() >= measuredFirstFrame) {
                obj_profile::mark("first_scene_frame_gpu_complete", {{"frame_token", measuredFirstFrame}});
                measuredFirstComplete = true;
            }
            if (!historyRestore.active) { woby::updatePostLoading(postLoading, ui, runtimes, layout, woby::graphics::completedFrameToken()); }
            if (initialLoading && (!woby::postLoadError(ui).empty() || !annotationPreparation.error.empty())) {
                throw std::runtime_error(annotationPreparation.error.empty() ? std::string(woby::postLoadError(ui)) : annotationPreparation.error);
            }
            if (initialLoading && initialModelsStarted && !backgroundLoad.active && !gpuFinalize.active && woby::scenePostLoadReady(ui)
                && woby::annotationPreparationReady(ui)) {
                initialLoading = false;
                woby::updateSceneDirty(ui, cleanSceneDocument);
                woby::resetSceneHistory(sceneHistory, ui);
                woby::logDuration("startup_initial_scene", elapsedMilliseconds(initialLoadStart));
                woby::setAutomationReady(*automation);
            }
            const double postLoadNow = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            const bool wasPostLoading = postLoading.noticePending;
            woby::updatePostLoadNotice(postLoading, ui, postLoadNow);
            if (!wasPostLoading && postLoading.noticePending) { toast.text.clear(); }
            if (finalized) {
                woby::finishSceneHistoryInteraction(sceneHistory);
                woby::recordSceneHistory(sceneHistory, ui);
                if (finalized->empty()) {
                    if (finalizingKind == AsyncLoadKind::openScene && currentScenePath) {
                        woby::rememberRecentFile(recentFiles, woby::RecentFileKind::scene, *currentScenePath);
                    } else if (isAppendModelLoadKind(finalizingKind)) {
                        rememberAddedModels(recentFiles, ui, firstAddedFile);
                    }
                }
            }
            if (automationAppend) {
                for (size_t i = previousGpuFailures; i < gpuFinalize.gpuFailures.size(); ++i) {
                    const auto& failure = gpuFinalize.gpuFailures[i];
                    for (auto& input : automationAppend->outcomes) {
                        if (input.path == failure.path) { input.state = "failed"; input.error = failure.error; }
                    }
                }
            }
            if (finalized && automationAppend) {
                if (finalizeCanceled) { completeAppend(); }
                else if (finalized->empty()) {
                    automationAppend->postLoadPending = true;
                    automationAppend->generation = ui.sceneGeneration;
                } else {
                    woby::completeAutomationCommand(*automation, automationAppend->id, woby::AutomationCommandError{*finalized});
                    automationAppend.reset();
                }
            }
            if (finalized && automationOpenCommandId) {
                if (finalized->empty()) {
                    automationOpenPostLoad = true;
                    automationOpenGeneration = ui.sceneGeneration;
                } else {
                    completeLifecycleError(*automationOpenCommandId, {finalizeCanceled ? "scene_canceled" : "open_failed", *finalized, finalizeCanceled ? -32017 : -32016});
                    automationOpenCommandId.reset();
                }
            }

            if (historyRestore.active) {
                const bool redo = historyRestore.redo;
                try {
                    if (const auto applied = woby::pollSceneHistoryRestore(historyRestore, sceneHistory, ui, runtimes)) {
                        if (*applied) {
                            woby::cancelAnnotationPreparation(annotationPreparation);
                            setToastMessage(toast, redo ? "Redid scene edit" : "Undid scene edit");
                        }
                        if (automationHistory) {
                            woby::completeAutomationCommand(*automation, *automationHistory, woby::AutomationControlResult{
                                {{"action", redo ? "redo" : "undo"}, {"applied", *applied}, {"dirty", ui.isDirty}}});
                            automationHistory.reset();
                        }
                    }
                } catch (const std::exception& error) {
                    const auto message = std::string(redo ? "Redo skipped: " : "Undo skipped: ") + error.what();
                    setToastMessage(toast, message);
                    if (automationHistory) {
                        woby::completeAutomationCommand(*automation, *automationHistory, woby::AutomationCommandError{message});
                        automationHistory.reset();
                    }
                }
            }

            // RPC load completion includes preparation; the viewer renders and remains responsive while clients wait.
            if (automationAppend && automationAppend->postLoadPending) {
                if (automationAppend->generation != ui.sceneGeneration || !woby::postLoadError(ui).empty()) {
                    woby::completeAutomationCommand(*automation, automationAppend->id,
                        woby::AutomationCommandError{woby::postLoadError(ui).empty() ? "Loading canceled by a scene change." : std::string(woby::postLoadError(ui))});
                    automationAppend.reset();
                } else if (woby::scenePostLoadReady(ui)) { completeAppend(); }
            }
            if (automationOpenCommandId && automationOpenPostLoad) {
                if (automationOpenGeneration != ui.sceneGeneration || !woby::postLoadError(ui).empty()) {
                    completeLifecycleError(*automationOpenCommandId, {"open_failed", woby::postLoadError(ui).empty()
                        ? "Loading canceled by a scene change." : std::string(woby::postLoadError(ui)), -32016});
                    automationOpenCommandId.reset(); automationOpenPostLoad = false;
                } else if (woby::scenePostLoadReady(ui)) {
                    woby::completeAutomationCommand(*automation, *automationOpenCommandId,
                        woby::AutomationSceneResult{currentScenePath, ui.isDirty});
                    automationOpenCommandId.reset(); automationOpenPostLoad = false;
                }
            }

            const auto saveDocument = [&](const std::filesystem::path& path) {
                woby::recordSceneHistory(sceneHistory, ui, woby::sceneHistoryInteraction());
                woby::finishSceneHistoryInteraction(sceneHistory);
                try {
                    const auto savedPath = saveSceneToPath(path, ui, currentScenePath, cleanSceneDocument);
                    woby::rememberRecentFile(recentFiles, woby::RecentFileKind::scene, savedPath);
                    setToastMessage(toast, "Saved scene " + fileDisplayName(savedPath));
                } catch (const std::exception& exception) {
                    setToastMessage(toast, std::string("Save scene failed: ") + exception.what());
                }
            };
            if (const auto warning = woby::pollRecentFiles(recentFiles); !warning.empty()) {
                spdlog::warn("{}", warning);
                setToastMessage(toast, warning);
            }
            if (!headless) {
                const bool processingFiles = backgroundLoad.active || gpuFinalize.active || historyRestore.active;
                const auto pendingModelPaths = takePendingModelPaths(modelFileDialogState);
                if (!pendingModelPaths.empty()) {
                    if (processingFiles) {
                        setModelFileDialogStatus(modelFileDialogState, "Already processing files");
                    } else if (!startAppendModelBackgroundLoad(
                                   backgroundLoad,
                                   pendingModelPaths,
                                   woby::totalGroupCount(ui))) {
                        setModelFileDialogStatus(modelFileDialogState, "Open model files failed: already processing files");
                    }
                }
                const auto pendingFolderTreeRoots = takePendingModelFolderTreeRoots(modelFileDialogState);
                for (const auto& folderTreeRoot : pendingFolderTreeRoots) {
                    if (backgroundLoad.active || gpuFinalize.active || historyRestore.active) {
                        setModelFileDialogStatus(modelFileDialogState, "Already processing files");
                        break;
                    }

                    std::string folderTreeStatus;
                    if (!startAppendFolderTreeBackgroundLoad(
                            backgroundLoad,
                            folderTreeRoot,
                            woby::totalGroupCount(ui),
                            folderTreeStatus)) {
                        folderTreeStatus = "Open folder tree failed: already processing files";
                    }
                    if (!folderTreeStatus.empty()) {
                        setModelFileDialogStatus(modelFileDialogState, std::move(folderTreeStatus));
                    }
                }
                const std::string modelDialogStatus = modelFileDialogStatus(
                    modelFileDialogState,
                    observedModelFileDialogStatusVersion);
                if (!modelDialogStatus.empty()) {
                    setToastMessage(toast, modelDialogStatus);
                }

                const auto pendingOpenScenePath = takePendingOpenScenePath(sceneFileDialogState);
                if (pendingOpenScenePath.has_value()) {
                    openSceneOrRequestDirtyWarning(
                        pendingOpenScenePath.value(),
                        ui,
                        backgroundLoad,
                        gpuFinalize,
                        sceneFileDialogState,
                        toast,
                        pendingDirtyOpenScenePath,
                        requestDirtyOpenWarning);
                }
                if (const auto path = takePendingSaveScenePath(sceneFileDialogState)) {
                    saveDocument(*path);
                }
                const std::string sceneDialogStatus = sceneFileDialogStatus(
                    sceneFileDialogState,
                    observedSceneFileDialogStatusVersion);
                if (!sceneDialogStatus.empty()) {
                    setToastMessage(toast, sceneDialogStatus);
                }

                const auto pendingSceneScreenshotPath = takePendingSaveSceneScreenshotPath(sceneScreenshotDialogState);
                if (pendingSceneScreenshotPath.has_value()) {
                    try {
                        requestSceneScreenshotCapture(sceneScreenshot, pendingSceneScreenshotPath.value(), ui.screenshotSettings);
                        setToastMessage(toast, "Saving screenshot...");
                    } catch (const std::exception& exception) {
                        setSceneScreenshotDialogStatus(
                            sceneScreenshotDialogState,
                            std::string("Save screenshot failed: ") + exception.what());
                    }
                }
                const std::string screenshotDialogStatus = sceneScreenshotDialogStatus(
                    sceneScreenshotDialogState,
                    observedSceneScreenshotDialogStatusVersion);
                if (!screenshotDialogStatus.empty()) {
                    setToastMessage(toast, screenshotDialogStatus);
                }

                const auto droppedPaths = takePendingDropPaths(dragDropState);
                if (!droppedPaths.empty()) {
                    if (processingFiles) {
                        setToastMessage(toast, "Already processing files");
                    } else {
                        processDroppedPaths(
                            droppedPaths,
                            ui,
                            backgroundLoad,
                            gpuFinalize,
                            sceneFileDialogState,
                            toast,
                            pendingDirtyOpenScenePath,
                            requestDirtyOpenWarning);
                    }
                }
            }

            recordFrameStage(frameTimings, woby::FrameStage::pendingIo, stageStart);

            updateAppWindowTitle(window.get(), currentScenePath, ui.isDirty, instanceId, windowTitleCache);

            const auto now = std::chrono::steady_clock::now();
            const float deltaSeconds = std::chrono::duration<float>(now - previousFrame).count();
            previousFrame = now;
            ++fpsFrameCount;
            const float fpsWindowSeconds = std::chrono::duration<float>(now - fpsWindowStart).count();
            if (fpsWindowSeconds >= 1.0f) {
                fps = static_cast<float>(fpsFrameCount) / fpsWindowSeconds;
                fpsFrameCount = 0;
                fpsWindowStart = now;
            }

            if (!headless) { updateUiScale(window.get(), ui, baseStyle); }
            const float minViewerPaneWidth = minimumViewerPaneWidth();
            const float maxViewerPaneWidth = std::max(
                minViewerPaneWidth,
                headless ? minViewerPaneWidth : canvasLayout(window.get(), ui).width - minSceneViewportWidth);
            if (!headless) { woby::setViewerPaneWidth(ui, viewerPaneWidth, minViewerPaneWidth, maxViewerPaneWidth); }

            if (!headless) { woby::graphics::dbgTextClear(); }
            recordFrameStage(frameTimings, woby::FrameStage::stateUpdate, stageStart);

            const bool popupWasOpen = !headless && ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopup);
            if (headless) {
                auto& io = ImGui::GetIO();
                io.DisplaySize = ImVec2(static_cast<float>(ui.screenshotSettings.width), static_cast<float>(ui.screenshotSettings.height));
                io.DeltaTime = std::max(deltaSeconds, 0.000001f);
            } else {
                ImGui_ImplSDL3_NewFrame();
            }
            ImGui::NewFrame();
            bool modalDialogOpen = false;
            // Recheck after each action: opening a dialog blocks other entry points in this frame.
            const auto fileActionsDisabled = [&]() {
                return headless || modalDialogOpen || backgroundLoad.active || gpuFinalize.active || historyRestore.active
                    || modelFileDialogIsOpen(modelFileDialogState)
                    || sceneFileDialogIsOpen(sceneFileDialogState)
                    || sceneScreenshotDialogIsOpen(sceneScreenshotDialogState);
            };
            const auto documentCommand = [&](woby::SceneAction action) {
                if (fileActionsDisabled()) {
                    return;
                }
                woby::cancelAnnotationPointer(annotationInteraction);
                if (annotationCommand) { woby::cancelAnnotationWork(annotationCommand->work); }
                if (action == woby::SceneAction::open) {
                    showOpenSceneDialog(window.get(), sceneFileDialogState);
                } else if (action == woby::SceneAction::saveAs || !currentScenePath) {
                    showSaveSceneDialog(window.get(), sceneFileDialogState);
                } else if (action == woby::SceneAction::save) {
                    saveDocument(*currentScenePath);
                }
            };
            auto historyCommand = woby::SceneHistoryCommand::none;
            if (!headless) {
                drawNativeDialogFallbacks(modelFileDialogState, sceneFileDialogState, sceneScreenshotDialogState);
                modalDialogOpen = ImGui::IsPopupOpen("Settings") || ImGui::IsPopupOpen("Updates")
                    || ImGui::IsPopupOpen("Export PNG")
                    || modelFileDialogIsOpen(modelFileDialogState)
                    || sceneFileDialogIsOpen(sceneFileDialogState)
                    || sceneScreenshotDialogIsOpen(sceneScreenshotDialogState);
                bool requestSettings = false;
                bool requestUpdates = false;
                const auto newScene = [&]() {
                    try {
                        resetSceneToUntitled(ui, runtimes, currentScenePath, cleanSceneDocument, annotationPreparation);
                        setToastMessage(toast, "Created new scene");
                    } catch (const std::exception& error) {
                        setToastMessage(toast, std::string("New scene failed: ") + error.what());
                    }
                };
                if (requestDirtyNewWarning) {
                    ImGui::OpenPopup("Unsaved scene changes##new");
                    requestDirtyNewWarning = false;
                }
                if (ImGui::BeginPopupModal("Unsaved scene changes##new", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
                    modalDialogOpen = true;
                    ImGui::TextUnformatted("The current scene has unsaved changes.");
                    ImGui::TextUnformatted("Create a new scene and discard them?");
                    if (ImGui::Button("New scene")) {
                        newScene();
                        ImGui::CloseCurrentPopup();
                    }
                    setLastItemTooltip("Discard unsaved changes and create an empty scene.");
                    ImGui::SameLine();
                    if (ImGui::Button("Cancel") || ImGui::IsKeyPressed(ImGuiKey_Escape, false)) { ImGui::CloseCurrentPopup(); }
                    setLastItemTooltip("Keep the current scene and return to it (Esc).");
                    ImGui::EndPopup();
                }
                if (requestDirtyOpenWarning) {
                    ImGui::OpenPopup("Unsaved scene changes");
                    requestDirtyOpenWarning = false;
                }
                if (ImGui::BeginPopupModal(
                        "Unsaved scene changes",
                        nullptr,
                        ImGuiWindowFlags_AlwaysAutoResize)) {
                    modalDialogOpen = true;
                    ImGui::TextUnformatted("The current scene has unsaved changes.");
                    if (pendingDirtyOpenScenePath.has_value()) {
                        ImGui::Text(
                            "Open %s and discard them?",
                            fileDisplayName(pendingDirtyOpenScenePath.value()).c_str());
                    }
                    if (ImGui::Button("Open")) {
                        if (pendingDirtyOpenScenePath.has_value()) {
                            const auto scenePath = pendingDirtyOpenScenePath.value();
                            if (!startOpenSceneBackgroundLoad(backgroundLoad, scenePath)) {
                                setSceneFileDialogStatus(
                                    sceneFileDialogState,
                                    "Open scene failed: already processing files");
                            } else {
                                setToastMessage(toast, "Opening scene " + fileDisplayName(scenePath));
                            }
                        }
                        pendingDirtyOpenScenePath.reset();
                        ImGui::CloseCurrentPopup();
                    }
                    setLastItemTooltip("Discard unsaved changes and open the selected scene.");
                    ImGui::SameLine();
                    if (ImGui::Button("Cancel") || ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                        pendingDirtyOpenScenePath.reset();
                        ImGui::CloseCurrentPopup();
                    }
                    setLastItemTooltip("Keep the current scene and cancel opening another scene (Esc).");
                    ImGui::EndPopup();
                }
                if (requestDirtyQuitWarning) {
                    ImGui::OpenPopup("Unsaved scene changes##quit");
                    requestDirtyQuitWarning = false;
                }
                if (ImGui::BeginPopupModal(
                        "Unsaved scene changes##quit",
                        nullptr,
                        ImGuiWindowFlags_AlwaysAutoResize)) {
                    modalDialogOpen = true;
                    ImGui::TextUnformatted("The current scene has unsaved changes.");
                    ImGui::TextUnformatted("Exit and discard them?");
                    if (ImGui::Button("Exit")) {
                        woby::requestQuit(ui);
                        ImGui::CloseCurrentPopup();
                    }
                    setLastItemTooltip("Discard unsaved changes and exit Woby.");
                    ImGui::SameLine();
                    if (ImGui::Button("Cancel") || ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                        ImGui::CloseCurrentPopup();
                    }
                    setLastItemTooltip("Keep Woby open with the current scene (Esc).");
                    ImGui::EndPopup();
                }
                if (drawProcessingDialog(backgroundLoad, gpuFinalize)) {
                    modalDialogOpen = true;
                }
                const auto menu = woby::drawMainMenu(ui, annotationInteraction,
                    {fileActionsDisabled(), sceneScreenshot.captureRequested || sceneScreenshot.readbackPending,
                        woby::canUndoScene(sceneHistory), woby::canRedoScene(sceneHistory), woby::updateBusy(updateRuntime.state)}, recentFiles.files);
                switch (menu.command) {
                case woby::MainMenuCommand::newScene:
                    woby::updateSceneDirty(ui, cleanSceneDocument);
                    if (ui.isDirty) { requestDirtyNewWarning = true; modalDialogOpen = true; }
                    else { newScene(); }
                    break;
                case woby::MainMenuCommand::openScene: documentCommand(woby::SceneAction::open); break;
                case woby::MainMenuCommand::saveScene: documentCommand(woby::SceneAction::save); break;
                case woby::MainMenuCommand::saveSceneAs: documentCommand(woby::SceneAction::saveAs); break;
                case woby::MainMenuCommand::addModels: showModelFileDialog(window.get(), modelFileDialogState); break;
                case woby::MainMenuCommand::addModelFolder: showModelFolderTreeDialog(window.get(), modelFileDialogState); break;
                case woby::MainMenuCommand::openRecentScene:
                    woby::cancelAnnotationPointer(annotationInteraction);
                    if (annotationCommand) { woby::cancelAnnotationWork(annotationCommand->work); }
                    woby::updateSceneDirty(ui, cleanSceneDocument);
                    openSceneOrRequestDirtyWarning(menu.recentPath, ui, backgroundLoad, gpuFinalize,
                        sceneFileDialogState, toast, pendingDirtyOpenScenePath, requestDirtyOpenWarning);
                    modalDialogOpen = modalDialogOpen || requestDirtyOpenWarning;
                    break;
                case woby::MainMenuCommand::addRecentModel:
                    if (!startAppendModelBackgroundLoad(backgroundLoad, {menu.recentPath}, woby::totalGroupCount(ui))) {
                        setToastMessage(toast, "Already processing files");
                    }
                    break;
                case woby::MainMenuCommand::removeRecentScene:
                case woby::MainMenuCommand::removeRecentModel:
                    woby::removeRecentFile(recentFiles, menu.command == woby::MainMenuCommand::removeRecentScene
                        ? woby::RecentFileKind::scene : woby::RecentFileKind::model, menu.recentPath);
                    break;
                case woby::MainMenuCommand::clearRecentFiles:
                    woby::clearRecentFiles(recentFiles);
                    break;
                case woby::MainMenuCommand::exportPng:
                    ImGui::OpenPopup("Export PNG");
                    ImGui::SetNextWindowPos(menu.popupPosition, ImGuiCond_Appearing);
                    break;
                case woby::MainMenuCommand::exit:
                    woby::updateSceneDirty(ui, cleanSceneDocument);
                    if (ui.isDirty) { requestDirtyQuitWarning = true; modalDialogOpen = true; }
                    else { woby::requestQuit(ui); }
                    break;
                case woby::MainMenuCommand::undo: historyCommand = woby::SceneHistoryCommand::undo; break;
                case woby::MainMenuCommand::redo: historyCommand = woby::SceneHistoryCommand::redo; break;
                case woby::MainMenuCommand::settings: requestSettings = true; break;
                case woby::MainMenuCommand::checkUpdates:
                    requestUpdates = true;
                    woby::startUiUpdate(updateRuntime, woby::UpdateCommand::check, ui.isDirty, deploymentGuard);
                    break;
                case woby::MainMenuCommand::none: break;
                }
                if (woby::drawSceneScreenshotOptions(ui)) {
                    showSaveSceneScreenshotDialog(window.get(), sceneScreenshotDialogState);
                }
                modalDialogOpen = modalDialogOpen || ImGui::IsPopupOpen("Export PNG");
                const auto panelLayout = canvasLayout(window.get(), ui);
                if (ui.viewerPaneVisible) {
                    const float availableHeight = panelLayout.height - panelLayout.top;
                    ImGui::SetNextWindowPos(ImVec2(0.0f, panelLayout.top), ImGuiCond_Always);
                    ImGui::SetNextWindowSize(
                        ImVec2(panelLayout.leftWidth, availableHeight),
                        ImGuiCond_Always);
                    ImGui::SetNextWindowSizeConstraints(
                        ImVec2(std::min(minViewerPaneWidth, panelLayout.leftWidth), availableHeight),
                        ImVec2(panelLayout.maxLeftWidth, availableHeight));
                    const bool showViewerContent = ImGui::Begin(
                        "##ViewerPane",
                        nullptr,
                        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
                    if (showViewerContent) {
                        woby::setViewerPaneWidth(
                            ui,
                            ImGui::GetWindowSize().x,
                            minViewerPaneWidth,
                            maxViewerPaneWidth);

                        drawViewerPaneToggleButton(ui);
                        ImGui::SameLine();
                        ImGui::TextUnformatted("Scene controls");
                        ImGui::SameLine();
                        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x
                            - 2.0f * renderModeButtonSize() - ImGui::GetStyle().ItemSpacing.x);
                        const auto toolbarHistoryCommand = woby::drawSceneHistoryToolbar(
                            woby::canUndoScene(sceneHistory), woby::canRedoScene(sceneHistory),
                            fileActionsDisabled() || sceneScreenshot.captureRequested || sceneScreenshot.readbackPending);
                        if (toolbarHistoryCommand != woby::SceneHistoryCommand::none) { historyCommand = toolbarHistoryCommand; }
                        ImGui::Separator();
                        const float statusHeight = ImGui::GetTextLineHeightWithSpacing() * 2.0f
                            + ImGui::GetStyle().ItemSpacing.y + 1.0f;
                        bool scenePaneOpen = false;
                        // Match SceneObjects' unpadded child so the header stays inside the content edges.
                        if (ImGui::BeginChild("DisplayHeader", {0, ImGui::GetFrameHeight()},
                                ImGuiChildFlags_None, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) {
                            scenePaneOpen = ImGui::CollapsingHeader("Display");
                        }
                        ImGui::EndChild();
                    if (scenePaneOpen) {
                        const float sceneContentHeight = renderModeButtonSize() * 3.0f + ImGui::GetStyle().ItemSpacing.y * 2.0f;
                        if (ImGui::BeginChild(
                                "SceneContent",
                                ImVec2(0.0f, sceneContentHeight),
                                ImGuiChildFlags_None)) {
                            woby::updateSceneSelectionQueries(renderScratch.queries, ui, &comparison);
                            drawCameraToolbar(ui, renderScratch.queries.selection);
                            if (drawRenderModeIconButton(
                                    "origin",
                                    originIcon,
                                    ui.showOrigin ? "Hide origin axes" : "Show origin axes",
                                    ui.showOrigin ? RenderModeState::on : RenderModeState::off,
                                    false)) {
                                woby::toggleShowOrigin(ui);
                            }
                            ImGui::SameLine();
                            if (drawRenderModeIconButton(
                                    "grid",
                                    gridIcon,
                                    ui.showGrid ? "Hide ground grid" : "Show ground grid",
                                    ui.showGrid ? RenderModeState::on : RenderModeState::off,
                                    false)) {
                                woby::toggleShowGrid(ui);
                            }
                            const size_t groupCount = woby::totalGroupCount(ui);
                            const size_t solidMeshCount = woby::countEnabledSceneRenderMode(
                                ui,
                                woby::UiRenderMode::solidMesh);
                            if (drawTriStateMasterIconButton(
                                    "solid_mesh",
                                    solidMeshIcon,
                                    "Solid mesh",
                                    solidMeshCount,
                                    groupCount)) {
                                woby::setAllSceneRenderModes(
                                    ui,
                                    woby::UiRenderMode::solidMesh,
                                    solidMeshCount != groupCount);
                            }
                            ImGui::SameLine();
                            const size_t triangleCount = woby::countEnabledSceneRenderMode(
                                ui,
                                woby::UiRenderMode::triangles);
                            if (drawTriStateMasterIconButton(
                                    "triangles",
                                    trianglesIcon,
                                    "Triangle edges",
                                    triangleCount,
                                    groupCount)) {
                                woby::setAllSceneRenderModes(
                                    ui,
                                    woby::UiRenderMode::triangles,
                                    triangleCount != groupCount);
                            }
                            ImGui::SameLine();
                            ImGui::BeginDisabled(!woby::scenePostLoadReady(ui));
                            const size_t vertexCount = woby::countEnabledSceneRenderMode(
                                ui,
                                woby::UiRenderMode::vertices);
                            if (drawTriStateMasterIconButton(
                                    "vertices",
                                    verticesIcon,
                                    "Vertices",
                                    vertexCount,
                                    groupCount)) {
                                woby::setAllSceneRenderModes(
                                    ui,
                                    woby::UiRenderMode::vertices,
                                    vertexCount != groupCount);
                            }
                            ImGui::SameLine(0.0f, 0.0f);
                            float editedMasterVertexPointSize = masterVertexPointSize;
                            ImGui::SetNextItemWidth(renderModeButtonRowWidth());
                            pushRenderModeControlHeight();
                            if (ImGui::DragFloat(
                                "##vertex_size",
                                &editedMasterVertexPointSize,
                                0.2f,
                                woby::minVertexPointSize,
                                woby::maxVertexPointSize,
                                "%.0f px")) {
                                woby::setMasterVertexPointSize(ui, editedMasterVertexPointSize);
                            }
                            ImGui::PopStyleVar();
                            ImGui::EndDisabled();
                        }
                        ImGui::EndChild();
                    }

                    if (scenePaneOpen) {
                        woby::drawAnnotationTools(ui, annotationInteraction, fileActionsDisabled());
                        ImGui::SameLine();
                        ImGui::BeginDisabled(!woby::scenePostLoadReady(ui));
                        bool showDimensions = ui.showDimensions;
                        if (ImGui::Checkbox("Show dimensions", &showDimensions)) {
                            woby::setShowDimensions(ui, showDimensions);
                        }
                        if (ImGui::IsItemHovered()) {
                            ImGui::SetTooltip("Size of visible selected geometry, including parent transforms.");
                        }
                        ImGui::EndDisabled();
                        if (showDimensions && ui.selectedSceneObjects.empty()) {
                            ImGui::TextDisabled("Select a mesh to see its dimensions.");
                        }
                    }

                    const float contentHeight = std::max(ImGui::GetFrameHeight(),
                        ImGui::GetContentRegionAvail().y - statusHeight - ImGui::GetStyle().ItemSpacing.y);
                    if (ImGui::BeginChild("SceneObjects", {0, contentHeight})) {
                        const std::string filesPaneTitle = "Models (" + std::to_string(files.size()) + " files)##Files";
                        if (!canvasSelectionPath.empty() && !woby::sceneObjectSelected(ui, canvasSelectionPath.back())) { canvasSelectionPath.clear(); }
                        bool modelsOpen = false;
                        if (ImGui::BeginTable("models_header", 2, ImGuiTableFlags_SizingStretchProp)) {
                            ImGui::TableSetupColumn("visibility", ImGuiTableColumnFlags_WidthFixed, renderModeButtonSize());
                            ImGui::TableSetupColumn("label", ImGuiTableColumnFlags_WidthStretch);
                            ImGui::TableNextRow(); ImGui::TableNextColumn();
                            const auto groupCount = woby::totalGroupCount(ui);
                            woby::updateSceneTreeQueries(renderScratch.queries.tree, ui);
                            size_t visibleCount = 0;
                            for (const auto& node : ui.sceneNodes) { visibleCount += woby::sceneTreeSummary(renderScratch.queries.tree, node.objectId).visible; }
                            if (drawTriStateVisibilityButton("models_visible", "Models", visibleCount, groupCount, "parts")) {
                                woby::setAllModelsVisible(ui, visibleCount != groupCount);
                            }
                            ImGui::TableNextColumn();
                            if (!canvasSelectionPath.empty()) { ImGui::SetNextItemOpen(true); }
                            modelsOpen = ImGui::CollapsingHeader(filesPaneTitle.c_str(), ImGuiTreeNodeFlags_DefaultOpen);
                            ImGui::EndTable();
                        }
                        if (modelsOpen) {
                            if (files.empty()) { ImGui::TextDisabled("No models yet."); }
                            std::optional<size_t> removeFileIndex;
                            for (size_t nodeIndex = 0; nodeIndex < ui.sceneNodes.size(); ++nodeIndex) {
                                ImGui::PushID(static_cast<int>(nodeIndex));
                                drawSceneTreeNode(ui, runtimes, ui.sceneNodes[nodeIndex], removeFileIndex, canvasSelectionPath, renderScratch.queries.tree);
                                ImGui::PopID();
                            }
                            if (removeFileIndex.has_value() && removeFileIndex.value() < files.size()) {
                                const std::string removedName = fileDisplayName(files[removeFileIndex.value()].path);
                                removeModelFile(ui, runtimes, removeFileIndex.value(), annotationPreparation);
                                setToastMessage(toast, "Removed " + removedName);
                            }
                        }
                        canvasSelectionPath.clear();
                        woby::drawComparisonObjects(ui, comparisonNameEdit, comparison);
                        woby::drawAnnotationObjects(ui, annotationNameEdit);
                        ImGui::BeginDisabled(fileActionsDisabled()
                            || sceneScreenshot.captureRequested || sceneScreenshot.readbackPending);
                        woby::drawViews(ui, viewNameEdit, viewListLayout, 0, true);
                        ImGui::EndDisabled();
                    }
                    ImGui::EndChild();
                    ImGui::SetCursorPosY(std::max(ImGui::GetCursorPosY(),
                        ImGui::GetWindowHeight() - ImGui::GetStyle().WindowPadding.y
                            - statusHeight));
                    ImGui::Separator();
                    size_t vertexCountTotal = 0;
                    size_t triangleCountTotal = 0, lineCountTotal = 0;
                    for (const auto& file : files) {
                        vertexCountTotal += meshGeometry(file.mesh).vertices.size();
                        triangleCountTotal += meshGeometry(file.mesh).indices.size() / 3u;
                        lineCountTotal += meshGeometry(file.mesh).lineIndices.size() / 2u;
                    }
                    ImGui::TextDisabled("%zu vertices | %zu triangles", vertexCountTotal, triangleCountTotal);
                    if (lineCountTotal) { ImGui::SameLine(); ImGui::TextDisabled("| %zu lines", lineCountTotal); }
                    ImGui::TextDisabled("%s | %.1f FPS", woby::graphics::getRendererName(woby::graphics::getRendererType()), fps);
                }
                    ImGui::End();
                }
                drawPaneToggles(ui, panelLayout.width, panelLayout.top);
                if (files.empty() && ui.comparisons.empty() && !backgroundLoad.active && !gpuFinalize.active) {
                    const float viewportWidth = panelLayout.width - panelLayout.leftWidth
                        - (ui.propertiesPaneVisible ? panelLayout.rightWidth : 0.0f);
                    ImGui::SetNextWindowPos(
                        ImVec2(panelLayout.leftWidth + viewportWidth * 0.5f, (panelLayout.top + panelLayout.height) * 0.5f),
                        ImGuiCond_Always, ImVec2(0.5f, 0.5f));
                    ImGui::SetNextWindowSize(ImVec2(std::max(120.0f, std::min(420.0f, viewportWidth - 24.0f)), 0.0f));
                    if (ImGui::Begin("##EmptyScene", nullptr, ImGuiWindowFlags_NoDecoration
                        | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove
                        | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing)) {
                        ImGui::TextWrapped("Start a scene");
                        ImGui::TextWrapped("Add models to inspect, or open a saved scene.");
                        ImGui::Spacing();
                        ImGui::BeginDisabled(fileActionsDisabled());
                        if (ImGui::Button("Add models", ImVec2(-1.0f, 0.0f))) {
                            showModelFileDialog(window.get(), modelFileDialogState);
                        }
                        setLastItemTooltip("Choose model files to add to the current scene.");
                        ImGui::EndDisabled();
                        ImGui::BeginDisabled(fileActionsDisabled());
                        if (ImGui::Button("Open scene", ImVec2(-1.0f, 0.0f))) {
                            documentCommand(woby::SceneAction::open);
                        }
                        setLastItemTooltip("Open scene (Ctrl+O)");
                        ImGui::EndDisabled();
                        ImGui::Spacing();
                        ImGui::TextWrapped("Models: OBJ and installed importer formats. Scenes: .woby.");
                        ImGui::TextWrapped("Tip: drop model files, folders or a .woby scene into this window.");
                    }
                    ImGui::End();
                }
                drawPropertiesPane(ui, comparison, panelLayout, inspector);
                if (requestSettings) {
                    woby::startFileAssociationAction(fileAssociations, {woby::FileAssociationAction::refresh});
                }
                const auto settings = woby::drawSettingsDialog(ui, requestSettings, menu.popupPosition,
                    fileAssociations.state);
                fileAssociationSettingsOpen = settings.open;
                woby::startFileAssociationAction(fileAssociations, settings.fileAssociationRequest);
                const auto updates = woby::drawUpdatesDialog(ui, requestUpdates, updateRuntime.state, menu.popupPosition);
                modalDialogOpen = modalDialogOpen || settings.open || updates.open;
                if (updates.updateCommand != woby::UpdateCommand::none) {
                    woby::startUiUpdate(updateRuntime, updates.updateCommand, ui.isDirty, deploymentGuard);
                }
                if (settings.scaleChanged && !preferencePath.empty()) {
                    std::ofstream preference(preferencePath);
                    if (!(preference << ui.uiScale)) { setToastMessage(toast, "Could not save UI scale preference"); }
                }
            }

            const auto beforeAnnotationRevision = ui.sceneEditRevision;
            woby::updateAnnotationPointer(ui, annotationInteraction, presentedPickView ? &*presentedPickView : nullptr);
            if (beforeAnnotationRevision != ui.sceneEditRevision) {
                woby::finishSceneHistoryInteraction(sceneHistory);
                woby::recordSceneHistory(sceneHistory, ui);
                woby::updateSceneDirty(ui, cleanSceneDocument);
            }
            recordFrameStage(frameTimings, woby::FrameStage::imguiBuild, stageStart);
            if (!headless && woby::recordSceneHistory(sceneHistory, ui, woby::sceneHistoryInteraction())) {
                woby::updateSceneDirty(ui, cleanSceneDocument);
            }

            woby::updateSceneBoundsQuery(renderScratch.queries, ui);
            updateAppWindowTitle(window.get(), currentScenePath, ui.isDirty, instanceId, windowTitleCache);
            // Both UI and CTL use the same restoration and failure-consumption path.
            const auto runSceneHistory = [&](bool redo) {
                woby::finishSceneHistoryInteraction(sceneHistory);
                return woby::beginSceneHistoryRestore(historyRestore, sceneHistory, ui, cleanSceneDocument, layout, redo);
            };
            // UI and loading commits have finished. No logical edits occur between
            // executing commands here and submitting their screenshots below.
            if (automationComparison) {
                // Difference jobs are tracked independently below.
                const auto& pending = *automationComparison;
                const auto it = comparison.objects.find(pending.objectId);
                const bool both = woby::enabledComparisonPartCount(ui, woby::ComparisonSide::a, pending.objectId) != 0
                    && woby::enabledComparisonPartCount(ui, woby::ComparisonSide::b, pending.objectId) != 0;
                const bool changed = pending.sceneGeneration != ui.sceneGeneration
                    || !woby::findComparison(ui, pending.objectId)
                    || pending.signature != woby::comparisonGeometrySignature(ui, pending.objectId)
                    || !woby::sameTopologyInspectionFilters(pending.topologyInspection, woby::comparisonSettings(ui, pending.objectId).topologyInspection)
                    || pending.intersectionLimits != woby::comparisonSettings(ui, pending.objectId).intersections.limits
                    || pending.topologyMode != woby::comparisonSettings(ui, pending.objectId).topologyMode
                    || !woby::sameDegenerateThresholds(pending.degenerates, woby::comparisonSettings(ui, pending.objectId).degenerates)
                    || pending.stages != woby::requestedComparisonStages(woby::comparisonSettings(ui, pending.objectId), both, true);
                const bool ready = !changed && it != comparison.objects.end()
                    && woby::comparisonResultsReady(it->second, ui, pending.objectId, true)
                    && (pending.exportPath.empty() || (!it->second.jobs.intersection.requested
                        && it->second.results.value.original.intersections.phase != woby::IntersectionPhase::queued
                        && it->second.results.value.original.intersections.phase != woby::IntersectionPhase::running));
                const bool failed = it != comparison.objects.end() && !it->second.jobs.error.empty()
                    && it->second.jobs.attemptedSignature == pending.signature;
                if (changed || ready || failed) {
                    try {
                        if (changed) { throw std::runtime_error("Analysis inputs or detectors changed while results were being requested; retry analysis.results."); }
                        if (!ready) { throw std::runtime_error(it->second.jobs.error); }
                        auto result = woby::controlComparisonResults(it->second.results.value, pending.tolerance, pending.exportPath.empty(), formatObjectId);
                        result["target"] = pending.target;
                        if (!pending.exportPath.empty()) {
                            woby::startAnalysisExport(analysisExport, it->second.results.value, std::move(result), pending.target, pending.exportPath);
                            result = {{"export", woby::analysisExportStatus(analysisExport)}};
                        }
                        woby::completeAutomationCommand(*automation, pending.id, woby::AutomationControlResult{std::move(result)});
                    } catch (const std::exception& error) {
                        woby::completeAutomationCommand(*automation, pending.id, woby::AutomationCommandError{error.what()});
                    }
                    if (it != comparison.objects.end()) { it->second.jobs.fullResultsRequested = false; }
                    automationComparison.reset();
                }
            }
            for (auto it = automationDifferences.begin(); it != automationDifferences.end();) {
                bool done = false;
                try {
                    const auto* item = woby::findComparison(ui, it->objectId);
                    if (ui.sceneGeneration != it->generation || !item) { throw std::runtime_error("Difference command canceled because the scene changed."); }
                    auto& runtime = comparison.objects.at(it->objectId).difference;
                    if (!it->exporting && item->differenceRequest.revision != it->request) { throw std::runtime_error("Difference command canceled or superseded."); }
                    const auto phase = it->exporting ? runtime.exportState : runtime.phase;
                    if (phase == "failed" || phase == "outdated" || phase == "canceled" || phase == "not_created") {
                        throw std::runtime_error(it->exporting ? runtime.exportError : runtime.error.empty() ? "Difference mesh is " + phase : runtime.error);
                    }
                    if (phase == "ready" || phase == "complete") {
                        if (!it->exporting && !woby::differenceStatus(runtime, ui, it->objectId).value("current", false)) {
                            throw std::runtime_error("Difference mesh is out of date.");
                        }
                        woby::completeAutomationCommand(*automation, it->id, woby::AutomationControlResult{{{"difference", woby::differenceStatus(runtime, ui, it->objectId)}}}); done = true;
                    }
                } catch (const std::exception& e) { woby::completeAutomationCommand(*automation, it->id, woby::AutomationCommandError{e.what()}); done = true; }
                if (done) { it = automationDifferences.erase(it); } else { ++it; }
            }
            if (annotationCommand) {
                auto& pending = *annotationCommand;
                if (!woby::annotationWorkCurrent(pending.identity, ui, true)) { woby::cancelAnnotationWork(pending.work); }
                if (pending.work->cancel.stop_requested() || pending.work->done.load(std::memory_order_acquire)) {
                    try {
                        auto result = woby::publishAnnotationCommand(ui, cleanSceneDocument, pending, formatObjectId);
                        if (commandLine.logPerformance) {
                            const auto& measurement = *pending.result;
                            spdlog::info("perf annotation projected_triangles={} projected_vertices={} snapshot_ms={} projection_ms={} exact_ms={}",
                                measurement.projectedTriangles, measurement.projectedVertices, measurement.snapshotMilliseconds,
                                measurement.projectionMilliseconds, measurement.exactMilliseconds);
                        }
                        woby::finishSceneHistoryInteraction(sceneHistory);
                        woby::recordSceneHistory(sceneHistory, ui);
                        woby::completeAutomationCommand(*automation, annotationCommandId, woby::AutomationControlResult{std::move(result)});
                    } catch (const std::exception& error) {
                        woby::completeAutomationCommand(*automation, annotationCommandId, woby::AutomationCommandError{error.what()});
                    }
                    annotationCommand.reset();
                }
            }
            for (size_t executed = 0; executed < woby::maxAutomationCommands; ++executed) {
                const auto command = woby::takeAutomationCommand(*automation);
                if (!command) {
                    break;
                }
                const auto beforeCommandRevision = ui.sceneEditRevision;
                const auto beforeCommandGeneration = ui.sceneGeneration;
                try {
                    std::visit([&](const auto& payload) {
                        using Command = std::decay_t<decltype(payload)>;
                        if constexpr (std::is_same_v<Command, woby::AutomationScreenshotCommand>) {
                            if (backgroundLoad.active || gpuFinalize.active || historyRestore.active) {
                                throw std::runtime_error("Cannot capture while model files are being processed.");
                            }
                            requestSceneScreenshotCapture(sceneScreenshot, payload.outputPath, ui.screenshotSettings);
                            automationScreenshotCommandId = command->id;
                        } else if constexpr (std::is_same_v<Command, woby::AutomationObjectsCommand>) {
                            woby::completeAutomationCommand(*automation, command->id,
                                woby::AutomationObjectsResult{woby::sceneObjects(ui)});
                        } else if constexpr (std::is_same_v<Command, woby::ControlOperation>) {
                            using A = woby::ControlAction;
                            using Json = nlohmann::json;
                            if (headless && (payload.action == A::pane || payload.action == A::performanceBegin || payload.action == A::performanceEnd)) {
                                throw std::invalid_argument("Desktop pane and performance capture controls are unavailable in headless mode.");
                            }
                            const bool historyOperation = payload.action == A::sceneUndo || payload.action == A::sceneRedo;
                            const bool busy = backgroundLoad.active || gpuFinalize.active || historyRestore.active
                                || (automationAppend && automationAppend->postLoadPending) || automationOpenPostLoad
                                || sceneScreenshot.captureRequested || sceneScreenshot.readbackPending
                                || modalDialogOpen || modelFileDialogIsOpen(modelFileDialogState)
                                || sceneFileDialogIsOpen(sceneFileDialogState) || sceneScreenshotDialogIsOpen(sceneScreenshotDialogState)
                                || (historyOperation && (ImGui::IsAnyItemActive() || ImGui::GetIO().WantTextInput));
                            for (const auto id : {payload.objectId, payload.aId, payload.bId, payload.memberId}) {
                                if (id != woby::invalidSceneObjectId && !woby::findSceneObject(ui, id)) {
                                    woby::completeAutomationCommand(*automation, command->id,
                                        woby::AutomationCommandError{"Unknown or stale object ID.", -32005});
                                    return;
                                }
                            }
                            if (busy && payload.action != A::comparisonCancel && payload.action != A::differenceCancel && payload.action != A::performanceEnd
                                && (woby::controlMethod(payload.action).mutating || (payload.action == A::comparisonResults || payload.action == A::comparisonExport))) {
                                woby::completeAutomationCommand(*automation, command->id,
                                    woby::AutomationCommandError{"Scene is busy loading, capturing, displaying a dialog, or editing a widget.", -32014});
                                return;
                            }
                            Json result;
                            if (!woby::scenePostLoadReady(ui) && (payload.vertices || payload.rotationDegrees || payload.scale
                                || payload.action == A::comparisonCreate || payload.action == A::comparisonResults || payload.action == A::comparisonExport)) {
                                woby::completeAutomationCommand(*automation, command->id,
                                    woby::AutomationCommandError{"Model data is being prepared. Retry when postLoadReady is true.", -32014});
                                return;
                            }
                            if (!woby::annotationControlReady(ui, payload.action)) {
                                woby::completeAutomationCommand(*automation, command->id,
                                    woby::AutomationCommandError{annotationPreparation.error.empty()
                                        ? "Annotation actions are disabled while annotation data is being prepared. Retry when annotationReady is true."
                                        : "Annotation preparation failed: " + annotationPreparation.error, -32014});
                                return;
                            }
                            if ((payload.action == A::annotationCreate && payload.shape != "section") || payload.action == A::annotationMove || payload.action == A::annotationReshape) {
                                auto next = woby::prepareAnnotationCommand(ui, payload);
                                if (annotationCommand) {
                                    woby::cancelAnnotationWork(annotationCommand->work);
                                    woby::completeAutomationCommand(*automation, annotationCommandId,
                                        woby::AutomationCommandError{"Annotation superseded by a newer geometry command."});
                                }
                                annotationCommand = std::move(next); annotationCommandId = command->id;
                                woby::submitAnnotationWork(annotationExecutor, annotationCommand->work);
                                return; // Success and history belong to publication, never submission.
                            }
                            if (annotationInteraction.pending && woby::controlMethod(payload.action).mutating) { woby::cancelAnnotationPointer(annotationInteraction); }
                            if (annotationCommand && woby::controlMethod(payload.action).mutating) {
                                woby::cancelAnnotationWork(annotationCommand->work);
                            }
                            if (historyOperation) {
                                const bool redo = payload.action == A::sceneRedo;
                                const bool applied = runSceneHistory(redo);
                                if (applied) { automationHistory = command->id; return; }
                                result = {{"action", redo ? "redo" : "undo"}, {"applied", applied}, {"dirty", ui.isDirty}};
                            } else if (payload.action >= A::differenceCreate && payload.action <= A::differenceDelete) {
                                auto& runtime = comparison.objects[payload.objectId].difference;
                                result = woby::controlDifference(ui, runtime, payload);
                                woby::updateSceneDirty(ui, cleanSceneDocument);
                                if (payload.action == A::differenceCreate || payload.action == A::differenceRebuild || payload.action == A::differenceExport) {
                                    automationDifferences.push_back({command->id, payload.objectId, ui.sceneGeneration,
                                        woby::findComparison(ui, payload.objectId)->differenceRequest.revision, payload.action == A::differenceExport});
                                    return;
                                }
                            } else if (payload.action == A::comparisonExportStatus || payload.action == A::comparisonExportCancel) {
                                if (payload.action == A::comparisonExportCancel) { woby::cancelAnalysisExport(analysisExport); }
                                result = {{"export", woby::analysisExportStatus(analysisExport)}};
                            } else if (payload.action == A::comparisonUvTriangles || payload.action == A::comparisonUvProbe
                                || payload.action == A::comparisonUvProbeGet || payload.action == A::comparisonUvProbeClear) {
                                const auto* source = woby::findComparison(ui, payload.objectId);
                                if (!source || source->settings.type != woby::AnalysisType::uvQuality) {
                                    throw std::invalid_argument("This command requires a UV quality analysis ID.");
                                }
                                const auto found = comparison.objects.find(payload.objectId);
                                const bool ready = found != comparison.objects.end()
                                    && woby::comparisonResultsReady(found->second, ui, payload.objectId, true);
                                const auto revision = ready ? Json(std::to_string(found->second.results.revision)) : Json(nullptr);
                                if (payload.action == A::comparisonUvTriangles) {
                                    if (!ready || !found->second.results.value.original.source.uvQuality) {
                                        throw std::invalid_argument("UV results are not current; call analysis results first.");
                                    }
                                    if (payload.revision && *payload.revision != std::to_string(found->second.results.revision)) {
                                        throw std::invalid_argument("Results changed; restart pagination without --revision.");
                                    }
                                    result = woby::controlUvTrianglePage(*found->second.results.value.original.source.uvQuality,
                                        static_cast<size_t>(payload.offset.value_or(0)), static_cast<size_t>(payload.limit.value_or(100)), formatObjectId);
                                    result["target"] = payload.target;
                                } else {
                                    result = woby::controlUvProbe(ui, ready ? &found->second.results.value : nullptr,
                                        ready ? found->second.results.signature : 0, payload, formatObjectId);
                                }
                                result["revision"] = revision;
                            } else if (payload.action == A::comparisonFindings) {
                                const auto found = comparison.objects.find(payload.objectId);
                                const auto category = static_cast<woby::DiagnosticCategory>(std::find(woby::diagnosticCategoryKeys.begin(),
                                    woby::diagnosticCategoryKeys.end(), *payload.detector) - woby::diagnosticCategoryKeys.begin());
                                if (found == comparison.objects.end() || !woby::comparisonDetectorReady(found->second, ui, payload.objectId, category)) {
                                    throw std::invalid_argument("Detector results are not current; run analysis run first.");
                                }
                                const auto revision = std::to_string(found->second.results.revision);
                                if (payload.revision && *payload.revision != revision) { throw std::invalid_argument("Results changed; restart pagination without --revision."); }
                                result = woby::analysisResultPage(found->second.results.value, *payload.side == "a" ? woby::ComparisonSide::a : woby::ComparisonSide::b,
                                    *payload.detector, payload.collection.value_or("/findings"), static_cast<size_t>(payload.offset.value_or(0)), static_cast<size_t>(payload.limit.value_or(100)));
                                result["revision"] = revision; result["target"] = payload.target;
                            } else if (payload.action == A::comparisonResults || payload.action == A::comparisonExport) {
                                const auto* source = woby::findComparison(ui, payload.objectId);
                                if (!source) { throw std::invalid_argument("analysis.results requires an analysis ID."); }
                                if (!woby::canInspectComparison(ui, payload.objectId)) {
                                    throw std::invalid_argument("Analysis needs at least one populated input and no missing references.");
                                }
                                if (automationComparison) { throw std::runtime_error("Another analysis.results request is still computing."); }
                                AutomationComparisonRuntime pending;
                                pending.id = command->id;
                                if (payload.action == A::comparisonExport) {
                                    if (woby::analysisExportStatus(analysisExport).value("state", "idle") == "running") { throw std::invalid_argument("An export is already running."); }
                                    pending.exportPath = payload.path;
                                }
                                pending.intersectionLimits = source->settings.intersections.limits;
                                pending.target = payload.target;
                                pending.objectId = payload.objectId;
                                pending.tolerance = source->settings.tolerance;
                                pending.degenerates = source->settings.degenerates;
                                pending.topologyInspection = source->settings.topologyInspection;
                                pending.topologyMode = source->settings.topologyMode;
                                pending.signature = woby::comparisonGeometrySignature(ui, payload.objectId);
                                pending.sceneGeneration = ui.sceneGeneration;
                                const bool both = woby::enabledComparisonPartCount(ui, woby::ComparisonSide::a, payload.objectId) != 0
                                    && woby::enabledComparisonPartCount(ui, woby::ComparisonSide::b, payload.objectId) != 0;
                                pending.stages = woby::requestedComparisonStages(source->settings, both, true);
                                comparison.objects[payload.objectId].jobs.fullResultsRequested = true;
                                automationComparison.emplace(std::move(pending));
                                return;
                            } else if (payload.action == A::comparisonFocus) {
                                const auto found = comparison.objects.find(payload.objectId);
                                if (found == comparison.objects.end() || !payload.detector) {
                                    throw std::invalid_argument("Analysis findings are not ready; run the detector first.");
                                }
                                const auto detector = std::find(woby::diagnosticCategoryKeys.begin(),
                                    woby::diagnosticCategoryKeys.end(), *payload.detector);
                                if (detector == woby::diagnosticCategoryKeys.end()
                                    || !woby::comparisonDetectorReady(found->second, ui, payload.objectId,
                                        static_cast<woby::DiagnosticCategory>(detector - woby::diagnosticCategoryKeys.begin()))) {
                                    throw std::invalid_argument("Detector findings are not current; run the detector first.");
                                }
                                result = woby::controlFocusComparisonDiagnostic(ui, found->second.results.value,
                                    found->second.results.signature, payload);
                                woby::updateSceneDirty(ui, cleanSceneDocument);
                            } else if (payload.action == A::status) {
                                result = woby::automationInstanceInfo(*automation);
                                result.update({{"path", currentScenePath ? Json(woby::pathToUtf8(*currentScenePath)) : Json(nullptr)},
                                    {"dirty", ui.isDirty}, {"loading", backgroundLoad.active}, {"gpuFinalizing", gpuFinalize.active},
                                    {"annotationPreparing", annotationPreparation.job != nullptr || postLoading.noticePending},
                                    {"annotationReady", woby::annotationPreparationReady(ui)},
                                    {"postLoading", postLoading.noticePending}, {"postLoadReady", woby::scenePostLoadReady(ui)},
                                    {"annotationPreparationError", annotationPreparation.error.empty() ? std::string(woby::postLoadError(ui)) : annotationPreparation.error},
                                    {"postLoadError", std::string(woby::postLoadError(ui))},
                                    {"capturing", sceneScreenshot.captureRequested || sceneScreenshot.readbackPending},
                                    {"busy", busy}, {"version", WOBY_VERSION},
                                    {"renderer", woby::graphics::getRendererName(woby::graphics::getRendererType())},
                                    {"screenshot", {{"width", ui.screenshotSettings.width}, {"height", ui.screenshotSettings.height}, {"format", "png"}}},
                                    {"propertiesPane", headless ? Json(nullptr) : Json{{"visible", ui.propertiesPaneVisible}, {"width", ui.propertiesPaneWidth}}},
                                    {"pane", headless ? Json(nullptr) : Json{{"visible", ui.viewerPaneVisible}, {"width", ui.viewerPaneWidth}}}});
                            } else if (payload.action == A::capabilities) {
                                result = woby::controlCapabilities();
                                result["headless"] = headless;
                                result["renderer"] = woby::graphics::getRendererName(woby::graphics::getRendererType());
                                for (auto& method : result["methods"]) {
                                    method["available"] = !headless || (method["method"] != "pane.set"
                                        && method["method"] != "performance.begin" && method["method"] != "performance.end");
                                }
                                result["limits"] = {{"admittedCommands", woby::maxAutomationCommands},
                                    {"retainedResults", woby::maxAutomationHistory}, {"requestKeys", woby::maxAutomationRequestKeys},
                                    {"timeoutSeconds", {1, 3600}}, {"vertexPixels", {woby::minVertexPointSize, woby::maxVertexPointSize}},
                                    {"scale", {woby::minGroupScale, woby::maxGroupScale}}};
                                result["importers"] = woby::controlImporterInfo(rememberedImporters);
                            } else if (payload.action == A::modelAdd || payload.action == A::folderAdd) {
                                auto paths = payload.action == A::folderAdd ? woby::collectModelPathsRecursive(payload.path)
                                    : std::vector<std::filesystem::path>{payload.path};
                                if (!startAppendModelBackgroundLoad(backgroundLoad, std::move(paths), woby::totalGroupCount(ui),
                                    payload.tree ? AsyncLoadKind::appendFolderTree : AsyncLoadKind::appendModel,
                                    payload.tree ? payload.path : std::filesystem::path{})) {
                                    throw std::runtime_error("Already processing files.");
                                }
                                obj_profile::mark("model_add_requested");
                                automationAppend = AutomationAppendRuntime{command->id, ui.files.size(), {}, false};
                                return;
                            } else if (payload.action == A::modelRemove) {
                                const auto found = std::find_if(ui.files.begin(), ui.files.end(), [&](const auto& file) { return file.objectId == payload.objectId; });
                                if (found == ui.files.end()) { throw std::invalid_argument("model.remove requires a file ID."); }
                                removeModelFile(ui, runtimes, static_cast<size_t>(found - ui.files.begin()), annotationPreparation);
                                woby::updateSceneDirty(ui, cleanSceneDocument);
                                result = {{"removed", payload.target}, {"dirty", ui.isDirty}};
                            } else if (payload.action == A::importersList || payload.action == A::importersAdd
                                || payload.action == A::importersScan || payload.action == A::importersForget) {
                                result = woby::applyControlImporterOperation(payload, importerSettingsPath, rememberedImporters);
                            } else if (payload.action == A::performanceBegin) {
                                if (frameCapture.active) { throw std::invalid_argument("A performance capture is already active."); }
                                captureScene = measurementScene();
                                woby::beginFrameCapture(frameCapture, frameIndex, woby::PerformanceClock::now());
                                result = {{"capacity", woby::maxCapturedFrames}, {"afterFrame", frameIndex}};
                            } else if (payload.action == A::performanceEnd) {
                                woby::endFrameCapture(frameCapture);
                                result = {{"capacity", woby::maxCapturedFrames}, {"droppedFrames", frameCapture.droppedFrames},
                                    {"sceneBefore", captureScene},
                                    {"sceneAfter", measurementScene()},
                                    {"environments", Json::array()}, {"events", Json::array()}};
                                const woby::FrameEnvironment* previous = nullptr;
                                for (const auto& event : frameCapture.events) {
                                    if (!previous || *previous != event.environment) {
                                        result["environments"].push_back(frameEnvironmentInfo(event.environment));
                                        previous = &event.environment;
                                    }
                                    auto row = frameTimingInfo(event.timing);
                                    row["environment"] = result["environments"].size() - 1;
                                    row["completedMilliseconds"] = event.completedMilliseconds;
                                    row["camera"] = event.camera;
                                    row["points"] = {{"active",event.pointRendererActive},{"navigation",event.pointNavigation},
                                        {"sourceCount",event.pointSourceCount},{"refinedCount",event.pointRefinedCount},
                                        {"submittedCount",event.pointSubmittedCount},{"gpuRasterCount",event.pointRasterCount},
                                        {"gpuRasterMilliseconds",event.pointRasterMilliseconds},{"gpuRasterBudgeted",event.pointRasterBudgeted}};
                                    result["events"].push_back(std::move(row));
                                }
                            } else if (payload.action == A::performance) {
                                result = frameTimingInfo(lastFrameTimings);
                                if (!headless) { result.update(frameEnvironmentInfo(lastFrameEnvironment)); }
                                else { result["drawable"] = nullptr; result["viewport"] = nullptr; }
                                result["fps"] = fps;
                                result["points"] = {{"active", adaptivePoints.active}, {"adaptive", ui.adaptivePoints},
                                    {"sourceCount", adaptivePoints.total}, {"refinedCount", adaptivePoints.refined},
                                    {"submittedCount", adaptivePoints.submitted}, {"budget", adaptivePoints.budget},
                                    {"rasterMilliseconds", woby::graphics::getStats()->pointRasterMs}, {"fallback", adaptivePoints.error}};
                                result["headless"] = headless;
                                result["renderer"] = woby::graphics::getRendererName(woby::graphics::getRendererType());
                                result["sdlVersion"] = SDL_GetVersion();
                                result["version"] = WOBY_VERSION;
                                result["buildConfiguration"] = WOBY_BUILD_CONFIG;
                                result["requestedWindow"] = commandLine.windowSize ? Json(*commandLine.windowSize) : Json(nullptr);
                                result["requestedDrawable"] = commandLine.drawableSize ? Json(*commandLine.drawableSize) : Json(nullptr);
                                result["fixedSize"] = commandLine.windowSize.has_value() || commandLine.drawableSize.has_value();
                            } else {
                                result = woby::applyControlSceneOperation(ui, cleanSceneDocument, payload, formatObjectId, minViewerPaneWidth, maxViewerPaneWidth);
                                if (payload.action == A::sceneInfo) { result["path"] = currentScenePath ? Json(woby::pathToUtf8(*currentScenePath)) : Json(nullptr); }
                                if (payload.action == A::stats) { result["renderer"] = woby::graphics::getRendererName(woby::graphics::getRendererType()); result["fps"] = fps; }
                            }
                            woby::completeAutomationCommand(*automation, command->id, woby::AutomationControlResult{std::move(result)});
                        } else if constexpr (std::is_same_v<Command, woby::SceneLifecycleCommand>) {
                            const bool busy = backgroundLoad.active || gpuFinalize.active || historyRestore.active
                                || (automationAppend && automationAppend->postLoadPending) || automationOpenPostLoad
                                || sceneScreenshot.captureRequested || sceneScreenshot.readbackPending
                                || modalDialogOpen || modelFileDialogIsOpen(modelFileDialogState)
                                || sceneFileDialogIsOpen(sceneFileDialogState)
                                || sceneScreenshotDialogIsOpen(sceneScreenshotDialogState);
                            // Lifecycle operations use the last committed scene and cancel pending geometry.
                            woby::cancelAnnotationPointer(annotationInteraction);
                            if (annotationCommand) { woby::cancelAnnotationWork(annotationCommand->work); }
                            woby::updateSceneDirty(ui, cleanSceneDocument);
                            const bool savesScene = payload.action == woby::SceneAction::save || payload.action == woby::SceneAction::saveAs
                                || (ui.isDirty && payload.onDirty == woby::DirtyPolicy::save);
                            if (const auto error = woby::beginSceneLifecycle(payload, ui, currentScenePath, cleanSceneDocument, busy)) {
                                completeLifecycleError(command->id, *error);
                                return;
                            }
                            if (savesScene && currentScenePath) {
                                woby::rememberRecentFile(recentFiles, woby::RecentFileKind::scene, *currentScenePath);
                            }
                            if (payload.action == woby::SceneAction::open) {
                                if (!startOpenSceneBackgroundLoad(backgroundLoad, payload.path)) {
                                    completeLifecycleError(command->id, {"scene_busy", "Already processing files.", -32014});
                                } else {
                                    automationOpenCommandId = command->id;
                                }
                                return;
                            }
                            if (payload.action == woby::SceneAction::newScene) {
                                resetSceneToUntitled(ui, runtimes, currentScenePath, cleanSceneDocument, annotationPreparation);
                            }
                            const bool quit = payload.action == woby::SceneAction::quit;
                            woby::completeAutomationCommand(*automation, command->id,
                                woby::AutomationSceneResult{currentScenePath, ui.isDirty, quit});
                            if (quit) { woby::requestQuit(ui); }
                        } else {
                            static_assert(std::is_same_v<Command, woby::AutomationObjectCommand>);
                            const auto object = woby::findSceneObject(ui, payload.objectId);
                            if (object) {
                                woby::completeAutomationCommand(*automation, command->id,
                                    woby::AutomationObjectResult{*object, woby::controlObjectDetails(ui, payload.objectId, formatObjectId)});
                            } else {
                                woby::completeAutomationCommand(*automation, command->id,
                                    woby::AutomationCommandError{"Unknown or stale object ID.", -32005});
                            }
                        }
                    }, command->payload);
                } catch (const std::invalid_argument& exception) {
                    woby::completeAutomationCommand(*automation, command->id, woby::AutomationCommandError{exception.what(), -32602});
                } catch (const std::exception& exception) {
                    const auto* lifecycle = std::get_if<woby::SceneLifecycleCommand>(&command->payload);
                    if (lifecycle && lifecycle->action == woby::SceneAction::open) {
                        completeLifecycleError(command->id, {"open_failed", exception.what(), -32016});
                    } else {
                        woby::completeAutomationCommand(*automation, command->id, woby::AutomationCommandError{exception.what()});
                    }
                }
                if (beforeCommandRevision != ui.sceneEditRevision
                    || beforeCommandGeneration != ui.sceneGeneration) {
                    woby::finishSceneHistoryInteraction(sceneHistory);
                    woby::recordSceneHistory(sceneHistory, ui);
                }
                if (const auto* lifecycle = std::get_if<woby::SceneLifecycleCommand>(&command->payload);
                    lifecycle && (lifecycle->action == woby::SceneAction::save
                        || lifecycle->action == woby::SceneAction::saveAs)) {
                    woby::finishSceneHistoryInteraction(sceneHistory);
                }
            }
            recordFrameStage(frameTimings, woby::FrameStage::sceneState, stageStart);

            if (!headless) {
                // Global document commands still work when the scene controls are hidden.
                // Run after widgets have applied edits so Save includes this frame's changes.
                const auto historyShortcut = woby::sceneHistoryShortcut(fileActionsDisabled()
                    || sceneScreenshot.captureRequested || sceneScreenshot.readbackPending
                    || (SDL_GetWindowFlags(window.get()) & SDL_WINDOW_INPUT_FOCUS) == 0u);
                if (historyShortcut != woby::SceneHistoryCommand::none) { historyCommand = historyShortcut; }
                if (historyCommand != woby::SceneHistoryCommand::none && !fileActionsDisabled()
                    && !sceneScreenshot.captureRequested && !sceneScreenshot.readbackPending) {
                    try {
                        (void)runSceneHistory(historyCommand == woby::SceneHistoryCommand::redo);
                    } catch (const std::exception&) {
                        // The shared adapter already consumed the action and displayed the error.
                    }
                }
                if (!fileActionsDisabled() && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopup)) {
                    if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_O, ImGuiInputFlags_RouteGlobal)) {
                        documentCommand(woby::SceneAction::open);
                        documentShortcutHeld = true;
                    } else if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiMod_Shift | ImGuiKey_S, ImGuiInputFlags_RouteGlobal)) {
                        documentCommand(woby::SceneAction::saveAs);
                        documentShortcutHeld = true;
                    } else if (ImGui::Shortcut(ImGuiMod_Ctrl | ImGuiKey_S, ImGuiInputFlags_RouteGlobal)) {
                        documentCommand(woby::SceneAction::save);
                        documentShortcutHeld = true;
                    }
                }
                if (!ImGui::IsKeyDown(ImGuiKey_S) && !ImGui::IsKeyDown(ImGuiKey_O)) {
                    documentShortcutHeld = false;
                }
                // Read keyboard input after widgets have claimed it, before drawing the scene.
                woby::dismissPopupOnEscape();
                const auto& keyboardIo = ImGui::GetIO();
                const bool sceneKeyboardAvailable = !fileActionsDisabled() && !documentShortcutHeld
                    && (SDL_GetWindowFlags(window.get()) & SDL_WINDOW_INPUT_FOCUS) != 0u
                    && !keyboardIo.WantCaptureKeyboard && !keyboardIo.WantTextInput
                    && !ImGui::IsAnyItemActive()
                    && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopup);
                if (sceneKeyboardAvailable && !annotationEscapeConsumed && !annotationInteraction.dragging && !annotationInteraction.tool && !annotationInteraction.sectionTool) {
                    if (!keyboardIo.KeyCtrl && !keyboardIo.KeyAlt && !keyboardIo.KeySuper) {
                        if (!popupWasOpen && ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
                            woby::clearSceneSelection(ui);
                        }
                        if (ImGui::IsKeyPressed(ImGuiKey_R, false)) {
                            woby::fitCameraToScene(ui);
                        }
                    }
                    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_B)) {
                        woby::toggleViewerPaneVisible(ui);
                    }
                    woby::updateCameraFromKeyboard(ui, deltaSeconds);
                }

            }

            woby::updateComparisonRuntimes(comparison, ui);

            for (size_t i = 0; i < std::min(files.size(), runtimes.size()); ++i) {
                try {
                    woby::updateGpuMeshFeatures(runtimes[i], files[i].mesh, woby::requestedGpuMeshFeatures(files[i]));
                } catch (const std::exception& error) {
                    setToastMessage(toast, std::string("Display buffer upload failed: ") + error.what());
                }
            }

            if (!headless) {
                const auto viewport = canvasLayout(window.get(), ui).viewport;
                const uint32_t sceneViewportWidth = viewport.width;
                const uint32_t sceneViewportHeight = viewport.height;
                woby::graphics::setViewRect(clearView, 0, 0, static_cast<uint16_t>(width), static_cast<uint16_t>(height));
                woby::graphics::touch(clearView);
                woby::graphics::setViewRect(
                    sceneView,
                    static_cast<uint16_t>(viewport.x),
                    static_cast<uint16_t>(viewport.y),
                    static_cast<uint16_t>(sceneViewportWidth),
                    static_cast<uint16_t>(sceneViewportHeight));
                woby::graphics::setViewRect(
                    helperView,
                    static_cast<uint16_t>(viewport.x),
                    static_cast<uint16_t>(viewport.y),
                    static_cast<uint16_t>(sceneViewportWidth),
                    static_cast<uint16_t>(sceneViewportHeight));
                woby::graphics::touch(sceneView);
                woby::graphics::touch(helperView);

                const bool homogeneousDepth = woby::graphics::getCaps()->homogeneousDepth;
                const auto currentPickView = woby::scenePickView(camera, ui.upAxis, sceneBounds,
                    sceneViewportWidth, sceneViewportHeight, homogeneousDepth,
                    static_cast<float>(width) / canvasLayout(window.get(), ui).width);
                const auto* view = currentPickView.view.data();
                presentedPickView = currentPickView;
                presentedViewport = viewport;
                woby::graphics::setViewTransform(sceneView, view, currentPickView.renderProjection.data(), true);
                woby::graphics::setViewTransform(helperView, view, currentPickView.renderProjection.data(), true);
                recordFrameStage(frameTimings, woby::FrameStage::viewSetup, stageStart);

                std::optional<HoveredVertex> hoveredVertex;
                const MousePosition windowMouse = mousePositionInPixels(window.get());
                const bool mouseInsideViewport = woby::contains(viewport, windowMouse.x, windowMouse.y);
                const MousePosition mouse{windowMouse.x - static_cast<float>(viewport.x), windowMouse.y - static_cast<float>(viewport.y)};
                const bool cameraInteractionActive = cameraInput.orbiting
                    || cameraInput.rolling
                    || cameraInput.panning;
                const bool nativeFileDialogOpen = modelFileDialogIsOpen(modelFileDialogState)
                    || sceneFileDialogIsOpen(sceneFileDialogState)
                    || sceneScreenshotDialogIsOpen(sceneScreenshotDialogState);
                const bool dialogOpen = modalDialogOpen
                    || nativeFileDialogOpen
                    || backgroundLoad.active
                    || gpuFinalize.active;
                scenePointerAvailable = !dialogOpen && !ImGui::IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopup)
                    && (SDL_GetWindowFlags(window.get()) & SDL_WINDOW_INPUT_FOCUS) != 0u;
                if (!scenePointerAvailable) {
                    scenePointer = {};
                    woby::setCameraOrbiting(ui, false);
                    woby::setCameraRolling(ui, false);
                    woby::setCameraPanning(ui, false);
                }
                const bool navigationPaused = woby::hoverNavigationPaused(hoverNavigation, camera, ui.upAxis,
                    cameraInput, std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count());
                const bool hoverPickingEnabled = mouseInsideViewport
                    && !ImGui::GetIO().WantCaptureMouse
                    && scenePointerAvailable
                    && !navigationPaused;
                const bool markersVisible = std::any_of(files.begin(), files.end(), [](const auto& file) {
                    return (woby::requestedGpuMeshFeatures(file) & woby::gpuMeshPoints) != 0;
                });
                bool gpuHover = false;
                try {
                    gpuHover = woby::beginGpuMarkerPicking(markerPicker, assets, ui, viewport, mouse,
                        hoverPickingEnabled && markersVisible, 4, woby::hoverSceneSignature(ui, runtimes) ^ woby::sceneComparisonRevision(ui, comparison));
                } catch (const std::exception& error) {
                    woby::destroyGpuMarkerPicker(markerPicker);
                    markerPicker.unavailable = true;
                    spdlog::warn("GPU hover picking unavailable: {}", error.what());
                }
                if (!hoverPickingEnabled || gpuHover) {
                    hoverPickCache.hoveredVertex.reset();
                    hoverPickCache.valid = false;
                } else {
                    const uint64_t hoverSignature = hoverPickSignature(hoverPickCache, ui, runtimes, mouse,
                        mouseInsideViewport, sceneViewportWidth, sceneViewportHeight, homogeneousDepth);
                    if (!hoverPickCache.valid || hoverPickCache.signature != hoverSignature) {
                        hoverPickCache.hoveredVertex.reset();
                        woby::resolveSceneParts(renderScratch.queries, ui, renderScratch.parts);
                        hoverPickCache.hoveredVertex = findHoveredVertex(ui, renderScratch.parts, runtimes, mouse, currentPickView);
                        hoverPickCache.signature = hoverSignature;
                        hoverPickCache.valid = true;
                    }
                }
                hoveredVertex = gpuHover ? markerPicker.coordinates : hoverPickCache.hoveredVertex;
                recordFrameStage(frameTimings, woby::FrameStage::hoverPick, stageStart);

                woby::updateSceneDrawPlan(renderScratch.drawCache, ui, &renderScratch.queries);
                woby::prepareAdaptivePoints(adaptivePoints, assets, currentPickView,
                    ui.adaptivePoints, std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(),
                    gpuHover, {mouse.x,mouse.y});
                woby::graphics::setViewMode(sceneView, woby::graphics::ViewMode::Sequential);
                {
                    submitSceneFiles(
                        sceneView,
                        renderScratch.drawCache.plan,
                        runtimes,
                        gpuHover ? markerPicker.mesh : meshProgram,
                        gpuHover ? markerPicker.line : colorProgram,
                        gpuHover ? markerPicker.point : pointSpriteProgram,
                        triangleEdgePrograms,
                        sceneViewportWidth,
                        sceneViewportHeight,
                        gpuHover ? &markerPicker.context : nullptr, false, &adaptivePoints, &transparentSurfacePrograms);
                }
                woby::submitComparisonScenes(sceneView, ui, comparison,
                    gpuHover ? markerPicker.line : colorProgram, renderScratch,
                    gpuHover ? markerPicker.comparison : woby::graphics::ProgramHandle{woby::graphics::kInvalidHandle});
                submitSceneFiles(sceneView, renderScratch.drawCache.plan, runtimes,
                    meshProgram, gpuHover ? markerPicker.lineSprite : lineSpriteProgram,
                    gpuHover ? markerPicker.point : pointSpriteProgram,
                    triangleEdgePrograms, sceneViewportWidth, sceneViewportHeight, gpuHover ? &markerPicker.context : nullptr, true);
                woby::submitGpuMarkerPicking(markerPicker, viewport);
                recordFrameStage(frameTimings, woby::FrameStage::submitScene, stageStart);

                submitSceneHelpers(helperView, ui, helperLayout, colorProgram);
                woby::prepareSceneAnnotations(ui, currentPickView, renderScratch, &annotationInteraction);
                woby::submitSceneAnnotations(helperView, ui, helperLayout, annotationProgram, renderScratch, &annotationInteraction);
                const float annotationMessageBottom = woby::drawAnnotationOverlay(ui, annotationInteraction, currentPickView,
                    static_cast<float>(viewport.x) / currentPickView.pixelScale, 1.0f / currentPickView.pixelScale,
                    scenePointerAvailable && !cameraInteractionActive
                        && (!woby::selectedAnnotation(ui) || woby::annotationPreparationReady(ui)),
                    static_cast<float>(viewport.y) / currentPickView.pixelScale);
                if (!ui.selectedSceneObjects.empty()) {
                    auto& selectedParts = renderScratch.parts;
                    woby::resolveSceneParts(renderScratch.queries, ui, selectedParts);
                    woby::appendVisibleComparisonPickParts(selectedParts, ui, comparison);
                    woby::submitSceneSelection(helperView, selectedParts, ui, helperLayout, colorProgram, renderScratch);
                    if (ui.showDimensions) {
                        woby::updateSceneSelectionQueries(renderScratch.queries, ui, &comparison);
                    }
                }
                if (ui.showGrid || ui.showDimensions) {
                    const float pixelScale = 1.0f / currentPickView.pixelScale;
                    woby::drawSceneScaleOverlay(*ImGui::GetBackgroundDrawList(), ui,
                        ui.selectedSceneObjects.empty() ? std::nullopt : renderScratch.queries.selection.dimensions,
                        currentPickView, {static_cast<float>(viewport.x) * pixelScale, static_cast<float>(viewport.y) * pixelScale}, pixelScale, ImGui::GetFontSize());
                }
                const auto postMessage = woby::postLoadNotice(postLoading, ui, postLoadNow);
                if (postMessage.empty()) {
                    drawToastMessage(toast, viewport, width, std::max(annotationMessageBottom, static_cast<float>(viewport.y) / currentPickView.pixelScale));
                } else {
                    ToastMessage statusToast{std::string(postMessage), std::chrono::steady_clock::now()};
                    drawToastMessage(statusToast, viewport, width, static_cast<float>(viewport.y) / currentPickView.pixelScale);
                }
                drawHoveredVertexOverlay(hoveredVertex, viewport, width, gpuHover);
                if (adaptivePoints.active) {
                    const auto label = adaptivePoints.refined == adaptivePoints.total ? std::string("Points: full detail")
                        : adaptivePoints.now-adaptivePoints.lastChange < .15 ? std::string("Points: adaptive navigation")
                        : "Points: refining " + std::to_string(adaptivePoints.total ? adaptivePoints.refined*100/adaptivePoints.total : 100) + "%";
                    const float scale=currentPickView.pixelScale;
                    ImGui::GetForegroundDrawList()->AddText({(float(viewport.x)+12)/scale,(float(viewport.y+viewport.height)-26)/scale},
                        IM_COL32(215,225,235,255),label.c_str());
                }
                recordFrameStage(frameTimings, woby::FrameStage::submitHelpers, stageStart);

            }

            const bool homogeneousDepth = woby::graphics::getCaps()->homogeneousDepth;
            try {
                submitSceneScreenshotCapture(
                    sceneScreenshot,
                    runtimes,
                    meshProgram,
                    colorProgram,
                    annotationProgram,
                    lineSpriteProgram,
                    pointSpriteProgram,
                    triangleEdgePrograms,
                    ui,
                    helperLayout,
                    sceneBounds,
                    camera,
                    homogeneousDepth,
                    &comparison, &transparentSurfacePrograms);
            } catch (const std::exception& exception) {
                failSceneScreenshotCapture(sceneScreenshot);
                if (automationScreenshotCommandId) {
                    woby::completeAutomationCommand(*automation, *automationScreenshotCommandId,
                        woby::AutomationCommandError{exception.what()});
                    automationScreenshotCommandId.reset();
                }
                setToastMessage(toast, std::string("Save screenshot failed: ") + exception.what());
            }

            if (headless) {
                ImGui::EndFrame();
            } else {
                ImGui::Render();
                woby::imgui_graphics::render(ImGui::GetDrawData());
            }
            recordFrameStage(frameTimings, woby::FrameStage::imguiRender, stageStart);

            const uint32_t frameNumber = woby::graphics::frame();
            woby::notePostLoadFrame(postLoading, ui, woby::graphics::submittedFrameToken());
            if (!ui.files.empty() && !measuredFirstFrame) {
                measuredFirstFrame = woby::graphics::submittedFrameToken();
                obj_profile::mark("first_scene_frame_submitted", {{"frame_token", measuredFirstFrame}, {"frame_index", frameIndex}});
            }
            woby::pollGpuMarkerPicking(markerPicker, frameNumber, ui, runtimes,
                woby::hoverSceneSignature(ui, runtimes) ^ woby::sceneComparisonRevision(ui, comparison));
            try {
                const std::optional<std::string> screenshotStatus = completeSceneScreenshotReadback(
                    sceneScreenshot,
                    frameNumber);
                if (screenshotStatus.has_value()) {
                    setToastMessage(toast, screenshotStatus.value());
                    if (automationScreenshotCommandId) {
                        woby::completeAutomationCommand(*automation, *automationScreenshotCommandId,
                            woby::AutomationScreenshotResult{sceneScreenshot.outputPath});
                        automationScreenshotCommandId.reset();
                    }
                }
            } catch (const std::exception& exception) {
                sceneScreenshot.readbackPending = false;
                if (automationScreenshotCommandId) {
                    woby::completeAutomationCommand(*automation, *automationScreenshotCommandId,
                        woby::AutomationCommandError{exception.what()});
                    automationScreenshotCommandId.reset();
                }
                setToastMessage(toast, std::string("Save screenshot failed: ") + exception.what());
            }
            recordFrameStage(frameTimings, woby::FrameStage::graphicsFrame, stageStart);
            frameTimings.totalMilliseconds = woby::millisecondsBetween(frameStart, woby::PerformanceClock::now());
            copyGraphicsStats(frameTimings);
            lastFrameTimings = frameTimings;
            if (!headless) { lastFrameEnvironment = frameEnvironment(window.get(), ui, presentedViewport); }
            if (frameCapture.active) {
                const auto& view = ui.camera;
                woby::captureFrame(frameCapture, {frameTimings, lastFrameEnvironment,
                    {view.target[0], view.target[1], view.target[2], view.yawRadians, view.pitchRadians, view.rollRadians,
                        view.distance, view.verticalFovDegrees, view.nearPlane},
                    woby::millisecondsBetween(frameCapture.start, woby::PerformanceClock::now()),
                    adaptivePoints.total, adaptivePoints.refined, adaptivePoints.submitted, adaptivePoints.active,
                    adaptivePoints.active && adaptivePoints.adaptive && adaptivePoints.now-adaptivePoints.lastChange < .15,
                    woby::graphics::getStats()->pointRasterCount, woby::graphics::getStats()->pointRasterMs,
                    woby::graphics::getStats()->pointRasterBudgeted});
            }
            if (commandLine.logPerformance) {
                woby::accumulateFrameTiming(frameTimingAccumulator, frameTimings);
                if (commandLine.logSlowFrameMilliseconds.has_value()) {
                    woby::logSlowFrame(frameTimings, commandLine.logSlowFrameMilliseconds.value());
                }
                if (frameTimingAccumulator.frameCount >= commandLine.logFrameInterval) {
                    woby::logFrameSummary(frameTimingAccumulator);
                    woby::resetFrameTimingAccumulator(frameTimingAccumulator);
                }
            }
            if (headless && running && !gpuFinalize.active && !sceneScreenshot.readbackPending) {
                // Wake promptly for commands; poll CPU workers without spinning at idle.
                // GPU readback must keep advancing frames until its completion frame.
                const bool processing = backgroundLoad.active || gpuFinalize.active || historyRestore.active || postLoading.noticePending || automationComparison.has_value()
                    || annotationCommand.has_value() || sceneScreenshot.captureRequested;
                woby::waitForAutomationWork(*automation, std::chrono::milliseconds(processing ? 10 : 50));
            }
        }

        updateRuntime.worker.request_stop();
        woby::finishRecentFiles(recentFiles);
        if (const auto warning = woby::pollRecentFiles(recentFiles); !warning.empty()) { spdlog::warn("{}", warning); }
        if (updateRuntime.worker.joinable()) { updateRuntime.worker.join(); }
        automation.reset();
        automationComparison.reset();
        woby::stopAnalysisExport(analysisExport);
        backgroundLoad.cancelRequested.store(true);
        if (backgroundLoad.worker.joinable()) {
            backgroundLoad.worker.join();
        }
        woby::cancelSceneHistoryRestore(historyRestore);
        woby::cancelPostLoading(postLoading);
        woby::cancelAnnotationPreparation(annotationPreparation);
        abortGpuFinalize(gpuFinalize);
        woby::unloadImporters();

        woby::imgui_graphics::shutdown();
        if (!headless) { ImGui_ImplSDL3_Shutdown(); }
        ImGui::DestroyContext();

        woby::destroyGpuMarkerPicker(markerPicker);
        woby::destroyAdaptivePoints(adaptivePoints);
        woby::destroyComparisonRuntimes(comparison);
        woby::graphics::destroy(pointSpriteProgram);
        woby::graphics::destroy(colorProgram);
        woby::graphics::destroy(annotationProgram);
        woby::graphics::destroy(lineSpriteProgram);
        woby::graphics::destroy(presentationProgram);
        woby::graphics::destroy(meshProgram);
        woby::destroyTriangleEdgePrograms(triangleEdgePrograms);
        woby::destroyTransparentSurfacePrograms(transparentSurfacePrograms);
        destroySceneScreenshotFramebuffer(sceneScreenshot);
        destroyModelRuntimes(runtimes);
        woby::graphics::shutdown();
        graphicsInitialized = false;
        window.reset();
        SDL_Quit();
        sdlInitialized = false;
        spdlog::shutdown();

        return 0;
    } catch (const std::exception& exception) {
        const char* message = dynamic_cast<const std::bad_alloc*>(&exception)
            ? "Insufficient CPU memory. Woby could not continue." : exception.what();
        // Report before cleanup, using static storage even if all allocations fail.
        std::fprintf(stderr, "%s\n", message);
        automation.reset();
        woby::unloadImporters();
        if (!headlessLaunchRequested && !woby::hasStandardError()) {
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Woby could not continue", message, nullptr);
        }
        if (graphicsInitialized) {
            woby::graphics::shutdown();
        }
        if (sdlInitialized) {
            SDL_Quit();
        }
        spdlog::shutdown();
        return 1;
    }
}
